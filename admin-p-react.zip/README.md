# BitBucket Pipeline for Taplingua React Dashboard PROD (dashboard2) #

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for?  ###

React Web https://dashboard2.taplingua.com/

* Folder: "/var/www/subdomains/dashboard2"   (WP Test server)
