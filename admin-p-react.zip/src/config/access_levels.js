const accessLevels = {
    CONSUMER: 0,
    ADMIN: 1,
    COMPANY: 3,
    AUDITOR: 4
}

export default accessLevels;