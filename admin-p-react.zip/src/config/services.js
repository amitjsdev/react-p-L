export const google = {
    clientId: '255632787494-9b7flcotkt486apprn0r11ha85bclvd5.apps.googleusercontent.com'
}

export const facebook = {
    appId: '1221319641380163'
}