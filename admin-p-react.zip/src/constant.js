export const up_looking = 0.1;
export const away_looking = 0.1;
export const multi_user = 0.45;
export const zero_candidate = 0.35;
export const CDN_URL = "https://cdnnew2.taplingua.com";



