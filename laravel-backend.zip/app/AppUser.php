<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppUser extends Model
{
    protected $table = 'userLogin';

    protected $guarded = [];

    const CREATED_AT = 'submittedAt';
    const UPDATED_AT = 'updatedAt';
    

    public function tokens() {
        return $this->hasMany(AppUserToken::class, 'user_email', 'email');
    }
}
