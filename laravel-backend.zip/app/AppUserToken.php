<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppUserToken extends Model
{
    protected $table = 'userlogin_token';
    protected $guarded = [];
}
