<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppVersion extends Model
{
    protected $table = 'appversion';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'OS', 'minimumBuildVersion', 'minimumAppVersion', 'recommendedBuildVersion', 'recommendedAppVersion', 'minimumUpdatesMessage', 'recommendedUpdatesMessage', 'adddate', 'status'
    ];
}
