<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AttemptTimer extends Model
{
    protected $fillable = [
        'quizSetId', 'time', 'userId','aiTimer'
    ];
}
