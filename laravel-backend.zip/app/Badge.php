<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Badge extends Model
{
    protected $fillable = [
        'name',
        'code',
        'category',
        'identifier',
        'description',
        'internal_description',
        'status',
    ];
}
