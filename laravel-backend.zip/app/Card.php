<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Card extends Model
{
    protected $table = 'cards';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'moduleNo', 'routeNo', 'lesssonNo', 'translatedText', 'originalText', 'addDate'
    ];
}
