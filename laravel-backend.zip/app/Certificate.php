<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Certificate extends Model
{
    protected $fillable = [
        'certificateId',
        'userId',
        'courseNumber',
        'level_number',
        'courseName',
        'name',
        'instructor',
        'date',
        'interviewSimulator'
    ];

    public function url()
    {
        return url('/certificate/' . $this->certificateId);
    }

    public function rawUrl()
    {
        return url('/certificate/issued/' . $this->certificateId);
    }
}
