<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cohort extends Model
{
    protected $fillable = [
        "company_code",
        "name",
        "notification_on",
        "program_id",
        "is_dynamic",
        "start_date",
        "type_id",
        "instructorEmails",
        "exam_end_time",
        "exam_start_time",
        "allotted_time",
        "adaptiveShuffle",
        "senderEmail",
        "profile_questionnaire",
        "vpi_value",
        "archived",
    ];

    /**
     * Get company this cohort is for
     *
     * @return void
     */
    public function company()
    {
        return $this->belongsTo(Company::class, "company_code", "Id");
    }
    public function quizSet()
    {
        return $this->hasMany(QuizSet::class);
    }

    /**
     * Get program this cohort is for
     *
     * @return void
     */
    public function program()
    {
        return $this->belongsTo(Program::class);
    }

    /**
     * Get course for this cohort using its module number
     *
     * @param [type] $module_number
     * @return void
     */
    public function getCourseByModuleNo($module_number) {
        return Course::where('cohort_id', $this->id)->where('moduleNumber', $module_number)->first();
    }
}
