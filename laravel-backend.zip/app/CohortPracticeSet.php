<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CohortPracticeSet extends Model
{
    protected $fillable = [
        'cohortId',
        'practiceSetId'
    ];

    public function practiceSet()
    {
        return $this->hasOne(PracticeSet::class, "practiceSetId", "practiceSetId");
    }
    public function cohort()
    {
        return $this->hasOne(Cohort::class, "id","cohortId");
    }
}
