<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CohortType extends Model
{
    protected $fillable = [
        "type",
    ];
}
