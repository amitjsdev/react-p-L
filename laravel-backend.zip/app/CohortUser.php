<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CohortUser extends Model
{
    protected $fillable = [
        'program_id',
        'userId',
    ];
}
