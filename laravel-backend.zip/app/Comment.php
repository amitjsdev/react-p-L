<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Comment extends Model
{
    use SoftDeletes;

    public function employee() {
        return $this->belongsTo(\App\Employee::class, 'userId', 'userId');
    }

    public function upvotes() {
        return $this->hasMany(\App\CommentUpvote::class);
    }

    public function commentOn() {
        return $this->morphTo('commentable');
    }

    public function comments() {
        return $this->morphMany(\App\Comment::class, "commentable")->oldest();
    }
}
