<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class CommentUpvote extends Model
{
    use SoftDeletes;

    protected $fillable = [
        "comment_id",
        "userId"
    ];

    public function comment()
    {
        $this->belongsTo(\App\Comment::class);
    }
}
