<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CommentView extends Model
{
    //
}
