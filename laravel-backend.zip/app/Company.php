<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Company extends Model
{
    //

    protected $table = 'company';
    protected $primaryKey = 'i_d';
    public $timestamps = false;
    protected $fillable = [
        'Id', 'Name', 'Email', 'Username', 'Password', 'AccessCode', 'Mobile', 'Modules', 'Description', 'LongDescription', 'Status', 'unmanagedStatus', 'PracticeSets'
    ];

    protected $hidden = [
        'Password'
    ];

}
