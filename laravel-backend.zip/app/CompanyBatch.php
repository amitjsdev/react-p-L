<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CompanyBatch extends Model
{
    protected $table = 'companybatch';
    protected $primaryKey = 'i_d';
    public $timestamps = false;
    protected $fillable = [
        'Id', 'acceptEvaluation', 'batchArchived', 'batchComplete', 'batchDuration', 'batchNumber', 'companyCode', 'startDate', 'endDate', 'issueDate'
    ];
}
