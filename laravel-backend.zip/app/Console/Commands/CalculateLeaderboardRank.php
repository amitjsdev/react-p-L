<?php

namespace App\Console\Commands;

use App\Company;
use App\Employee;
use App\Http\Controllers\LeaderBoardController;
use App\LeaderboardRank;
use App\UserDailyGoalLog;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class CalculateLeaderboardRank extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'taplingua:calculateleaderboardrank';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command to calculate leaderboard rank!';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        // for each company calculate ranks
        foreach(Company::all() as $company) {

            // get users by cutoff
            // get users by cutoff 01 August 2020
            // update today ranks
            $this->updateRankByDateRange(today()->startOfDay(), today()->endOfDay(), 'daily', $company->Id);

            $this->line("Updated daily ranks for company code " . $company->Id);


            // check if saturday for current week has passed
            if (now()->dayOfWeek >= 6) {
                // today is saturday or more
                $startOfWeek = today()->addDays(6 - now()->dayOfWeek)->startOfDay();
                $endOfWeek = today()->addWeek()->addDays(5 - now()->dayOfWeek)->endOfDay();
            } else {
                // saturday yet to come
                $startOfWeek = today()->subWeek()->addDays(6 - now()->dayOfWeek)->startOfDay();
                $endOfWeek = today()->addDays(5 - now()->dayOfWeek)->endOfDay();
            }

            // update weekly ranks
            $this->updateRankByDateRange($startOfWeek, $endOfWeek, 'weekly', $company->Id);

            $this->line("Updated weekly ranks for company code " . $company->Id);
        }
    }

    private function updateRankByDateRange($startDate, $endDate, $type, $companyCode = 0)
    {
        // get all users for that company
        $userIds = Employee::where('CompanyCode', $companyCode)->whereNotIn('userId', LeaderBoardController::emailExceptions)->pluck('userId')->toArray();

        // get all the ones on leaderboard
        $ranks = UserDailyGoalLog::select('userId', DB::raw('sum(points) as current'))
            ->whereIn('userId', $userIds)
            ->whereBetween('dated', [$startDate, $endDate])
            ->groupBy('userId')
            ->orderBy('current', 'desc')
            ->get();
        // pluck the winners, they are sorted by rank already
        $winners = $ranks->pluck('userId')->toArray();
        // add the rest of employees, they are all leftovers
        // $remainingEmployees = Employee::whereNotIn('userId', $winners)
        //     ->whereDate('accountCreationDate', '>=', new Carbon('2020-08-15'))
        //     ->pluck('userId')->toArray();
        $remainingEmployees = [];

        // map it to hold rank
        $timestamp = now();
        $ranks = array_merge($winners, $remainingEmployees);
        
        foreach($ranks as $key => $item) {
            // foreach rank, check if already exists
            $previousRank = LeaderboardRank::where('userId', $item)->where('type', $type)->where('companyCode', $companyCode)->first();
            $newRank = $key + 1;
            if($previousRank) {
                // if previous rank exists, calculate the delta
                $newDelta = $previousRank->rank - $newRank;
                // if the rank has changed, update the delta
                if($previousRank->rank !== $newRank) {
                    $previousRank->delta = $newDelta;
                }
            } else {
                $previousRank = new LeaderboardRank([
                    'userId' => $item,
                    'companyCode' => $companyCode,
                    'type' => $type,
                    'delta' => 0,
                ]);
            }
            // set new rank
            $previousRank->rank = $newRank;
            $previousRank->save();
        }

        return true;
    }
}
