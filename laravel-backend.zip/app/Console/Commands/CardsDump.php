<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use DB;
use Illuminate\Support\Facades\Storage;

class CardsDump extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'CardsDump:cron';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        
        $this->info("CardsDump is started fine!");

        
        $q = "select moduleno, routeno, lesson_no, media_alt2, summary_translation, summary_new_format from `exercise` where id!='' order by id ";


        $assessment = array(); 
           
        $query = DB::select(DB::raw($q)); 
        
        
        foreach($query as $row){

            $summary_translation = explode("\n", $row->summary_translation);
            $summary_translation = str_replace("\r", "", $summary_translation);


            $assessment[] = array("module_no" => $row->moduleno, 
                                  "route_no" => $row->routeno, 
                                  "lesson_no" => $row->lesson_no, 
                                  "level_no" => (string)ceil($row->lesson_no/3), 
                                  "lesson_summary" => $row->media_alt2, 
                                  "summary_translation" => $summary_translation, 
                                  "summary_new_format" => $row->summary_new_format
                                 );


            
            foreach ($summary_translation as $value) {  
                
                $text = explode(";", $value);

                if(is_array($text))
                {

                $original = trim($text[0]);
                
                if( isset($text[1]) )
                 $translated = trim($text[1]);
                else
                 $translated = ""; 

                if($original!="" && $translated!="")
                {

                    $cards = "INSERT INTO `cards` (`id`, `moduleNo`, `routeNo`, `lesssonNo`, `translatedText`, `originalText`, `addDate`) VALUES (NULL, '".$row->moduleno."', '".$row->routeno."', '".$row->lesson_no."', '".addslashes($translated)."', '".addslashes($original)."', now())";

                    DB::select(DB::raw($cards)); 

                    $this->info('Card dumped successfully!');

                } 

                
                }
                
                

            }    

                     


        }   

        

        echo "\r\nDone....";
      
        $this->info('CardsDump Cummand Run successfully!');

    }
}
