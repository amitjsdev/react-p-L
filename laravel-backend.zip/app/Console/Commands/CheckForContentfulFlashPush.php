<?php

namespace App\Console\Commands;

use App\Employee;
use App\Jobs\SendContentfulFlashPush;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Cache;

class CheckForContentfulFlashPush extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'taplingua:checkforcontentfulflashpush {userId?} {--force}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'This command check if conditional flash push is needed to be sent to all employee, if so, it does that.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        // get userid if available 
        $userId = $this->argument('userId');
        $shouldBeForced = $this->option('force'); // clear the cache first
        // contentful flash push will be sent only two times a day as of now
        // Get all Users
        $employees = $userId
            ? Employee::where('userId', $userId)->get()
            : Employee::whereDate('accountCreationDate', '>=', Carbon::createFromDate(2020, 8, 1))->get();
            // add getTestPushUsers() to filter out users

        // for each user
        foreach ($employees as $employee) {
            //check if the push-cache-key is in cache ? (if job is created it is there)
            if (!checkIfJobDispatched($employee->userId, SendContentfulFlashPush::CONTENTFULFLASHPUSH_ONE) || $shouldBeForced) {
                // we need to send it
                SendContentfulFlashPush::dispatch($employee, SendContentfulFlashPush::CONTENTFULFLASHPUSH_ONE)
                    ->delay(Carbon::createFromTimeString('17:00', $employee->timezone));
                markJobDispatched($employee->userId, SendContentfulFlashPush::CONTENTFULFLASHPUSH_ONE, "push_job");
                $this->line("Dispatching contentful flash push one for {$employee->userId}!");
            } else {
                $this->line("Already dispatched contentful flash push one for {$employee->userId}!");
            }
            //check if need to send the push two
            if (!checkIfJobDispatched($employee->userId, SendContentfulFlashPush::CONTENTFULFLASHPUSH_TWO) || $shouldBeForced) {
                // we need to send it
                SendContentfulFlashPush::dispatch($employee, SendContentfulFlashPush::CONTENTFULFLASHPUSH_TWO)
                    ->delay(Carbon::createFromTimeString('08:00', $employee->timezone));
                markJobDispatched($employee->userId, SendContentfulFlashPush::CONTENTFULFLASHPUSH_TWO, "push_job");
                $this->line("Dispatching contentful flash push two for {$employee->userId}!");
            } else {
                $this->line("Already dispatched contentful flash push two for {$employee->userId}!");
            }
        }
        return 0;
    }
}
