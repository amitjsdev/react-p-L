<?php

namespace App\Console\Commands;

use App\Course;
use App\Employee;
use App\Jobs\SendContentfulPush;
use App\PushLog;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class CheckForContentfulPush extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'taplingua:checkforcontentfulpush {userId?} {--test}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'This command check if conditional push is needed to be sent to all employee, if so, it does that.
                                {userId: Email of the user as in employee Table}
                                {--test: Send a immediate push as well}
                                ';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        
        if($userId = $this->argument('userId')) {
            $employees = Employee::where('userId', $userId)->get();
        } else {
            $employees = Employee::whereDate('accountCreationDate', '>=', Carbon::createFromDate(2020, 8, 1))->get();
            // add getTestPushUsers() to filter out users
        }
        

        foreach ($employees as $employee) {
            $this->checkFor($employee);
        }

        $this->line("All contentful push checks complete!");

        return 0;
    }

    /**
     * Check for Certail employee if the push has to be sent.
     *
     * @param Employee $employee
     * @return void
     */
    private function checkFor(Employee $employee)
    {
        try {


            $userId = $employee->userId;

            // get current module of the employee
            $currentCourse = $employee->currentCourse;

            if (!isset($currentCourse) || $currentCourse === '') {
                return; // currentCourse not found
            }

            $moduleNo = Course::where('courseNumber', $currentCourse)->first()->moduleNumber;

            // we need to check if for current module have we completed the lesson 1

            // check if it is completed by user or not
            $isLesson1Completed = \App\UserActivityLog::where('moduleNo', $moduleNo)
                ->where('userId', $userId)
                ->where('lessonNo', 1)
                ->where('activityType', 3)->exists();
            // if level1 is completed 
            if ($isLesson1Completed) {
                // now we will send a random exercise to the user

                // create a job to send the contentful push at every hour
                #1. 2 hours after 1st lesson if we have completed the last lesson just now
                if ($this->option('test')) {
                    $this->sendConditionalContentfulPush($userId, $moduleNo, now()->addSeconds(5)->timezone($employee->timezone), $employee->timezone, 'conditional-push-now-' . time()); // for test
                }
                // send a push after two hours only if it has not been sent ever before
                if (PushLog::where('userId', $userId)->where('type', 'conditional-push-2hr')->doesntExist()) {
                    $this->sendConditionalContentfulPush($userId, $moduleNo, now()->addHours(2)->timezone($employee->timezone), $employee->timezone, "conditional-push-2hr");
                }
                #3. Local time  8 AM
                if (now()->lt(Carbon::createFromTimeString('08:00', $employee->timezone))) {
                    $this->sendConditionalContentfulPush($userId, $moduleNo, Carbon::createFromTimeString('08:00', $employee->timezone), $employee->timezone, "conditional-push-0800");
                }
                // 1 PM
                if (now()->lt(Carbon::createFromTimeString('13:00', $employee->timezone))) {
                    $this->sendConditionalContentfulPush($userId, $moduleNo, Carbon::createFromTimeString('13:00', $employee->timezone), $employee->timezone, "conditional-push-1300");
                }
                // // 5 PM
                // if (now()->lt(Carbon::createFromTimeString('17:00', $employee->timezone))) {
                //     $this->sendConditionalContentfulPush($userId, $moduleNo, Carbon::createFromTimeString('17:00', $employee->timezone), $employee->timezone, "conditional-push-1700");
                // }
                // // 8 PM 
                // if (now()->lt(Carbon::createFromTimeString('20:00', $employee->timezone))) {
                //     $this->sendConditionalContentfulPush($userId, $moduleNo, Carbon::createFromTimeString('20:00', $employee->timezone), $employee->timezone, "conditional-push-2000");
                // }
            } else {
                $this->line("{$userId} has not completed activity 3 for lesson 1");
            }
            $this->line("contentful pushes checked for {$userId}");

        } catch(\Exception $e) {
            \Log::info('contentful pushes check failed for {$userId}', [$e]);
            $this->line("contentful pushes check failed for {$userId}");
        }
    }

    /**
     * This function only sends push if it is only being sent before 10PM
     *
     * @param string $userId
     * @param int $moduleNo
     * @return void
     */
    private function sendConditionalContentfulPush($userId, $moduleNo, $time = null, $timezone, $campaignId = "conditional-push")
    {
        // check if time is less than 10PM 
        if (Carbon::createFromTimeString('22:00', $timezone)->gte($time)) {
            // check if the job already exists
            if(!DB::table('jobs')->where('payload', 'like', "%SendContentfulPush%{$userId}%")->where('available_at', $time->timestamp)->exists()) {
                if(checkIfJobDispatched($userId, $campaignId)) {
                    $this->line("Contentful push for already {$time} set");
                    return false;
                }
                SendContentfulPush::dispatch($userId, $moduleNo, $campaignId)->delay($time);
                markJobDispatched($userId, $campaignId, "push_job");
                $this->line("Contentful push for {$time} set");
                return true;
            } else {
                $this->line("Contentful push for already {$time} set");
                return false;
            }
        } else {
            $this->line("{$time} is past 10PM");
        }
    }
}
