<?php

namespace App\Console\Commands;

use App\Employee;
use App\Http\Controllers\LeaderBoardController;
use App\LingoCoinLog;
use App\UserDailyGoalLog;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class CheckForLeaderboardWinners extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'taplingua:checkforleaderboardwinner';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    const COINFORDAILYRANK = [
        1 => 5,
        2 => 3,
        3 => 2,
        4 => 1,
        5 => 1
    ];

    const COINFORWEEKLYRANK = [
        1 => 10,
        2 => 5,
        3 => 2
    ];

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        // this cron will run at 00:01 everyday, so we have to check for yesterday
        // check daily winner for yesterday
        $startDate = today()->subDay()->startOfDay();
        $winners = $this->getLeaderboardByDateRange($startDate, today()->subDay()->endOfDay(), 5);

        $rank = 1;
        foreach ($winners as $winner) {
            $this->addLingoCoinLog(
                [
                    'userId' => $winner['userId'],
                    'date' => today()->subDay()->startOfDay(),
                    'type' => 'daily',
                    'rank' => $rank
                ],
                [
                    'coins' => self::COINFORDAILYRANK[$rank],
                ]
            );
            $this->line($winner['userId'] . " logged with rank " . $rank . " for date " . $startDate . " in type daily.");
            $rank++;
        }
        $this->updateHighScore($startDate, today()->subDay()->endOfDay(), 'daily');

        // check for weekly winner if today is saturday
        if (today()->dayOfWeek === 6) {
            // today is saturday, so start is yesterday minus a week start of day and end is yesterday endof the day
            $startDate = today()->subWeek()->startOfDay();
            $endDate = today()->subDay()->endOfDay();
            $rank = 1;
            foreach ($this->getLeaderboardByDateRange($startDate, $endDate, 3) as $winner) {
                $this->addLingoCoinLog(
                    [
                        'userId' => $winner['userId'],
                        'date' => $startDate,
                        'type' => 'weekly',
                        'rank' => $rank
                    ],
                    [
                        'coins' => self::COINFORWEEKLYRANK[$rank],
                    ]
                );
                $this->line($winner['userId'] . " logged with rank " . $rank . " for date " . $startDate . " in type weekly.");
                $rank++;
            } 
            $this->updateHighScore($startDate, $endDate, 'weekly');
        }
    }

    private function getLeaderboardByDateRange($startDate, $endDate, $cutoff = 1)
    {
        $leaderboard = UserDailyGoalLog::select('userId', DB::raw('sum(points) as current'))
            ->whereNotIn('userId', LeaderBoardController::emailExceptions)
            ->whereBetween('dated', [$startDate, $endDate]);

        // get top 50 records
        $leaderboard = $leaderboard
            ->groupBy('userId')
            ->orderBy('current', 'desc')
            ->take($cutoff)
            ->get();

        return $leaderboard;
    }

    private function updateHighScore($startDate, $endDate, $type)
    {
        $this->line("Updating highscore for " . $startDate . " " . $endDate . " " . $type);
        $highscores = UserDailyGoalLog::select('userId', DB::raw('sum(points) as current'))
            ->whereNotIn('userId', LeaderBoardController::emailExceptions)
            ->whereBetween('dated', [$startDate, $endDate])
            ->groupBy('userId')
            ->orderBy('current', 'desc')
            ->get();

        foreach ($highscores as $highscore) {
            $employee = Employee::where('userId', $highscore->userId)->first();
            if ($type === 'daily') {
                // daily
                if ($employee->dailyHighScore < $highscore->current) {
                    // update if score is more than what is set
                    $employee->dailyHighScore = $highscore->current;
                    $employee->dailyHighScoreDate = $startDate;
                    $employee->save();
                    $this->line("Updated " . $employee->userId);
                }
            } else {
                // weekly
                if ($employee->weeklyHighScore < $highscore->current) {
                    // update if score is more than what is set
                    $employee->weeklyHighScore = $highscore->current;
                    $employee->weeklyHighScoreDate = $startDate;
                    $employee->save();
                    $this->line("Updated " . $employee->userId);
                }
            }
        }
        $this->line("Updated highscore for " . $startDate . " " . $endDate . " " . $type);
    }

    private function addLingoCoinLog($condition, $updates)
    {
        // create lingo log
        if (isset($condition['userId'])) {
            LingoCoinLog::updateOrCreate(
                $condition,
                $updates
            );
        }
        // recalculate the lingo counts
        $coins = (int) LingoCoinLog::where('userId', $condition['userId'])->sum('coins');
        // update the lingo coins in employee table
        Employee::where('userId', $condition['userId'])->update([
            'lingoCoins' => $coins
        ]);
    }
}
