<?php

namespace App\Console\Commands;

use App\Employee;
use App\UserDailyGoalLog;
use App\UserDailyPhaseLog;
use App\UserSegment;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class CheckForUserStateUsingUserPoints extends Command
{
    const SEGMENT_LAPSED_USERS = 'lapsed_users';
    const SEGMENT_RESURRECTED_USERS = 'resurrected_users';
    const SEGMENT_AT_RISK_1_USERS = 'at_risk_1_users';
    const SEGMENT_AT_RISK_2_USERS = 'at_risk_2_users';
    const SEGMENT_ACTIVE_USERS = 'active_users';
    const SEGMENT_NOT_ACTIVATED_USERS = 'not_activated_users';

    const SEGMENTS = [
        'lapsed_users' => "LAPSED USERS", // Lapsed users are thos that haven't been active in the last month.
        'resurrected_users' => "RESURRECTED USERS", // Resurrected users are those that were inactive for 7 days but are active now
        'at_risk_1_users' => "AT RISK 1 USERS", // not active in last 14 days
        'at_risk_2_users' => "AT RISK 2 USERS", // not active in last 29 days
        'active_users' => "ACTIVE USERS", // Active Users are those who have scored points in the last 7 days
        'not_activated_users' => "NOT ACTIVATED USERS", // users that have not done any activity till now
    ];


    const INACTIVE_DAYS_SEGMENTS = [ // Segment codes for inactive days
        'inactive-day-1' => "INACTIVE DAY 1",
        'inactive-day-2' => "INACTIVE DAY 2",
        'inactive-day-3' => "INACTIVE DAY 3",
        'inactive-day-4' => "INACTIVE DAY 4",
        'inactive-day-5' => "INACTIVE DAY 5",
        'inactive-day-6' => "INACTIVE DAY 6",
        'inactive-day-7' => "INACTIVE DAY 7",
    ];
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'taplingua:checkforuserstateusingpoints {userId?} {--refresh}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Check and move user to segments according to their user points';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        // add segments if needed
        foreach (self::SEGMENTS as $code => $name) {
            DB::table('user_segments')->updateOrInsert([
                'code' => $code
            ], [
                'code' => $code,
                'name' => $name
            ]);
        }

        // get user segment
        $userSegments = [];

        foreach (self::SEGMENTS as $code => $name) {
            $userSegments[$code] = UserSegment::whereCode($code)
                ->select('id', 'code', 'name')
                ->first()->toArray();
        }

        // add inactive segments if needed
        foreach (self::INACTIVE_DAYS_SEGMENTS as $code => $name) {
            DB::table('user_segments')->updateOrInsert([
                'code' => $code
            ], [
                'code' => $code,
                'name' => $name
            ]);
        }
        // get user inactive segment (get id from db)
        $userInactiveSegments = [];

        foreach (self::INACTIVE_DAYS_SEGMENTS as $code => $name) {
            $userInactiveSegments[$code] = UserSegment::whereCode($code)
                ->select('id', 'code', 'name')
                ->first()->toArray();
        }



        if ($userId = $this->argument('userId')) {
            $users = Employee::whereDate('accountCreationDate', '>=', new Carbon('2020-08-01'))
                ->where('userId', $userId)
                ->get();
        } else {
            $users = Employee::whereDate('accountCreationDate', '>=', new Carbon('2020-08-01'))
                ->get();
        }
        // $users = Employee::where('userId', 'demo_bosch@taplingua.com')->get();

        if ($this->option('refresh')) {
            // calculate from start
            // foreach user
            foreach ($users as $user) {
                $lastDailyLogDate = $this->getUserLastDailyLog($user);
                // if $last
                $segmentUserBelongsTo = null;
                if ($lastDailyLogDate === null) {
                    // if no activity, put in not activated segment
                    $segmentUserBelongsTo = self::SEGMENT_NOT_ACTIVATED_USERS;
                } else if ($lastDailyLogDate < today()->subMonth()) {
                    // if active less than a month ago, put in looser segment
                    $segmentUserBelongsTo = self::SEGMENT_LAPSED_USERS;
                } else if ($lastDailyLogDate <= today()->subDays(15)) {
                    // if active more than 15 days ago, put in risk 2 segment
                    $segmentUserBelongsTo = self::SEGMENT_AT_RISK_2_USERS;
                } else if ($lastDailyLogDate <= today()->subDays(7)) {
                    // if active more than 7 days ago, put in risk 1 segment
                    $segmentUserBelongsTo = self::SEGMENT_AT_RISK_1_USERS;
                } else if ($lastDailyLogDate > today()->subWeek()->addDay()) {
                    // if active less 7 days ago, active segment
                    $segmentUserBelongsTo = self::SEGMENT_ACTIVE_USERS;
                    // Check for user in inactive-day-x
                    $this->checkForUsersInInactiveDays($user, $lastDailyLogDate, $userInactiveSegments);
                }

                // check according to current segment, where user should be
                $this->removeUserFromOtherSegmentAndAddTo($segmentUserBelongsTo, $user->userId, $userSegments);
            }
        } else {
            // just see the new record
        }

    }

    /**
     * Remove user from other phases and add to
     *
     * @param [type] $segmentCode
     * @param [type] $userId
     * @param [type] $userSegments
     * @return void
     */
    private function removeUserFromOtherSegmentAndAddTo($segmentCode, String $userId, Array $userSegments)
    {
        try {

            // get the user segment
            $segmentId = $userSegments[$segmentCode]["id"];
            // for active segment
            if ($segmentCode === self::SEGMENT_ACTIVE_USERS) {
                // check if was in lapsed
                $userWasInLapse = UserDailyPhaseLog::where('phase', self::SEGMENT_LAPSED_USERS)
                    ->where("userId", $userId)
                    ->exists();

                if ($userWasInLapse) {
                    // set segment id and code to resurrected
                    $segmentCode = self::SEGMENT_RESURRECTED_USERS;
                    $segmentId = $userSegments[$segmentCode]['id'];
                }
            }

            // $other segment have other segments that are available in windows
            $otherSegmentIds = array_values(array_filter(array_map(function ($segment) {
                return $segment['id'];
            }, $userSegments), function ($id) use ($segmentId) {
                return $id !== $segmentId;
            }));

            // delete user from other segments
            DB::table('user_user_segment')->where('userId', $userId)
                ->whereIn('user_segment_id', $otherSegmentIds)
                ->delete();

            // TODO: Decrease user count from all those segments

            addUserToSegment($segmentCode, $userId);
            // Log user phase for the date
            UserDailyPhaseLog::updateOrCreate([
                'dated' => today(),
                'userId' => $userId,
                'phase' => $segmentCode
            ]);
            $this->line("Moved " . $userId . " to " . $segmentCode);
        } catch (\Exception $e) {
            $this->line("Errored!");
            dump($e);
        }
    }

    /**
     * Get the last daily log for user
     *
     * @param Employee $employee
     * @return void
     */
    private function getUserLastDailyLog(Employee $employee) : string
    {
        $lastLogin = UserDailyGoalLog::where('userId', $employee->userId)
            ->latest()->first();
        return $lastLogin ? $lastLogin->dated : null;
    }

    // Check for users inactivity for last 7 days
    private function checkForUsersInInactiveDays(Employee $user, string $lastDailyLogDate, Array $userSegments)
    {
        $segmentsIndexed = array_keys(self::INACTIVE_DAYS_SEGMENTS);
        $segmentsIds = array_map(function($value) {}, $userSegments);

        // get the index 
        $userInactiveSegmentIndex = today()->diffInDays($lastDailyLogDate) - 1;

        // remove user from all other segments
        foreach($userSegments as $uS) {
            DB::table('user_user_segment')->where('userId', $user->userId)
            ->where('user_segment_id', $uS['id'])
            ->delete();
        }

        // create new user user segment log
        addUserToSegment($segmentsIndexed[$userInactiveSegmentIndex], $user->userId);
    }
}
