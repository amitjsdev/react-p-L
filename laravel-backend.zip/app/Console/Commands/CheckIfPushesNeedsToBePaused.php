<?php

namespace App\Console\Commands;

use App\Employee;
use App\Jobs\SendWeAreOnABreakPush;
use App\PushLog;
use App\UserTimeLog;
use Carbon\Carbon;
use Illuminate\Console\Command;

class CheckIfPushesNeedsToBePaused extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'taplingua:checkifpushesneedstobepaused {userId?}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command puts user on pause if need be.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $userId = $this->argument('userId');

        if($userId) {
            $users = Employee::where('userId', $userId)->get();
        } else {
            $users = Employee::whereDate('accountCreationDate', '>=', Carbon::createFromDate(2020, 8, 0))->get();
        }

        $now = now();

        foreach($users as $user) {
            // check if user is not on pause
            if(!$user->push_paused) {
                $user->push_paused = $this->shouldUserBeOnPause($user);
                if($user->push_paused) {
                    // set date if push was paused today
                    $user->push_paused_at = $now;
                }
            }

            $this->line("[" . $user->userId . "] The push_pause status is " . ($user->push_paused ? "Paused" : "Not Paused"));

            // save the user data
            $user->save();
        }
    }


    /**
     * Check if user should be user pause
     *
     * @param Employee $employee
     * @return boolean
     */
    private function shouldUserBeOnPause(Employee $employee) {

        // if the user is new, dont mark him lost
        if (today()->subDays(1)->lt(\Carbon\Carbon::parse($employee->accountCreationDate))) {
            return false;
        }

        if($employee->push_paused) {
            return true;
        }

        // check if user was on a break 
        if ($employee->was_on_break) {
            // End the user's break
            $employee->was_on_break = false;
            $employee->save();
            return false;
        } else {
            // check if the user needs to go on a break
            // check if the user last opened the push
            $lastOpenPush = PushLog::where('userId', $employee->userId)
                ->where('pushOpened', 1)
                ->whereDate('created_at', '>=', now()->subDays(3))->exists();

            if (!$lastOpenPush) {
                // user hasnt opened any push in last 3 days, mark him lost
                // and send we are on a break push
                // but first check if the user has already gotten a we-were-on-a-break push in last few days
                if (!PushLog::where('userId', $employee->userId)->where('type', SendWeAreOnABreakPush::CAMPAIGN_ID)->whereDate('created_at', '>', now()->subDays(5))->exists()) {
                    SendWeAreOnABreakPush::dispatch($employee->userId);
                }
                return true;
            }

            // check the last date on which the user was seen
            $lastTimeLog = UserTimeLog::where('userId', $employee->userId)->latest()->first();
            if (!$lastTimeLog) {
                return true;
            }
            // if the user was last active before 5 days, mark him lost
            if (now()->subDays(5)->gt($lastTimeLog->updated_at)) {
                // send the user a last notification about not disturbing him for sometime
                // but first check if the user has already gotten a we-were-on-a-break push in last few days
                if (!PushLog::where('userId', $employee->userId)->where('type', SendWeAreOnABreakPush::CAMPAIGN_ID)->whereDate('created_at', '>', now()->subDays(5))->exists()) {
                    SendWeAreOnABreakPush::dispatch($employee->userId);
                }
                // declate the user lost
                return true;
            }
        }
        return false;
    }
}
