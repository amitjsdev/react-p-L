<?php

namespace App\Console\Commands;

use App\LoginLog;
use Illuminate\Auth\Events\Failed;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class CleanDB extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'maintainence:cleandb';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cleans the unnecessary records from db';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        // delete failed jobs one day prior
        DB::table('failed_jobs')
            ->whereDate('failed_at', '<=', today()->subDay())
            ->delete();
        $this->line("\nfailed_jobs table cleared!");
        
        // delete failed logins from 5 days prior
        LoginLog::whereDate('created_at', '<=', today()->subDays(5));
        $this->line("\nlogin_logs table cleared!");
    }
}
