<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use DB;

class CourseWeeklyEmail extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'CourseWeeklyEmail:cron
                           {--date= : Current Date d-m-Y}
                           {--course= : Course Number 11572201022020}
                           {--type= : test or real}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    public $DAYS_INTERVAL = 7;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        
        $this->info("CourseWeeklyEmail:Cron Cummand Run Started...\r\n");

        date_default_timezone_set("Europe/Madrid");

        $date = $this->option('date');
        $course = $this->option('course');
        $type = $this->option('type') ? $this->option('type') : 'test';

        if($date!="")
         $currDate = $date;
        else 
         $currDate = date("d-m-Y"); 

        // echo $currDate;

        //$sql = "SELECT a.*, b.* FROM  courses b Join employeecourse a on a.courseNumber = b.courseNumber WHERE  b.weeklyEmail = 'Y'";

        if($course!="")
        {

            $sql = "SELECT DISTINCT ec.`userId`,e.`CompanyCode`, comp.`Name` AS companyName, ec.`courseNumber`
            , c.`moduleNumber`, c.`courseName`, concat(e.`FirstName`,' ', e.`LastName`) AS `Name`, e.`fcmToken`,  r.`routeno`, m.language, concat(m.`description`,'  (Taplingua)') AS `moduleName`,  r.`description`, DATE_FORMAT(c.courseStartDate, '%d-%m-%Y') as courseStartDate, co.Name AS companyName
            FROM employeecourse ec
            JOIN employee e ON e.`userId` = ec.`userId`
            JOIN company comp ON comp.`Id` = e.`CompanyCode`
            JOIN courses c ON c.`courseNumber` = ec.`courseNumber`
            JOIN module m ON m.`moduleno` = c.`moduleNumber` 
            JOIN route r ON r.`moduleno` = c.`moduleNumber`
            LEFT JOIN company co ON co.`Id` = e.CompanyCode
            where c.courseNumber = '".$course."' GROUP BY ec.userId";

        }
        else
        {
            /*$sql = "SELECT DISTINCT ec.`userId`,e.`CompanyCode`, comp.`Name` AS companyName, ec.`courseNumber`
            , c.`moduleNumber`, c.`courseName`, concat(e.`FirstName`,' ', e.`LastName`) AS `Name`, e.`fcmToken`,  r.`routeno`, m.language, concat(m.`description`,'  (Taplingua)') AS `moduleName`,  r.`description`, DATE_FORMAT(c.courseStartDate, '%d-%m-%Y') as courseStartDate, co.Name AS companyName
            FROM employeecourse ec
            JOIN employee e ON e.`userId` = ec.`userId`
            JOIN company comp ON comp.`Id` = e.`CompanyCode`
            JOIN courses c ON c.`courseNumber` = ec.`courseNumber`
            JOIN module m ON m.`moduleno` = c.`moduleNumber` 
            JOIN route r ON r.`moduleno` = c.`moduleNumber`
            LEFT JOIN company co ON co.`Id` = e.CompanyCode
            where c.weeklyEmail = 'Y' GROUP BY ec.userId";*/

            $sql = "SELECT DISTINCT ec.`userId`,e.`CompanyCode`, comp.`Name` AS companyName, ec.`courseNumber`
            , c.`moduleNumber`, c.`courseName`, concat(e.`FirstName`,' ', e.`LastName`) AS `Name`, e.`fcmToken`,  r.`routeno`, m.language, concat(m.`description`,'  (Taplingua)') AS `moduleName`,  r.`description`, DATE_FORMAT(c.courseStartDate, '%d-%m-%Y') as courseStartDate, co.Name AS companyName
            FROM employeecourse ec
            JOIN employee e ON e.`userId` = ec.`userId`
            JOIN company comp ON comp.`Id` = e.`CompanyCode`
            JOIN courses c ON c.`courseNumber` = ec.`courseNumber`
            JOIN module m ON m.`moduleno` = c.`moduleNumber` 
            JOIN route r ON r.`moduleno` = c.`moduleNumber`
            LEFT JOIN company co ON co.`Id` = e.CompanyCode
            where ( courseStartDate BETWEEN NOW() - INTERVAL 45 DAY AND NOW() ) GROUP BY ec.userId";

        }    

        $query = DB::select(DB::raw($sql));

        if (sizeof($query) > 0) {

        foreach ($query as $rows) {

            //print_r($rows);
            
            if($rows->userId!=""){
            
                
                $days = dateDiffInDays($rows->courseStartDate, $currDate);

                //$week = round($days / $this->DAYS_INTERVAL);

                //$week = ceil($days / 7);

                $week = ceil($days / $this->DAYS_INTERVAL);

                if($week==0) $week=1;
                
                
                echo "\r\n";                
                echo "RouteNo: ".$rows->routeno."\r\n";
                echo "CompanyCode: ".$rows->CompanyCode."\r\n";
                echo "ModuleNo: ".$rows->moduleNumber."\r\n";
                echo "CourseNo: ".$rows->courseNumber."\r\n";
                echo "CourseName:  ".$rows->courseName."\r\n";
                echo "courseStartDate: ".$rows->courseStartDate."\r\n";
                echo "UserID: ".$rows->userId."\r\n";
                echo "Days: ".$days."\r\n";
                echo "Week: ".$week."\r\n\r\n";
                echo "Type: ".$type."\r\n\r\n";

                
                $routeNo = $rows->routeno;
                
                //echo $rows->courseNumber." - ".$rows->courseName." - ".$rows->userId."\r\n";                

                /*$params = array("modules" => "1", "fetchLevel" => "1", "id" => $rows->moduleNumber);
                $newRequest = new \Illuminate\Http\Request($params);
                $levelData = (array) app(\App\Http\Controllers\ModuleController::class)->index($newRequest);
                //print_r($levelData);

                foreach($levelData['0']["routes"] as $routeArr){
                    if($routeArr["routeno"] == $routeNo){ 

                       print_r($routeArr);

                    }
                }*/  
                
                
                $params = array("courseNo" => $rows->courseNumber);
                $newRequest = new \Illuminate\Http\Request($params);
                $levelData = app(\App\Http\Controllers\RouteController::class)->list($newRequest);
                
                $totalWeeks = sizeof($levelData);

                echo "Total Weeks: ".$totalWeeks."\r\n";

                //$routeNumber = 1;

                $routeNumber = $levelData[0]->id;

                /* Skip all other weeks are over based on dateTime */  
                /*if($week > $totalWeeks) 
                {    
                  
                  $this->error("CourseWeeklyEmail:Cron Nothing to send!");  
                  //break;
                }*/

                //print_r($levelData);


                /* Select current running week routeNumber  */
                foreach($levelData as $routeArr)
                {

                    if($routeArr->routeno==$week)
                    {
                     $routeNumber = $routeArr->id;                      
                    } 

                }

                echo "Current routeNumber: ".$routeNumber."\r\n";


                if(isset($rows->language) && $rows->language!="")
                  $lang = trim($rows->language);
                else
                  $lang = "ES";


                /* Skip all other weeks are over based on dateTime */  
                if($week > $totalWeeks) 
                { 

                  $this->error("CourseWeeklyEmail:Cron Nothing to send!"); 

                }
                else
                {    

                // Start Day of Week
                if($this->DAYS_INTERVAL==7)
                 $emailStartOfWeek = array(0, 8, 15, 22, 29, 36, 43, 50);
                else
                 $emailStartOfWeek = array(0, 1, 2, 3, 4, 5, 6, 7); 
                 
                if(in_array($days, $emailStartOfWeek))
                {

                /* Check if email already sent or not */    
                $logs = "SELECT id from `course_weekly_email_logs` where userId='".trim($rows->userId)."' and routeNo='".$rows->routeno."' and companyCode='".$rows->CompanyCode."' and moduleNo='".$rows->moduleNumber."' and courseNo='".$rows->courseNumber."' and courseStartDate='".date("Y-m-d H:i:s", strtotime($rows->courseStartDate))."' and days='".$days."' and week='".$week."' and emailSent='Y'";

                $sent = DB::select(DB::raw($logs));


                if(sizeof($sent)<=0)
                {

                //$params = array("params" => array("to" => array($rows->userId), "routeNumber" => $routeNumber, "mailMode" => $type, "companyCode" => $rows->CompanyCode, "courseNumber" => $rows->courseNumber, "batchNumber" => "1", "lang" => $lang, "type" => "weekly_email"));

                $params = array("params" => array("to" => array($rows->userId), "routeNumber" => $routeNumber, "mailMode" => $type, "companyCode" => $rows->CompanyCode, "courseNumber" => $rows->courseNumber, "lang" => $lang, "type" => "weekly_email"));
                //print_r($params);


                $logList = "SELECT id from `ses_sns_email_list` where userId='" . trim($rows->userId) . "'";
                $sentList = DB::select(DB::raw($logList));

                if(sizeof($sentList)<=0)  /// send email if not in blocked list
                {    

                $newRequest = new \Illuminate\Http\Request($params);
                $res = app(\App\Http\Controllers\NotificationController::class)->weekly($newRequest);                
                $this->info($res);

                //print_r($levelData);

                $logs = "INSERT INTO `course_weekly_email_logs` (`id`, `userId`, `routeNo`, `companyCode`, `moduleNo`, `courseNo`, `courseStartDate`, `days`, `week`, `totalWeeks`, `currentRouteNo`, `language`, `emailType`, `emailSent`, `rundate`, `adddate`) VALUES (NULL, '".trim($rows->userId)."', '".$rows->routeno."', '".$rows->CompanyCode."', '".$rows->moduleNumber."', '".$rows->courseNumber."', '".date("Y-m-d H:i:s", strtotime($rows->courseStartDate))."', '".$days."', '".$week."', '".$totalWeeks."', '".$routeNumber."', '".$lang."', '".$type."', 'Y', '".date("Y-m-d H:i:s", strtotime($currDate))."', now())";

                DB::select(DB::raw($logs));


                $this->info("CourseWeeklyEmail:Cron Email Sent!");
                
                }
                else
                {

                
                $this->error("CourseWeeklyEmail:Cron Email is in email blocked list!");


                }    



                }
                else
                {

                    $this->error("CourseWeeklyEmail:Cron Email already Sent!");

                }


                
                }
                else
                {
                    $this->error("CourseWeeklyEmail:Cron Emails will be Sent on Start day of week!");
                }


                }


            }
        }
        
        }

        /*{"params":{"to":["santanu@taplingua.com"],"routeNumber":"431","mailMode":"Test","companyCode":"115","courseNumber":"74119292","batchNumber":"1","lang":"ES","type":"weekly_email"}}*/

        //$params = array("params" => array("to" => array("santanu@taplingua.com"), "routeNumber" => "431", "mailMode" => "test", "companyCode" => "115", "courseNumber" => "74119292", "batchNumber" => "1", "lang" => "ES", "type" => "weekly_email"));

        //$newRequest = new \Illuminate\Http\Request($params);

        //app(\App\Http\Controllers\NotificationController::class)->weekly($newRequest);

      
        $this->info("\r\nCourseWeeklyEmail:Cron Cummand Run Done!");


    }
}
