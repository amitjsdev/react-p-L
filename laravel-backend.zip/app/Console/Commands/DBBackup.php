<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use DB;
use Illuminate\Support\Facades\Storage;

class DBBackup extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'DBBackup:cron';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        
        $this->info("Cron is started fine!");

        //echo env("S3_ACCESSKEY");

        //echo storage_path(); //$storagePath = Storage::disk('local')->path();
     
        
        $sql_file = storage_path()."/backup-".date("d-m-Y-H-i-s-A").".sql";

        $sqlbackup="/usr/bin/mysqldump --host='".env("DB_HOST")."' --user='".env("DB_USERNAME")."' --password='".env("DB_PASSWORD")."' ".env("DB_DATABASE")." > ".$sql_file." 2>&1";
        exec($sqlbackup, $o);
        echo implode("\r\n", $o);


        $bucket = 'laravel-dashboard-backup';

        ///usr/local/aws/bin

        exec("AWS_ACCESS_KEY_ID=".env("S3_ACCESSKEY")." AWS_SECRET_ACCESS_KEY=".env("S3_SECRETKEY")." ".env("AWS_CLI")." s3 cp ".$sql_file." s3://".$bucket."/ 2>&1", $pp); 

        echo implode("\r\n", $pp);


        exec("rm -rf ".$sql_file);
        @unlink($sql_file); 


        echo "\r\nRemoved: ".$sql_file;
        echo "\r\nDone....";
      
        $this->info('DBBackup:Cron Cummand Run successfully!');

    }
}
