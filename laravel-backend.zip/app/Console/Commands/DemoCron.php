<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use DB;

class DemoCron extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'demo:cron 
                           {--date= : Current Date M-d-YY}
                           {--course= : Course Number 11572201022020}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        //\Log::info("Cron is working fine!");
     
        /* Write your cron logic */

        /*$email = "svnlabs@gmail.com"; 
        $message = "SES Email CRON Test";
        $subject = "Cron Subject";
        $to_name = "Sandeep";

        sendEmail($email, $message, $subject, $to_name);*/

        //echo $currentDate = $this->argument('currentDate');
        //echo $courseNumber = $this->argument('courseNumber');

        echo $date = $this->option('date');
        echo $course = $this->option('course');


        date_default_timezone_set("Europe/Madrid");
        $currDate = date("M d Y"); 


        echo $sql = "SELECT a.*, b.* FROM  courses b Join employeecourse a on a.courseNumber = b.courseNumber WHERE  b.weeklyEmail = 'Y'";

/*$sql = "SELECT DISTINCT ec.`userId`,e.`CompanyCode`, comp.`Name` AS companyName, ec.`courseNumber`
, c.`moduleNumber`, c.`courseName`, concat(e.`FirstName`,' ', e.`LastName`) AS `Name`, e.`fcmToken`,  r.`routeno`, concat(m.`description`,'  (Taplingua)') AS `moduleName`,  r.`description`, DATE_FORMAT(c.courseStartDate, '%d-%m-%Y') as courseStartDate, co.Name AS companyName
FROM employeecourse ec
JOIN employee e ON e.`userId` = ec.`userId`
JOIN company comp ON comp.`Id` = e.`CompanyCode`
JOIN courses c ON c.`courseNumber` = ec.`courseNumber`
JOIN module m ON m.`moduleno` = c.`moduleNumber` 
JOIN route r ON r.`moduleno` = c.`moduleNumber`
LEFT JOIN company co ON co.`Id` = e.CompanyCode
where c.weeklyEmail = 'Y' GROUP BY ec.userId";*/

        $query = DB::select(DB::raw($sql));

        if (sizeof($query) > 0) {

        foreach ($query as $rows) {

            //print_r($rows);
            
            if($rows->userId!=""){
            
                //echo $rows->routeno." = ".$rows->courseNumber." - ".$rows->courseName." - ".$rows->userId."\r\n";
                echo $rows->courseNumber." - ".$rows->courseName." - ".$rows->userId."\r\n";

            }
        }
        
        }

        /*{"params":{"to":["santanu@taplingua.com"],"routeNumber":"431","mailMode":"Test","companyCode":"115","courseNumber":"74119292","batchNumber":"1","lang":"ES","type":"weekly_email"}}*/

        //$params = array("params" => array("to" => array("santanu@taplingua.com"), "routeNumber" => "431", "mailMode" => "test", "companyCode" => "115", "courseNumber" => "74119292", "batchNumber" => "1", "lang" => "ES", "type" => "weekly_email"));

        //$newRequest = new \Illuminate\Http\Request($params);

        //app(\App\Http\Controllers\NotificationController::class)->weekly($newRequest);

      
        $this->info('Demo:Cron Cummand Run successfully!');
    }
}
