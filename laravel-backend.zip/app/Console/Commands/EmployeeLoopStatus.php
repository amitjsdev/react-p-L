<?php

namespace App\Console\Commands;

use App\Course;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class EmployeeLoopStatus extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:userstatusupdate';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'This command updates the courseemployee status for everyuser in that table';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        // show tart message
        $this->line("Starting updates for the the courseemployee status for everyuser");
        // get all course registrations
        $employeecourses = DB::table('employeecourse')
            ->get();
        foreach ($employeecourses as $employeecourse) { // for each course registration
            // get the actual course that user has registered for
            $course = Course::where('courseNumber', $employeecourse->courseNumber)->first();


            if (!$course) {
                $this->line('course ' . $employeecourse->courseNumber . ' not found for ' . $employeecourse->userId);
                continue;
            }

            // get number of lessons done
            $numberOfLessonsDone = \App\UserActivityLog::where('userId', $employeecourse->userId)
                ->where('moduleNo', $course->moduleNumber)
                ->distinct('moduleNo', 'routeNo', 'levelNo', 'lessonNo')
                ->count();

            if ($numberOfLessonsDone === 0) {
                continue; //if user has no activity leave it
            }

            // current week
            $currentWeek = now()->diffInWeeks(\Carbon\Carbon::parse($course->courseStartDate)) + 1; // get current week for course
            $usersCurrentWeek = \App\UserActivityLog::selectRaw('max(routeNo) as routeNo') // get users current week
                ->where('userId', $employeecourse->userId)
                ->where('moduleNo', $course->moduleNumber)
                ->first()->routeNo;

            // update the loop status of the user first
            if ($currentWeek >= $usersCurrentWeek) { // if current week is actually greater than or equal to  users current with
                $newLoopStatus = 1;
                if ($numberOfLessonsDone > 3 && $numberOfLessonsDone <= 15) {
                    $newLoopStatus = 2;
                } else if ($numberOfLessonsDone > 15) {
                    $newLoopStatus = 3;
                }
            } else {
                $newLoopStatus = '10'; // 10 is for Ahead of time users
            }
            // update user status
            $userState = $this->getState($employeecourse->userId, $course->moduleNumber, $newLoopStatus);
            DB::table('employeecourse')
                ->where('userId', $employeecourse->userId)
                ->where('courseNumber', $employeecourse->courseNumber)
                ->update([
                    'loopStatus' => $newLoopStatus,
                    'loopState' => $userState,
                ]);
            $this->line("Updated employeecourse with userId '" . $employeecourse->userId . "' with for courseNumber='" . $employeecourse->courseNumber . "' loopStatus='" . $newLoopStatus . "' loopState='" . $userState . "' for module " . $course->moduleNumber);
        }
    }

    private function getState($userId, $moduleNo, $loopStatus)
    {
        $lastActivity = DB::table('useractivitylog_api')
            ->where('userId', $userId)
            ->where('moduleNo', $moduleNo)
            ->orderBy('activityDateTo', 'desc')
            ->first();
        if ($lastActivity) {
            $lastActivityDaysBefore = \Carbon\Carbon::parse($lastActivity->activityDateTo)->diffInDays(now());
            switch ((int) $loopStatus) {
                case 1:
                    if ($lastActivityDaysBefore >= 8) {
                        return "1D";
                    }
                    if ($lastActivityDaysBefore >= 7) {
                        return "1C";
                    }
                    if ($lastActivityDaysBefore >= 3) {
                        return "1B";
                    }
                    return "1A";
                case 2:
                    if ($lastActivityDaysBefore >= 14) {
                        return "2D";
                    }
                    if ($lastActivityDaysBefore >= 10) {
                        return "2C";
                    }
                    if ($lastActivityDaysBefore >= 7) {
                        return "2B";
                    }
                    return "2A";
                case 3:
                    return "3D";
                default:
                    return null;
            }
        } else {
            return null;
        }
    }
}
