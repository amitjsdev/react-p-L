<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use DB;
use Illuminate\Support\Facades\Storage;

class ExerciseDescriptionDump extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'ExerciseDescriptionDump:cron';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        
        $this->info("ExerciseDescriptionDump is started fine!");

        
        $q = "select id, moduleno, routeno, lesson_no, exercise_no, description from `exercise` where id!='' order by id ";


        $assessment = array(); 
           
        $query = DB::select(DB::raw($q)); 
        
        
        foreach($query as $row){

            $description = explode("\n", $row->description);
            $description = str_replace("\r", "", $description);


            foreach ($description as $value) {  
                
                //$text = explode(";", $value);

                echo $row->id."\r\n";

                echo $value."\r\n";

                echo "\r\n\r\n\r\n\r\n";

                


                if($value!="" && $value!="_")
                {

                    $cards = "INSERT INTO `exercise_description` (`id`, `exerciseId`, `moduleNo`, `routeNo`, `lessonNo`, `exerciseNo`, `description`, `created_at`) VALUES (NULL, '".$row->id."', '".$row->moduleno."', '".$row->routeno."', '".$row->lesson_no."', '".$row->exercise_no."', '".addslashes($value)."', now())";

                    DB::select(DB::raw($cards)); 

                    $this->info('ExerciseDescriptionDump dumped successfully!');

                } 

                
            
                
                

            }    

                     


        }   

        

              
        $this->info('ExerciseDescriptionDump Cummand Run successfully!');

    }
}
