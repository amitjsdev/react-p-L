<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use DB;
use Illuminate\Support\Facades\Storage;

class ExerciseMediaAlt3Dump extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'ExerciseMediaAlt3Dump:cron';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        
        $this->info("ExerciseMediaAlt3Dump is started fine!");

        
        $q = "select id, moduleno, routeno, lesson_no, exercise_no, media_alt3 from `exercise` where id!='' order by id ";


        $assessment = array(); 
           
        $query = DB::select(DB::raw($q)); 
        
        
        foreach($query as $row){

            $media_alt3 = explode("\n", $row->media_alt3);
            $media_alt3 = str_replace("\r", "", $media_alt3);


            foreach ($media_alt3 as $value) {  
                
                //$text = explode(";", $value);

                echo $row->id."\r\n";

                echo $value."\r\n";

                echo "\r\n\r\n\r\n\r\n";

                


                if($value!="" && $value!="_")
                {

                    $cards = "INSERT INTO `exercise_media_alt3` (`id`, `exerciseId`, `moduleNo`, `routeNo`, `lessonNo`, `exerciseNo`, `media_alt3`, `created_at`) VALUES (NULL, '".$row->id."', '".$row->moduleno."', '".$row->routeno."', '".$row->lesson_no."', '".$row->exercise_no."', '".addslashes($value)."', now())";

                    DB::select(DB::raw($cards)); 

                    $this->info('ExerciseMediaAlt3Dump dumped successfully!');

                } 

                
            
                
                

            }    

                     


        }   

        

              
        $this->info('ExerciseMediaAlt3Dump Cummand Run successfully!');

    }
}
