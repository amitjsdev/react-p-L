<?php

namespace App\Console\Commands;

use App\Todo;
use App\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class GenerateDailyTodo extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:generatedailytodo {userId?} {--force}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Generates daily TodoList for every user or a specific user
                            {userId : Email id of the user if the command is to be run for s specific user}
                            {--force : Boolean which describes if the command should forcely rebuild the todolist }';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $userId = $this->argument("userId");
        $shouldBeForced = $this->option("force");

        $today = now();
        $this->line("Generating Todo list for " . $today);
        //  get users
        if ($userId) {
            $user = User::where('email', $userId)->first();
            if ($user) { // if user exists
                $users = [$user]; // add a single user to the group
            } else {
                // if user does not exist, return 
                return $this->line("!!! User not found !!!");
            }
        } else {
            $users = User::all();
        }
        // create todolist foreach user
        foreach ($users as $user) {
            try {
                // if --force is true
                if($shouldBeForced) {
                    // remove previous todolist for today
                    Todo::whereDate('date', $today)->where('userId', $user->email)->delete();
                    // create todo list
                    $userTodoList = generateTodoListByUserId($user->email);

                    // get currentCourse number
                    // save user todo
                    foreach ($userTodoList["activities"] as $todo) {
                        Todo::create(array_merge([
                            'date' => $today,
                            'userId' => $user->email,
                        ], $todo));
                    }
                    $this->line("Todo created for " . $user->email . " with force!");
                } else {
                    // check if todo is already created, if not forced
                    if (!Todo::whereDate('date', $today)->where('userId', $user->email)->exists()) {
                        // if there is no previous todo, create
                        $userTodoList = generateTodoListByUserId($user->email);
                        // save user todo
                        foreach ($userTodoList["activities"] as $todo) {
                            Todo::create(array_merge([
                                'date' => $today,
                                'userId' => $user->email,
                            ], $todo));
                        }
                        $this->line("Todo created for " . $user->email . "!");
                    } else {
                        // todo already exists, leave as is
                        $this->line("Todo already defined for " . $user->email . "!");
                    }
                }
            } catch (\Exception $e) {
                \Log::error('php artisan cron:generatedailytodo failed', [$e]);
                $this->line("Failed for " . $user->email . "!");
            }
        }


        $this->line("Generated Todo list for " . $today);
    }
}
