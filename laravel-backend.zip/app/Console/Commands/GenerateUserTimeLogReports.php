<?php

namespace App\Console\Commands;

use App\UserTimeLogReport;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class GenerateUserTimeLogReports extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'generate:usertimelogreports';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Creates User Time Log Report';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {

        // remove old records
        UserTimeLogReport::truncate();


        // /fetch all the data by group
        $cases = [
            1 => 'lesson',
            2 => 'route',
            3 => 'module'
        ];

        //  for each case calculate the report
        foreach ($cases as $caseId => $case) {

            // select the columns according to the case
            switch ($case) {
                case "module":
                    $columns = "moduleNo, courseNo";
                    break;
                case "route":
                    $columns = "moduleNo, courseNo, routeNo";
                    break;
                default:
                    $columns = "moduleNo, courseNo, routeNo, lessonNo";
                    break;
            }

            // generate query
            $query = DB::table('user_time_logs')
                ->selectRaw("employeecourse.userId, dateRegistered, {$columns}, sec_to_time(sum(time_to_sec(timediff(outTime, inTime)))) as time_spent");


            // add join for registration date
            $query->join('employeecourse', function ($join) {
                $join->on(DB::raw('BINARY employeecourse.courseNumber'), '=', DB::raw('BINARY user_time_logs.courseNo'));
                $join->on(DB::raw('BINARY employeecourse.userId'), '=', DB::raw('BINARY user_time_logs.userId'));
            });

            // use group by according to case
            switch ($case) {
                case "module":
                    $query->groupBy('userId', 'moduleNo');
                    break;
                case "route":
                    $query->groupBy('userId', 'moduleNo', 'routeNo');
                    break;
                default:
                    $query->groupBy('userId', 'moduleNo', 'routeNo', 'lessonNo');
                    break;
            }

            // initiate the fetch
            $data = with(clone $query)->get();

            // add caseId to every record
            $data->map(function ($item, $key) use ($caseId) {
                $item->groupBy = $caseId;
                // save every record to user_report_time_log_reports
                UserTimeLogReport::create((array) $item);
            });


            $this->line("Generated user time log report for " . $case);
        }
    }
}
