<?php

namespace App\Console\Commands;

use App\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class HashUsers extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'utility:hash {table} {column}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Hashes the passwords in bcrypt table';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->inform('Hashing userLogin table ...');
        $table = $this->argument('table');
        $column = $this->argument('column');
        $records = DB::table($table)->get(['password', 'id']);
        foreach ($records as $record) {
            if (Str::startsWith($record->password, '$2') && $record->password > 59) {
                // Skipped
            } else {
                User::find($record->id)->update([
                    'password' => bcrypt($record->password)
                ]);
            }
        }
        $this->success("User login hash successful!");
    }

    public function inform($string)
    {
        $this->line("<fg=cyan>INFO: <fg=default>{$string}</>");
    }
    public function danger($string)
    {
        $this->line("<fg=red>ERROR: <fg=default>{$string}</>");
    }

    public function success($string)
    {
        $this->line("<fg=green>SUCCESS: <fg=default>{$string}</>");
    }

    public function warning($string)
    {
        $this->line("<fg=yellow>WARNING: <fg=default>{$string}</>");
    }
}
