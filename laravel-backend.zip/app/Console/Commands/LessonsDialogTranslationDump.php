<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use DB;
use Illuminate\Support\Facades\Storage;

class LessonsDialogTranslationDump extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'LessonsDialogTranslationDump:cron';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        
        $this->info("LessonsDialogTranslationDump is started fine!");

        
        $q = "select id, moduleno, routeno, lesson_no, dialog_translation from `lessons` where id!='' order by id ";


        $assessment = array(); 
           
        $query = DB::select(DB::raw($q)); 
        
        
        foreach($query as $row){

            $dialog_translation = explode("\n", $row->dialog_translation);
            $dialog_translation = str_replace("\r", "", $dialog_translation);


            foreach ($dialog_translation as $value) {  
                
                //$text = explode(";", $value);

                echo $row->id."\r\n";

                echo $value."\r\n";

                echo "\r\n\r\n\r\n\r\n";

                


                if($value!="")
                {

                    $cards = "INSERT INTO `lessons_dialog_translation` (`id`, `lesssonId`, `moduleNo`, `routeNo`, `lessonNo`, `dialog_translation`, `created_at`) VALUES (NULL, '".$row->id."', '".$row->moduleno."', '".$row->routeno."', '".$row->lesson_no."', '".addslashes($value)."', now())";

                    DB::select(DB::raw($cards)); 

                    $this->info('LessonsDialogTranslation dumped successfully!');

                } 

                
            
                
                

            }    

                     


        }   

        

              
        $this->info('LessonsDialogTranslationDump Cummand Run successfully!');

    }
}
