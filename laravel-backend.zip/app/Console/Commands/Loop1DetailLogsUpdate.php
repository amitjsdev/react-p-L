<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class Loop1DetailLogsUpdate extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:updateloop1detaillogs';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Update loop 1 detail logs';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->line('Update loop 1 detail logs');

        // get all modules and for each module 
        foreach (DB::table('module')->get() as $module) {
            // get moduleno
            $moduleNo = $module->moduleno;
            // get first route for the module
            $route = DB::table('route')
                ->where('moduleno', $moduleNo)->orderBy('routeno')->first();
            if (!$route) continue;
            // get route no
            $routeNo = $route->routeno;
            // get the distinct records from useractivitylog_api for the same but for every user
            
            $userActivities = DB::table('useractivitylog_api')
                ->selectRaw('userId, sum(activityType) as sum')
                ->distinct('moduleNo, lessonNo, levelNo, userId, activityType')
                ->where('moduleNo', $moduleNo)
                ->where('routeNo', $routeNo)
                ->where('levelNo', 1)
                ->groupBy('userId')
                ->get();

            // filter users according to their activity
            $actTypeA = 0; // Activity Type Sum 1-5
            $actTypeB = 0; // Activity Type Sum 6-11
            $actTypeC = 0; // Activity Type Sum 12-17
            $actTypeD = 0; // Activity Type Sum 18+
            foreach ($userActivities as $userActivity) {
                $sum = $userActivity->sum;
                if ($sum > 17) {
                    $actTypeD++;
                } else if ($sum > 11) {
                    $actTypeC++;
                } else if ($sum > 5) {
                    $actTypeB++;
                } else {
                    $actTypeA++;
                }
            }

            DB::table('loop1detail_logs')->updateOrInsert([
                'moduleNumber' => $moduleNo,
            ], [
                'moduleNumber' => $moduleNo,
                'actTypeA' => $actTypeA,
                'actTypeB' => $actTypeB,
                'actTypeC' => $actTypeC,
                'actTypeD' => $actTypeD,
                'total' => $actTypeA + $actTypeB + $actTypeC + $actTypeD,
                'created_at' => new \DateTime,
                'updated_at' => new \DateTime,
            ]);
            $this->line("Updated loop1detail_logs for moduleno " . $moduleNo);
        }
        $this->line("Updated " . \DB::table('loop1detail_logs')->count() . "records!");
        $this->line('Update loop 1 detail logs complete!');
    }
}
