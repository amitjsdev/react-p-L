<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class Loop1DetailLogsUpdateDates extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:updateloop1detaillogsdates';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Update loop 1 detail logs';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->line('Update loop 1 detail logs');

        // get all modules and for each module 
        foreach (DB::table('module')->get() as $module) {
            // get moduleno
            $moduleNo = $module->moduleno;

            //if($moduleNo!=0) continue;

            // get first route for the module
            $route = DB::table('route')
                ->where('moduleno', $moduleNo)->orderBy('routeno')->first();

            if (!$route) continue;
            // get route no
            $routeNo = $route->routeno;
            // get the distinct records from useractivitylog_api for the same but for every user

            $userActivities = DB::table('useractivitylog_api AS ual')
                ->selectRaw('ual.userId, SUM(ual.activityType) as sum, ec.dateRegistered, e.mobileOS')
                ->distinct('ual.moduleNo, ual.lessonNo, ual.levelNo, ual.userId, ual.activityType')
                ->join('employee AS e', 'e.userId', '=', 'ual.userId')
                ->join('employeecourse AS ec', 'ec.userId', '=', 'ual.userId')
                ->where('ual.moduleNo', $moduleNo)
                ->where('ual.routeNo', $routeNo)
                ->where('ual.levelNo', 1)
                //->where('ual.userId', 'margaritabb63@gmail.com') 
                ->groupBy('ual.userId')
                ->get();
            
            /*$userActivities = DB::table('useractivitylog_api')
                ->selectRaw('userId, sum(activityType) as sum')
                ->distinct('moduleNo, lessonNo, levelNo, userId, activityType')
                ->where('moduleNo', $moduleNo)
                ->where('routeNo', $routeNo)
                ->where('levelNo', 1)
                ->groupBy('userId')
                ->get();*/

            // filter users according to their activity
            /*
            $actTypeA = 0; // Activity Type Sum 1-5
            $actTypeB = 0; // Activity Type Sum 6-11
            $actTypeC = 0; // Activity Type Sum 12-17
            $actTypeD = 0; // Activity Type Sum 18+
            */

            foreach ($userActivities as $userActivity) {

                print_r($userActivity);


                // filter users according to their activity
                $actTypeA = 0; // Activity Type Sum 1-5
                $actTypeB = 0; // Activity Type Sum 6-11
                $actTypeC = 0; // Activity Type Sum 12-17
                $actTypeD = 0; // Activity Type Sum 18+

                $sum = $userActivity->sum;

                $dateRegistered = $userActivity->dateRegistered;
                $mobileOS = $userActivity->mobileOS;
                $userId = $userActivity->userId;

                if ($sum > 17) {
                    $actTypeD=1;
                } else if ($sum > 11) {
                    $actTypeC=1;
                } else if ($sum > 5) {
                    $actTypeB=1;
                } else {
                    $actTypeA=1;
                }


                DB::table('loop1detail_logs_dates')->insert(
                [
                    'moduleNumber' => $moduleNo,
                    'dateRegistered' => $dateRegistered,
                    'userId' => $userId,
                    'mobileOS' => $mobileOS,
                    'actTypeA' => $actTypeA,
                    'actTypeB' => $actTypeB,
                    'actTypeC' => $actTypeC,
                    'actTypeD' => $actTypeD,
                    'total' => $actTypeA + $actTypeB + $actTypeC + $actTypeD,
                    'created_at' => new \DateTime,
                    'updated_at' => new \DateTime,
                ]);


            }

            
            

            /*DB::table('loop1detail_logs_dates')->updateOrInsert([
                'moduleNumber' => $moduleNo,
            ], [
                'moduleNumber' => $moduleNo,
                'actTypeA' => $actTypeA,
                'actTypeB' => $actTypeB,
                'actTypeC' => $actTypeC,
                'actTypeD' => $actTypeD,
                'total' => $actTypeA + $actTypeB + $actTypeC + $actTypeD,
                'created_at' => new \DateTime,
                'updated_at' => new \DateTime,
            ]);*/


            $this->line("Updated loop1detail_logs_dates for moduleno " . $moduleNo);
        }
        $this->line("Updated " . \DB::table('loop1detail_logs_dates')->count() . "records!");
        $this->line('Update loop 1 detail logs complete!');
    }
}
