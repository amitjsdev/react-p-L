<?php

namespace App\Console\Commands;

use App\Http\Controllers\LeaderBoardController;
use App\UserDailyGoalLog;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class NotifyLeadersOfLeaderBoard extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'taplingua:notifyleadersofleaderboard {--test}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Notify the previous winners about their win';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    public $testUsers = [
        [
            "userId" => "demo_bosch@taplingua.com",
            "current" => 100,
        ],
        [
            "userId" => "exercises@taplingua.com",
            "current" => 100,
        ],
        [
            "userId" => "thefallenmerc@taplingua.com",
            "current" => 100,
        ],
    ];

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $isTest = $this->option('test');
        // this cron will run at 00:01 everyday, so we have to check for yesterday
        // check daily winner for yesterday
        $startDate = today()->subDay()->startOfDay();
        // daily winners list
        $dailyWinners = $isTest ? $this->testUsers : $this->getLeaderboardByDateRange($startDate, today()->subDay()->endOfDay(), 3);

        $rank = 1;
        foreach ($dailyWinners as $winner) {
            // TODO: notify the user
            $this->line($winner['userId'] . " sent message to " . $rank . " for date " . $startDate . " in type daily.");
            $rank++;
        }

        // check for weekly winner if today is saturday
        if (today()->dayOfWeek === 6) {
            // today is saturday, so start is yesterday minus a week start of day and end is yesterday endof the day
            $startDate = today()->subWeek()->startOfDay();
            $endDate = today()->subDay()->endOfDay();
            // weekly winners list
            $weeklyWinners = $isTest ? $this->testUsers : $this->getLeaderboardByDateRange($startDate, $endDate, 3);
            $rank = 1;
            foreach ($weeklyWinners as $winner) {
                // TODO: notify the user
                $this->line($winner['userId'] . " logged with rank " . $rank . " for date " . $startDate . " in type weekly.");
                $rank++;
            }
        }
    }

    private function getLeaderboardByDateRange($startDate, $endDate, $cutoff = 1)
    {
        $leaderboard = UserDailyGoalLog::select('userId', DB::raw('sum(points) as current'))
            ->whereNotIn('userId', LeaderBoardController::emailExceptions)
            ->whereBetween('dated', [$startDate, $endDate]);

        // get top 50 records
        $leaderboard = $leaderboard
            ->groupBy('userId')
            ->orderBy('current', 'desc')
            ->take($cutoff)
            ->get();

        return $leaderboard;
    }
}
