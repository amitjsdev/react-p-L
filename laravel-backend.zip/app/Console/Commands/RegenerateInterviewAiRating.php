<?php

namespace App\Console\Commands;

use App\InterviewVideo;
use App\Jobs\GenerateInterviewAiRating;
use Illuminate\Console\Command;

class RegenerateInterviewAiRating extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'airating:rerun {attemptId}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Rerun the ai rating script on a specific attempt id';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        // get the attempt id
        $attemptId = $this->argument('attemptId');

        // get interview video 
        $interviewVideo = InterviewVideo::find($attemptId);

        if (!$interviewVideo) {
            $this->line("Interview video with attemptId " . $attemptId . " not found!");
            return;
        }
        if (!$interviewVideo->reviewFileLocation) {
            $interviewVideo->reviewStatus = 3;
            $interviewVideo->save();
            $this->line("Interview video reviewFileLocation missing with attemptId " . $attemptId . "!");
            return;
        }


        $this->line("Dispatching the job for attemptId " . $attemptId);

        GenerateInterviewAiRating::dispatch($attemptId, $interviewVideo->reviewFileLocation, true);
        $this->line("Dispatched the job for attemptId " . $attemptId);
        return 0;
    }
}
