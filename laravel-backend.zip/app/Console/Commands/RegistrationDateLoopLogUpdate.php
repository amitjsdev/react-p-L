<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class RegistrationDateLoopLogUpdate extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:updateregistrationdatelooplog';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Updates registration date loop logs';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->line("Updating  registration date loop logs table");
        $counts = DB::table('employeecourse')
            ->selectRaw('dateRegistered, count(i_d) as count, loopStatus')
            ->groupBy('dateRegistered')
            ->get(); // get all distict employees

        $loopOneUsers = 0;
        $loopTwoUsers = 0;
        $loopThreeUsers = 0;
        $aheadOfTimes = 0;

        foreach ($counts as $count) {

        $loopOneUsers = 0;
        $loopTwoUsers = 0;
        $loopThreeUsers = 0;
        $aheadOfTimes = 0;

            switch ($count->loopStatus) {
                case 1: // its loopOneUser
                    $loopOneUsers = $count->count;
                    break;
                case 2: // its loopTwoUsers
                    $loopTwoUsers = $count->count;
                    break;
                case 3: // its loopThreeUsers
                    $loopThreeUsers = $count->count;
                    break;
                case 10: // its aheadOfTimes
                    $aheadOfTimes = $count->count;
                    break;
                default:
                    break;
            }
            DB::table('user_registration_loop_logs')->updateOrInsert([
                'registrationDate' => $count->dateRegistered,
            ], [
                'registrationDate' => $count->dateRegistered,
                'loopOneUsers' => $loopOneUsers,
                'loopTwoUsers' => $loopTwoUsers,
                'loopThreeUsers' => $loopThreeUsers,
                'aheadOfTimes' => $aheadOfTimes,
                'created_at' => new \DateTime,
                'updated_at' => new \DateTime,
            ]);
            $this->line("Updated record for date " . $count->dateRegistered);
        }
        $this->line("Updating  registration date loop logs table complete");
        $this->line("Total Records: " . DB::table('user_registration_loop_logs')->count());
    }
}
