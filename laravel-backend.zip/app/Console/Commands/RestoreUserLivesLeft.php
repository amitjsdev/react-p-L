<?php

namespace App\Console\Commands;

use App\Employee;
use App\Jobs\SendLivesReplenishedEmail;
use App\Jobs\SendLivesReplenishedPush;
use Illuminate\Console\Command;

class RestoreUserLivesLeft extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'taplingua:restoreuserlivesleft {userId?}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Restores the value of dailyLivesLeft with the value of dailyLivesCount
                                {userId: The id of user, incase need to update only 1}                            
    ';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $userId = $this->argument('userId');

        if ($userId) {
            $users = Employee::where('userId', $userId)->get();
        } else {
            $users = Employee::all();
        }

        foreach ($users as $user) {
            $oldDailyLivesLeft = $user->dailyLivesLeft;
            $oldReplenishesLeft = $user->replenishesLeft;
            $user->dailyLivesLeft = $user->dailyLivesCount;
            $user->replenishesLeft = $user->replenishesCount;
            $this->line("[" . $user->userId . "]: Daily Lives Left update to " . $user->dailyLivesLeft);
            $this->line("[" . $user->userId . "]: Replenishes Left update to " . $user->replenishesLeft);
            if ($user->dailyLivesLeft !== $oldDailyLivesLeft && (int) $oldDailyLivesLeft === 0) {
                // push will only be send in case of lives reset to 0
                // send replenished push
                SendLivesReplenishedPush::dispatch($user->userId)
                    ->delay(getTimeInUserTimezone('08:00', $user));
                // send replenished email
                SendLivesReplenishedEmail::dispatch($user->userId)
                    ->delay(getTimeInUserTimezone('08:00', $user));
                // save the lives
                $user->save();
            }
        }
    }
}
