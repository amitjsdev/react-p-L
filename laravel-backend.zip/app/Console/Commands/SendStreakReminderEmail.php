<?php

namespace App\Console\Commands;

use App\Jobs\SendMailToSubscriber;
use Carbon\Carbon;
use Illuminate\Console\Command;

class SendStreakReminderEmail extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:sendstreakreminderemails {userId?} {type=1}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sends every user streak reminder emails
                                {userId: if you wanna send to a single user}
                                {type: the type of reminder to send}
    ';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        return 1;
        $this->line("Starting to send email reminders!");
        // get user id
        $userId = $this->argument('userId');
        $type = $this->argument('type');
        // if userId is avalaible fetch employee for it
        if ($userId) {
            $users = \App\Employee::where('userId', $userId)->get();
        } else {
            // else fetch all employees
            $users = \App\Employee::whereDate('accountCreationDate', '>=', Carbon::createFromDate(2020, 8, 1))->get();
        }


        $label = "Yes, begin fun learning now!!";
        $message = "Learning a language is fun and easy, do just 2 minutes a day and be a native in no time! 
    Our motto: A little bit of play everyday!!";
        $campaign_id = "streak-reminder-email";

        // foreach employee send the mail at their local time
        foreach($users as $employee) {

            // make mail
            $reminderMail = new \App\Mail\DailyStreakReminder1($employee, $label, $campaign_id, $message);

            // delay mail
            try {
                SendMailToSubscriber::dispatch($reminderMail, $employee->userId)
                ->delay(
                        Carbon::createFromTimeString(
                            "08:00",
                            $employee->timezone ?? "GMT+1"
                        )
                    );
                $this->line("[" . $employee->userId . "] scheduled at 8AM " . $employee->timezone);
            } catch (\Throwable $th) {
                $this->line("[" . $employee->userId . "] badtimezone!");
            }
        }


        return 1;
    }
}
