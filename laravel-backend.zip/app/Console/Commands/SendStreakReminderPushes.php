<?php

namespace App\Console\Commands;

use App\Employee;
use App\Jobs\SendPushForNewStrategy;
use Carbon\Carbon;
use Illuminate\Console\Command;

class SendStreakReminderPushes extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:sendstreakreminderpushes {userId?} {type=1}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sends every user streak reminder pushes
                                {userId: if you wanna send to a single user}
                                {type: the type of reminder to send}';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $this->line("Starting to send email reminders!");
        // get user id
        $userId = $this->argument('userId');
        $type = $this->argument('type');
        // if userId is avalaible fetch employee for it
        if ($userId) {
            $users = \App\Employee::where('userId', $userId)->get();
        } else {
            // else fetch all employees
            $users = \App\Employee::whereDate('accountCreationDate', '>=', Carbon::createFromDate(2020, 8, 1))->get();
        }

        // foreach employee send the mail at their local time
        foreach ($users as $employee) {
            $this->schedulePush($employee);
        }


        return 1;
    }


    private function schedulePush(Employee $employee) {

        // send the five pushes at their time tomorrow
        // morning push
        $this->sendStrategyPush(
            $employee,
            SendPushForNewStrategy::NEWUSERMORNINGPUSH1,
            SendPushForNewStrategy::NEWUSERMORNINGPUSH1_TIME
        );
        // // lunch push
        // $this->sendStrategyPush(
        //     $employee,
        //     SendPushForNewStrategy::NEWUSERLUNCHPUSH,
        //     SendPushForNewStrategy::NEWUSERLUNCHPUSH_TIME
        // );
        // // night push
        // $this->sendStrategyPush(
        //     $employee,
        //     SendPushForNewStrategy::NEWUSEREVENINGPUSH,
        //     SendPushForNewStrategy::NEWUSEREVENINGPUSH_TIME
        // );

        $this->line("[" . $employee->userId . "] scheduled!");
    }

    // generate and send strategy push
    private function sendStrategyPush(Employee $employee, String $campaignId, String $time)
    {
        try {
            SendPushForNewStrategy::dispatch(
                $employee->userId,
                $campaignId
            )
                ->delay($this->getTime($time, $employee));
        } catch (\Throwable $th) {
            $this->line("[" . $employee->userId . "] badtimezone!");
        }
    }

    private function getTime(String $time, Employee $employee)
    {
        return Carbon::createFromTimeString(
            '11:00', // set streak reminder time to 11 am
            $employee->timezone ?? "GMT+1"
        );
    }
}
