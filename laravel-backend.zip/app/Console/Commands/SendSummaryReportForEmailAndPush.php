<?php

namespace App\Console\Commands;

use App\Mail\SummaryReportForEmailAndPush;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Mail;

class SendSummaryReportForEmailAndPush extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'taplingua:sendsummaryreportforemailandpush';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sends summary report for email and push for the day to santanu';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $date = today();

        $emails = [
            "shubham@truetechpro.com",
            "santanu@taplingua.com",
            "dharmin.polra@taplingua.com"
        ];

        Mail::to($emails)
        ->send(new SummaryReportForEmailAndPush($date));

        $this->line("Sent mail to " . implode(", ", $emails));

        return 0;
    }
}
