<?php

namespace App\Console\Commands;

use App\Employee;
use App\Jobs\SendPush;
use App\UserDailyGoalLog;
use Illuminate\Console\Command;

class SendUserPushIfStreakNotAcheived extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'taplingua:senduserpushifstreaknotacheived {userId? : a single user for which command should be run} {--test : should the users be picked from test field in db}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send User Push If Streak (25 daily points) for today is not achieved by user';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $this->line("Streak check started!");
        // get user id
        $userId = $this->argument('userId');
        $test = $this->option('test');
        // if userId is avalaible fetch employee for it
        if ($userId) {
            $users = Employee::where('userId', $userId)->get();
        } else {
            // else fetch all employees
            if($test) {
                $userIds = array_filter(explode(",", __get_variable('test_users_for_streak_push') ?? ""), function ($id) { 
                    return strlen(trim($id)) > 0;
                });

                $users = Employee::whereIn('userId', $userIds)->get();
            } else {
                $users = Employee::all();
            }
        }

        $today = now();


        // foreach employee, check if usergoallog count is more than 25
        foreach ($users as $user) {
            $userId = $user->userId;

            // get total for today
            $total = UserDailyGoalLog::where('userId', $userId)
                ->whereDate('dated', $today)
                ->sum('points');

            if ($total < 25) {
                // send the push
                SendPush::dispatch($user->userId, [
                    "title" => "Don't lose your streak!",
                    "body" => "Tap now to save streak!"
                ], "push-for-unachieved-streak", null, "Don't lose your streak!", "Tap now to save streak!", true);
                $this->line("Streak reminder sent to " . $userId);
            }
        }
    }
}
