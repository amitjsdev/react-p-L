<?php

namespace App\Console\Commands;

use App\Employee;
use App\Events\CheckForBadges;
use App\Listeners\CheckForBadges as AppCheckForBadges;
use App\RoundLog;
use App\Todo;
use App\UserDailyGoalLog;
use Carbon\Carbon;
use Illuminate\Console\Command;
use \DB;

class UpdateUserStreks extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:updateuserstreaks {userId?} {--thorough} {--skipdailygoalreset}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Updates every employees streaks by looking into the user goal attained pattern!
                            {userId : The emailId of specific user this command should run for}
                            {--thorough : Not just only increment the streak but recalculate it}
                            {--skipdailygoalreset : Dont reset daily goal}';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->line("Streak updates started!");
        // get user id
        $userId = $this->argument('userId');
        // get thorough
        $isThorough = $this->option('thorough');
        $skipGoalReset = $this->option('skipdailygoalreset');
        // if userId is avalaible fetch employee for it
        if ($userId) {
            $users = Employee::where('userId', $userId)->get();
        } else {
            // else fetch all employees
            $users = Employee::all();
        }
        $today = now();
        // foreach employee, get their max streak
        foreach ($users as $user) {
            $userId = $user->userId;

            // to store previous date for comparision
            $previousDate = null;
            $maxStreak = 0;
            $currentStreak = 0;
            $currentStreakDate = null;
            $maxStreakDate = null;

            // check if thorough or not
            if ($isThorough) {

                // get all roundlog for the current user, in ascending order
                $dailyLogs = UserDailyGoalLog::where('userId', $userId)
                    ->select('id', 'userId', 'created_at', 'dated', DB::raw('sum(points) as goal_attained'))
                    ->having('goal_attained', '>=', $user->daily_goal_total)
                    ->groupBy("dated")
                    ->orderBy("dated")
                    ->get();
                // for each round log check for streak
                foreach ($dailyLogs as $dailyLog) {
                    // if subtracting a day from today gives previousDate, that means the streak is intact.
                    // if so increase the currentStreak and check for maxStreak
                    $currentDatesPreviousDate = Carbon::parse($dailyLog->dated)->subDay();
                    // is currentdate's previous date is actually the previousDate
                    if ($currentDatesPreviousDate->eq($previousDate)) {
                        // increase currentStreak
                        $currentStreak++;
                        // set currentDate to currentStreakDate
                        $currentStreakDate = $dailyLog->dated;
                    } else {
                        // set current streak to 1
                        $currentStreak = 1;
                        // set current streak date to today
                        $currentStreakDate = $dailyLog->dated;
                    }
                    // check if maxStreak reached
                    if ($currentStreak > $maxStreak) {
                        // set max streak to current streak
                        $maxStreak = $currentStreak;
                        // set maxStreakDate to currentStreakDate
                        $maxStreakDate = $currentStreakDate;
                    }
                    // set previous day to today
                    $previousDate = Carbon::parse($dailyLog->dated);
                }

                // check if the last data of round log was yesterday
                if (count($dailyLogs) > 0) {
                    if (!Carbon::parse($dailyLogs[count($dailyLogs) - 1]->dated)->gte(today()->subDay())) {
                        $currentStreak = 0;
                        $currentStreakDate = null;
                    }
                }
            } else {
                // get the round log of yesterday
                $goalAttainedYesterday = UserDailyGoalLog::where('userId', $userId)
                    ->select('id', 'userId', 'created_at', 'dated', DB::raw('sum(points) as goal_attained'))
                    ->having('goal_attained', '>=', $user->daily_goal_total)
                    ->whereDate('dated', Carbon::yesterday())
                    ->groupBy("dated")
                    ->orderBy("dated", 'desc')
                    ->first();
                // get the round log of today
                $goalAttainedToday = UserDailyGoalLog::where('userId', $userId)
                    ->select('id', 'userId', 'created_at', 'dated', DB::raw('sum(points) as goal_attained'))
                    ->having('goal_attained', '>=', $user->daily_goal_total)
                    ->whereDate('dated', Carbon::today())
                    ->groupBy("dated")
                    ->orderBy("dated", 'desc')
                    ->first();
                // if both logs exist, add one to last streak
                if ($goalAttainedYesterday) {
                    if ($goalAttainedToday) {
                        // if goal attained today already, keep it same
                        if($goalAttainedToday->dated === $user->currentStreakDate) {
                            $currentStreak = $user->currentStreak;
                        } else {
                            $currentStreak = $user->currentStreak + 1;
                        }
                        $currentStreakDate = $goalAttainedToday->dated;
                    } else {
                        $currentStreak = $user->currentStreak;
                        $currentStreakDate = $goalAttainedYesterday->dated;
                    }
                } else {
                    if($goalAttainedToday) {
                        // no streak till yesterday, got streak today, set it to 1
                        $currentStreak = 1;
                        $currentStreakDate = today();
                    } else {
                        $currentStreak = 0;
                        $currentStreakDate = null;
                    }
                }
            }
            // if currentstreak is more than max 
            if ($currentStreak > $maxStreak) {
                $maxStreak = $currentStreak;
                $maxStreakDate = $currentStreakDate;
            } else {
                // let the max streak be
                $maxStreak = $user->maxStreak < $maxStreak ? $maxStreak : $user->maxStreak;
                $maxStreakDate = $user->maxStreak < $maxStreak ? $maxStreakDate : $user->maxStreakDate;
            }
            // set current streak and max streak to empoyee table
            $user->currentStreak = $currentStreak;
            $user->currentStreakDate = $currentStreakDate;
            $user->maxStreak = $maxStreak;
            $user->maxStreakDate = $maxStreakDate;
            // reset user daily_goal_attained as well
            if(!$skipGoalReset) {
                $user->daily_goal_attained = 0;
            }
            // reset user daily lives left
            $user->dailyLivesLeft = $user->dailyLivesCount;
            $user->save();
            // check for badge
            event(new CheckForBadges([
                "eventType" => AppCheckForBadges::$streak,
                "courseNumber" => null,
                "userId" => $userId,
                "maxStreak" => $maxStreak,
            ]));
            $this->line("Streak updated to {$currentStreak} for user " . $userId);
        }
        $this->line("Streak updates complete!");
    }
}
