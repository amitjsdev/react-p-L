<?php

namespace App\Console\Commands;

use App\Course;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class UserLoopLogUpdate extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:updateuserlooplog';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Updates user loop log';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->line('Updating table user_loop_logs');
        $employeeCourses = DB::table('employeecourse')
            ->distinct('courseNumber')
            ->where('dateRegistered', '>=', '2020-04-15')
            ->get(); // get employee courses
        foreach ($employeeCourses as $employeeCourse) {

            $courseNumber = $employeeCourse->courseNumber;

            $course = Course::where('courseNumber', $employeeCourse->courseNumber)->first(); // get course

            if (!$course) continue; // if course not found continue

            $moduleNumber = $course->moduleNumber;


            $counts = DB::table('employeecourse')
                ->selectRaw('courseNumber, loopStatus, count(*) as count')
                ->where('courseNumber', $courseNumber)
                ->groupBy('loopStatus')->get();

            $loopOneUsers = 0;
            $loopTwoUsers = 0;
            $loopThreeUsers = 0;
            $aheadOfTimes = 0;

            foreach ($counts as $count) {
                switch ($count->loopStatus) {
                    case 1: // its loopOneUser
                        $loopOneUsers = $count->count;
                        break;
                    case 2: // its loopTwoUsers
                        $loopTwoUsers = $count->count;
                        break;
                    case 3: // its loopThreeUsers
                        $loopThreeUsers = $count->count;
                        break;
                    case 10: // its aheadOfTimes
                        $aheadOfTimes = $count->count;
                        break;
                    default:
                        break;
                }
                DB::table('user_loop_logs')->insert(
                    [
                        'date' => now()->subDay(), // get log for yesterday
                        'moduleNumber' => $moduleNumber,
                        'courseNumber' => $courseNumber,
                        'loopOneUsers' => $loopOneUsers,
                        'loopTwoUsers' => $loopTwoUsers,
                        'loopThreeUsers' => $loopThreeUsers,
                        'aheadOfTimes' => $aheadOfTimes,
                    ]
                );

                $this->line('Updated table user_loop_logs for courseNumber ' . $courseNumber);
            }
        }
        $this->line('Updating table user_loop_logs completing');
    }
}
