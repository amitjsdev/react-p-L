<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use DB;
use Illuminate\Support\Facades\Storage;

class employeeCourseJsonWithEmail extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'employeeCourseJsonWithEmail:cron';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        
        $this->info("employeeCourseJsonWithEmail is started fine!");

        
        $employeeCourseJson = array();

        //$sql = "SELECT a.*, b.moduleNumber FROM  `employeecourse` a Join courses b on a.courseNumber = b.courseNumber WHERE  a.userId LIKE  '" . $userId . "'";

        //$sql = "SELECT a.*, b.moduleNumber FROM  `employeecourse` a Join courses b on a.courseNumber = b.courseNumber";

        $sql = "SELECT a.*, b.moduleNumber, e.mobileOS, e.CountryCode, CONCAT(FirstName, ' ', LastName) AS userName FROM  `employeecourse` a Join courses b on a.courseNumber = b.courseNumber Join employee e on e.userId = a.userId WHERE a.dateRegistered >= '2020-04-15'";


        $query = DB::select(DB::raw($sql));

        if (sizeof($query) > 0) {

            foreach ($query as $rows) {

                $userId = $rows->userId;

                $modName = getModuleNameByCourse($rows->moduleNumber);

                //$getModuleNameByCourseInfo = getModuleNameByCourseInfo($rows->moduleNumber);

                //print_r($getModuleNameByCourseInfo);

                //echo $getModuleNameByCourseInfo->long_description." pppppp";

                ///$modNameLong = $getModuleNameByCourseInfo['long_description'] ?? '';

                ///$toLanguage = $getModuleNameByCourseInfo['tolanguage'] ?? '';

                $rows->moduleName = $modName;

                ////$rows->wordcount = cards_words_count($rows->moduleNumber);

                //$rows->long_description = $modNameLong;

                //$rows->to_language = $toLanguage;
                
                $rows->loopState = $rows->loopState ?? '';


                $rows->coursePercent = coursePercent($rows->moduleNumber, $userId);


                $rows->module_lesson_count = module_lesson_count($rows->moduleNumber);


                $rows->routeCount = routeCount($rows->moduleNumber);




                $sqlR = "SELECT * FROM `route` where moduleno = '" . $rows->moduleNumber . "'  and status = '1' order by description ";


                $routes = DB::select(DB::raw($sqlR));


                $Routes = array();

                $j = 1;

                $Lessons = array();

                foreach ($routes as $rot) {


                    //// filter based on route Numbers  
                    // filter
                    /*if(!empty($routeNumberArr))
                {
                
                if(!in_array($rot['routeno'], $routeNumberArr)) continue;

                } */

                    //$Routes[] = $rot['description'];

                    $Levels = array();

                    /**for ($i = 1; $i <= 5; $i++) {



                        $sql1 = "SELECT distinct moduleNo, routeNo, levelNo, lessonNo FROM `useractivitylog_api` where moduleNo = '" . $rows->moduleNumber . "' and routeNo = '" . $rot->routeno . "' and levelNo = '" . $j . "' and userId = '" . $userId . "' order by moduleNo, routeNo, levelNo, lessonNo";




                        $result1 = DB::select(DB::raw($sql1));

                        


                        if (sizeof($result1) > 0) {

                            $Lessons = array();

                            foreach ($result1 as $rws) {

                                $Lessons[] = array("Lesson " . $rws->lessonNo => "33");
                            }
                        } else { 

                        }



                        $Levels["Level " . $j] = array("levelPercent" => levelPercent($rows->moduleNumber, $rot->routeno, $j, $userId), "Lessons" => $Lessons);


                        $j++;
                    }**/


                    //////////$Routes[$rot->description] = array("routePercent" => routePercent($rows->moduleNumber, $rot->routeno, $userId), "Levels" => $Levels);

                    $Routes[] = routePercentOneTwoThree($rows->moduleNumber, $rot->routeno, $userId);

                    //$Routes[$rot['description']] = "00";

                    //$Routes[$rot['description']]["Levels"][] = $Levels;


                }

                

                DB::table('employee_course_json_with_email')->updateOrInsert([
                        'i_d' => $rows->i_d,
                    ], [
                        'i_d' => $rows->i_d,
                        'dateRegistered' => $rows->dateRegistered,
                        'userId' => $userId,
                        'userName' => $rows->userName,
                        'mobileOS' => $rows->mobileOS,
                        'CountryCode' => $rows->CountryCode, 
                        'courseNumber' => $rows->courseNumber,
                        'moduleNumber' => $rows->moduleNumber,
                        'moduleName' => $rows->moduleName,
                        'coursePercent' => $rows->coursePercent,
                        'module_lesson_count' => $rows->module_lesson_count,
                        'routeCount' => $rows->routeCount,
                        'loopStatus' => $rows->loopStatus,
                        'loopState' => $rows->loopState,
                        'route1Per' => isset($Routes[0])?$Routes[0]:null,
                        'route2Per' => isset($Routes[1])?$Routes[1]:null,
                        'route3Per' => isset($Routes[2])?$Routes[2]:null,
                        'route4Per' => isset($Routes[3])?$Routes[3]:null,
                        'route5Per' => isset($Routes[4])?$Routes[4]:null,
                        'route6Per' => isset($Routes[5])?$Routes[5]:null,
                    ]);


                
                
                $this->info('Processed i_d = ' . $rows->i_d);


                /////$rows->Routes = $Routes;

                //////$employeeCourseJson[] = $rows;
            }
        }
        



             
        $this->info('employeeCourseJsonWithEmail Command Run successfully!');

    }
}
