<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use DB;
use Illuminate\Support\Facades\Storage;

class employeeRetention extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'employeeRetention:cron';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        
        $this->info("employeeRetention is started fine!");


        /* Truncate Table */

        DB::statement("TRUNCATE employee_cohort");
        DB::statement("TRUNCATE employee_cohort_count");
        DB::statement("TRUNCATE employee_cohort_size");
        DB::statement("TRUNCATE employee_cohort_retention");
        DB::statement("TRUNCATE employee_cohort_final");

        $this->info('employeeRetention Command TRUNCATE TABLE successfully!');

        /* Truncate Table */


        /// employee_cohort

        $q = "Insert into employee_cohort select DISTINCT userId, DATE(dateRegistered) as cohort_day from employeecourse where DATE(dateRegistered) >= '2020-05-25' order by 1, 2";

        DB::statement($q);

        $this->info('employeeRetention Command INSERT INTO TABLE employee_cohort successfully!');


        
        /// employee_cohort_count

        $q = "insert into employee_cohort_count select A.userId, ABS( DATEDIFF( DATE(A.activityDateFrom), C.cohort_day ) ) as day_number from useractivitylog_api A left join employee_cohort C ON A.userId = C.userId  where DATE(A.activityDateFrom) >= '2020-06-01' group by 1, 2 ";

        //$q = "insert into employee_cohort_count select A.userId, ( DATEDIFF( DATE(A.activityDateFrom), C.cohort_day ) ) as day_number from useractivitylog_api A left join employee_cohort C ON A.userId = C.userId  where DATE(A.activityDateFrom) >= '2020-06-01' and DATEDIFF( DATE(A.activityDateFrom), C.cohort_day ) > 0 group by 1, 2 ";

        DB::statement($q);

        $this->info('employeeRetention Command INSERT INTO TABLE employee_cohort_count successfully!');


        /// employee_cohort_size

        $q = "insert into employee_cohort_size select cohort_day, count(1) as num_users from employee_cohort group by 1 order by 1";

        DB::statement($q);

        $this->info('employeeRetention Command INSERT INTO TABLE employee_cohort_size successfully!');



        /// employee_cohort_retention

        $q = "insert into employee_cohort_retention select C.cohort_day, A.day_number, count(1) as num_users from employee_cohort_count A left join employee_cohort C ON A.userId = C.userId group by 1, 2";

        DB::statement($q);
        
        $this->info('employeeRetention Command INSERT INTO TABLE employee_cohort_retention successfully!');



        /// employee_cohort_final

        $q = "insert into employee_cohort_final select B.cohort_day, S.num_users as total_users, B.day_number, B.num_users * 100 / S.num_users as percentage, B.num_users as totalOnDay  from employee_cohort_retention B  left join employee_cohort_size S ON B.cohort_day = S.cohort_day  where B.cohort_day IS NOT NULL  order by 1, 3";

        DB::statement($q);

        $this->info('employeeRetention Command INSERT INTO TABLE employee_cohort_final successfully!');


        
               
             
        $this->info('employeeRetention Command Run successfully!');

    }
}
