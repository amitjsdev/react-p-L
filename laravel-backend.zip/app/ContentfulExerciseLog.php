<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ContentfulExerciseLog extends Model
{
    protected $fillable = [
        'userId',
        'questionId',
        'type',
        'additionalInfo',
        'livesLeft',
        'additionalLivesClaimed',
        'status',
    ];
}
