<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ContentfulFlashLog extends Model
{
    protected $fillable = [
        'cardId',
        'userId',
        'difficulty_level',
        'next_date',
    ];
}
