<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Course extends Model
{
    //

    protected $table = 'courses';
    protected $primaryKey = 'i_d';
    public $timestamps = false;
    protected $fillable = [
        'courseNumberOfStudents', 'numRoutes', 'holidayInCourseFlag', 'courseFlag', 'courseName', 'Company', 'holidayWeek', 'courseStartDate', 'courseEndDate', 'evaluationRequired', 
        'courseNumber', 'moduleNumber', 'courseBatch', 'weeklyEmail', 'numberOfWeeks', 'Status', 'cohort_id'
    ];

}
