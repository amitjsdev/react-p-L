<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Dialog extends Model
{
    protected $table = 'dialogs';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'lesson_id', 'moduleno', 'routeno', 'lesson_no', 'dialog_no', 'title', 'voice_id', 'voice_ssml', 'status', 'sequence'
    ];
}
