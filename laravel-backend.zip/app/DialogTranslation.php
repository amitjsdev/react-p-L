<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DialogTranslation extends Model
{
    protected $fillable = [
        "moduleNo",
        "routeNo",
        "lessonNo",
        "language",
        "translation",
    ];
}
