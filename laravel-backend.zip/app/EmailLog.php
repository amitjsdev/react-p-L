<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmailLog extends Model
{
    protected $fillable = [
        'userId', 'log_uuid', 'type', 'moduleNo', 'routeNo', 'lessonNo', 'emailSent', 'emailOpened', 'ctaClicked'
    ];

    public function getPixelUrlAttribute()
    {
        return route('pixel', ['uuid' => $this->log_uuid]);
    }
}
