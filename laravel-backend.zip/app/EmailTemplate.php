<?php

namespace App;

use App\Jobs\SendMailToSubscriber;
use App\Mail\TemplateMail;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

class EmailTemplate extends Model
{
    protected $fillable = ["template_content", "template_description", "template_subject", "template_name", "template_identifier",
        "call_to_action_type",
    "call_to_action_label", "call_to_action_screen", "call_to_action_link"];

    /**
     * Find an email template using the template_identifier
     *
     * @param String $identifier
     * @return EmailTemplate
     */
    public static function findByIdentifier(String $identifier) {
        return EmailTemplate::where('template_identifier', $identifier)->first();
    }


    /**
     * Send mail to a user
     *
     * @param Employee $user
     * @param Carbon $time
     * @return void
     */
    public function sendMail(Employee $user, Carbon $time)
    {
        return SendMailToSubscriber::dispatch(
            new TemplateMail($user->userId, $this), 
            $user->userId
        )->delay($time);
    }
}
