<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    //

    protected $table = 'employee';
    protected $primaryKey = 'i_d';
    protected $fillable = [
        'verification_code', 'subscriptionValidDate', 'CompanyCode', 'userId', 'mobileOS', 'Location', 'accountCreationDate', 'lastLoginDate', 'Mobilewcode', 'FirstName', 'CountryCode', 'activationDate',
        'LastName', 'deviceMake', 'fcmToken', 'accountActivated', 'status', 'Mobile', 'company', 'DNI', 'versionNumber', 'disable', 'versionName', 'deviceOsVersion', 'token', 'acceptedGDPR',
        'acceptedGDPRDate', 'weeklyEmail', 'altEmail', 'updatedAt', 'appUserId', 'platformPayment', 'productIdentifier', 'billingStart', 'subscriptionExpires', 'isSandbox', 'defaultLanguage', 'receiveEmails',
        'receivePush', 'receiveRemidersDay', 'receiveRemindersTime', 'languageLocale', 'deleteAccountRequested', 'currentCourse', 'currentModule', 'levelOfLanguage', 'timezone', 'gender', 'dob', 'age_range', 'reason_to_learn', 'max_daily_push', 'score', 'last_lesson', 'daily_goal_total', 'age', 'education', 'qualification', 'enforceWall', 'payWallLesson', 'payWallSummary', 'livesLessonWall', 'dailyLivesCount', 'dailyLivesLeft', 'lockedLessons', 'user_language', 'utm_source'
    ];

    public function company()
    {
        return $this->hasOne(\App\Company::class, 'Id', 'CompanyCode');
    }

    public function companyRecord()
    {
        return $this->hasOne(\App\Company::class, 'Id', 'CompanyCode');
    }

    public function user()
    {
        return $this->hasOne(\App\User::class, "email", "userId");
    }

    public function user_questions()
    {
        return $this->hasMany(UserQuestion::class, "userId", "userId");
    }

    public function daily_goal()
    {
        return $this->hasMany(UserDailyGoalLog::class, "userId", "userId");
    }

    public function time_logs()
    {
        return $this->hasMany(UserTimeLog::class, "userId", "userId");
    }

    public function getLastGoalScoredDateAttribute()
    {
        return $this->daily_goal()->orderBy('created_at', 'desc')->first()->created_at ?? null;
    }

    public function following_user_questions()
    {
        return $this->hasManyThrough(UserQuestion::class, FollowingUserQuestion::class, 'userId', 'id', 'userId', 'user_question_id');
    }

    // Thumbs Up 
    public function getDailyThumbsUpAttribute()
    {
        return UserThumbsUpLog::where('userTo', $this->userId)
            ->whereDate('created_at', today())
            ->where('type', 'daily')
            ->count();
    }

    public function getWeeklyThumbsUpAttribute()
    {
        $startOfWeek = null; // last saturday
        // check if saturday for current week has passed
        if (now()->dayOfWeek >= 6) {
            // today is saturday or more
            $startOfWeek = today()->addDays(6 - now()->dayOfWeek)->startOfDay();
            $endOfWeek = today()->addWeek()->addDays(5 - now()->dayOfWeek)->endOfDay();
        } else {
            // saturday yet to come
            $startOfWeek = today()->subWeek()->addDays(6 - now()->dayOfWeek)->startOfDay();
            $endOfWeek = today()->addDays(5 - now()->dayOfWeek)->endOfDay();
        }

        return UserThumbsUpLog::where('userTo', $this->userId)
            ->where('type', 'weekly')
            ->whereBetween('created_at', [$startOfWeek, $endOfWeek])
            ->count();
    }
}
