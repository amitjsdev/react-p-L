<?php

namespace App;
use Illuminate\Database\Eloquent\Model;
class EmployeeCourse extends Model
{
    //

    protected $table = 'employeecourse';
    protected $primaryKey = 'i_d';



}
