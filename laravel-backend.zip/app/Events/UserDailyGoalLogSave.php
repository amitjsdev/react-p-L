<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class UserDailyGoalLogSave
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $response;

    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct($response)
    {
        /* $response = [
            'message' => 'Log Saved!',
            'log' => $userDailyGoalLog,
            'daily_goal_attained' => $employee->daily_goal_attained,
            'daily_goal_total' => $employee->daily_goal_total,
            'is_daily_goal_attained' => $is_daily_goal_attained,
            'is_half_of_daily_goal_attained' => $is_half_of_daily_goal_attained,
        ]; */
        $this->response = $response;
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return \Illuminate\Broadcasting\Channel|array
     */
    public function broadcastOn()
    {
        return new PrivateChannel('channel-name');
    }
}
