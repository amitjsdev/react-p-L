<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class ExceptionLog extends Model
{
    protected $guarded = []; // YOLO

    protected static function boot()
    {
        parent::boot();

        // defining event trigger on creating record
        static::creating(function ($exceptionLog) {
            $exceptionLog->{$exceptionLog->getKeyName()} = (string) Str::uuid();
        });
    }

    public function getIncrementing()
    {
        return false;
    }

    public function getKeyType()
    {
        return 'string';
    }
}
