<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Exercise extends Model
{
    protected $table = 'exercise';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'lesson_id', 'moduleno', 'routeno', 'lesson_no', 'exercise_no', 'exercise_type_id', 'title', 'description', 'media', 'media_alt1', 'media_alt2', 'media_alt3', 
        'summary_translation', 'summary_new_format', 'image', 'status', 'sequence'
    ];
}
