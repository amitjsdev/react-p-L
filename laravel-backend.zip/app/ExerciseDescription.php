<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExerciseDescription extends Model
{
    protected $table = 'exercise_description';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'exerciseId', 'moduleNo', 'routeNo', 'lessonNo', 'exerciseNo', 'description', 'created_at'
    ];
}
