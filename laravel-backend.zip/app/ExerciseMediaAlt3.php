<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExerciseMediaAlt3 extends Model
{
    protected $table = 'exercise_media_alt3';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'exerciseId', 'moduleNo', 'routeNo', 'lessonNo', 'exerciseNo', 'media_alt3', 'created_at'
    ];
}
