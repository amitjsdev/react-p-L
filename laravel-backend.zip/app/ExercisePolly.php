<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExercisePolly extends Model
{
    protected $table = 'exercises';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'lesson_id', 'moduleno', 'routeno', 'lesson_no', 'exercise_no', 'title', 'voice_id', 'voice_ssml', 'status', 'sequence'
    ];
}
