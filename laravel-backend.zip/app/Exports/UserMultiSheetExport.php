<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;
use App\Exports\UsersExportCohortMultiSheet;


class UserMultiSheetExport implements WithMultipleSheets
{
    /**
    * @return \Illuminate\Support\Collection
    */
    private $cohorts;
    private $company_code;
    public function __construct($cohorts,$company_code){
        $this->cohorts = $cohorts;
        $this->company_code = $company_code;

    }

    public function sheets(): array
    {
        //
        $sheets = [];

        $sheets[] = new UsersExportCohortMultiSheet($this->company_code,'Summary',$this->company_code);

        for($month = 0;$month<count($this->cohorts);$month++){
if($this->cohorts[$month]->type_id != '4'){
    $sheets[] = new UsersExportCohortMultiSheet($this->cohorts[$month]->id,$this->cohorts[$month]->name,$this->company_code);

}

        }
        
        return $sheets;
    }
}
