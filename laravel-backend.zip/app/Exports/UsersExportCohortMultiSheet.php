<?php

namespace App\Exports;

use App\User;
use App\Cohort;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithColumnWidths;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithTitle;

use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Events\BeforeExport;
use Maatwebsite\Excel\Events\AfterSheet;
use Illuminate\Contracts\View\View;
use Illuminate\Contracts\Support\Responsable;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithMapping;


use App\Http\Controllers\CohortController;
use Illuminate\Http\Request;

// class UsersExport implements FromCollection, WithColumnWidths, WithStyles, WithHeadings, WithEvents
class UsersExportCohortMultiSheet implements FromView,Responsable,ShouldAutoSize,WithTitle
{
    /**
     * @return \Illuminate\Support\Collection
     */
   
     use Exportable;
     private $cohortId;
     private $cohorts;

     public function __construct( $cohortId,$cohorts,$company_code)
     {
         $this->cohortId = $cohortId;
         $this->cohorts = $cohorts;
         $this->company_code = $company_code;
     }

    //  public function collection(){

    //     return  $cohorts = Cohort::where('company_code', $request->company_code)->get();
    //     return User::with('addresses')->get();
    //  }




    //  public function query(){

    //     return  $cohorts = Cohort::where('company_code', 176)->get();
    //     // return User::query()->with('address')
    //     // ->whereYear('created_at',$this->year)
    //     // ->whereYear('created_at',$this->month);
    //  }

    //  public function map($user): array
    //  {
    //          return [
    //              $user->id,
    //              $user->email,
    //              $user->address->country,
    //              $user->created,

    //          ];
    //  }

    public function view(): View
    {
        $c =new CohortController();
        // $d = Cohort::where('company_code', 176)->get();
        $d =$c->cohortExport($this->cohortId,$this->cohorts);
        return view('cohorts', [
            'users' => $d,
            'cohort' => $this->cohorts,
        ]);
    }

    public function headings(): array
    {
        return [
            ['Response', 'Name:', '', 'Email:', '', 'Phone', '', 'Question How am I studpid'],
            ['', 'Answer', 'score', 'Answer', 'score', 'Answer', 'score', 'Answer', 'score', 'Answer', 'score'],
        ];
    }
    public function styles(Worksheet $sheet)
    {
        return [
            // Style the first row as bold text.
            1    => ['font' => ['bold' => true]],
            2    => ['font' => ['bold' => true]],

            // // Styling a specific cell by coordinate.
            // 'B2' => ['font' => ['italic' => true]],

            // // Styling an entire column.
            // 'C'  => ['font' => ['size' => 16]],
        ];
    }
    public function columnWidths(): array
    {
        return [
            'A' => 15,
            'B' => 30,
            'C' => 20,
            'D' => 30,
            'E' => 20,
            'F' => 30,
            'G' => 20,
            'H' => 30,
            'I' => 20,
        ];
    }
    public function collection()
    {
        return User::all();
    }
    public function registerEvents(): array
    {
        return [
            AfterSheet::class    => function (AfterSheet $event) {
                $event->sheet->styleCells(
                    '1',
                    [
                        // //Set border Style
                        // 'borders' => [
                        //     'outline' => [
                        //         'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THICK,
                        //         'color' => ['argb' => 'EB2B02'],
                        //     ],

                        // ],

                        // //Set font style
                        // 'font' => [
                        //     'name'      =>  'Calibri',
                        //     'size'      =>  15,
                        //     'bold'      =>  true,
                        //     'color' => ['argb' => 'EB2B02'],
                        // ],

                        //Set background style
                        'fill' => [
                            'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                            'startColor' => [
                                'rgb' => 'dff0d8',
                            ]
                        ],

                    ]
                );
                $event->sheet->styleCells(
                    '2',
                    [
                        // //Set border Style
                        // 'borders' => [
                        //     'outline' => [
                        //         'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THICK,
                        //         'color' => ['argb' => 'EB2B02'],
                        //     ],

                        // ],

                        // //Set font style
                        // 'font' => [
                        //     'name'      =>  'Calibri',
                        //     'size'      =>  15,
                        //     'bold'      =>  true,
                        //     'color' => ['argb' => 'EB2B02'],
                        // ],

                        //Set background style
                        'fill' => [
                            'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                            'startColor' => [
                                'rgb' => 'dff0d8',
                            ]
                        ],

                    ]
                );
            },
        ];
    }


    public function title(): string
    {

     return $this->cohorts;

    }
}