<?php

namespace App\Exports;

use App\User;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithColumnWidths;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\BeforeExport;
use Maatwebsite\Excel\Events\AfterSheet;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;
use App\Http\Controllers\CohortController;
use Illuminate\Http\Request;
// class UsersExport implements FromCollection, WithColumnWidths, WithStyles, WithHeadings, WithEvents
class UsersExportVpiData implements FromView
{
    /**
     * @return \Illuminate\Support\Collection
     */
    public function __construct( $cohortId,$startDate,$endDate)
    {
        $this->cohortId = $cohortId;
        $this->startDate = $startDate;
        $this->endDate = $endDate;

    }
    public function view(): View
    {
        $c =new CohortController();
        $d =$c->vpiExportData($this->cohortId,$this->startDate,$this->endDate);
        $array = [];
    //     if(isset($d['users'])){
    //     foreach ($d['users'] as $val) { 
    //         if($val->userAnswered){
    //             $val->userAnswered= $val->userAnswered;
    //             $val->mail = $val->email;
    //             $val->name = $val->FirstName .' '.$val->LastName;
    //             $array[] =$val;

    //         }
    //     }
    // }else{
    //     foreach ($d['users'] as $val){
    //         $val->mail = $val->email;
    //         $val->name = $val->FirstName .' '.$val->LastName;
    //         $array[] = $val;
    //     }
    // }
        
        return view('vpiExport', [
            'users' => $d['users'],
            'questions' => $d['questions'],
        ]);
    }

    public function headings(): array
    {
        return [
            ['Response', 'Name:', '', 'Email:', '', 'Phone', '', 'Question How am I studpid'],
            ['', 'Answer', 'score', 'Answer', 'score', 'Answer', 'score', 'Answer', 'score', 'Answer', 'score'],
        ];
    }
    public function styles(Worksheet $sheet)
    {
        return [
            // Style the first row as bold text.
            1    => ['font' => ['bold' => true]],
            2    => ['font' => ['bold' => true]],

            // // Styling a specific cell by coordinate.
            // 'B2' => ['font' => ['italic' => true]],

            // // Styling an entire column.
            // 'C'  => ['font' => ['size' => 16]],
        ];
    }
    public function columnWidths(): array
    {
        return [
            'A' => 15,
            'B' => 30,
            'C' => 20,
            'D' => 30,
            'E' => 20,
            'F' => 30,
            'G' => 20,
            'H' => 30,
            'I' => 20,
        ];
    }
    public function collection()
    {
        return User::all();
    }
    public function registerEvents(): array
    {
        return [
            AfterSheet::class    => function (AfterSheet $event) {
                $event->sheet->styleCells(
                    '1',
                    [
                        // //Set border Style
                        // 'borders' => [
                        //     'outline' => [
                        //         'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THICK,
                        //         'color' => ['argb' => 'EB2B02'],
                        //     ],

                        // ],

                        // //Set font style
                        // 'font' => [
                        //     'name'      =>  'Calibri',
                        //     'size'      =>  15,
                        //     'bold'      =>  true,
                        //     'color' => ['argb' => 'EB2B02'],
                        // ],

                        //Set background style
                        'fill' => [
                            'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                            'startColor' => [
                                'rgb' => 'dff0d8',
                            ]
                        ],

                    ]
                );
                $event->sheet->styleCells(
                    '2',
                    [
                        // //Set border Style
                        // 'borders' => [
                        //     'outline' => [
                        //         'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THICK,
                        //         'color' => ['argb' => 'EB2B02'],
                        //     ],

                        // ],

                        // //Set font style
                        // 'font' => [
                        //     'name'      =>  'Calibri',
                        //     'size'      =>  15,
                        //     'bold'      =>  true,
                        //     'color' => ['argb' => 'EB2B02'],
                        // ],

                        //Set background style
                        'fill' => [
                            'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                            'startColor' => [
                                'rgb' => 'dff0d8',
                            ]
                        ],

                    ]
                );
            },
        ];
    }
}