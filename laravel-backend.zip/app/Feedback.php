<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Feedback extends Model
{
    protected $table = 'feedbacks';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'userId', 'userRating', 'userComments', 'created_at', 'moduleNo', 'routeNo', 'lessonNo'
    ];
}
