<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FollowingForum extends Model
{
    protected $fillable = ['userId', 'forum_id'];
}
