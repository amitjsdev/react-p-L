<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FollowingUserQuestion extends Model
{
    protected $fillable = ['userId', 'user_question_id'];
}
