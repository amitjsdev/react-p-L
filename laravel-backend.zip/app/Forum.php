<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Forum extends Model
{
    use SoftDeletes;

    protected $fillable = [
        "forumable_type",
        "forumable_id",
        "for",
        "title",
        "content",
    ];

    public function forumFor()
    {
        return $this->morphTo('forumable');
    }

    public function comments()
    {
        return $this->morphMany(\App\Comment::class, "commentable")->oldest();
    }
}
