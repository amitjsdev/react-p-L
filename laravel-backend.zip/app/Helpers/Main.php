<?php

use App\CommentView;
use App\Course;
use App\DispatchedJobLog;
use App\EmailLog;
use App\Employee;
use App\Events\CheckForBadges;
use App\Events\UserAddedToSegment;
use App\Events\UserTodoActivated;
use App\Forum;
use App\Lesson;
use App\LessonFailCount;
use App\Listeners\CheckForBadges as AppCheckForBadges;
use App\Mail\Admin\ServerErrorEmail;
use Illuminate\Support\Facades\Log;
use Lcobucci\JWT\Builder as JWTBuilder;
use Lcobucci\JWT\Parser;
use Lcobucci\JWT\Signer\Hmac\Sha256;
use Lcobucci\JWT\Signer\Key;
use App\Mail\TestAmazonSes;
use App\Module;
use App\ProgramUser;
use App\PushLog;
use App\RoundExerciseLog;
use App\RoundLog;
use App\UserActivityLog;
use App\V2Exercise;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Ramsey\Uuid\Uuid;

const KEY = 'somereallyoddkey';

if (!function_exists('createToken')) {
    /**
     * Create an encrypted token for user
     */
    function createToken($payload)
    {
        $issuedAt = time();

        $token = (new JWTBuilder())->issuedBy('taplingua')
            ->permittedFor('taplingua')
            ->issuedAt($issuedAt)
            ->canOnlyBeUsedAfter($issuedAt + 10)
            ->expiresAt($issuedAt + (60 * 60 * 24 * 365))
            ->withClaim('email', $payload['email'])
            ->getToken(new Sha256(), new Key(KEY));

        return $token;
    }
}

if (!function_exists('validateToken')) {
    function validateToken($token)
    {
        try {
            $token = (new Parser())->parse((string) $token);
            if (!$token->verify(new SHA256(), new Key(KEY))) {
                return false;
            }
            return $token;
        } catch (\Exception $e) {
            return false;
        }
    }
}


if (!function_exists('activity_logger')) {
    function activity_logger($data)
    {
        Log::channel('user_activity')->info($data);
    }
}


if (!function_exists('error_logger')) {
    function error_logger($data)
    {
        Log::channel('user_error')->error($data);
    }
}

if (!function_exists('getGUID')) {
    function getGUID()
    {
        if (function_exists('com_create_guid')) {
            return com_create_guid();
        } else {
            mt_srand((float) microtime() * 10000); //optional for php 4.2.0 and up.
            $charid = strtoupper(md5(uniqid(rand(), true)));
            $hyphen = chr(45); // "-"

            $uuid = substr($charid, 0, 8) . $hyphen
                . substr($charid, 8, 4) . $hyphen
                . substr($charid, 12, 4) . $hyphen
                . substr($charid, 16, 4) . $hyphen
                . substr($charid, 20, 12);

            return strtolower($uuid);
        }
    }
}

if (!function_exists('formatDate')) {
    function formatDate($date)
    {
        if ($date == "0000-00-00 00:00:00") {
            $date = "";
        }
        $newDate = date("d-m-Y", strtotime($date));
        return $newDate;
    }
}


if (!function_exists('removeNewLine')) {
    function removeNewLine($text)
    {

        //$text = preg_replace("/\r|\n/", " ", $text);
        $text = str_replace("\r\n", " ", $text);
        return $text;
    }
}


if (!function_exists('getModuleNameByCourse')) {
    function getModuleNameByCourse($m)
    {

        $sql = "SELECT description FROM `module` where moduleno = '" . $m . "'  and status = '1' ";

        $query = DB::select(DB::raw($sql));

        if (isset($query[0]->description) && $query[0]->description != "")
            return $query[0]->description;

        return "";
    }
}


if (!function_exists('totalEmployees')) {
    function totalEmployees($companyCode)
    {

        $sql = "select count(*) as cnt from (SELECT distinct userId FROM  `employee` WHERE CompanyCode = '" . $companyCode . "') as A";

        $query = DB::select(DB::raw($sql));

        return $query[0]->cnt;
    }
}

if (!function_exists('activeCourses')) {
    function activeCourses($companyCode)
    {

        $sql = "SELECT count(Id) as cnt FROM  `courses` WHERE Company = '" . $companyCode . "' ";

        $query = DB::select(DB::raw($sql));

        return $query[0]->cnt;
    }
}

if (!function_exists('ongoingBatches')) {
    function ongoingBatches($companyCode)
    {

        $sql = "SELECT count(Id) as cnt FROM  `companybatch` WHERE companyCode = '" . $companyCode . "' ";

        $query = DB::select(DB::raw($sql));

        return $query[0]->cnt;
    }
}


if (!function_exists('routePercent')) {
    /**
     * $m = moduleNo
     * $r = routeNo
     * $u = userId
     */
    function routePercent($m, $r, $u)
    {

        $sql = "SELECT SUM(act1.activityType) as tmp FROM (SELECT DISTINCT moduleNo, routeNo, lessonNo, activityType FROM useractivitylog_api act2 WHERE moduleNo='" . $m . "' AND routeNo='" . $r . "' AND userId = '" . $u . "') AS act1";

        $query = DB::select(DB::raw($sql));

        //print_r($query);

        $rp = $query[0]->tmp;

        $POINTS_PER_LEVEL = 15;

        $lessonCount = lessonCount($m, $r);

        $calc = $POINTS_PER_LEVEL * $lessonCount;   /// 15 * 5

        //return round(($rp / (15 * 5)) * 100);

        try {
            return round(($rp / $calc) * 100);
        } catch (\Exception $e) {
            return 1;
        }
    }
}


if (!function_exists('lessonCount')) {

    function lessonCount($moduleNumber, $routeNumber)
    {

        $LESSONS_PER_LEVEL = 3;

        //SELECT round(count(id)/3) as lessonCount FROM `lessons` WHERE moduleno='12' AND routeno='1'

        //$query = "SELECT round(count(id)/$LESSONS_PER_LEVEL) as lessonCount FROM `lessons` WHERE moduleno='".$moduleNumber."' AND routeno='".$routeNumber."'";
        //return $conn->query($query)->fetch_object()->lessonCount;

        $sql = "SELECT round(count(id)/$LESSONS_PER_LEVEL) as lessonCount FROM `lessons` WHERE moduleno='" . $moduleNumber . "' AND routeno='" . $routeNumber . "'";

        $query = DB::select(DB::raw($sql));

        return $query[0]->lessonCount;
    }
}



/// activityType (1,2,3)
if (!function_exists('routePercentOneTwoThree')) {
    /**
     * $m = moduleNo
     * $r = routeNo
     * $u = userId
     */
    function routePercentOneTwoThree($m, $r, $u)
    {

        $sql = "SELECT SUM(act1.activityType) as tmp FROM (SELECT DISTINCT moduleNo, routeNo, lessonNo, activityType FROM useractivitylog_api act2 WHERE moduleNo='" . $m . "' AND routeNo='" . $r . "' AND userId = '" . $u . "') AS act1 where  act1.activityType in (1,2,3)";

        $query = DB::select(DB::raw($sql));

        //print_r($query);

        $rp = $query[0]->tmp;

        $POINTS_PER_LEVEL = 15;

        $lessonCount = lessonCount($m, $r);

        $calc = $POINTS_PER_LEVEL * $lessonCount;   /// 15 * 5

        //return round(($rp / $calc) * 100);

        try {
            return round(($rp / $calc) * 100);
        } catch (\Exception $e) {
            return 1;
        }
    }
}





if (!function_exists('routeTime')) {
    function routeTime($m, $r, $u)
    {
        $sql = "SELECT sum(TIME_TO_SEC(activityDateTo) - TIME_TO_SEC(activityDateFrom)) as totalTime FROM `useractivitylog_api` WHERE (`activityDateFrom` != '0000-00-00 00:00:00') AND (`activityDateTo` != '0000-00-00 00:00:00') and moduleNo='" . $m . "' and routeNo ='" . $r . "' AND userId = '" . $u . "'";

        $query = DB::select(DB::raw($sql));

        //print_r($query);

        $sum = gmdate("H:i:s", $query[0]->totalTime);
        return $sum;
    }
}


if (!function_exists('routeCount')) {
    function routeCount($m)
    {
        $sql = "select id from route where status='1' and moduleno='" . $m . "' order by routeno";

        $query = DB::select(DB::raw($sql));

        $i = sizeof($query);

        return $i;
    }
}


if (!function_exists('levelPercent')) {
    function levelPercent($m, $r, $l, $u)
    {

        $sql = "SELECT distinct moduleNo, routeNo, levelNo, lessonNo FROM `useractivitylog_api` where moduleNo = '" . $m . "' and routeNo = '" . $r . "' and  levelNo = '" . $l . "' and userId = '" . $u . "' order by moduleno, routeno, levelno,lessonno";

        $query = DB::select(DB::raw($sql));

        $i = sizeof($query);

        return round(($i / 3) * 100);
    }
}

if (!function_exists('coursePercent')) {
    /**
     * Undocumented function
     *
     * @param [type] $m ModuleNumber
     * @param [type] $u UserId
     * @return void
     */
    function coursePercent($m, $u)
    {

        // get total lesson count
        $totalLessons = getLessonCountForModule($m);

        // get lessonsCompleted
        $lessonsCompleted = \App\UserActivityLog::distinct('lessonNo')->where('activityType', 3)->where('moduleNo', $m)->where('userId', $u)->orderBy('lessonNo', 'desc')->count();

        $completionPercentage = (int) ($totalLessons > 0 ? ($lessonsCompleted / $totalLessons) * 100 : 0);

        return $completionPercentage > 100 ? 100 : $completionPercentage;
    }
}


if (!function_exists('sessionTotalTime')) {
    function sessionTotalTime($userId, $moduleNo, $routeNo)
    {


        $whr = " WHERE userId='" . $userId . "'";

        if ($moduleNo != "")
            $whr .= " and moduleNo='" . $moduleNo . "'";

        if ($routeNo != "")
            $whr .= " and routeNo='" . $routeNo . "'";


        $sql = "SELECT sum(TIMESTAMPDIFF(SECOND, startTime, endTime)) as cnt FROM usersessionlog_api $whr group by userId, moduleNo, routeNo";

        $query = DB::select(DB::raw($sql));

        if (sizeof($query))
            return $query[0];

        return 0;
    }
}

if (!function_exists('getModuleNameByCourseLong')) {
    function getModuleNameByCourseLong($m)
    {

        $sql = "SELECT long_description FROM `module` where moduleno = '" . $m . "'  and status = '1' ";

        $modules = DB::select(DB::raw($sql));

        if (sizeof($modules))
            return $modules[0]->long_description;

        return "";
    }
}

if (!function_exists('getModuleNameByCourseInfo')) {
    function getModuleNameByCourseInfo($m)
    {

        $sql = "SELECT * FROM `module` where moduleno = '" . $m . "'  and status = '1' ";

        $modules = DB::select(DB::raw($sql));

        if (sizeof($modules))
            return (array) $modules[0];

        return array();
    }
}

if (!function_exists('module_lesson_count')) {
    function module_lesson_count($m)
    {

        //echo "select count(id) as cnt from `lessons` where status='1' and moduleno='".$m;

        $sql = ("select id from `lessons` where status='1' and moduleno='" . $m . "'");

        $query = DB::select(DB::raw($sql));

        return sizeof($query);
    }
}



if (!function_exists('route_lesson_count')) {
    function route_lesson_count($m, $r)
    {

        $sql = "select id from `lessons` where status='1' and moduleno='" . $m . "' and routeno='" . $r . "'";

        $query = DB::select(DB::raw($sql));

        return sizeof($query);
    }
}

if (!function_exists('employeeCourses')) {
    function employeeCourses($userId)
    {
        $courses = DB::select(DB::raw("SELECT a.*, b.* FROM  `employeecourse` a Join courses b on a.courseNumber = b.courseNumber WHERE  a.userId = '" . $userId . "' "));
        return $courses;
    }
}


if (!function_exists('lastSession')) {
    function lastSession($user, $course)
    {

        $sql = "SELECT activityDateFrom FROM `useractivitylog_api` where courseNumber = '" . $course . "' and userId = '" . $user . "' order by i_d desc limit 1";

        $query = DB::select(DB::raw($sql));

        if (sizeof($query))
            return $query[0]->activityDateFrom;

        return "";
    }
}


if (!function_exists('getCourseModule')) {
    function getCourseModule($c)
    {


        $sql = "SELECT moduleNumber FROM `courses` where courseNumber = '" . $c . "' ";

        $query = DB::select(DB::raw($sql));

        return $query[0]->moduleNumber;
    }
}


if (!function_exists('sendEmail')) {
    function sendEmail($email, $message, $subject = "Taplingua", $to_name = "", $from = "cristina@taplingua.com", $from_name = "Taplingua")
    {

        $data = [
            'name'      => $to_name,
            'message'   => $message,
            'subject'   => $subject,
            'from'      => $from,
            'from_name' => $from_name
        ];


        /* Check if email exist in block email list */
        if (is_array($email)) { // check if a email is array
            $logs = "SELECT id from `ses_sns_email_list` where userId='" . trim($email[0]) . "'";
        } else {
            $logs = "SELECT id from `ses_sns_email_list` where userId='" . trim($email) . "'";
        }

        $sent = DB::select(DB::raw($logs));

        \Log::info('sendEmail Helper', [$email, $data, $sent]);
        if (sizeof($sent) <= 0)  /// send email if not in blocked list
        {

            Mail::to($email)->send(new TestAmazonSes($data));
        }
    }
}

if (!function_exists('pushNotification')) {
    function pushNotification($token = '', $title = 'Hey', $body = 'New notification Received', $data = [])
    {
        $endpoint = 'https://fcm.googleapis.com/fcm/send';
        $fields = [
            'to' => $token,
            'data' => [
                'data' => $data
            ],
            'notification' => [
                'title' => $title,
                'body' => $body
            ]
        ];
        $headers = [
            'Content-Type: application/json',
            'Authorization: key=' . config('taplingua.FCM_SERVER_KEY')
        ];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $endpoint);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        $result = curl_exec($ch);
        if ($result === FALSE) {
            return false;
        }
        curl_close($ch);
        \Log::info('pushed through pushNotification', [$result, $fields]);
        return $result;
    }
}

if (!function_exists('getPushNotificationPayload')) {
    function getPushNotificationPayload($response, $companyCode, $lang, $index = 0)
    {
        //Push Notification for Completion Reports
        $results = [];
        $value = $response[$index]; // did it to quickly modify the function
        $data = array();
        $fName = ($value['FirstName'] != "") ? $value['FirstName'] : $value['userId'];
        $data['screenType'] = 'completionReports';
        $data['image'] = 'https://www.taplingua.com/wp-content/themes/taplinguab2b/images/taplingua_logo.png';
        $data['title'] = 'Hi ' . $fName . '.';
        $data['message'] = 'Please find your Completion Report';
        $data['moduleName'] = trim($value['moduleName']);
        $data['moduleNumber'] = (int) $value['moduleNumber'];
        $data['courseNumber'] = (int) $value['courseNumber'];
        $data['timestamp'] = date('Y-m-d G:i:s');
        $data['courseStartDate'] = $value['courseStartDate'] ?? '';
        $data['courseEndDate'] = $value['courseEndDate'] ?? '';
        $i = 0;
        foreach ($value['Routes'] as $rKey => $rValue) {
            $data['routes'][$i]['routeNo'] = $rValue['routeno'];
            $data['routes'][$i]['routeName'] = $rKey;
            $data['routes'][$i]['routePercent'] = $rValue['routePercent'];
            $data['routes'][$i]['description'] = $rValue['description'] ?? '';
            $data['routes'][$i]['longDescription'] = $rValue['longDescription'] ?? '';
            $i++;
        }

        $fcmToken = $value['fcmToken'];

        $pushData = array('data' => $data);
        $fields = array(
            'branch_key' => config('taplingua.BRANCHIO_KEY'),
            'data' => [
                'isDeepLink' => 1,
                'screenCode' => 101,
                'pushMsg' => $data
            ]
        );
        return $fields;
    }
}

if (!function_exists('sendPushNotification')) {
    function sendPushNotification($response, $companyCode, $lang)
    { //Push Notification for Completion Reports
        $results = [];
        // $value = ['FirstName' => 'Shubham', 'userId' => 'santanu@taplingua.com', 'moduleNumber' => 0, 'courseNumber' => 0, 'Routes' => [], 'fcmToken' => ''];
        foreach ($response as $key => $value) {
            $data = array();
            //$fName = $value['FirstName'];
            $fName = ($value['FirstName'] != "") ? $value['FirstName'] : $value['userId'];
            $data['screenType'] = 'completionReports';
            $data['image'] = 'https://www.taplingua.com/wp-content/themes/taplinguab2b/images/taplingua_logo.png';
            $data['title'] = 'Hi ' . $fName . '.';
            $data['message'] = 'Please find your Completion Report';
            $data['moduleName'] = trim($value['moduleName']);
            $data['moduleNumber'] = (int) $value['moduleNumber'];
            $data['courseNumber'] = (int) $value['courseNumber'];
            $data['timestamp'] = date('Y-m-d G:i:s');
            $data['courseStartDate'] = $value['courseStartDate'] ?? '';
            $data['courseEndDate'] = $value['courseEndDate'] ?? '';
            $i = 0;
            foreach ($value['Routes'] as $rKey => $rValue) {
                $data['routes'][$i]['routeNo'] = $rValue['routeno'];
                $data['routes'][$i]['routeName'] = $rKey;
                $data['routes'][$i]['routePercent'] = $rValue['routePercent'];
                $data['routes'][$i]['description'] = $rValue['description'] ?? '';
                $data['routes'][$i]['longDescription'] = $rValue['longDescription'] ?? '';
                $i++;
            }


            // save push log for each push
            $pushLog = PushLog::create([
                "userId" => $value["userId"],
                "type" => "weekly-completion",
                "screenCode" => "101", // 201 is for weekly completion screen receive and 301 for open
                "moduleNo" => $value["moduleNumber"],
                "routeNo" => "",
                "lessonNo" => "",
            ]);

            $fcmToken = $value['fcmToken'];
            //$fcmToken = 'd3OgpixrD5A:APA91bHUuk4H9BVTM-3iy9-UXzAO18pqF8u02FVIhGtNEtJ70XibsvW0hb10Ef0Cyyb1o0--xbUpbXmYg3Gu6iHf7mJU8iBKc2spwE4bZCGZe3vBFFXdkKRzBSi6I8TzUCEZLS1UaBDf';

            $pushData = array('data' => $data);
            $fields = array(
                'to' => $fcmToken,
                'data' => [
                    'isDeepLink' => 1,
                    'screenCode' => 101,
                    'pushId' => $pushLog->id,
                    'pushMsg' => $data,
                    'branch' => getBranchIOLink(getPushNotificationPayload($response, $companyCode, $lang, $key))
                ]
            );
            if (sendNotification($fields)) {
                $results[$value['userId']] = 'Push Notification sent!!';
            } else {
                $results[$value['userId']] = 'Unable to send Push Notification !!';
            }
        }
        return $results;
    }
}

if (!function_exists('sendNotification')) {
    function sendNotification($fields)
    {
        $endpoint = 'https://fcm.googleapis.com/fcm/send';
        $headers = [
            'Content-Type: application/json',
            'Authorization: key=' . config('taplingua.FCM_SERVER_KEY')
        ];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $endpoint);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        $result = curl_exec($ch);
        if ($result === FALSE) {
            return false;
        }
        curl_close($ch);
        return $result;
    }
}

if (!function_exists('sendWelcomeEmail')) {

    // TODO: Optimize it
    function sendWelcomeEmail($response, $companyCode, $lang, $mailMode, $from)
    {
        $HH = date("H");

        $results = array();
        foreach ($response as $key => $value) {

            $weekStartDate = $value['courseStartDate'];
            //$weekStartDate = ($weekStartDate != "") ? date_format($weekStartDate,"d-m-Y") : $weekStartDate;
            $date = date_create($weekStartDate);
            $days = count($value['Routes']) * 7;
            date_add($date, date_interval_create_from_date_string($days . " days"));
            $weekEndDate = date_format($date, "d-m-Y");
            $message = "";
            $messageTemplate = welcomeEmailTemplate($lang);
            $messageFooterTemplate = messageFooterTemplate($lang);
            $macros = array();
            $macros['##MODULE_NAME##'] = $value['courseName'];
            //$macros['##NAME##'] = $value['Name'];
            $macros['##NAME##'] = ($value['Name'] != "") ? $value['Name'] : $value['userId'];
            $macros['##COMPANY_NAME##'] = $value['companyName'];
            //$macros['##START_DATE##'] = $weekStartDate;
            //$macros['##END_DATE##'] = $weekEndDate;
            $subject = str_replace(array_keys($macros), array_values($macros), $messageTemplate['subject']);
            $routeData = '';
            $courseDate = $weekStartDate;
            $courseEndDate = $weekEndDate;
            //$courseDate=date_create($courseDate);
            $macros['##DURATION##'] = count($value['Routes']);
            $macros['##COURSESTARTDATE##'] = $weekStartDate;

            $routeData = "";
            $count = 0;

            foreach ($value['Routes'] as $rKey => $rValue) {
                $date = date_create($courseDate);
                //$dayCounts = '7';
                //$days = ($count == 0) ? $dayCounts : ($dayCounts*$count) ;
                $days = '7';
                if ($count > 0) {
                    date_add($date, date_interval_create_from_date_string($days . " days"));
                    $courseDate = date_format($date, "d-m-Y");
                }
                $endDate = date_create($courseDate);
                date_add($endDate, date_interval_create_from_date_string($days . " days"));
                $courseEndDate = date_format($endDate, "d-m-Y");

                $ovalOrange = "https://dashboard.taplingua.com/images/Oval.png";
                $ovalGrey = "https://dashboard.taplingua.com/images/OvalCopy.png";

                $ovalImg = ($count == 0) ? $ovalOrange : $ovalGrey;

                $lineImg = '<img src="https://dashboard.taplingua.com/images/line.png" width="33" height="63" />';

                $lineImgTag = ($count == (count($value['Routes']) - 1)) ? "" : $lineImg;

                $desc = $rValue['description'];
                $long_desc = $rValue['long_description'];

                $routeData .= '<tr><td width="33" align="left" valign="top" style="width:33px;"><img src="' . $ovalImg . '" width="33" height="33" /></td><td style="padding:0px 0px 0px 10px; font-weight:bold; color:#000000; text-align:left; vertical-align:top; font-size:18px;"> ' . $desc . '</td></tr><tr><td rowspan="2" align="left" valign="top" style="width:33px; height:63px;">' . $lineImgTag . '</td><td align="left" valign="middle" style="padding:0px 0px 0px 10px; font-weight:normal; height:23px; color:#939393; text-align:left; vertical-align:top; font-size:12px;"><u>' . $courseDate . '</u> - <u>' . $courseEndDate . '</u></td></tr><tr><td align="left" valign="top" style="padding:0px 0px 0px 10px; font-weight:normal; height:40px; text-align:left; vertical-align:top; color:#000000; font-size:14px;">' . $long_desc . '</td></tr>';

                $count = $count + 1;
                //$count++;

            }
            $macros['##COURSEENDDATE##'] = $courseEndDate;
            $macros['##ROUTE_DATA##'] = $routeData;

            $message = str_replace(array_keys($macros), array_values($macros), $messageTemplate['message']);
            $messageText = str_replace(array_keys($macros), array_values($macros), $messageTemplate['text']);

            $companyIconLogo = $value['companyName'];

            $companyLogoImgName = "companyicon-" . $companyCode . ".png";
            $companyLogoSrc = 'https://dashboard.taplingua.com/images/' . $companyLogoImgName;
            if (@getimagesize($companyLogoSrc)) {
                $companyIconLogo = '<img src="' . $companyLogoSrc . '"  width="60" height="60">';
            }

            $messageBody = '<!doctype html><html><head> <meta name="viewport" content="width=device-width" /> <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> <title>Welcome Email</title> </head> <body> <table style="top: 0px;left: 120px;width: 613px;height: 641px;background-color: #F8F8F8; opacity: 1;border: 1px solid;"><tr> <td style="width: 50px;"><img src="https://dashboard.taplingua.com/images/logo.png"></td> <td style = "font-family:SF Pro Text;font-size: 17px;color: #939393;text-align: left; vertical-align: middle;width: 10px;">for </td> <td style = "font-family:SF Pro Text;font-weight: bold;font-size: 14px;color: #000000;text-align: left;width: 150px;height:50px;">' . $companyIconLogo . '</td> </tr>' . $messageText . '  ' . $message . '  ' . $messageFooterTemplate['certificate'] . '  ' . $messageFooterTemplate['footer'] . '  <tr> <td colspan="3"></td> </tr> </table></body> </html>';

            $message = $messageBody;

            $to = array("santanu.dasgupta@taplingua.com");

            if ($mailMode == "Real" || $mailMode == "real") { // REAL mode
                $to = array(trim($value['userId']));
            }
            //$bcc = "santanu.dasgupta@taplingua.com";
            if (sendEmail($to, $message, $subject, null, $from)) {
                // if(sendEmail($to, $bcc, $subject, $message, $from)){
                $results[$value['userId']] = 'Report email sent!!';
            } else {
                $results[$value['userId']] = 'Unable to send email !!';
            }
        }
        return $results;
    }

    if (!function_exists('welcomeEmailTemplate')) {
        function welcomeEmailTemplate($lang = "EN")
        {

            // TODO: Optimize it
            $template = array();
            if ($lang == 'EN') {
                $subject = "Welcome to ##MODULE_NAME## for ##COMPANY_NAME##";
                //$text = 'Welcome to';
                $text2 = "Hi, ##NAME##!<br/><br/>Welcome to ##MODULE_NAME##! We’re glad you’re here.<br/> For the next ##DURATION## weeks you'll be improving your language skills<br/> through our Taplingua app.<br/><br/>";
                $message = "Course Overview";
                $duration = "Duration ##DURATION## weeks";
                //$message2 = 'In this course you need to complete the mentioned objectives';
            }
            if ($lang == 'ES') {
                $subject = "Bienvenido a ##MODULE_NAME## para ##COMPANY_NAME##";
                //$text = 'Your objectives in';
                $text2 = "Hola, ##NAME##!<br/><br/Bienvenido a ##MODULE_NAME##! Estamos contentos de que estés aquí.<br/>Para el siguiente ##DURATION## semanas mejorarás tus habilidades lingüísticas<br/> a través de nuestra aplicación Taplingua.<br/><br/>";
                $message = "Resumen del curso";
                $duration = "Duración ##DURATION## semanas";
                //$message2 = 'In this course you need to complete the mentioned objectives';
            }
            if ($lang == 'PT') {
                $subject = "Bem-vindo ao ##MODULE_NAME## para ##COMPANY_NAME##";
                //$text = 'Your objectives in';
                $text2 = "Oi, ##NAME##!<br/><br/>Bem-vindo ao ##MODULE_NAME##! Estamos felizes por você estar aqui.<br/> Para o próximo ##DURATION## semanas você estará melhorando suas habilidades no idioma<br/> através do nosso aplicativo Taplingua.<br/><br/>";
                $message = "Visão geral do curso";
                $duration = "Duração ##DURATION## semanas";
                //$message2 = 'In this course you need to complete the mentioned objectives';
            }
            $template['subject'] = $subject;
            //$template['text'] = '<tr><td colspan="3" style = "font-family:SF Pro Display;font-size: 28px;color: #000000;text-align: left;">' . $text . ' <br/>##MODULE_NAME##<br/></td></tr><tr><td colspan="3" style = "font-family:SF Pro Text;font-size: 14px;color: #000000;text-align: left;">' . $text2 . '<br/><br/></td> </tr>';
            //$template['message'] = '<tr> <td colspan="3" align="center"> <table style="left: 148px;width: 557px;height: 366px; background-color: #FFFFFF; border: 1px solid #F2F2F2;border-radius: 8px;opacity: 1;"><tr><td colspan="2" style = "font-family:SF Pro Display;font-size: 25px;color: #EE8538;text-align: left;vertical-align: top">' . $message . '</td></tr><tr> <td colspan="2" style = "font-family:SF Pro Text;font-size: 14px;color: #000000;text-align: left;">' . $message2 . '.</td> </tr><tr> <td colspan="2" align="center">##ROUTE_DATA##</td> </tr>';

            $template['text'] = '<tr><td colspan="3" style = "font-family:SF Pro Display bold;font-size: 28px;color: #000000;text-align: left;">' . $subject . ' !</td></tr><tr><td colspan="3" style = "font-family:SF Pro Text;font-size: 17px;color: #000000;text-align: left;">' . $text2 . '</td></tr>';

            $template['message'] = '<tr><td colspan="3" align="center"><table style="left: 148px;width: 557px;height: 366px; background-color: #FFFFFF; border: 1px solid #F2F2F2;border-radius: 8px;opacity: 1;"><tr><td colspan="2" style = "font-family:SF Pro Text;font-size: 12px;color: #939393;text-align: left;">' . $duration . '&nbsp;&nbsp;<u>##COURSESTARTDATE##</u> - <u>##COURSEENDDATE##</u></td></tr><tr><td colspan="2" style = "font-family:SF Pro Display;font-size: 25px;color: #EE8538;text-align: left;vertical-align: top">' . $message . '</td></tr><tr><td colspan="2" align="center"><table style="width:100%;padding-left:50px;">##ROUTE_DATA##</table></td></tr></table></td></tr>';

            return $template;
        }
    }

    if (!function_exists('messageFooterTemplate')) {
        function messageFooterTemplate($lang = "EN")
        {

            // TODO: Optimize it
            $template = array();
            if ($lang == 'EN') {
                $certificate = 'Earn a Course Certificate';
                $certificate2 = 'Please try to complete at least 75% of the course each week to receive a certificate of course completion';
                $certificate3 = 'Learn more about Course Certificate';
                $help = 'Need Help? ';
                $forgotpass = 'Forgot your password? <a href="https://dashboard.taplingua.com/forgotpass">Reset it here</a>';
            }
            if ($lang == 'ES') {
                $certificate = 'Gana un certificado de curso';
                $certificate2 = 'Intente completar al menos el 75% del curso cada semana para recibir un certificado de finalizción del curso';
                $certificate3 = 'Obtenga más información sobre el Certificado del curso';
                $help = 'Necesitas ayuda? ';
                $forgotpass = 'Olvidaste tu contraseña? <a href="https://dashboard.taplingua.com/forgotpass">Restablecer aquí</a>';
            }
            if ($lang == 'PT') {
                $certificate = 'Ganhe um certificado de curso';
                $certificate2 = 'Tente concluir pelo menos 75% do curso a cada semana para receber um certificado de conclusão do curso';
                $certificate3 = 'Saiba mais sobre o certificado do curso';
                $help = 'Preciso de ajuda? ';
                $forgotpass = 'Esqueceu sua senha? <a href="https://dashboard.taplingua.com/forgotpass">Redefina aqui</a>';
            }

            //$template['certificate'] = '<tr> <td colspan="3" align="center"> <table style="top: 772px;left: 148px;width: 557px;height: 115px;background-color: #FFFFFF;border: 1px solid #F2F2F2;border-radius: 8px;opacity: 1;"> <tr> <td style = "font-family:SF Pro Display;font-size: 25px;color: #EE8538;text-align: left;">'. $certificate .'</td> </tr> <tr> <td style = "font-family:SF Pro Text;font-size: 14px;color: #000000;text-align: left;">' . $certificate2 . '.</td> </tr> <tr> <td style = "font-family:SF Pro Text;font-size: 14px;text-align: left;"><a href="#">' . $certificate3 . '</a></td> </tr> </table> </td> </tr>';

            //$template['footer'] = '<tr> <td colspan="3" align="center"> <table> <tr> <td style = "font-family:SF Pro Text;font-size: 14px;text-align: left;">' . $help . ' <a href="#">cristina.guijarro@taplingua.com</a></td> </tr> <tr> <td style = "font-family:SF Pro Text;font-size: 14px;text-align: left;">' . $forgotpass . '</td> </tr> <tr> <td style = "font-family:SF Pro Text;font-weight: bold;font-size: 17px;text-align: center;">Download the Taplingua app</td> </tr> <tr> <td style = "font-family:SF Pro Text;font-size: 10px;text-align: center;">Delivered by Taplingua Calle de Walia 10, Madrid 28007, Spain.</td> </tr> <tr> <td style = "font-family:SF Pro Text;font-size: 10px;text-align: center;">Â© 2019 Taplingua All rights reserved</td> </tr> </table> </td> </tr>';

            $template['certificate'] = "";

            $template['footer'] = '<tr> <td colspan="3" align="center"> <table> <tr> <td style = "font-family:SF Pro Text;font-size: 14px;text-align: left;">' . $help . ' <a href="#">cristina.guijarro@taplingua.com</a></td> </tr> <tr> <td style = "font-family:SF Pro Text;font-size: 14px;text-align: left;"></td> </tr> <tr> <td style = "font-family:SF Pro Text;font-weight: bold;font-size: 17px;text-align: center;">Download the Taplingua app</td> </tr> <tr> <td style = "font-family:SF Pro Text;font-size: 10px;text-align: center;">Delivered by Taplingua Calle de Walia 10, Madrid 28007, Spain.</td> </tr> <tr> <td style = "font-family:SF Pro Text;font-size: 10px;text-align: center;">&copy; 2019 Taplingua All rights reserved<br><br><a href="' . env('APP_URL') . '/unsubscribe" target="_blank">Click here to unsubscribe</a></td> </tr> </table> </td> </tr>';

            return $template;
        }
    }

    if (!function_exists('sendWeeklyEmail')) {
        function sendWeeklyEmail($response, $lang = "PT", $mailMode = "Test", $from)
        {
            $results = array();
            foreach ($response as $key => $value) {
                $row = (array) $value[0];
                $weekStartDate = $row['courseStartDate'];
                //$weekStartDate = ($weekStartDate != "") ? date_format($weekStartDate,"d-m-Y") :
                $date = date_create($weekStartDate);
                $days = count($row['routeLevels']) * 7;

                $routeNo = $row['routeno'];
                $routeStartDays = ($routeNo - 1) * 7;
                $routeEndDays = $routeNo * 7;
                $selectedWeekStartDate = date_format(date_add(date_create($weekStartDate), date_interval_create_from_date_string($routeStartDays . " days")), "d-m-Y");
                $selectedWeekEndDate = date_format(date_add(date_create($weekStartDate), date_interval_create_from_date_string($routeEndDays . " days")), "d-m-Y");

                date_add($date, date_interval_create_from_date_string($days . " days"));
                $weekEndDate = date_format($date, "d-m-Y");

                $message = "";
                $messageTemplate = weeklyEmailTemplate($lang);
                $messageFooterTemplate = messageFooterTemplate($lang);
                $macros = array();
                $macros['##MODULE_NAME##'] = $row['moduleName'];
                //$macros['##NAME##'] = $row['Name'];
                $macros['##NAME##'] = ($row['Name'] != "") ? $row['Name'] : $row['userId'];
                $macros['##COMPANY_NAME##'] = $row['companyName'];
                $macros['##ROUTE_NAME##'] = $row['description'];
                $macros['##WEEK_DURATION##'] = $selectedWeekStartDate . " to " . $selectedWeekEndDate;
                //$macros['##START_DATE##'] = $weekStartDate;
                //$macros['##END_DATE##'] = $weekEndDate;
                $subject = str_replace(array_keys($macros), array_values($macros), $messageTemplate['subject']);
                $routeData = '';
                foreach ($row['routeLevels'] as $routeLevels) {
                    $routeData .= '<tr><td><table><tr><td><p style="border-radius: 50%;width: 15px;height: 15px;padding: 8px;background: #1155cc;color: #ffffff;text-align: center;font: 15px Arial, sans-serif;">' . $routeLevels['levelno'] . '</p></td><td style = "font-family:SF Pro Text;font-size: 14px;text-align: left;">' . $routeLevels['description'] . '</td></tr></table></td></tr>';
                }
                $macros['##ROUTE_DATA##'] = $routeData;
                $message = str_replace(array_keys($macros), array_values($macros), $messageTemplate['message']);
                $messageText = str_replace(array_keys($macros), array_values($macros), $messageTemplate['text']);

                $companyIconLogo = $row['companyName'];

                $companyLogoImgName = "companyicon-" . $row['CompanyCode'] . ".png";
                $companyLogoSrc = 'https://dashboard.taplingua.com/images/' . $companyLogoImgName;
                if (@getimagesize($companyLogoSrc)) {
                    $companyIconLogo = '<img src="' . $companyLogoSrc . '"  width="60" height="60">';
                }

                $messageBody = '<table style="top: 0px;left: 120px;width: 613px;height: 641px;background-color: #F8F8F8; opacity: 1;border: 1px solid;"><tr> <td style="width: 50px;"><img src="https://dashboard.taplingua.com/images/logo.png"></td> <td style = "font-family:SF Pro Text;font-size: 17px;color: #939393;text-align: left; vertical-align: middle;width: 10px;">for </td> <td style = "font-family:SF Pro Text;font-weight: bold;font-size: 14px;color: #000000;text-align: left;width: 150px;height:50px;">' . $companyIconLogo . '</td> </tr>' . $messageText . '  ' . $message . '  ' . $messageFooterTemplate['certificate'] . '  ' . $messageFooterTemplate['footer'] . '  <tr> <td colspan="3"></td> </tr> </table>';

                $message = $messageBody;

                $to = array("santanu.dasgupta@taplingua.com");
                $userId = $key;
                if ($mailMode == "Real" || $mailMode == "real") { // REAL mode
                    $to = array(trim($userId));
                }
                //$bcc = "santanu.dasgupta@taplingua.com";
                if (sendEmail($to, $message, $subject, null, $from)) {
                    $results[$userId] = 'Report email sent!!';
                } else {
                    $results[$userId] = 'Unable to send email !!';
                }
            }
            return $results;
        }
    }
}


if (!function_exists('weeklyEmailTemplate')) {
    function weeklyEmailTemplate($lang = "EN")
    {
        $template = array();
        if ($lang == 'EN') {
            $subject = "Your objectives next week in ##MODULE_NAME##";
            $text = 'Your objectives next week in';
            $text2 = "Hi, ##NAME##!<br/>Here you can see the next week's objectives in ##MODULE_NAME##<br/> (##COMPANY_NAME##).";
            $message = "Your objectives next Week (##WEEK_DURATION##)";
            $duration = "Duration";
            $message2 = 'Next week you need to complete 5 levels. You can decide when you want to complete each level whenever you finish before the deadline';
            $review = "Review Week 1";
            $resume = "Go to Week 2";
        }
        if ($lang == 'ES') {
            $subject = "Tus objetivos esta semana en ##MODULE_NAME##";
            $text = 'Tus objetivos esta semana en';
            $text2 = 'Hola, ##NAME##!<br/>aquí puedes ver los objetivos de la esta semana en en ##MODULE_NAME## <br/> (##COMPANY_NAME##).';
            $message = "Tus objetivos esta semana (##WEEK_DURATION##)";
            $message2 = 'La próxima semana debes completar 5 niveles. Puedes decidir cuándo quieres completar cada nivel cuando termines antes de la fecha límite';
            $duration = "duración";
            $review = "Revsión Week1";
            $resume = "Ir Week2";
        }
        if ($lang == 'PT') {
            $subject = "Seus objetivos na esta semana em ##MODULE_NAME##";
            $text = 'Seus objetivos na esta semana em';
            $text2 = 'Oi, ##NAME##!<br/>Aqui Você pode ver os objetivos da esta semana em ##MODULE_NAME## <br/> (##COMPANY_NAME##).';
            $message = "Seus objetivos na esta semana (##WEEK_DURATION##)";
            $message2 = 'Na próxima semana Você precisa completar 5 níveis. Você pode decidir quando deseja concluir cada nível  sempre que terminar antes do prazo';
            $duration = "duração";
            $review = "Reveja Week1";
            $resume = "Vamos para Week2";
        }
        $template['subject'] = $subject;
        $template['text'] = '<tr><td colspan="3" style = "font-family:SF Pro Display;font-size: 28px;color: #000000;text-align: left;">' . $text . ' <br/>##MODULE_NAME##<br/></td></tr><tr><td colspan="3" style = "font-family:SF Pro Text;font-size: 14px;color: #000000;text-align: left;">' . $text2 . '<br/><br/></td> </tr>';
        //$template['message'] = '<tr> <td colspan="3" align="center"> <table style="left: 148px;width: 557px;height: 366px; background-color: #FFFFFF; border: 1px solid #F2F2F2;border-radius: 8px;opacity: 1;"><tr><td colspan="2" style = "font-family:SF Pro Display;font-size: 25px;color: #EE8538;text-align: left;vertical-align: top">' . $message . '</td></tr><tr><td colspan="2" style = "font-family:SF Pro Text;font-size: 12px;color: #939393;text-align: left;">' . $duration . ': ##START_DATE## - ##END_DATE##</td></tr><tr> <td colspan="2" style = "font-family:SF Pro Text;font-size: 14px;color: #000000;text-align: left;">' . $message2 . '.</td> </tr><tr> <td colspan="2" align="center"> <table><tr> <td><img src=""></td><td style = "font-family:SF Pro Text;font-weight:bold;font-size: 19px;text-align: left;">##MODULE_NAME## course<br/>##ROUTE_NAME##</td></tr>  ##ROUTE_DATA##  </table> </td> </tr> <tr> <td align="center"> <p style=" border-radius: 25px;border: 2px solid #F17761;padding: 20px;width: 170px;height: 20px;color: #F17761;">' . $review . '</p> </td> <td align="center"> <p style="border-radius: 25px;background: #F17761;padding: 20px; width: 170px;height: 20px;color: #FFFFFF;">' . $resume .  '</p> </td> </tr> </table> </td> </tr>';
        $template['message'] = '<tr> <td colspan="3" align="center"> <table style="left: 148px;width: 557px;height: 366px; background-color: #FFFFFF; border: 1px solid #F2F2F2;border-radius: 8px;opacity: 1;"><tr><td colspan="2" style = "font-family:SF Pro Display;font-size: 20px;color: #EE8538;text-align: left;vertical-align: top">' . $message . '</td></tr><tr> <td colspan="2" style = "font-family:SF Pro Text;font-size: 14px;color: #000000;text-align: left;">' . $message2 . '.</td> </tr><tr> <td colspan="2" align="center"> <table><tr><td style = "font-family:SF Pro Text;font-weight:bold;font-size: 19px;text-align: left;">##MODULE_NAME## course<br/>##ROUTE_NAME##</td></tr>  ##ROUTE_DATA##  </table></td></tr></table></td></tr>';

        return $template;
    }
}

if (!function_exists('sendWeeklyPushNotification')) {
    function sendWeeklyPushNotification($response, $lang)
    {
        foreach ($response as $key => $value) {
            $data = array();
            $fName = ($value[0]->Name != "") ? $value[0]->Name : $value[0]->userId;
            $moduleName = $value[0]->moduleName;
            $routeNo = $value[0]->routeno;
            $courseStartDate = $value[0]->courseStartDate;
            $routeStartDays = ($routeNo - 1) * 7;
            $routeEndDays = ($routeNo * 7) - 1;
            $routeStartDate = date_format(date_add(date_create($courseStartDate), date_interval_create_from_date_string($routeStartDays . " days")), "d-m-Y");
            $routeEndDate = date_format(date_add(date_create($courseStartDate), date_interval_create_from_date_string($routeEndDays . " days")), "d-m-Y");

            $data['screenType'] = 'WeeklyReports';
            $data['image'] = 'https://www.taplingua.com/wp-content/themes/taplinguab2b/images/taplingua_logo.png';
            $data['title'] = 'Hi ' . $fName . '.';
            $data['message'] = 'Please find your weekly Report';
            $data['moduleName'] = trim($moduleName);
            $data['moduleNumber'] = (int) $value[0]->moduleNumber;
            $data['courseNumber'] = (int) $value[0]->courseNumber;
            $data['routeNo'] = $routeNo;
            $data['routeName'] = $value[0]->description;
            $data['from_date'] = $routeStartDate;
            $data['to_date'] = $routeEndDate;
            $data['timestamp'] = date('Y-m-d G:i:s');
            $i = 0;
            foreach ($value[0]->routeLevels as $routeLevels) {
                $data['lessons'][$i]['level'] = $routeLevels['levelno'];
                $data['lessons'][$i]['lessonno'] = $routeLevels['lessonno'];
                $data['lessons'][$i]['description'] = $routeLevels['description'];
                $data['lessons'][$i]['long_description'] = $routeLevels['long_description'];
                $i++;
            }


            // so we will log it
            $pushLog = PushLog::create([
                "userId" => $value[0]->userId,
                "type" => "weekly-task",
                "screenCode" => "102", // 202 is for weekly task screen receive and 302 for open
                "moduleNo" => $value[0]->moduleNumber,
                "routeNo" => $value[0]->routeno,
                "lessonNo" => "",
            ]);
            // so we will log it end
            // and send the push_log_id as push_id to the client too, so that we can track it in user_time_logs (its done using pushId later in this code)

            $fcmToken = $value[0]->fcmToken;
            //$fcmToken = 'd3OgpixrD5A:APA91bHUuk4H9BVTM-3iy9-UXzAO18pqF8u02FVIhGtNEtJ70XibsvW0hb10Ef0Cyyb1o0--xbUpbXmYg3Gu6iHf7mJU8iBKc2spwE4bZCGZe3vBFFXdkKRzBSi6I8TzUCEZLS1UaBDf';
            $pushData = array('data' => $data);
            $fields = array(
                'to' => $fcmToken,
                'data' => [
                    'isDeepLink' => 1,
                    'screenCode' => 102,
                    'pushId' => $pushLog->id,
                    'pushMsg' => $data,
                    'branch' => getBranchIOLink(getWeeklyPushNotificationPayload($response, $lang, $key)),
                ],
            );

            if (sendNotification($fields)) {
                $results[$key] = 'Push Notification sent!!';
            } else {
                $results[$key] = 'Unable to send Push Notification !!';
            }
        }
        return $results;
    }
}

/**
 * Generates only payload for weekly notification
 */
if (!function_exists('getWeeklyPushNotificationPayload')) {
    function getWeeklyPushNotificationPayload($response, $lang, $index = 0)
    {
        $value = $response[$index];
        $data = array();
        $fName = ($value[0]->Name != "") ? $value[0]->Name : $value[0]->userId;
        $moduleName = $value[0]->moduleName;
        $routeNo = $value[0]->routeno;
        $courseStartDate = $value[0]->courseStartDate;
        $routeStartDays = ($routeNo - 1) * 7;
        $routeEndDays = ($routeNo * 7) - 1;
        $routeStartDate = date_format(date_add(date_create($courseStartDate), date_interval_create_from_date_string($routeStartDays . " days")), "d-m-Y");
        $routeEndDate = date_format(date_add(date_create($courseStartDate), date_interval_create_from_date_string($routeEndDays . " days")), "d-m-Y");

        $data['screenType'] = 'WeeklyReports';
        $data['image'] = 'https://www.taplingua.com/wp-content/themes/taplinguab2b/images/taplingua_logo.png';
        $data['title'] = 'Hi ' . $fName . '.';
        $data['message'] = 'Please find your weekly Report';
        $data['moduleName'] = trim($moduleName);
        $data['moduleNumber'] = (int) $value[0]->moduleNumber;
        $data['courseNumber'] = (int) $value[0]->courseNumber;
        $data['routeNo'] = $routeNo;
        $data['routeName'] = $value[0]->description;
        $data['from_date'] = $routeStartDate;
        $data['to_date'] = $routeEndDate;
        $data['timestamp'] = date('Y-m-d G:i:s');
        $i = 0;
        foreach ($value[0]->routeLevels as $routeLevels) {
            $data['lessons'][$i]['level'] = $routeLevels['levelno'];
            $data['lessons'][$i]['lessonno'] = $routeLevels['lessonno'];
            $data['lessons'][$i]['description'] = $routeLevels['description'];
            $data['lessons'][$i]['long_description'] = $routeLevels['long_description'];
            $i++;
        }

        $fcmToken = $value[0]->fcmToken;
        //$fcmToken = 'd3OgpixrD5A:APA91bHUuk4H9BVTM-3iy9-UXzAO18pqF8u02FVIhGtNEtJ70XibsvW0hb10Ef0Cyyb1o0--xbUpbXmYg3Gu6iHf7mJU8iBKc2spwE4bZCGZe3vBFFXdkKRzBSi6I8TzUCEZLS1UaBDf';
        $pushData = array('data' => $data);
        $fields = array(
            'branch_key' => config('taplingua.BRANCHIO_KEY'),
            'data' => [
                'isDeepLink' => 1,
                'screenCode' => 102,
                'pushMsg' => $data
            ],
        );

        return $fields;
    }
}

if (!function_exists('completionMessageTemplate')) {
    function completionMessageTemplate($lang = "EN")
    {
        $template = array();
        if ($lang == 'EN') {
            $subject = "Percentage of weekly completion in ##MODULE_NAME##";
            $text = 'Percentage of weekly completion in';
            $text2 = 'Hi, ##NAME##!<br/>You can see the percentage of weekly course completion in ##MODULE_NAME##<br/> (##COMPANY_NAME##).';
            $message = "Your percentage of completion this week";
            $duration = "Duration";
            $review = "Review Week 1";
            $resume = "Resume Learning";
        }
        if ($lang == 'ES') {
            $subject = "Porcentaje de finalizción semanal en ##MODULE_NAME##";
            $text = 'Porcentaje de finalizción semanal en';
            $text2 = 'Hola, ##NAME##!<br/>Puede ver el porcentaje de finalizción semanal del curso en ##MODULE_NAME## <br/> (##COMPANY_NAME##).';
            $message = "Su porcentaje de finalizción esta semana";
            $duration = "duración";
            $review = "Revsión Week 1";
            $resume = "Reanudar el aprendizaje";
        }
        if ($lang == 'PT') {
            $subject = "Porcentagem de conclusão semanal em ##MODULE_NAME##";
            $text = 'Puede ver el porcentaje de finalizción semanal del curso en';
            $text2 = 'Oi, ##NAME##!<br/>Você pode ver a porcentagem de conclusão semanal do curso em ##MODULE_NAME## <br/> (##COMPANY_NAME##).';
            $message = "Sua porcentagem de conclusão esta semana";
            $duration = "duração";
            $review = "Reveja Week 1";
            $resume = "Currículo";
        }
        $template['subject'] = $subject;
        $template['text'] = '<tr><td colspan="3" style = "font-family:SF Pro Display;font-size: 28px;color: #000000;text-align: left;">' . $text . ' <br/>##MODULE_NAME##<br/></td></tr><tr><td colspan="3" style = "font-family:SF Pro Text;font-size: 14px;color: #000000;text-align: left;">' . $text2 . '<br/><br/></td> </tr>';
        //$template['message'] = '<tr> <td colspan="3" align="center"> <table style="left: 148px;width: 557px;height: 366px; background-color: #FFFFFF; border: 1px solid #F2F2F2;border-radius: 8px;opacity: 1;"><tr><td colspan="2" style = "font-family:SF Pro Display;font-size: 25px;color: #EE8538;text-align: left;vertical-align: top">' . $message . '</td></tr><tr><td colspan="2" style = "font-family:SF Pro Text;font-size: 12px;color: #939393;text-align: left;">' . $duration . ': ##START_DATE## - ##END_DATE##</td></tr><tr> <td colspan="2" align="center"> <table> <tr> ##ROUTE_DATA## </tr> </table> </td> </tr> <tr> <td align="center"> <p style=" border-radius: 25px;border: 2px solid #F17761;padding: 20px;width: 170px;height: 20px;color: #F17761;">' . $review . '</p> </td> <td align="center"> <p style="border-radius: 25px;background: #F17761;padding: 20px; width: 170px;height: 20px;color: #FFFFFF;">' . $resume .  '</p> </td> </tr> </table> </td> </tr>';
        $template['message'] = '<tr> <td colspan="3" align="center"> <table style="left: 148px;width: 557px;height: 366px; background-color: #FFFFFF; border: 1px solid #F2F2F2;border-radius: 8px;opacity: 1;"><tr><td colspan="2" style = "font-family:SF Pro Display;font-size: 25px;color: #EE8538;text-align: left;vertical-align: top">' . $message . '</td></tr><tr><td colspan="2" align="center"> <table> <tr> ##ROUTE_DATA## </tr></table></td></tr></table></td> </tr>';

        return $template;
    }
}

if (!function_exists('sendCompletionStatus')) {

    function sendCompletionStatus($response, $companyCode, $lang = "PT", $mailMode = "Test", $from)
    {

        $results = array();
        foreach ($response as $key => $value) {
            $weekStartDate = $value['courseStartDate'];
            //$weekStartDate = ($weekStartDate != "") ? date_format($weekStartDate,"d-m-Y") : $weekStartDate;
            $date = date_create($weekStartDate);
            $days = count($value['Routes']) * 7;
            date_add($date, date_interval_create_from_date_string($days . " days"));
            $weekEndDate = date_format($date, "d-m-Y");

            $message = "";
            $messageTemplate = completionMessageTemplate($lang);
            $messageFooterTemplate = messageFooterTemplate($lang);
            $macros = array();
            $macros['##MODULE_NAME##'] = $value['moduleName'];
            $macros['##NAME##'] = ($value['Name'] != "") ? $value['Name'] : $value['userId'];
            $macros['##COMPANY_NAME##'] = $value['companyName'];
            //$macros['##START_DATE##'] = $weekStartDate;
            //$macros['##END_DATE##'] = $weekEndDate;
            $subject = str_replace(array_keys($macros), array_values($macros), $messageTemplate['subject']);
            $routeData = '';

            foreach ($value['Routes'] as $rKey => $rValue) {
                $routeNo = $rValue['routeno'];
                $routeStartDays = ($routeNo - 1) * 7;
                $routeEndDays = $routeNo * 6;
                $routeWeekStartDate = date_format(date_add(date_create($weekStartDate), date_interval_create_from_date_string($routeStartDays . " days")), "d-m-Y");
                $routeWeekEndDate = date_format(date_add(date_create($weekStartDate), date_interval_create_from_date_string($routeEndDays . " days")), "d-m-Y");
                $currentDate = date("d-m-Y");

                $color = 'grey';
                if (strtotime($currentDate) > strtotime($routeWeekEndDate)) { //Past Week
                    $routeCal = '0%';
                    $routePercent = $rValue['routePercent'];

                    if ($routePercent > 75) $color = "green";
                    if (in_array($routePercent, range(51, 75))) $color = "orange";
                    if ($routePercent < 50) $color = "red";

                    $routeCal = $routePercent . '%';
                } else { //Current and Future Week
                    $routeCal = "----";
                }

                $routeData .= '<td align="center"><div style="border-radius: 50%; width: 101px; height: 100px; border: 15px solid ' . $color . ';text-align: center;"><p style="padding-top:25px;">' . $routeCal . '</p></div>' . $rKey . '</td>';
            }
            $macros['##ROUTE_DATA##'] = $routeData;
            $message = str_replace(array_keys($macros), array_values($macros), $messageTemplate['message']);
            $messageText = str_replace(array_keys($macros), array_values($macros), $messageTemplate['text']);

            $companyIconLogo = $value['companyName'];

            $companyLogoImgName = "companyicon-" . $companyCode . ".png";
            $companyLogoSrc = 'https://dashboard.taplingua.com/images/' . $companyLogoImgName;
            if (@getimagesize($companyLogoSrc)) {
                $companyIconLogo = '<img src="' . $companyLogoSrc . '"  width="60" height="60">';
            }
            $messageBody = '<table style="top: 0px;left: 120px;width: 613px;height: 641px;background-color: #F8F8F8; opacity: 1;border: 1px solid;"><tr> <td style="width: 50px;"><img src="https://dashboard.taplingua.com/images/logo.png"></td> <td style = "font-family:SF Pro Text;font-size: 17px;color: #939393;text-align: left; vertical-align: middle;width: 10px;">for </td> <td style = "font-family:SF Pro Text;font-weight: bold;font-size: 14px;color: #000000;text-align: left;width: 150px;height:50px;">' . $companyIconLogo . '</td> </tr>' . $messageText . '  ' . $message . '  ' . $messageFooterTemplate['certificate'] . '  ' . $messageFooterTemplate['footer'] . '  <tr> <td colspan="3"></td> </tr> </table>';
            $message = $messageBody;

            $to = array("santanu.dasgupta@taplingua.com");

            if ($mailMode == "Real"  || $mailMode == "real") { // REAL mode
                $to = array(trim($value['userId']));
            }
            //$bcc = "santanu.dasgupta@taplingua.com";

            if (sendEmail($to, $message, $subject, null, $from)) {
                $results[$value['userId']] = 'Report email sent!!';
            } else {
                $results[$value['userId']] = 'Unable to send email !!';
            }
        }
        return $results;
    }
}

if (!function_exists('dateDiffInDays')) {
    function dateDiffInDays($date1, $date2)
    {
        // Calulating the difference in timestamps
        $diff = strtotime($date2) - strtotime($date1);

        // 1 day = 24 hours
        // 24  60  60 = 86400 seconds
        return abs(round($diff / 86400));
    }
}


if (!function_exists('cards_words_count')) {
    function cards_words_count($m)
    {

        $sql = "select id from `cards` where moduleNo='" . $m . "'";

        $query = DB::select(DB::raw($sql));

        return sizeof($query);
    }
}

if (!function_exists('makeCertificate')) {
    function makeCertificate($userId, $courseNumber, $data)
    {
        $employee = \App\Employee::where('userId', $userId)->first();
        $certificate = new \App\Certificate([
            'certificateId' => strtoupper(uniqid("CERT")),
            'userId' => $userId,
            'courseNumber' => $courseNumber,
            'courseName' => $data['courseName'],
            'name' => $employee->FirstName . " " . $employee->LastName,
            'instructor' => $data['instructor'] ?? "Instructor",
            'date' => !empty($data['date']) ? strtoupper($data['date']) : null,
        ]);

        $certificate->save();
        return $certificate;
    }
}

if (!function_exists('getCertificate')) {
    function getCertificate($userId, $courseNumber, $data = [],$interviewSimulator=false)
    {
        $certificate = \App\Certificate::where('userId', $userId)->where('courseNumber', $courseNumber)->first();
        if (!$certificate) {
            $course = \App\Course::where('courseNumber', $courseNumber)->first();
            $user = \App\User::where('email', $userId)->first();
            $employee = \App\Employee::where('userId', $userId)->first();
            $module = \App\Module::where('moduleno', $course->moduleNumber)->first();

            // check if user part of module program
            $level_number = "";
            $userProgram = ProgramUser::where('userId', $userId)->first();
            // if user program is there,
            if ($userProgram) {
                // check if we hava a program module for current module
                $programModule = $userProgram->programModules()->where('module_number', $course->moduleNumber)->first();
                // if current module is there, get the level number
                if ($programModule) {
                    $level_number = $programModule->level_number;
                }
            }


            $certificate = new \App\Certificate([
                'certificateId' => strtoupper(uniqid("CERT")),
                'userId' => $userId,
                'courseNumber' => $courseNumber,
                'level_number' => $level_number,
                'courseName' => $module->description, // to get original name of the module instead of custom course name
                'name' => ($employee->FirstName !== $employee->LastName) ? $employee->FirstName . " " . $employee->LastName : $employee->FirstName,
                'instructor' => $data['instructor'] ?? "Instructor",
                'date' => !empty($data['date']) ? strtoupper($data['date']) : null,
                'interviewSimulator' => $interviewSimulator
            ]);
            $certificate->save();
        }
        return $certificate;
    }
}

if (!function_exists('getCertificateIfExists')) {
    function getCertificateIfExists($userId, $courseNumber, $data = [])
    {
        return \App\Certificate::where('userId', $userId)->where('courseNumber', $courseNumber)->first();
    }
}

if (!function_exists('userIsAheadOfTimeInModule')) {
    function userIsAheadOfTimeInModule($userId, $moduleNumber, $courseNumber)
    {
        $course = Course::where('courseNumber', $courseNumber)->first();
        if (!$course) {
            return false;
        }

        $currentWeek = now()->diffInWeeks(\Carbon\Carbon::parse($course->courseStartDate)) + 1; // get current week for course
        $usersCurrentWeek = \App\UserActivityLog::selectRaw('max(routeNo) as routeNo') // get users current week
            ->where('userId', $userId)
            ->where('moduleNo', $moduleNumber)
            ->first()->routeNo;
        return $currentWeek < $usersCurrentWeek ? true : false;
    }
}

if (!function_exists("userIsLost")) {
    /**
     * Checks if user is lost based on his/her last activity
     *
     * @param string $userId
     * @param integer $moduleNumber
     * @return boolean
     */
    function userIsLost($userId, $moduleNumber)
    {
        $lastActivity = DB::table('useractivitylog_api')
            ->where('userId', $userId)
            ->where('moduleNo', $moduleNumber)
            ->orderBy('activityDateTo', 'desc')
            ->first();

        // if there is no last activity, probably user has not started yet
        if (!$lastActivity) return false;
        // check the time of last activity
        return now()->diffInWeeks(\Carbon\Carbon::parse($lastActivity->activityDateTo)) > 3 ? true : false;
    }
}


if (!function_exists('transcribeJobs')) {
    function transcribeJobs($id)
    {

        $sql = "select jsonFile from `transcribe_jobs` where transcribeId='" . $id . "' and transcribeStatus='1'";

        $query = DB::select(DB::raw($sql));

        //print_r($query);

        if (sizeof($query))
            return $query;
    }
}

if (!function_exists('getBranchIOLink')) {
    /**
     * This function Creates a branch.io deep link for the payload provided
     */
    function getBranchIOLink($payload = [])
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, config('taplingua.BRANCHIO_URL'));
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Content-Type" => "application/json"
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        $result = curl_exec($ch);
        if ($result === FALSE) {
            Log::warning("branch.io link generation failed", [$payload, $result]);
            return null;
        } else {
            $result = json_decode($result);
        }
        curl_close($ch);
        if (property_exists($result, 'url')) {
            return $result->url;
        } else {
            Log::warning("branch.io link generation failed", [$payload, $result]);
            return null;
        }
    }
}


// get tracker link for branch link
if (!function_exists("getCTATrakerForBranchLink")) {
    function getCTATrakerForBranchLink(String $emailLogUuid, String $branchURL)
    {
        return route('cta', ['uuid' => $emailLogUuid, 'to' => $branchURL]);
    }
}

// for todolist activites of a user with activation status 0
if (!function_exists('getActivitiesFor0StatusUser')) {
    function getActivitiesFor0StatusUser($userId = "")
    {
        $currentCourse = DB::table('employee')->where("userId", $userId)->first()->currentCourse;

        $moduleNumber = DB::table('courses')->where('courseNumber', $currentCourse)->first()->moduleNumber;

        $firstLesson = Lesson::where("moduleno", $moduleNumber)->where("lesson_no", 1)->first(); //  get first lesson

        $moduleRouteLevelLesson = $moduleNumber . "_1_1_1"; // for first lesson of first level in first route of this module

        // check the status of activity types
        $activityStatus1 = DB::table("useractivitylog_api")->where("moduleNo", $moduleNumber)->where("userId", $userId)->where("lessonNo", 1)->where("activityType", 1)->exists() ? 1 : 0;
        $activityStatus2 = DB::table("useractivitylog_api")->where("moduleNo", $moduleNumber)->where("userId", $userId)->where("lessonNo", 1)->where("activityType", 2)->exists() ? 1 : 0;
        $activityStatus3 = DB::table("useractivitylog_api")->where("moduleNo", $moduleNumber)->where("userId", $userId)->where("lessonNo", 1)->where("activityType", 3)->exists() ? 1 : 0;
        $activityStatus4 = DB::table("useractivitylog_api")->where("moduleNo", $moduleNumber)->where("userId", $userId)->where("lessonNo", 1)->where("activityType", 4)->exists() ? 1 : 0;


        return [
            [
                "moduleRouteLesson" => null,
                "title" => "Signup for the course",
                "description" => "Signup for the course",
                "activityType" => 981, // registration has 981
                "activityStatus" => 1, // by default will be turned to 1 // we can use activityType 981 for this
                'courseNumber' => $currentCourse,
            ],
            [
                "moduleRouteLesson" => $moduleRouteLevelLesson,
                "title" => $firstLesson->long_description,
                "description" => $firstLesson->description,
                "activityType" => 1,
                "activityStatus" => $activityStatus1,
                'courseNumber' => $currentCourse,
            ],
            [
                "moduleRouteLesson" => $moduleRouteLevelLesson,
                "title" => $firstLesson->long_description,
                "description" => $firstLesson->description,
                "activityType" => 2,
                "activityStatus" => $activityStatus2,
                'courseNumber' => $currentCourse,
            ],
            [
                "moduleRouteLesson" => $moduleRouteLevelLesson,
                "title" => $firstLesson->long_description,
                "description" => $firstLesson->description,
                "activityType" => 3,
                "activityStatus" => $activityStatus3,
                'courseNumber' => $currentCourse,
            ],
            [
                "moduleRouteLesson" => $moduleRouteLevelLesson,
                "title" => $firstLesson->long_description,
                "description" => $firstLesson->description,
                "activityType" => 4,
                "activityStatus" => $activityStatus4,
                'courseNumber' => $currentCourse,
            ],
        ];
    }
}

// finds if user is active for activation status in todolist by user id
if (!function_exists('findIfUserIsActivatedByHisEmail')) {
    function findIfUserIsActivatedByHisEmail($email = "")
    {
        $activities = getActivitiesFor0StatusUser($email);
        // get sum
        $sum = array_reduce($activities, function ($prev, $activity) {
            return $prev + $activity["activityStatus"];
        }, 0);

        $isUserActivated = $sum >= 4;
        // check for activation badge if user is activated
        if ($isUserActivated) {
            event(new UserTodoActivated(["userId" => $email]));
        }
        // check for activation badge if user is activated end

        return $isUserActivated ? true : false; // return true for if sum if more than 3
    }
}

if (!function_exists('generateTodoListByUserId')) {

    /**
     * Generates and returns todolist for a specific user using his/her id
     *
     * @param string $userId
     * @return mixed
     */
    function generateTodoListByUserId($userId = "")
    {
        $currentCourse = DB::table('employee')->where("userId", $userId)->first()->currentCourse;

        $moduleNumber = DB::table('courses')->where('courseNumber', $currentCourse)->first()->moduleNumber;

        if (findIfUserIsActivatedByHisEmail($userId)) {


            $threeLessons = [];  // <--- this will have the first three tasks

            // get all the lessons available to user (user has registered to them), for the currentCourse
            $lessons = DB::table('employeecourse')->where('employeecourse.userId', $userId)
                // ->selectRaw('lessons.moduleNo, lessons.routeno, lessons.lesson_no, lessons.level_no')
                ->distinct('lessons.moduleNo, lessons.routeno, lessons.lesson_no, lessons.level_no')
                ->where('courses.moduleNumber', $moduleNumber)
                ->join('courses', 'employeecourse.courseNumber', '=', 'courses.courseNumber')
                ->join('lessons', 'lessons.moduleNo', '=', 'courses.moduleNumber')
                ->orderBy('lessons.moduleno')
                ->orderBy('lessons.lesson_no')
                ->get();
            // check if it exists in useractivitylog_api, if not add it to todo list
            foreach ($lessons as $lesson) {
                // if activities are not filled
                if (count($threeLessons) < 3) {
                    // get occurence in useractivitylog for current lesson
                    $currentLesson = DB::table('useractivitylog_api')
                        ->select(['moduleNo', 'routeNo', 'levelNo', 'lessonNo', 'activityType'])
                        ->distinct(['moduleNo', 'routeNo', 'levelNo', 'lessonNo', 'activityType'])
                        ->where('userId', $userId)
                        ->where('moduleNo', $lesson->moduleno)
                        ->where('routeNo', $lesson->routeno)
                        ->where('lessonNo', $lesson->lesson_no)->get();
                    // if current lesson has one occurence and is a multiple of 3, that means that it is a play acitivity from 3rd set and we can skip it
                    if ($lesson->lesson_no % 3 === 0 && count($currentLesson) > 0) {
                        continue;
                    }
                    // base lesson to create other lessons from
                    $newLessonBase = new \stdClass();
                    $newLessonBase->moduleNo = $lesson->moduleno;
                    $newLessonBase->routeNo = $lesson->routeno;
                    $newLessonBase->levelNo = getLevelNoFromLessonNo($lesson->lesson_no);
                    $newLessonBase->lessonNo = $lesson->lesson_no;

                    // if current lesson is a play activity but no occurence in user activity add it the three lessons and continue
                    if ($lesson->lesson_no % 3 === 0 && count($currentLesson) === 0) {
                        $newLesson = clone $newLessonBase;
                        $newLesson->activityType = 3; // 3 because its play activity
                        $threeLessons[] = $newLesson;
                        continue;
                    }

                    // if current lesson has 0 occurence then we can loop over it thrice
                    if (count($currentLesson) === 0) {
                        // loop over thrice
                        for ($i = 1; $i <= 3; $i++) {
                            // as we only need three lessons, we can cap it
                            if (count($threeLessons) < 3) {
                                $newLesson = clone $newLessonBase;
                                $newLesson->activityType = $i;
                                $threeLessons[] = $newLesson;
                            } else {
                                break;
                            }
                        }
                    } else if (count($currentLesson) < 3) {
                        // if current lesson has less than three activities done
                        //  get all activities that are done in current scenario
                        $doneActivities = (clone $currentLesson)->pluck('activityType');

                        // it is the list of activity that are not done, we get it by removing the done activities for current lesson
                        $activitiesNotDone = array_map(function ($value) use ($newLessonBase) {
                            $newLesson = clone $newLessonBase;
                            $newLesson->activityType = $value;
                            return $newLesson;
                        }, array_diff([1, 2, 3], $doneActivities->toArray()));
                        // now iterate over these activities and push them into $threeLesson
                        foreach ($activitiesNotDone as $newActivity) {
                            if (count($threeLessons) < 3) {
                                $newActivity->levelNo = getLevelNoFromLessonNo($newActivity->lessonNo);
                                $threeLessons[] = $newActivity;
                            } else {
                                break;
                            }
                        }
                    }
                } else {
                    break;
                }
            }

            // we have three activities now, lets get flashcard and the roleplay

            $flashcard = null;  // <--- it will have the flashcard

            $cards = DB::table('employeecourse')->where('employeecourse.userId', $userId)
                // ->selectRaw('cards.id, cards.moduleNo, cards.routeNo, cards.lesssonNo')
                ->join('courses', 'employeecourse.courseNumber', '=', 'courses.courseNumber')
                ->join('cards', 'cards.moduleNo', '=', 'courses.moduleNumber')
                ->where('cards.moduleNo', $moduleNumber)
                ->orderBy('cards.moduleNo')
                ->orderBy('cards.routeNo')
                ->orderBy('cards.lesssonNo')
                ->get();

            foreach ($cards as $card) {
                if ($flashcard === null) {
                    if (!DB::table('useractivitylog_api')
                        ->where('userId', $userId)
                        ->where('moduleNo', $card->moduleNo)
                        ->where('routeNo', $card->routeNo)
                        ->where('lessonNo', $card->lesssonNo)
                        ->where('activityType', 4)->exists()) { // 4 is for flash card
                        $flashcard = $card;
                        break; // set flashcard to current card as it is not in dband break
                    }
                }
            }

            // we have flashcard as well now, lets head and get the last thing in the list, that is roleplay

            $newRolePlay = null;  // <--- it will have the roleplay
            //get last user activity
            $lastUserActivity = DB::table("useractivitylog_api")
                ->where('userId', $userId)
                ->where('moduleNo', $moduleNumber)
                ->orderBy('routeNo', 'desc')
                ->orderBy('lessonNo', 'desc')
                ->orderBy('activityDateTo', 'desc')
                ->first();
            // if last user actiivty is null we should put firstcourses first roleplay as the activity
            // now $lastRolePlay can be null if no role play is done, assign lesson 1 as the role play in this case
            // <module_no>_<route_number>_<level_number>_<lesson_number>
            $newRolePlay = $moduleNumber . "_1_1_1"; // sets it by default to basic
            // if there is last activity make roleplay accordinly
            if ($lastUserActivity) {
                $lastUsedModule = $lastUserActivity->moduleNo;
                // get last role play done in the module
                $lastRolePlay = DB::table("useractivitylog_api")
                    ->where('userId', $userId)
                    ->where('moduleNo', $moduleNumber)
                    ->where('activityType', 5)
                    ->orderBy('activityDateTo', 'desc')->first();
                if (!$lastRolePlay) {
                    // now $lastRolePlay can be null if no role play is done, assign lesson 1 as the role play in this case
                    // <module_no>_<route_number>_<level_number>_<lesson_number>
                    $newRolePlay = $lastUserActivity->moduleNo . "_1_1_" . 1;
                } else {
                    // or just assign next in the pattern
                    // <module_no>_<route_number>_<level_number>_<lesson_number>
                    $rolePlayLessonNumber = (($lastRolePlay->lessonNo + 1) % 3 === 0 ? $lastRolePlay->lessonNo + 2 : $lastRolePlay->lessonNo + 1);
                    // get routeno from lessons table for this specific lessona nd module
                    $lesson = Lesson::where("moduleno", $moduleNumber)->where("lesson_no", $rolePlayLessonNumber)->first();

                    if ($lesson) {
                        $newRolePlay =  $lesson->moduleno . "_" . $lesson->routeno . "_" . getLevelNoFromLessonNo($rolePlayLessonNumber) . "_" . $rolePlayLessonNumber;
                        // it could be the last available assign nil in this case.
                        $lastLesson = DB::table('lessons')->where('moduleNo', $lastRolePlay->moduleNo)->orderBy('lesson_no', 'desc')->first();
                        // get last available lesson from the module
                    } else {
                        $newRolePlay = null; // no role play available in current module
                    }
                    if ($rolePlayLessonNumber > $lastLesson->lesson_no) {
                        $newRolePlay = null; // no role play available in current module
                    }
                }
            }
            // check if three lessons are available or not, if not padd them
            if (count($threeLessons) < 3) {
                $threeLessons = array_pad($threeLessons, 3, (object) [
                    "moduleNo" => null,
                    "routeNo" => null,
                    "lessonNo" => null,
                    "levelNo" => null,
                    "activityType" => null,
                    "moduleRouteLesson" => null,
                ]);
            }

            return [
                'activation_status' => 1, // 1 for activated
                "activities" =>  array_merge(
                    array_map(function ($arr) use ($currentCourse) {
                        // get title and description for current lesson
                        $lessonDetails = DB::table("lessons")->where("moduleno", $arr->moduleNo)->where("routeno", $arr->routeNo)->where("lesson_no", $arr->lessonNo)->first();
                        return [
                            // <module_no>_<route_number>_<level_number>_<lesson_number>
                            "moduleRouteLesson" => $arr->moduleNo . "_" . $arr->routeNo . "_" . $arr->levelNo . "_" . $arr->lessonNo,
                            "title" => $lessonDetails->long_description,
                            "description" => $lessonDetails->description,
                            "activityType" => $arr->activityType, // 5 is for roleplay
                            "activityStatus" => 0, // 0  for unfinished , 1 for finished, will be updated from table while fetching
                            'courseNumber' => $currentCourse,
                        ];
                    }, $threeLessons),
                    [
                        [
                            // <module_no>_<route_number>_<level_number>_<lesson_number>
                            "moduleRouteLesson" => $flashcard ? $flashcard->moduleNo . "_" . $flashcard->routeNo . "_" . getLevelNoFromLessonNo($flashcard->lesssonNo) . "_" . $flashcard->lesssonNo : null,
                            "title" => "Go through a round of flashcards",
                            "description" => "Learn some new words",
                            "activityType" => 4, // 5 is for roleplay
                            "activityStatus" => 0, // 0  for unfinished , 1 for finished, will be updated from table while fetching
                            'courseNumber' => $currentCourse,
                        ],
                        [
                            "moduleRouteLesson" => $newRolePlay,
                            "title" => "Role-play conversation",
                            "description" => "Practice your conversation skills",
                            "activityType" => 5, // 5 is for roleplay
                            "activityStatus" => 0, // 0  for unfinished , 1 for finished, will be updated from table while fetching
                            'courseNumber' => $currentCourse,
                        ]
                    ]
                )
            ];
        } else {

            // activation status 0
            return [
                'activation_status' => 0, // 0 is for user that is not activated
                'activities' =>  getActivitiesFor0StatusUser($userId),
            ];
        }
    }
}

if (!function_exists('getTodoListByUserId')) {
    function getTodoListByUserId($userId = null)
    {
        if (!$userId) {
            return null;
        }
        // get todos
        $todos = \App\Todo::whereDate('date', now())->where('userId', $userId)
            ->get([
                'moduleRouteLesson',
                'title',
                'description',
                'activityType',
                'activityStatus',
                'courseNumber',
            ]);

        // get current course
        $currentCourse = \App\Employee::where('userId', $userId)->first()->currentCourse;
        // if todos are available
        if (count($todos) > 0) {
            // and current course does not match todo course
            if ($currentCourse && $currentCourse !== $todos[0]->courseNumber) {
                // regenerate all the todos
                // set todos to empty array so that it can be regerenated on line 1584, next line this is
                $todos = [];
            }
        }
        // if todos are empty try to generate them
        if (count($todos) === 0) {
            generateTodoListByUserId($userId);
            \Artisan::call("cron:generatedailytodo {$userId} --force");
            $todos = \App\Todo::whereDate('date', now())->where('userId', $userId)
                ->get([
                    'moduleRouteLesson',
                    'title',
                    'description',
                    'activityType',
                    'activityStatus',
                    'courseNumber',
                ]);
            // set current course from todoitself
            if (count($todos) > 0) {
                $currentCourse = $todos[0]->courseNumber;
            }
        } else {
            // check if current course mismatches, in which case regenerate the todolist
            if ($currentCourse !== $todos[0]->courseNumber) {
                //  regenerate todos for current user
                \Artisan::call("cron:generatedailytodo {$userId} --force");
                // set current course from todoitself
                $currentCourse = $todos[0]->courseNumber;
            }
        }
        return [
            'activation_status' => findIfUserIsActivatedByHisEmail($userId) ? 1 : 0,
            'currentCourse' => $currentCourse,
            'activities' => array_map(function ($todo) {
                unset($todo['courseNumber']);
                return $todo;
            }, $todos->toArray())
        ];
    }
}

if (!function_exists('getLevelNoFromLessonNo')) {
    /**
     * This function returns level no calculated from lesson no
     *
     * @param integer $lessonNo
     * @return integer
     */
    function getLevelNoFromLessonNo($lessonNo = 1)
    {
        return (int) (ceil($lessonNo / 3));
    }
}


if (!function_exists("updateTodoListStatusForUserId")) {
    /**
     * Updates status of items in user's todolist if necessary
     *
     * @param string $userId
     * @return void
     */
    function updateTodoListStatusForUserId(string $userId = ""): void
    {
        // get all the todos available to the user for today
        $todos = \App\Todo::whereDate('date', now())->where("userId", $userId)->get();

        if (count($todos) === 0) {
            return;
        }
        $currentCourse = $todos[0]->courseNumber;
        $moduleNumber = DB::table('courses')->where('courseNumber', $currentCourse)->first()->moduleNumber;
        // foreach todo update the todo according to its activity type and moduleRouteLevelLesson
        foreach ($todos as $todo) {
            // only if activityStatus is 0 (not done), check for status update
            if ($todo->activityStatus === 0) {
                $isActivityDone = false;
                switch ($todo->activityType) {
                        // for case 1,2,3,4,5 (listen, learn, play, flashcard and role play) just check in userActivityLogAPI for a record, if it exists, set is ActivityDone to true
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                        try {
                            list($moduleNo, $routeNo, $levelNo, $lessonNo) = explode("_", $todo->moduleRouteLesson);
                            $isActivityDone = DB::table('useractivitylog_api')
                                ->where('moduleNo', $moduleNo)
                                ->where('routeNo', $routeNo)
                                ->where('levelNo', $levelNo)
                                ->where('lessonNo', $lessonNo)
                                ->where('userId', $userId)
                                ->where('activityType', $todo->activityType)
                                ->exists() ? true : false;
                        } catch (\Exception $e) {
                            \Log::error("error in auto todolist update", [$e]);
                        }
                        break;
                    case 981: // registration has 981
                        break;
                    case 982:  // setting_up_reminder has 982
                        $isActivityDone = empty(DB::table('employee')->where('userId', $userId)->first()->receiveRemidersDay) ? false : true;
                        break;
                    case 983:
                        $isActivityDone = DB::table('useractivitylog_api') // TODO: has to be corrected, it uses lessonNo not activityType
                            ->select('lessonNo')
                            ->distinct('lessonNo')
                            ->where('userId', $userId)
                            ->where('moduleNo', $moduleNumber)
                            ->whereIn('LessonNo', [1, 2, 3])
                            ->whereIn('activityType', [1, 2, 3])
                            ->count() ? true : false;
                        break;
                    case 984: // flashcard has 984
                        $isActivityDone = DB::table('useractivitylog_api')
                            ->where('userId', $userId)
                            ->where('moduleNo', $moduleNumber)
                            ->where('activityType', 4)
                            ->exists() ? true : false;
                        break;
                    case 985: // roleplay has 985
                        $isActivityDone = DB::table('useractivitylog_api')
                            ->where('userId', $userId)
                            ->where('moduleNo', $moduleNumber)
                            ->where('activityType', 5)
                            ->exists() ? true : false;
                        break;
                    default:
                }
                //  if the activity is done save it
                if ($isActivityDone) {
                    $todo->activityStatus = 1;
                    $todo->save();
                }
            }
        }
    }
}


if (!function_exists("pushPayloadToUserId")) {
    /**
     * Push a associative array as payload to employee using employee's userId
     *
     * @param string $userId the email if of the user to send push to
     * @param array $payload the associative array to be sent as payload
     * @return boolean the boolean value whether the push was successful or not
     */
    function pushPayloadToUserId(string $userId, $payload = []): bool
    {
        try {

            // get employee
            $employee = DB::table("employee")->where("userId", $userId)->first();
            if (!$employee) {
                return false;
            }

            // get employee fcm token
            $fcmToken = $employee->fcmToken;
            if (!$fcmToken) {
                return false;
            }

            // set payload
            $fields = array(
                'to' => $fcmToken,
                'data' => $payload
            );
            // send notification
            Log::info("pushPayloadToUserId " . $userId, $fields);
            return sendNotification($fields);
        } catch (\Exception $e) {
            Log::error("pushPayloadToUserId failed", [$e]);
            return false;
        }
    }
}

if (!function_exists("getAllScreenNames")) {
    function getAllScreenNames()
    {
        return [
            "98" => "Add Name",
            "99" => "Course Registration",
            "100" => "Home Screen",
            "101" => "Module Screen",
            "102" => "LLP Screen",
            "103" => "Pre-Listen Screen",
            "104" => "Listen Screen",
            "105" => "Learn Screen",
            "106" => "Play Screen",
            "107" => "Profile Tab",
            "108" => "Listen Interactive Screen",
            "109" => "Pre-Listen Interactive Screen",
            "110" => "FORUM_NOTIFICATION",
            "111" => "EXERCISES_NOTIFICATION",
            "112" => "FLASHCARD_NOTIFICATION",
            "113" => "Inactive User Type 1",
            "114" => "Inactive User Type 2",
            "115" => "Inactive User Type 3",
            "116" => "Inactive User Type 4",
            "117" => "Open App",
            "118" => "Payment Screen",
            "119" => "Payment Screen 2",
            "121" => "Video Completion Screen",
            "122" => "Exercise Completion Screen",
            "123" => "Pre Play Screen",
            "124" => "Quick Tip",
            "125" => "Exercise Cancel Screen",
            "131" => "Translate Sentence",
            "132" => "Select Correct Translation",
            "133" => "Informational",
            "134" => "Mini Lesson",
            "135" => "Select Missing Word",
            "136" => "Multiple Choice",
            "137" => "Tap What You Hear",
            "138" => "The The Pair",
            "139" => "Tap The Pair Sentences",
            "140" => "Voice Recognition",
            "141" => "Forum Screen",
            "142" => "Community Forum Screen",
            "143" => "Community Forum Comments Screen",
            "144" => "Community Forum Create Screen",
            "145" => "Age OnBoarding Screen",
            "146" => "Education OnBoarding Screen",
            "147" => "Qualification OnBoarding Screen",
            "148" => "Level OnBoarding Screen",
            "200" => "RECEIVE_FLASH_CARD_NOTIFICATION",
            "201" => "RECEIVE_WEEKLY_COMPLETION_NOTIFICATION",
            "202" => "RECEIVE_WEEKLY_TASK_NOTIFICATION",
            "203" => "",
            "204" => "RECEIVE_DAILY_NOTIFICATION",
            "205" => "",
            "206" => "RECEIVE_REGISTRATION_NOTIFICATION",
            "210" => "RECEIVE_FORUM_NOTIFICATION",
            "211" => "RECEIVE_EXERCISES_NOTIFICATION",
            "212" => "RECEIVE_FLASHCARD_NOTIFICATION",
            "300" => "OPEN_FLASH_CARD_NOTIFICATION",
            "301" => "OPEN_WEEKLY_COMPLETION_NOTIFICATION",
            "302" => "OPEN_WEEKLY_TASK_NOTIFICATION",
            "303" => "",
            "304" => "OPEN_DAILY_NOTIFICATION",
            "305" => "",
            "306" => "OPEN_REGISTRATION_NOTIFICATION",
            "310" => "OPEN_FORUM_NOTIFICATION",
            "311" => "OPEN_EXERCISES_NOTIFICATION",
            "312" => "OPEN_FLASHCARD_NOTIFICATION",
        ];
    }
}


if (!function_exists("getScreenNameFromCode")) {
    /**
     * Returns screen name for screenCode
     *
     * @param integer $screenCode
     * @return string
     */
    function getScreenNameFromCode($screenCode = 99): string
    {
        try {
            $screenCodes = getAllScreenNames();

            return $screenCodes[$screenCode];
        } catch (\Exception $e) {
            return "Default";
        }
    }
}


if (!function_exists("getCourseNofromModuleNo")) {
    /**
     * This function returns courseNumber from given moduleNo
     * and userId, for a specific person
     *
     * @param integer $moduleNo
     * @param string $userId
     * @return integer|null
     */
    function getCourseNoFromModuleNo($moduleNo = null, $userId = null, $returnModel = false)
    {
        try {
            /* as we do not have moduleNumber in direct relation to employee,
               we are joining employeecourse and courses table to fetch the courseNo,
               use user id and moduleNo */
            $course = DB::table('employeecourse')
                ->join("courses", "employeecourse.courseNumber", "=", "courses.courseNumber")
                ->where("courses.moduleNumber", $moduleNo)
                ->where("employeecourse.userId", $userId)
                ->first();
            if ($returnModel) return $course;

            return $course ? $course->courseNumber : null;
        } catch (\Exception $e) {
            return null;
        }
    }
}

if (!function_exists("getCourseNoByCohortIdAndModuleNumber")) {
    /**
     * This function returns courseNumber from given moduleNo
     * and userId, for a specific person
     *
     * @param integer $moduleNo
     * @param string $userId
     * @return integer|null
     */
    function getCourseNoByCohortIdAndModuleNumber($cohortId = null, $moduleNo = false, $returnModel = false)
    {
        try {
            /* as we do not have moduleNumber in direct relation to employee,
               we are joining employeecourse and courses table to fetch the courseNo,
               use user id and moduleNo */
            $course = DB::table('courses')
                ->where("moduleNumber", $moduleNo)
                ->where("cohort_id", $cohortId)
                ->first();
            if ($returnModel) return $course;
            return $course ? $course->courseNumber : null;
        } catch (\Exception $e) {
            return null;
        }
    }
}


if (!function_exists('getTokenForEmail')) {
    /**
     * Returns token for specific email id
     *
     * @param [type] $email
     * @return void
     */
    function getTokenForEmail($email = null)
    {
        try {
            if (empty($email)) {
                return null;
            }
            $user = \App\User::where("email", $email)->first();
            if (empty($user)) {
                return null;
            }
            return $user->createToken('PAT')->accessToken;
        } catch (\Exception $e) {
            throw $e;
            return null;
        }
    }
}


if (!function_exists("td")) {
    /**
     * DD replica, just shows data in simple table and die
     *
     * @param \Illuminate\Support\Collection|array $input
     * @return void
     */
    function td($input = [])
    {
        $data = $input instanceof \Illuminate\Support\Collection ? $input->toArray() : (array) $input;
        $isFirst = true;
        if (!empty($data)) {
            echo "<table>";
            foreach ($data as $datum) {
                if ($isFirst) {
                    // print all the keys in th
                    $datum = (array) $datum;
                    echo "<tr style=\"border: 1px solid gray;\">";
                    foreach (array_keys($datum) as $columnName) {
                        echo "<th>";
                        echo $columnName;
                        echo "</th>";
                    }
                    echo "</tr>";
                    $isFirst = false;
                }
                echo "<tr>";
                foreach ($datum as $columnValue) {
                    echo "<td>";
                    echo $columnValue;
                    echo "</td>";
                }
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "Empty dataset";
        }
        die();
    }
}



if (!function_exists("tt")) {
    /**
     * DD replica, just shows data in simple table
     *
     * @param \Illuminate\Support\Collection|array $input
     * @return void
     */
    function tt($input = [])
    {
        $data = $input instanceof \Illuminate\Support\Collection ? $input->toArray() : (array) $input;
        $isFirst = true;
        if (!empty($data)) {
            echo "<table>";
            foreach ($data as $datum) {
                if ($isFirst) {
                    // print all the keys in th
                    $datum = (array) $datum;
                    echo "<tr style=\"border: 1px solid gray;\">";
                    foreach (array_keys($datum) as $columnName) {
                        echo "<th>";
                        echo $columnName;
                        echo "</th>";
                    }
                    echo "</tr>";
                    $isFirst = false;
                }
                echo "<tr>";
                foreach ($datum as $columnValue) {
                    echo "<td>";
                    echo $columnValue;
                    echo "</td>";
                }
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "Empty dataset";
        }
    }
}


if (!function_exists("getUserIdFromToken")) {
    /**
     * Takes in the passport token and returns user email Id
     *
     * @param string $token
     * @return string|null
     */
    function getUserIdFromToken($token = "")
    {
        try {
            $keyPath = \Laravel\Passport\Passport::keyPath('oauth-public.key');
            $parseTokenKey = file_get_contents($keyPath);

            $token = (new \Lcobucci\JWT\Parser())->parse((string) $token);

            $signer = new \Lcobucci\JWT\Signer\Rsa\Sha256();

            if ($token->verify($signer, $parseTokenKey)) {
                $id = $token->getClaim('sub');
                return \App\User::find($id)->email;
            } else {
                return null;
            }
        } catch (\Exception $e) {
            return null;
        }
    }
}


if (!function_exists("setForumAsSeenByUser")) {
    /**
     * Marks Comment and their replies on a forum to seen using an email id
     *
     * @param Forum $forum
     * @param string $userId
     * @return void
     */
    function setForumAsSeenByUser(Forum $forum, string $userId)
    {
        try {

            $commentIds = [];
            // get all the comment id for the forum;
            foreach ($forum->comments as $comment) {
                // push the comment id in array
                $commentIds[] = $comment->id;
                // iterate for its replies
                foreach ($comment->comments as $reply) {
                    // push the reply id in array
                    $commentIds[] = $reply->id;
                }
            }
            // we now have all the comment ids in $commentIds
            // now we can check for each comment id and our email that if the records exists in our db
            foreach ($commentIds as $id) {
                $view = CommentView::where('userId', $userId)->where('comment_id', $id)->first();
                if (!$view) {
                    // if no records, that means its not viewed yet.
                    // create a view in this case
                    $view = new CommentView();
                    $view->userId = $userId;
                    $view->comment_id = $id;
                    $view->save();
                }
            }
        } catch (\Exception $e) {
            Log::error("setForumAsSeenByUser failed", [$e]);
        }
    }
}


if (!function_exists('getCountOfNewMessagesInForum')) {
    /**
     * Returns number of new messages from a forum that user has not seen
     *
     * @param Forum $forum
     * @param string $userId
     * @return integer
     */
    function getCountOfNewMessagesInForum(Forum $forum, string $userId): int
    {
        try {

            $commentIds = [];
            // get all the comment id for the forum;
            foreach ($forum->comments as $comment) {
                // push the comment id in array
                $commentIds[] = $comment->id;
                // iterate for its replies
                foreach ($comment->comments as $reply) {
                    // push the reply id in array
                    $commentIds[] = $reply->id;
                }
            }
            // we now have all the comment ids in $commentIds
            $commentCount = count($commentIds);
            // now we can check if any of the comment id is not available in comment_views table for our user
            $commentViewed = CommentView::whereIn("comment_id", $commentIds)->where('userId', $userId)->distinct('comment_id')->count();
            if ($commentCount > $commentViewed) {
                return $commentCount - $commentViewed;
            } else {
                return 0;
            }
        } catch (\Exception $e) {
            Log::error("setForumAsSeenByUser failed", [$e]);
            return 0;
        }
    }
}

if (!function_exists('addUserToSegment')) {
    /**
     * This function adds a user to a segment
     *
     * @param string $segmentCode unique code of the segment
     * @param string $userId email id of the user
     * @return boolean returns bool whether the operation was successful or not
     */
    function addUserToSegment(string $segmentCode, string $userId): bool
    {
        try {
            // get the user segment
            $userSegment = \App\UserSegment::where('code', $segmentCode)->first();
            // if user segment exists, add user to it
            if ($userSegment) {
                // returns true if data inserted
                $done = DB::table('user_user_segment')->updateOrInsert([
                    'userId' => $userId,
                    'user_segment_id' => $userSegment->id
                ], [
                    'userId' => $userId,
                    'user_segment_id' => $userSegment->id
                ]);

                // update the user count
                $userSegment->user_count = $userSegment->user_count + 1;
                $userSegment->save();

                // trigger event
                if ($done) {
                    // if actually changed server
                    event(new UserAddedToSegment($segmentCode, $userId));
                }
                return $done;
            } else {
                // else return false
                return false;
            }
        } catch (\Exception $e) {
            Log::error("exception occurred at addUserToSegment helper function", [$e]);
            return false;
        }
    }
}

if (!function_exists("getLivesLeftForLesson")) {
    /**
     *  show the lives left in previous round with best attempt
     *
     * @param integer $moduleNo
     * @param integer $routeNo
     * @param integer $lessonNo
     * @param string $userId
     * @return integer $livesLeft
     */
    function getLivesLeftForLesson(int $moduleNo, int $routeNo, int $lessonNo, string $userId): int
    {

        try {
            $lastRound = RoundLog::where('moduleNo', $moduleNo)
                ->where('routeNo', $routeNo)
                ->where('lessonNo', $lessonNo)
                ->where('userId', $userId)
                ->latest()
                ->first();
            return (int) $lastRound->livesLeft ?? 0;
        } catch (\Exception $e) {
            Log::error("exception occurred at getLivesLeftForLesson helper function", [$e]);
            return 0;
        }
    }
}

if (!function_exists("updateUserScoreForCourse")) {
    /**
     * Helper to update user score
     * should always user it to trigger badges too
     *
     * @param string $userId email of employee
     * @param int $courseNumber course number
     * @param int $score score to be update
     * @return void
     */
    function updateUserScoreForCourse($userId, $courseNumber = null, $score = null)
    {
        // Do nothing
        return;
        try {
            // FIXME: Change me when all users update
            $employee = Employee::where('userId', $userId)->first();
            if (
                (strtolower($employee->mobileOS) === "ios" && ((float) $employee->versionNumber) < 1.5057) || (strtolower($employee->mobileOS) === "android" && ((int) $employee->versionNumber) < 145)
            ) {
                // update the user score
                DB::table('employeecourse')->where('userId', $userId)->where('courseNumber', $courseNumber)->update([
                    'score' => $score,
                ]);
                // update the score in employee table as well
                $employee->score = $score;
                $employee->save();
                // trigger event
                event(new CheckForBadges([
                    "eventType" => AppCheckForBadges::$pointsgains,
                    "courseNumber" => $courseNumber,
                    "userId" => $userId,
                    'score' => $score,
                ]));
            } else {
                throw new \Exception('new apps wont use this');
            }
        } catch (\Exception $e) {
            Log::error("updateUserScoreForCourse helper function", [compact('userId', 'courseNumber', 'score'), $e]);
        }
    }
}

if (!function_exists("addUserScoreForCourse")) {
    /**
     * Helper to update user score
     * should always user it to trigger badges too
     *
     * @param string $userId email of employee
     * @param int $courseNumber course number
     * @param int $point point to be added
     * @return void
     */
    function addUserScoreForCourse($userId, $courseNumber, $point)
    {
        try {
            // get last score
            $score = (int) \DB::table('employeecourse')->where('userId', $userId)->where('courseNumber', $courseNumber)->first()->totalScore ?? 0;

            if ($score === 0) {
                // calculate the total score for (not for  current course now)
                $score = \App\UserDailyGoalLog::where('userId', $userId)
                    ->sum('points') - $point;
                // as point will be added later
            }
            // update the user score
            $newScore = $score + $point;
            \DB::table('employeecourse')->where('userId', $userId)->where('courseNumber', $courseNumber)->update([
                'totalScore' => $newScore,
            ]);
            // update the score in employee table as well
            \App\Employee::where('userId', $userId)->update([
                'totalScore' => $newScore,
            ]);
            // trigger event
            event(new \App\Events\CheckForBadges([
                "eventType" => AppCheckForBadges::$pointsgains,
                "courseNumber" => $courseNumber,
                "userId" => $userId,
                'score' => $newScore,
            ]));
            return $newScore;
        } catch (\Exception $e) {
            \Log::error("addUserScoreForCourse helper function", [compact('userId', 'courseNumber', 'score'), $e]);
            return 0;
        }
    }
}

if (!function_exists("getLessonsComplete")) {
    /**
     * Get lessonNos for completed lesson of a course
     *
     * @param [type] $userId
     * @param [type] $courseNumber
     * @return void
     */
    function getLessonsCompleteForCourse($userId, $courseNumber)
    {
        try {
            // get course, to get moduleNumber
            $course = Course::where('courseNumber', $courseNumber)->first();
            // return the lesson No of all completed lessons
            return UserActivityLog::distinct('moduleNo', 'lessonNo', 'levelNo', 'activityType')
                ->where('moduleNo', $course->moduleNumber)
                ->where('userId', $userId)
                ->where('activityType', 3)
                ->pluck('lessonNo');
        } catch (\Exception $e) {
            Log::error("getLessonsCompleteForCourse helper function", [compact('userId', 'courseNumber'), $e]);
        }
    }
}

if (!function_exists('getMilestonesCompleted')) {

    /**
     * Returns the last milestone crossed by userfor a certain module, on basisc of round log api
     *
     * @param string $userId
     * @param integer $moduleNumber
     * @return integer
     */
    function getMilestonesCompleted($userId = "", $moduleNumber = 0): int
    {
        $unlockedMilestone = -1;
        try {
            $milestones = Lesson::where('moduleno', $moduleNumber)
                ->where('is_challenge', 1)
                ->where('challenge_type', 'milestone')
                ->orderBy('lesson_no', 'desc')
                ->get(['moduleno', 'routeno', 'lesson_no']);

            // for each milestone, in creasing order, just check if it has been done, if so, return the it as done milestone.
            foreach ($milestones as $milestone) {
                if (RoundLog::where('userId', $userId)->where('moduleNo', $milestone->moduleno)->where('routeNo', $milestone->routeno)->where('lessonNo', $milestone->lesson_no)->where('status', 1)->exists()) {
                    // this is the latest milestone
                    $unlockedMilestone = $milestone->lesson_no;
                    break;
                }
            }
        } catch (\Exception $e) {
            Log::error("getLessonsCompleteForCourse helper function", [compact('userId', 'courseNumber'), $e]);
        }
        // return the unlocked milestone
        return $unlockedMilestone;
    }
}


if (!function_exists('getTestPushUsers')) {
    /**
     * Returns an array of user Id
     *
     * @return void
     */
    function getTestPushUsers(): array
    {
        return [
            'sanjoy.sanyal@taplingua.com',
            'jrachoene@yahoo.com',
            'thefallenmerc@gmail.com',
            'simran@truetechpro.com',
        ];
    }
}

if (!function_exists('followTheForum')) {
    function followTheForum($userId, \App\Comment $entity)
    {
        // if entity's commentOn is a forum, save the id and send it back
        if ($entity->commentOn instanceof \App\Forum) {
            if (!\App\FollowingForum::where('userId', $userId)->where('forum_id', $entity->commentable_id)->exists()) {
                \App\FollowingForum::create([
                    'userId' => $userId,
                    'forum_id' => $entity->commentable_id,
                ]);
            }
            return $entity->commentable_id;
        } else if ($entity->commentOn instanceof \App\Comment) {
            return followTheForum($userId, $entity->commentOn);
        } else {
            return null;
        }
    }
}

if (!function_exists('getForumForComment')) {
    function getForumForComment(\App\Comment $comment): \App\Forum
    {
        if ($comment->commentOn instanceof \App\Forum) {
            // if entity's commentOn is a forum return it
            return $comment->commentOn;
        } else if ($comment->commentOn instanceof \App\Comment) {
            // else if its a comment check for forum on it
            return getForumForComment($comment->commentOn);
        } else {
            // else return null
            return null;
        }
    }
}

if (!function_exists('getForumWebAppLink')) {
    function getForumWebAppLink(string $userId, \App\Forum $forum): string
    {
        if (!$forum) {
            return null;
        }

        $url = url('/app/forum/');

        $token = getTokenForEmail($userId);

        switch ($forum->for) {
            case 'v2exercise':
                $url = url('/uiforum?exerciseId=' . $forum->forumable_id);
                break;
            case 'listen':
                $lesson = $forum->forumFor;
                $url = url('/uiforum?forumFor=listen&moduleNo' . $lesson->moduleno . "&routeNo" . $lesson->routeno . "&lessonNo" . $lesson->lesson_no);
                break;
            case 'video':
                $lesson = $forum->forumFor;
                $url = url('/uiforum?forumFor=video&moduleNo' . $lesson->moduleno . "&routeNo" . $lesson->routeno . "&lessonNo" . $lesson->lesson_no);
                break;
        }

        return $url . "&token=" . $token;
    }
}

if (!function_exists('generatePushCacheKey')) {
    function generatePushCacheKey($userId = "", $campaignId = "", $date = null)
    {
        if ($date === null) {
            $date = \Carbon\Carbon::now()->format("Y-m-d");
        }
        return $userId . "-" . $campaignId . "-" . $date;
    }
}

if (!function_exists('createBadgeDescription')) {
    function createBadgeDescription($description, $userId)
    {
        //  get employee
        $employee = Employee::where('userId', $userId)->first();
        $description = preg_replace('/\{username\}/i', $employee->FirstName, $description);
        return $description;
    }
}

if (!function_exists('reactivateUserIfNeeded')) {
    function reactivateUserIfNeeded(Employee $employee)
    {
        try {
            if ($employee->is_user_lost && \Carbon\Carbon::parse($employee->user_lost_at)->lt(\Carbon\Carbon::parse($employee->lastLoginDate))) {
                $employee->is_user_lost = false;
                // enable notificaiton to him, if were disabled by system
                if ($employee->receivePush == -1) {
                    $employee->receivePush = 1;
                }
                $employee->user_lost_at = null;
                $employee->save();
            }
        } catch (\Throwable $th) {
            Log::error('reactivating user failed', [$employee->userId, $th->getMessage()]);
        }
    }
}

if (!function_exists('getUserGoalDataForLast7Days')) {
    /**
     * get the user goal stats for last 7 days
     *
     * @param \App\Employee $employee
     * @return array
     */
    function getUserGoalDataForLast7Days(\App\Employee $employee): array
    {
        $last7DaysRaw = \App\UserDailyGoalLog::selectRaw("sum(points) as total, dated")
            ->where('userId', $employee->userId)
            ->whereDate('dated', '>=', today()->subDays(7))
            ->whereDate('dated', '<=', today())
            ->groupBy('dated', 'userId')
            ->orderBy('dated', 'DESC')
            ->get();

        $last7Days = [
            now()->subDays(0)->format('Y-m-d') => 0,
            now()->subDays(1)->format('Y-m-d') => 0,
            now()->subDays(2)->format('Y-m-d') => 0,
            now()->subDays(3)->format('Y-m-d') => 0,
            now()->subDays(4)->format('Y-m-d') => 0,
            now()->subDays(5)->format('Y-m-d') => 0,
            now()->subDays(6)->format('Y-m-d') => 0,
            now()->subDays(7)->format('Y-m-d') => 0,
        ];

        foreach ($last7DaysRaw as $day) {
            $last7Days[$day->dated] = $day->total;
        }

        return [
            'employee' => $employee,
            'last7Days' => $last7Days,
            'total' => array_sum($last7Days),
        ];
    }
}

if (!function_exists("checkIfJobDispatched")) {
    /**
     * Check if Job Dispatched to the user
     *
     * @param string $userId userId from employee table
     * @param string $job_name unique name of the job
     * @param string $date date in Y-m-d format
     * @return boolean
     */
    function checkIfJobDispatched(string $userId, string $job_name, string $date = null): bool
    {

        $date = $date ? \Carbon\Carbon::parse($date) : today();

        return \App\DispatchedJobLog::where('userId', $userId)
            ->where('job_name', $job_name)
            ->whereDate('created_at', $date)
            ->exists();
    }
}

if (!function_exists("markJobDispatched")) {
    /**
     * Mark Job as dispatched
     *
     * @param string $userId
     * @param string $job_name
     * @param string $job_type
     * @return boolean
     */
    function markJobDispatched(string $userId, string $job_name, string $job_type): bool
    {
        try {
            \App\DispatchedJobLog::create([
                'userId' => $userId,
                'job_name' => $job_name,
                'job_type' => $job_type,
            ]);
            return true;
        } catch (\Exception $th) {
            return false;
        }
    }
}

if (!function_exists("sendNotificationMail")) {
    function sendNotificationMail($employee, $title, $body, $branchURL, $campaignId, $webAppLink = "")
    {
        try {

            $mail = null;
            switch ($campaignId) {
                case 'comment_notification_push':
                    $mail = new \App\Mail\CommentNotificationMail(
                        $employee,
                        $title,
                        $body,
                        $branchURL,
                        $webAppLink
                    );
                    break;
                default:
                    $mail = new \App\Mail\NotificationMail(
                        $employee,
                        $title,
                        $body,
                        $branchURL
                    );
                    break;
            }
            // check if not blocked
            if (\DB::table("ses_sns_email_list")->where('userId', $employee->userId)->doesntExist() || $campaignId === "comment_notification_push") {
                // send mail
                \Mail::to($employee->userId)
                    ->queue($mail);
            } else {
                \Log::channel("pushlog")->info("user Id blocked", [$employee->userId]);
            }
        } catch (\Throwable $th) {
            \Log::channel("pushlog")->info("could not send notification mail", [$employee, $title, $body, $branchURL, $campaignId, $webAppLink = ""]);
        }
    }
}



if (!function_exists('followTheCommunityForum')) {
    function followTheCommunityForum($userId, \App\Comment $entity)
    {
        // if entity's commentOn is a forum, save the id and send it back
        if ($entity->commentOn instanceof \App\UserQuestion) {
            if (!\App\FollowingUserQuestion::where('userId', $userId)->where('user_question_id', $entity->commentable_id)->exists()) {
                \App\FollowingUserQuestion::create([
                    'userId' => $userId,
                    'user_question_id' => $entity->commentable_id,
                ]);
            }
            return $entity->commentable_id;
        } else if ($entity->commentOn instanceof \App\Comment) {
            return followTheCommunityForum($userId, $entity->commentOn);
        } else {
            return null;
        }
    }
}

if (!function_exists('checkIfEmailSubscribed')) {
    function checkIfEmailSubscribed(string $email)
    {
        return \DB::table("ses_sns_email_list")
            ->where('userId', $email)
            ->doesntExist();
    }
}

if (!function_exists('getUnsubscribeLink')) {
    function getUnsubscribeLink(string $email = "")
    {
        return url("unsubscribe?email=" . $email);
    }
}

if (!function_exists('getTotalGoalPointsForUser')) {
    function getTotalGoalPointsForUser($userId)
    {
        return (int) \App\UserDailyGoalLog::where('userId', $userId)
            ->sum('points');
    }
}

if (!function_exists('updateRankByDateRange')) {
    function updateRankByDateRange($startDate, $endDate, $type)
    {
        // get all the ones on leaderboard
        $ranks = \App\UserDailyGoalLog::select('userId', \DB::raw('sum(points) as current'))
            ->whereBetween('dated', [$startDate, $endDate])
            ->groupBy('userId')
            ->orderBy('current', 'desc')
            ->get();
        // pluck the winners, they are sorted by rank already
        $winners = $ranks->pluck('userId')->toArray();
        // add the rest of employees, they are all leftovers
        $remainingEmployees = \App\Employee::whereNotIn('userId', $winners)
            ->whereDate('accountCreationDate', '>=', new \Carbon\Carbon('2020-08-01'))
            ->pluck('userId')->toArray();

        // map it to hold rank
        $timestamp = now();
        $ranks = array_merge($winners, $remainingEmployees);

        foreach ($ranks as $key => $item) {
            // foreach rank, check if already exists
            $previousRank = \App\LeaderboardRank::where('userId', $item)->where('type', $type)->first();
            $newRank = $key + 1;
            if ($previousRank) {
                // if previous rank exists, calculate the delta
                $newDelta = $newRank - $previousRank->rank;
                // if the rank has changed, update the delta
                if ($previousRank->rank !== $newRank) {
                    $previousRank->delta = $newDelta;
                }
            } else {
                $previousRank = new \App\LeaderboardRank([
                    'userId' => $item,
                    'type' => $type,
                    'delta' => 0,
                ]);
            }
            // set new rank
            $previousRank->rank = $newRank;
            $previousRank->save();
        }

        return $ranks;
    }
}

if (!function_exists('__temp_get_milestone_exception_user_list')) {
    /**
     * This function returns the list of users that are allowed to see milestones
     *
     * @return Array
     */
    function __temp_get_milestone_exception_user_list(): array
    {
        return DB::table('__temp_milestone_exception_users')->pluck('userId')->toArray();
    }
}

if (!function_exists('__check_for_milestone_version_app')) {
    // Android milestone will be returned for version 153
    // for IOS it will be 1.6010
    function __check_for_milestone_version_app(String $userId)
    {
        $employee = Employee::where('UserId', $userId)->first();
        if (!$employee) {
            return false;
        }

        if (strtolower($employee->mobileOS) === "ios") {
            // check for ios
            return (float) $employee->versionNumber >= 1.6010;
        } else {
            // check for android
            return (float) $employee->versionNumber >= 160;
        }
    }
}

if (!function_exists('__get_variable')) {
    // get a code variable directly from database
    function __get_variable(string $key)
    {
        $record = DB::table('__code_variables')->where("variable_name", $key)->first();
        if ($record) {
            return $record->variable_value;
        } else {
            return null;
        }
    }
}

if (!function_exists('getUserMistakesForLesson')) {
    // get count of user failed exercises in an mrl
    function getUserMistakesForLesson(int $moduleNo, int $routeNo, int $lessonNo, string $userId)
    {


        $failedExerciseData = \DB::select(
            \DB::raw("SELECT distinct(questionId) as id, v2_exercises.sequenceNo, v2_exercises.moduleNo, v2_exercises.routeNo, v2_exercises.lessonNo, v2_exercises.exerciseType, v2_exercises.forInteractiveListen, v2_exercises.question, v2_exercises.options, v2_exercises.answer, v2_exercises.translation, v2_exercises.status, v2_exercises.created_at, v2_exercises.updated_at, sum(failCount) as fail_count FROM `round_exercise_logs` INNER JOIN v2_exercises on v2_exercises.id = round_exercise_logs.questionId WHERE userId = '{$userId}' AND round_exercise_logs.moduleNo = {$moduleNo} AND round_exercise_logs.routeNo = {$routeNo} AND round_exercise_logs.lessonNo = {$lessonNo}  GROUP BY questionId HAVING fail_count > 0")
        );

        $collectedFailedExercises = collect($failedExerciseData)->filter(function ($value) use ($userId) {
            return !userHasReviewedV2Exercise($userId, $value->id);
        });

        return $collectedFailedExercises->map(function ($exercise) {
            $exercise->module = \App\Module::where('moduleno', $exercise->moduleNo)->first();
            return $exercise;
        });

        return $failedExerciseData;

        // no need for bottom one

        // hold failed exercises ids in id => fail_count
        $failedExerciseIDs = [];

        foreach ($failedExerciseData as $failedExercise) {
            // Check if User already completed review for it
            $isAlreadyReviewed = RoundExerciseLog::where('questionId', $failedExercise->questionId)
                ->where('userId', $userId)
                ->where('status', 1)
                ->where('roundType', 'failed_exercise')
                ->exists();

            if (!$isAlreadyReviewed) {
                $failedExerciseIDs[$failedExercise->questionId] = $failedExercise->fail_count;
            }
        }

        $failedExercises = \App\V2Exercise::whereIn('id', array_keys($failedExerciseIDs))
            ->where('moduleNo', $moduleNo)
            ->where('routeNo', $routeNo)
            ->where('lessonNo', $lessonNo)
            ->get();

        // add fail count to map
        $failedExercises = $failedExercises->map(function ($failedExercise) use ($failedExerciseIDs) {
            $failedExercise->fail_count = $failedExerciseIDs[$failedExercise->id];
            return $failedExercise;
        });

        return $failedExercises;
    }
}

if (!function_exists('getUserMistakesCountForLesson')) {
    function getUserMistakesCountForLesson(int $moduleNo, int $routeNo, int $lessonNo, string $userId, bool $thorough = false)
    {
        return 0;
        //bypass to prevent sql lockout time

        // get mistake count from failed lesson count
        $lessonFailCount = LessonFailCount::where('userId', $userId)
            ->where('moduleNo', $moduleNo)
            ->where('routeNo', $routeNo)
            ->where('lessonNo', $lessonNo)
            ->first();

        if ($lessonFailCount && !$thorough) {
            return $lessonFailCount->fail_count;
        } else {
            // calculate the fail count
            $queryResult = \DB::select(
                \DB::raw("SELECT distinct(questionId) FROM `round_exercise_logs` WHERE userId = '{$userId}' AND moduleNo = {$moduleNo} AND routeNo = {$routeNo} AND lessonNo = {$lessonNo} AND status = 0 GROUP BY questionId")
            );

            // get sum of all the fails in all the exercises that have not been reviewed
            $fail_count = array_sum(array_map(function ($value) use ($userId) {
                // check if the mistake is reviewed once by the user, set fail count to 0 in that case
                if (userHasReviewedV2Exercise($userId, $value->questionId)) {
                    return 0;
                }
                return 1;
            }, $queryResult));

            LessonFailCount::where('moduleNo', $moduleNo)
                ->where('routeNo', $routeNo)
                ->where('lessonNo', $lessonNo)
                ->where('userId', $userId)
                ->delete();

            // save the fail count
            LessonFailCount::create([
                'userId' => $userId,
                'moduleNo' => $moduleNo,
                'routeNo' => $routeNo,
                'lessonNo' => $lessonNo,
                'fail_count' => $fail_count
            ]);
            // return the fail count
            return $fail_count;
        }
    }
}

if (!function_exists('userHasReviewedV2Exercise')) {
    /**
     * Check if user has review the v2exercise successfully
     *
     * @param [type] $userId
     * @param [type] $v2exerciseId
     * @return void
     */
    function userHasReviewedV2Exercise($userId, $v2exerciseId)
    {
        return \App\RoundExerciseLog::where('userId', $userId)->where('questionId', $v2exerciseId)->where('roundType', 'failed_exercise')->where('status', 1)->exists();
    }
}

if (!function_exists('makeV2PollyFromSSMLAndUploadToS3')) {
    // make polly for SSML and upload to S3
    function makeV2PollyFromSSMLAndUploadToS3(string $ssml, string $m_r_l, int $v2exerciseId, bool $debug = false)
    {
        $debugOutput = "";
        // folder to store the polly
        $mp3folder = storage_path() . "/Lesson_Module_Packs/Lesson_" . $m_r_l . "_Pack/v2exercises/";
        // make the mp3folder if not exists
        $cmd = "mkdir -p " . $mp3folder;
        exec($cmd, $debugOutput);

        if ($debug) {
            print_r([
                'cmd' => $cmd,
                'output' => $debugOutput
            ]);
        }

        // generate link to mp3 file
        $mp3file = $mp3folder . $v2exerciseId . ".mp3";

        // get the voice actor from module tolanguage
        $lang = "ES";
        try {
            $lang = strtoupper(V2Exercise::find($v2exerciseId)->module->tolanguage);
        } catch (\Exception $e) { }

        $voice = "Lucia";

        switch ($lang) {
            case 'EN':
                $voice = "Aditi";
                break;
            case 'DE':
                $voice = "Marlene";
                break;
            case 'IT':
                $voice = "Carla";
                break;
            case 'FR':
                $voice = "Mathieu";
                break;
            case 'PT':
                $voice = "Cristiano";
                break;
        }

        // Make MP3 Polly files on local
        $cmd = 'LANG=en_US.UTF-8; AWS_ACCESS_KEY_ID=' . env("POLLY_ACCESSKEY") . ' AWS_SECRET_ACCESS_KEY=' . env("POLLY_SECRETKEY") . ' ' . env("AWS_CLI") . ' polly synthesize-speech --region ' . env("POLLY_REGION") . ' --text-type ssml --text "' . str_replace('"', "'", trim($ssml)) . '" --output-format mp3 --voice-id ' . $voice . ' ' . $mp3file . ' 2>&1';

        exec($cmd, $debugOutput);

        if ($debug) {
            print_r([
                'cmd' => $cmd,
                'output' => $debugOutput
            ]);
        }

        // Copy the polly mp3 on s3 media folder
        $S3Dir = "s3://" . env("S3_MEDIA_BUCKET") . "/Lesson_" . $m_r_l . "_Pack/v2exercises/";
        exec("LANG=en_US.UTF-8; AWS_ACCESS_KEY_ID=" . env("S3_ACCESSKEY") . " AWS_SECRET_ACCESS_KEY=" . env("S3_SECRETKEY") . " " . env("AWS_CLI") . " s3 cp '" . $mp3file . "' " . $S3Dir . " --acl public-read 2>&1");

        // remove the localfile
        @unlink($mp3file);
    }
}

if (!function_exists('uploadToS3')) {
    // make polly for SSML and upload to S3
    function uploadToS3(string $location = "", $fileLocation = "", $fileName = "file.txt", $unlink = true)
    {
        // Copy the polly mp3 on s3 media folder
        $S3Dir = "s3://" . env("S3_MEDIA_BUCKET") . '/uploads/' . $location . "/" . $fileName;
        ob_start();
        $command = "LANG=en_US.UTF-8; AWS_ACCESS_KEY_ID=" . env("S3_ACCESSKEY") . " AWS_SECRET_ACCESS_KEY=" . env("S3_SECRETKEY") . " " . env("AWS_CLI") . " s3 cp '" . $fileLocation . "' " . $S3Dir . " --acl public-read 2>&1";
        exec($command, $output);
        $result = ob_get_contents();
        \Log::info('s3 upload status', [$result, $output, $command]);
        ob_end_clean();
        // remove the localfile
        if ($unlink) {
            @unlink($fileLocation);
        }
    }
}
if (!function_exists('uploadCombineToS3')) {
    // make polly for SSML and upload to S3
    function uploadCombineToS3(string $location = "", $fileLocation = "", $fileName = "file.txt", $unlink = true)
    {
        // Copy the polly mp3 on s3 media folder
        $S3Dir = "s3://" . env("S3_MEDIA_BUCKET") . '/uploads/combinedquizvideos/' . $location . "/" . $fileName;
        ob_start();
        $command = "LANG=en_US.UTF-8; AWS_ACCESS_KEY_ID=" . env("S3_ACCESSKEY") . " AWS_SECRET_ACCESS_KEY=" . env("S3_SECRETKEY") . " " . env("AWS_CLI") . " s3 cp '" . $fileLocation . "' " . $S3Dir . " --acl public-read 2>&1";
        exec($command, $output);
        $result = ob_get_contents();
        \Log::info('s3 upload status', [$result, $output, $command]);
        ob_end_clean();
        // remove the localfile
        if ($unlink) {
            @unlink($fileLocation);
        }
    }
}


if (!function_exists('uploadToS3Exact')) {
    // again
    // make polly for SSML and upload to S3
    function uploadToS3Exact(string $location = "", $fileLocation = "", $fileName = "file.txt", $unlink = true)
    {
        // echo "$location $fileLocation $fileName";
        // Copy the polly mp3 on s3 media folder
        $S3Dir = "s3://" . env("S3_MEDIA_BUCKET") . '/' . $location . "/" . $fileName;
        ob_start();
        $command = "LANG=en_US.UTF-8; AWS_ACCESS_KEY_ID=" . env("S3_ACCESSKEY") . " AWS_SECRET_ACCESS_KEY=" . env("S3_SECRETKEY") . " " . env("AWS_CLI") . " s3 cp '" . $fileLocation . "' " . $S3Dir . " --acl public-read 2>&1";
        exec($command, $output);
        $result = ob_get_contents();
        \Log::info('s3 upload status', [$S3Dir,$result, $output, $command]);
        ob_end_clean();
        // remove the localfile
        if ($unlink) {
            @unlink($fileLocation);
        }
    }
}

if (!function_exists('makeV2PollyFromV2ExerciseAndUploadToS3')) {
    // make polly for SSML and upload to S3
    function makeV2PollyFromV2ExerciseAndUploadToS3(\App\V2Exercise $v2exercise, bool $debug = false)
    {
        $v2exerciseId = $v2exercise->id;
        $m_r_l = $v2exercise->moduleNo . "_" . $v2exercise->routeNo . "_" . $v2exercise->lessonNo;
        $ssml = "<speak>" . $v2exercise->question . "</speak>";

        makeV2PollyFromSSMLAndUploadToS3($ssml, $m_r_l, $v2exerciseId, $debug);
    }
}


if (!function_exists("getMRLProgressOnRoundLog")) {
    function getMRLProgressOnRoundLog($userId, $moduleNo, $routeNo, $lessonNo)
    {
        // get last round done by user
        $roundLog = \App\RoundLog::with('exercise')->where('userId', $userId)
            ->where("moduleNo", $moduleNo)
            ->where("routeNo", $routeNo)
            ->where("lessonNo", $lessonNo)
            ->where("isMiniRound", '!=', 1)
            ->whereNull("roundType")
            ->orderBy('roundNo', "desc")
            ->first();

        // if roundlog is null, send 0
        if (!$roundLog) {
            return 0;
        }
        // get round exercises
        $roundExerciseLogs = $roundLog->exercise;

        // get total
        $total = $roundExerciseLogs->count();

        if ($total === 0) {
            return 0;
        }

        // correct answers in that round
        $correct = $roundExerciseLogs->where('status', 1)->count();

        return $correct / $total;
    }
}


if (!function_exists('logEmail')) {
    function logEmail(String $userId, $type = "", $moduleNo = null, $routeNo = null, $lessonNo = null)
    {
        // generate uuidv4
        $uuid = Uuid::uuid4();
        // create a email log
        $emailLog = EmailLog::create([
            'userId' => $userId,
            'log_uuid' => $uuid,
            'type' => $type,
            'moduleNo' => $moduleNo,
            'routeNo' => $routeNo,
            'lessonNo' => $lessonNo,
            'emailSent' => true
        ]);

        // return email log
        return $emailLog;
    }
}


if (!function_exists("isThumbsUpedByMe")) {
    function isThumbsUpedByMe($userId, $type)
    {
        try {
            $me = auth()->user() ? auth()->user()->email : null;

            if ($type === "weekly") {
                $startOfWeek = null; // last saturday
                // check if saturday for current week has passed
                if (now()->dayOfWeek >= 6) {
                    // today is saturday or more
                    $startOfWeek = today()->addDays(6 - now()->dayOfWeek)->startOfDay();
                    $endOfWeek = today()->addWeek()->addDays(5 - now()->dayOfWeek)->endOfDay();
                } else {
                    // saturday yet to come
                    $startOfWeek = today()->subWeek()->addDays(6 - now()->dayOfWeek)->startOfDay();
                    $endOfWeek = today()->addDays(5 - now()->dayOfWeek)->endOfDay();
                }

                return \App\UserThumbsUpLog::where('userTo', $userId)
                    ->where('userFrom', $me)
                    ->where('type', 'weekly')
                    ->whereBetween('created_at', [$startOfWeek, $endOfWeek])
                    ->exists();
            } else {
                return \App\UserThumbsUpLog::where('userTo', $userId)
                    ->where('userFrom', $me)
                    ->whereDate('created_at', today())
                    ->where('type', 'daily')
                    ->exists();
            }
        } catch (\Throwable $th) {
            \Log::error("isThumbsUpedByMe ", [$userId]);
            return false;
        }
    }
}

if (!function_exists('isTheUserAnnoyed')) {
    function isTheUserAnnoyed(Employee $employee)
    {
        // if the user is new, dont mark him lost
        if (today()->subDays(1)->lt(\Carbon\Carbon::parse($employee->accountCreationDate))) {
            return false;
        }

        // check if user was on a break
        if ($employee->was_on_break) {
            // End the user's break
            return false;
        } else {
            // check if the user needs to go on a break
            // check if the user last opened the push
            $lastOpenPush = \App\PushLog::where('userId', $employee->userId)
                ->where('pushOpened', 1)
                ->whereDate('created_at', '>=', now()->subDays(3))->exists();

            if (!$lastOpenPush) {
                return true;
            }

            // check the last date on which the user was seen
            $lastTimeLog = \App\UserTimeLog::where('userId', $employee->userId)->latest()->first();
            if (!$lastTimeLog) {
                return true;
            }
            // if the user was last active before 5 days, mark him lost
            if (now()->subDays(5)->gt($lastTimeLog->updated_at)) {
                return true;
            }
        }
    }
}

if (!function_exists('getTimeInUserTimezone')) {
    /**
     * Get time in user's timezone
     *
     * @param string $time
     * @param Employee $user
     * @return void
     */
    function getTimeInUserTimezone(string $time = '11:00', Employee $user = null)
    {
        return \Carbon\Carbon::createFromTimeString(
            $time, // set streak reminder time to 11 am
            $user->timezone ?? "GMT+1"
        );
    }
}

if (!function_exists('getLeaderboardByDateRange')) {
    /**
     * Get leaderboard by date range
     *
     * @param date $startDate
     * @param date $endDate
     * @param string $userId
     * @param boolean $withNewUsers
     * @param string $type
     * @param integer $companyCode
     * @return void
     */
    function getLeaderboardByDateRange($startDate, $endDate, $userId, $withNewUsers = false, $type, $companyCode = 0)
    {
        // get all users for that company
        $userIds = \App\Employee::where('CompanyCode', (int) $companyCode)->whereNotIn('userId', \App\Http\Controllers\LeaderBoardController::emailExceptions)->get()->pluck('userId')->toArray();

        $leaderboard = \App\UserDailyGoalLog::select('userId', DB::raw('sum(points) as current'))->whereIn('userId', $userIds)->whereBetween('dated', [$startDate, $endDate]);

        // if new users are not needed, apply the filter
        if (!$withNewUsers) {
            // get users with total score more than 500 (optimize it later)
            $userIds = \App\UserDailyGoalLog::select('userId', DB::raw('sum(points) as total'))->groupBy('userId')->having('total', '>=', 250)->pluck('userId');
            $leaderboard = $leaderboard->whereIn('userId', $userIds->toArray());
        }

        // get top 50 records
        $leaderboard = $leaderboard->groupBy('userId')->orderBy('current', 'desc')->take(15)->get();

        return $leaderboard;
    }
}


if (!function_exists('getLessonCountForModule')) {
    function getLessonCountForModule($moduleNumber)
    {
        // get routes id that have status 1
        $routes = \App\Route::where('moduleno', $moduleNumber)->where('status', '1')->pluck('routeno');
        // get totalLessons
        $totalLessons = \App\Lesson::where('moduleno', $moduleNumber)
            ->whereIn('routeno', $routes)
            ->where('is_challenge', 0)
            ->where('challenge_type', '!=', 'milestone')
            ->whereRaw('MOD(lesson_no,3) != 0')
            ->where('status', '1')->count();

        return $totalLessons;
    }
}

if (!function_exists('sendSMS')) {
    function sendSMS($mobile, $text = "")
    {
        try {
            $twilio = new Twilio\Rest\Client(config('taplingua.TWILIO_SID'), config('taplingua.TWILIO_TOKEN'));
            $message = $twilio->messages->create($mobile, [
                "messagingServiceSid" => config('taplingua.TWILIO_MESSINGSERVICESID'),
                "body" => $text
            ]);
            return $message->sid;
        } catch (\Throwable $th) {
            \Log::error("sendSMS helper failed", [
                'mobile' => $mobile,
                'text' => $text,
                'message' => $th->getMessage()
            ]);
            return false;
        }
    }
}

if (!function_exists("logCredentialsLoginAction")) {
    /**
     * Log Credentials Login
     *
     * @param string $email
     * @param string $password
     * @param string $reason
     * @return void
     */
    function logCredentialsLoginAction(string $email = "", string $password = "", $reason = "none")
    {
        try {
            return \App\LoginLog::create([
                "type" => "credentials",
                "email" => $email,
                "password" => null,
                "mobile" => null,
                "otp" => null,
                "reason" => $reason
            ]);
        } catch (\Throwable $th) {
            \Log::error("logCredentialsLoginAction failed", [
                "email" => $email,
                "password" => $password,
                "reason" => $reason
            ]);
            return null;
        }
    }
}

if (!function_exists("logOTPLoginAction")) {
    /**
     * Log OTP Login
     *
     * @param string $mobile
     * @param string $otp
     * @param string $reason
     * @return void
     */
    function logOTPLoginAction(string $mobile = "", string $otp = "", $reason = "none")
    {
        try {
            return \App\LoginLog::create([
                "type" => "otp",
                "email" => null,
                "password" => null,
                "mobile" => $mobile,
                "otp" => null,
                "reason" => $reason
            ]);
        } catch (\Throwable $th) {
            \Log::error("logCredentialsLoginAction failed", [
                "mobile" => $mobile,
                "otp" => $otp,
                "reason" => $reason
            ]);
            return null;
        }
    }
}


if (!function_exists("generateTranslations")) {
    /**
     * Generate translation of a text in a target language, using google
     *
     * @param array $queries
     * @return void
     */
    function generateTranslations($queries = [], $language = "hi"): array
    {
        try {

            $key = config('taplingua.GOOGLE_API_KEY');

            $response = \Illuminate\Support\Facades\Http::post("https://translation.googleapis.com/language/translate/v2?key=" . $key, [
                "q" => $queries,
                "target" => $language
            ]);

            $translations = array_map(function ($translation) {
                return $translation["translatedText"];
            }, $response->json()["data"]["translations"]);
            return $translations;
        } catch (\Exception $e) {
            \Log::error("generateTranslations failed", [$e, $response->json(), $queries]);
            return [];
        }
    }
}

if (!function_exists("getTranslations")) {
    function getTranslations($moduleNo, $routeNo, $lessonNo, $language = "hi")
    {

        // check if lesson exists
        $lesson = \App\Lesson::where('moduleno', $moduleNo)
            ->where('routeno', $routeNo)
            ->where('lesson_no', $lessonNo)->first();

        if (!$lesson) return null;

        try {

            // check in db if we have this translation
            $dialogTranslation = \App\DialogTranslation::where('moduleNo', $moduleNo)
                ->where('routeNo', $routeNo)
                ->where('lessonNo', $lessonNo)
                ->where('language', $language)->first();

            if ($dialogTranslation) {
                return $dialogTranslation->translation;
            }

            // else  generate the translation
            $translations = generateTranslations(explode("\n", $lesson->dialog_translation), $language);

            // save the translations
            $dialogTranslation = \App\DialogTranslation::create([
                "moduleNo" => $moduleNo,
                "routeNo" => $routeNo,
                "lessonNo" => $lessonNo,
                "language" => $language,
                "translation" => implode("\n", $translations)
            ]);

            return $dialogTranslation->translation;
        } catch (\Exception $e) {
            \Log::error('getTranslations failed', [$e]);
            return $lesson->dialog_translation;
        }
    }
}

if (!function_exists("getEmployeeLevelForProgram")) {

    function getEmployeeLevelForProgram($userId, $program_id)
    {
        $program = \App\Program::find($program_id);

        $modules = $program->modules()->orderBy('level_number')->get();

        // set default level 1;
        $maxLevel = 1;
        $level = 1;
        // get last level user has completed
        foreach ($modules as $module) {
            $courseNo = getCourseNoFromModuleNo($module->module_number, $userId);
            $module->completed = getCertificateIfExists($userId, $courseNo) ? true : false;
            if ($module->completed) {
                $level = $module->level_number;
            }
            // update max level
            if ($module->level_number > $maxLevel) {
                $maxLevel = $module->level_number;
            }
        }

        // for the level got, if user has already done all the modules.
        // set level as level + 1
        $levelNeedsOneUp = $modules->filter(function ($module) use ($level) {
            return (int) $level === (int) $module->level_number;
        })->every(function ($module) {
            return $module->completed;
        });

        // if we need to increase level and it can be increase
        if ($levelNeedsOneUp && $level < $maxLevel) {
            $level++;
        }

        return $level;
    }
}

if (!function_exists('makeV2PollyFromV2ExerciseAndUploadToS3Google')) {
    // make polly for SSML and upload to S3 using google
    function makeV2PollyFromV2ExerciseAndUploadToS3Google(\App\V2Exercise $v2exercise, bool $debug = false)
    {
        $v2exerciseId = $v2exercise->id;
        $m_r_l = $v2exercise->moduleNo . "_" . $v2exercise->routeNo . "_" . $v2exercise->lessonNo;
        $ssml = "<speak>" . $v2exercise->question . "</speak>";

        makeV2PollyFromSSMLAndUploadToS3UsingGoogle($ssml, $m_r_l, $v2exerciseId, $debug);
    }
}

if (!function_exists('makeV2PollyFromSSMLAndUploadToS3UsingGoogle')) {
    /**
     * Generate v2polly from ssml using google
     *
     * @param string $ssml
     * @param string $m_r_l
     * @param integer $v2exerciseId
     * @param boolean $debug
     * @return void
     */
    function makeV2PollyFromSSMLAndUploadToS3UsingGoogle(string $ssml, string $m_r_l, int $v2exerciseId, bool $debug = false)
    {

        $debugOutput = "";
        // folder to store the polly
        $mp3folder = storage_path() . "/Lesson_Module_Packs/Lesson_" . $m_r_l . "_Pack/v2exercises/";
        // make the mp3folder if not exists
        $cmd = "mkdir -p " . $mp3folder;
        exec($cmd, $debugOutput);

        if ($debug) {
            print_r([
                'cmd' => $cmd,
                'output' => $debugOutput
            ]);
        }

        // generate link to mp3 file
        $mp3file = $mp3folder . $v2exerciseId . ".mp3";

        // get the voice actor from module tolanguage
        $lang = "en-IN";
        try {
            $lang = strtoupper(V2Exercise::find($v2exerciseId)->module->tolanguage);
        } catch (\Exception $e) { }

        // Make MP3 Polly files on local
        $decodedAudioContent = getTextToDecodedSpeechFromGoogle(str_replace('"', "'", trim($ssml)), $lang);

        file_put_contents($mp3file, $decodedAudioContent);

        // Copy the polly mp3 on s3 media folder
        $S3Dir = "s3://" . env("S3_MEDIA_BUCKET") . "/Lesson_" . $m_r_l . "_Pack/v2exercises/";
        exec("LANG=en_US.UTF-8; AWS_ACCESS_KEY_ID=" . env("S3_ACCESSKEY") . " AWS_SECRET_ACCESS_KEY=" . env("S3_SECRETKEY") . " " . env("AWS_CLI") . " s3 cp '" . $mp3file . "' " . $S3Dir . " --acl public-read 2>&1");

        // remove the localfile
        @unlink($mp3file);
    }
}


if (!function_exists('getTextToDecodedSpeechFromGoogle')) {
    /**
     * Get decoded audio for text from google
     *
     * @param string $text
     * @param string $lang
     * @return void
     */
    function getTextToDecodedSpeechFromGoogle($text = "", $lang = "en-IN", $voiceName = "en-IN-Standard-D")
    {

        $key = config('taplingua.GOOGLE_API_KEY');

        $response = \Illuminate\Support\Facades\Http::post("https://texttospeech.googleapis.com/v1/text:synthesize?alt=json&key=" . $key, [
            "input" => [
                "ssml" => $text
            ],
            "audioConfig" => [
                "audioEncoding" => "MP3"
            ],
            "voice" => [
                "languageCode" => $lang,
                "name" => $voiceName,
            ]
        ])->json();

        $decodedString = base64_decode($response["audioContent"]);

        return $decodedString;
    }
}


if (!function_exists('getCohortMistakesByPlacementRound')) {
    /**
     * gives list of mistakes in that round with total attempt
     *
     * @param \App\PlacementLog $placementLog
     * @return void
     */
    function getCohortMistakesByPlacementRound(\App\PlacementLog $placementLog)
    {
        // create holders for mistakes
        $mistakes = [
            "Concept 1" => 0,
            "Concept 2" => 0,
            "Listening" => 0,
            "Speaking" => 0,
            "Total" => 0,
        ];

        // create holder for total
        $total = [
            "Concept 1" => 0,
            "Concept 2" => 0,
            "Listening" => 0,
            "Speaking" => 0,
            "Total" => 0,
        ];

        // get all logs
        $roundExerciseLogs = \App\PlacementExerciseLog::where('roundLogId', $placementLog->id)->get();
        // go through each log and create data for user
        foreach ($roundExerciseLogs as $log) {
            // increment the in one of the categories for user,
            $category = \App\Http\Controllers\ReportController::$exercise_categories_relation[$log->type];
            // if status is false
            if ($log->status == 0) {
                $mistakes[$category]++;
                $mistakes["Total"]++;
            }
            // also push into total
            $total[$category]++;
            $total["Total"]++;
        }

        // return the mistake and total
        return [
            'mistakes' => $mistakes,
            'total' => $total
        ];
    }

    if (!function_exists("sendServerErrorMail")) {
        function sendServerErrorMail($description = "Exception Occurred", $data = [])
        {
            try {
                Mail::to([
                    "thefallenmerc@gmail.com",
                    "shubham@truetechpro.com",
                    "santanu@taplingua.com",
                ])->send(new ServerErrorEmail("ServerError: " . $description, $data));
            } catch (\Throwable $th) {
                \Log::error("Could not send server error mail", compact("description", "data", "th"));
            }
        }
    }

    if (!function_exists("getUserCohortIds")) {
        function getUserCohortIds($userId)
        {
            return \App\Course::distinct("cohort_id")
                ->join("employeecourse", "courses.courseNumber", "=", "employeecourse.courseNumber")
                ->whereNotNull("cohort_id")
                ->where("userId", $userId)
                ->pluck("cohort_id");
        }
    }
}
