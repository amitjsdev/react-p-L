<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class AccessLevelController extends Controller
{
    public function index(Request $request)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $users = User::orderBy('email')
            ->where('email', '!=', '')
            ->where('email', '!=', null)
            ->get();

        $accessLevels = [
            "CONSUMER" => 0,
            "ADMIN" => 1,
            "COMPANY" => 3,
            "AUDITOR" => 4
        ];

        return view('admin.access-level.access-level-index', compact('users', 'accessLevels'));
    }

    /**
     * Update Access Level
     *
     * @param Request $request
     * @param [type] $email
     * @return void
     */
    public function updateAccessLevel(Request $request, $email)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $user = User::where("email", $email)->first();

        $user->accesslevel = $request->accesslevel;

        $user->save();

        return redirect()->back()->with('message', 'Access changed for ' . $user->email);
    }
}
