<?php

namespace App\Http\Controllers\Admin;

use App\Certificate;
use App\Company;
use App\Course;
use App\Http\Controllers\Controller;
use App\Employee;
use App\Module;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Intervention\Image\Image;

class CertificateController extends Controller
{
    public function index()
    {
        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $userIds = Employee::select('userId')->orderBy('userId')->distinct()->get()->pluck('userId');
        return view('admin.certificate', ['userIds' =>  $userIds]);
    }

    public function userCourses(Request $request)
    {
        return response()->json(employeeCourses($request->userId));
    }

    public function generate(Request $request)
    {


        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $data = [
            'userId' => $request->userId,
            'courseNumber' => $request->courseNumber,
            'firstName' => $request->firstName,
            'lastName' => $request->lastName,
            'date' => $request->date
        ];

        $employee = Employee::where('userId', $request->userId)->first();

        if (!$employee) {
            return back()->with('error', 'User id incorrect!');
        }

        $course = Course::where('courseNumber', $request->courseNumber)->first();

        if (!$course) {
            return back()->with('error', 'Course number incorrect!');
        }

        $certificate = Certificate::where('userId', $request->userId)
            ->where('courseNumber', $course->courseNumber)
            ->first();
        if (!$certificate) {
            $certificate = new Certificate([
                'certificateId' => strtoupper(uniqid("CERT")),
                'userId' => $request->userId,
                'courseNumber' => $course->courseNumber,
                'courseName' => $course->courseName,
                'name' => $data['firstName'] . " " . $data['lastName'],
                'instructor' => "Instructor",
                'date' => strtoupper($data['date']),
            ]);
        }
        $certificate->name = $data['firstName'] . " " . $data['lastName'];
        $certificate->date = strtoupper($data['date']);
        $certificate->save();
        return back()->with(
            'message',
            'Certificate available with id: <a target="_blank" href="/certificate/' . $certificate->certificateId . '">' . $certificate->certificateId . '</a>'
        );
    }

    public function certificateShowcase(Request $request, $certificateId)
    {
        // get certificate
        $certificate = Certificate::where('certificateId', $certificateId)->first();
        if ($certificate) {
            // render the certificate
            $user = Employee::where('userId', $certificate->userId)->first();
            $course = Course::where('courseNumber', $certificate->courseNumber)->first();
            $module = Module::where('moduleno', $course->moduleNumber)->first();
            $interviewSimulator =$certificate->interviewSimulator;
            if($interviewSimulator){
                return view('admin.certificate-interviewSimulator', compact('certificate', 'module', 'user','interviewSimulator'));
            } else {
            return view('admin.certificate-showcase', compact('certificate', 'module', 'user','interviewSimulator'));
            }
        } else {
            return abort(404);
        }
    }

    public function certificateRaw(Request $request, $certificateId)
    {
        // get certificate
        $certificate = Certificate::where('certificateId', $certificateId)->first();
        // render the certificate
        if ($certificate) {
            if($certificate->interviewSimulator){

                return $this->makeImageInterviewSimulator($certificate->toArray())->response('jpg');
            } else {
                return $this->makeImage($certificate->toArray())->response('jpg');
            }

        } else {
            return $this->notFound();
        }
    }

    private function makeImage($data)
    {
        // get course
        $course = Course::where('courseNumber', $data['courseNumber'])->first();
        $module = Module::where('moduleno', $course->moduleNumber)->first();
        $moduleDetailInformation = $module->moduleDetailInformation;

        $coursePercent = coursePercent($course->moduleNumber, $data['userId']);

        $employee = Employee::where('userId', $data['userId'])->first();
        $company = Company::where('Id', $employee->CompanyCode)->first();

        $companyName = $company->Name;

        $companyLogo = "https://langappnew.s3.amazonaws.com/logos/" . $employee->CompanyCode . ".jpeg";

        $cristinaLogo = \Image::make(storage_path('app/public/cristina-signature.png'));


        // check if course is in progress
        if ($coursePercent < 75) {
            $inProgress = true;
        } else {
            $inProgress = false;
        }

        // set inprogress to false by default
        $inProgress = false;

        if ($inProgress) {
            $img = \Image::make(storage_path('app/public/course-template-grey.png'));
        } else {
            $img = \Image::make(storage_path('app/public/course-template.png'));
        }

        $height = $img->height();
        $width = $img->width();

        // Heading
        $img->text(!$inProgress ? "CERTIFICATE OF COMPLETION" : "CERTIFICATE OF PROGRESS", $width / 2, $height / 5.45, function ($font) use ($width, $data, $inProgress) {
            $font->size($width / 23);
            $font->file(storage_path('app/public/SFProText-Bold.ttf'));
            $font->color(!$inProgress ? '#301332' : '#000000');
            $font->align('center');
            $font->valign('center');
        });

        // module detail information
        $img->text("FOUNDATION PROGRAM IN SPOKEN ENGLISH", $width / 2, $height / 3.65, function ($font) use ($width, $data, $inProgress) {
            $font->size($width / 45);
            $font->file(storage_path('app/public/SFProText-Bold.ttf'));
            $font->color(!$inProgress ? '#301332' : '#000000');
            $font->align('center');
            $font->valign('center');
        });

        // User name
        $img->text($data['name'], $width / 2, $height / 2.50, function ($font) use ($width) {
            $font->size($width / 22);
            $font->file(storage_path('app/public/GreatVibes-Regular.otf'));
            $font->color('#301332');
            $font->align('center');
            $font->valign('center');
        });

        // instructor
        $img->insert($cristinaLogo, "bottom-right", 420, 370);
        $img->text($cristinaLogo, $width / 1.37, $height / 1.375, function ($font) use ($width) {
            $font->size($width / 80);
            $font->file(storage_path('app/public/SFProText-Bold.ttf'));
            $font->color('#301332');
            $font->align('center');
            $font->valign('center');
        });
        $img->text("Dr. Cristina Guijarro", $width / 1.37, $height / 1.315, function ($font) use ($width) {
            $font->size($width / 80);
            $font->file(storage_path('app/public/SFProText-Bold.ttf'));
            $font->color('#301332');
            $font->align('center');
            $font->valign('center');
        });
        $img->text("Heading of Learning", $width / 1.37, $height / 1.275, function ($font) use ($width) {
            $font->size($width / 80);
            $font->file(storage_path('app/public/SFProText-Bold.ttf'));
            $font->color('#301332');
            $font->align('center');
            $font->valign('center');
        });

        // course pre
        $img->text(!$inProgress ? $data['completed'] ?? 'has completed the' : 'has in progress', $width / 2, $height / 1.93, function ($font) use ($width) {
            $font->size($width / 90);
            $font->file(storage_path('app/public/OpenSans-Regular.ttf'));
            $font->color('#301332');
            $font->align('center');
            $font->valign('center');
        });

        // course
        $img->text($moduleDetailInformation ?? '', $width / 2, $height / 1.803, function ($font) use ($width) {
            $font->size($width / 40);
            $font->file(storage_path('app/public/SFProText-Bold.ttf'));
            $font->color('#301332');
            $font->align('center');
            $font->valign('center');
        });

        // date
        if (!empty($data['date'])) {
            $img->text('on ' . \Carbon\Carbon::parse($data['date'])->format('d-M-Y'), $width / 2, $height / 1.68, function ($font) use ($width) {
                $font->size($width / 100);
                $font->file(storage_path('app/public/SFProText-Bold.ttf'));
                $font->color('#301332');
                $font->align('center');
                $font->valign('center');
            });
        }

        // company name
        if (!empty($companyName)) {
            $img->text($companyName, $width * 0.072, $height / 1.350, function ($font) use ($width) {
                $font->size($width / 70);
                $font->file(storage_path('app/public/SFProText-Bold.ttf'));
                $font->color('#301332');
                $font->align('left');
                $font->valign('center');
            });
        }

        $img->insert($companyLogo, "bottom-left", 265, 175);

        // course no
        if (!empty($data['date'])) {
            $img->text(strtoupper($data['certificateId']), $width * 0.085, $height / 1.099, function ($font) use ($width) {
                $font->size($width / 90);
                $font->file(storage_path('app/public/OpenSans-Regular.ttf'));
                $font->color('#301332');
                $font->align('left');
                $font->valign('center');
            });
        }

        return $img;
    }
    private function makeImageInterviewSimulator($data)
    {
        // get course
        $course = Course::where('courseNumber', $data['courseNumber'])->first();
        $module = Module::where('moduleno', $course->moduleNumber)->first();
        $moduleDetailInformation = $module->moduleDetailInformation;

        $coursePercent = coursePercent($course->moduleNumber, $data['userId']);

        $employee = Employee::where('userId', $data['userId'])->first();
        $company = Company::where('Id', $employee->CompanyCode)->first();

        $companyName = $company->Name;

        $companyLogo = "https://langappnew.s3.amazonaws.com/logos/" . $employee->CompanyCode . ".jpeg";

        $cristinaLogo = \Image::make(storage_path('app/public/cristina-signature.png'));


        // check if course is in progress
        if ($coursePercent < 75) {
            $inProgress = true;
        } else {
            $inProgress = false;
        }

        // set inprogress to false by default
        $inProgress = false;

        if ($inProgress) {
            $img = \Image::make(storage_path('app/public/course-template-grey.png'));
        } else {
            $img = \Image::make(storage_path('app/public/course-template.png'));
        }

        $height = $img->height();
        $width = $img->width();

        // Heading
        $img->text(!$inProgress ? "CERTIFICATE OF PARTICIPATION" : "CERTIFICATE OF PROGRESS", $width / 2, $height / 5.45, function ($font) use ($width, $data, $inProgress) {
            $font->size($width / 23);
            $font->file(storage_path('app/public/SFProText-Bold.ttf'));
            $font->color(!$inProgress ? '#301332' : '#000000');
            $font->align('center');
            $font->valign('center');
        });

        // module detail information
        // $img->text("FOUNDATION PROGRAM IN SPOKEN ENGLISH", $width / 2, $height / 3.65, function ($font) use ($width, $data, $inProgress) {
        //     $font->size($width / 45);
        //     $font->file(storage_path('app/public/SFProText-Bold.ttf'));
        //     $font->color(!$inProgress ? '#301332' : '#000000');
        //     $font->align('center');
        //     $font->valign('center');
        // });

        // User name
        $img->text($data['name'], $width / 2, $height / 2.50, function ($font) use ($width) {
            $font->size($width / 22);
            $font->file(storage_path('app/public/GreatVibes-Regular.otf'));
            $font->color('#301332');
            $font->align('center');
            $font->valign('center');
        });

        // instructor
        $img->insert($cristinaLogo, "bottom-right", 420, 370);
        $img->text($cristinaLogo, $width / 1.37, $height / 1.375, function ($font) use ($width) {
            $font->size($width / 80);
            $font->file(storage_path('app/public/SFProText-Bold.ttf'));
            $font->color('#301332');
            $font->align('center');
            $font->valign('center');
        });
        $img->text("Dr. Cristina Guijarro", $width / 1.37, $height / 1.315, function ($font) use ($width) {
            $font->size($width / 80);
            $font->file(storage_path('app/public/SFProText-Bold.ttf'));
            $font->color('#301332');
            $font->align('center');
            $font->valign('center');
        });
        $img->text("VP of Learning", $width / 1.37, $height / 1.275, function ($font) use ($width) {
            $font->size($width / 80);
            $font->file(storage_path('app/public/SFProText-Bold.ttf'));
            $font->color('#301332');
            $font->align('center');
            $font->valign('center');
        });

        // course pre
        $img->text(!$inProgress ? $data['completed'] ?? 'has participated in' : 'has in progress', $width / 2, $height / 1.93, function ($font) use ($width) {
            $font->size($width / 90);
            $font->file(storage_path('app/public/OpenSans-Regular.ttf'));
            $font->color('#301332');
            $font->align('center');
            $font->valign('center');
        });

        // course
        $img->text('Pilot Product Testing of the Interview Prep App by Taplingua in association with CareerLabs', $width / 2, $height / 1.803, function ($font) use ($width) {
            $font->size($width / 80);
            $font->file(storage_path('app/public/SFProText-Bold.ttf'));
            $font->color('#301332');
            $font->align('center');
            $font->valign('center');
        });

        // date
        if (!empty($data['date'])) {
            $img->text('on ' . \Carbon\Carbon::parse($data['date'])->format('d-M-Y'), $width / 2, $height / 1.68, function ($font) use ($width) {
                $font->size($width / 100);
                $font->file(storage_path('app/public/SFProText-Bold.ttf'));
                $font->color('#301332');
                $font->align('center');
                $font->valign('center');
            });
        }

        // company name
        if (!empty($companyName)) {
            $img->text($companyName, $width * 0.072, $height / 1.350, function ($font) use ($width) {
                $font->size($width / 70);
                $font->file(storage_path('app/public/SFProText-Bold.ttf'));
                $font->color('#301332');
                $font->align('left');
                $font->valign('center');
            });
        }

        $img->insert($companyLogo, "bottom-left", 265, 175);

        // course no
        if (!empty($data['date'])) {
            $img->text(strtoupper($data['certificateId']), $width * 0.085, $height / 1.099, function ($font) use ($width) {
                $font->size($width / 90);
                $font->file(storage_path('app/public/OpenSans-Regular.ttf'));
                $font->color('#301332');
                $font->align('left');
                $font->valign('center');
            });
        }

        return $img;
    }

    private function notFound()
    {
        return $this->makeImage([
            'certificateId' => 'yourcertificateid',
            'userId' => '{Your Email}',
            'courseNumber' => '{Course Number}',
            'courseName' => '{This could be some new course}',
            'name' => '{This could be your name}',
            'instructor' => "{The instructor}",
            'date' => "{Some date in future}",
        ])->response('jpg');
    }
}
