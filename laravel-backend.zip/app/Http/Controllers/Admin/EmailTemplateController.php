<?php

namespace App\Http\Controllers\Admin;

use App\EmailTemplate;
use App\Employee;
use App\Http\Controllers\Controller;
use App\Jobs\SendMailToSubscriber;
use App\Mail\TemplateMail;
use App\UserSegment;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class EmailTemplateController extends Controller
{

    public function index(Request $request)
    {
        $templates = EmailTemplate::paginate();

        return view('admin.email_templates.index')->with(compact('templates'));
    }


    public function new(Request $request)
    {
        $template = $request->has('clone') ? EmailTemplate::find($request->clone) : new EmailTemplate();

        $screens = getAllScreenNames();

        unset($template->id);

        return view('admin.email_templates.new')->with(compact('template', 'screens'));
    }


    /**
     * Show view for sending email template to a segment
     *
     * @param Request $request
     * @return void
     */
    public function sendToSegmentView(Request $request)
    {
        $templates = EmailTemplate::all();
        $segments = UserSegment::all();

        return view('admin.email_templates.send-to-segment')->with(compact('templates', 'segments'));
    }

    /**
     * send email template to a segment
     */
    public function sendEmailToSegment(Request $request)
    {
        // validate the data
        $validator = Validator::make($request->all(), [
            "template" => "string|required|exists:email_templates,template_identifier",
            "segment" => "numeric|required|exists:user_segments,id"
        ]);

        if ($validator->fails()) {
            return redirect()->back()->with('error', $validator->errors()->all()[0])->withInput();
        }

        // get the template
        $template = EmailTemplate::where('template_identifier', $request->template)->first();
        // get the segment
        $segment = UserSegment::find($request->segment);

        // get the users for the segment
        $users = $segment->users;

        // for each user
        foreach ($users as $user) {
            // check if user email if correct
            if (Str::contains($user->userId, '@')) {
                // user has a valid email, we can send him the template
                // create the template mail
                $email = new TemplateMail($user->userId, $template);
                // send the mail to subscriber
                SendMailToSubscriber::dispatch($email, $user->userId);
            } else { }
        }

        return redirect()->back()->with('message', 'Template Email Sent to users of the ' . $segment->name . ' segment!');
    }

    // create new template
    public function create(Request $request)
    {
        $validator = Validator::make($request->all(), [
            "template_name" => "string|required",
            "template_identifier" => "string|required",
            "template_subject" => "string|required",
            "template_description" => "string|nullable",
            "template_content" => "string|required",
            "call_to_action_label" => "string|nullable",
            "call_to_action_screen" => "required_if:call_to_action_type,branch",
            "call_to_action_type" => "string",
            "call_to_action_link" => "string|nullable",
        ]);

        if ($validator->fails()) {
            return redirect()->back()->with('error', $validator->errors()->all()[0])->withInput();
        }

        EmailTemplate::create($validator->validated());

        return redirect()->to(url('/email-templates'))->with('message', 'Template created!');
    }

    // show a template to edit
    public function show(Request $request, $id)
    {

        $template = EmailTemplate::find($id);

        if (!$template) {
            return redirect()->back()->with('error', 'Not found!');
        }

        $screens = getAllScreenNames();

        return view('admin.email_templates.new')->with(compact('template', 'screens'));
    }

    public function preview(Request $request, $id)
    {

        $template = EmailTemplate::find($id);

        if (!$template) {
            abort(404, "Not found!");
        }
        return new TemplateMail('thefallenmerc@gmail.com', $template, true);
    }

    public function test(Request $request, $id)
    {

        $template = EmailTemplate::find($id);

        $email1 = "santanu@taplingua.com";
        $email2 = "shubham@truetechpro.com";
        $email3 = "dharmin.polra@gmail.com";

        if (!$template) {
            abort(404, "Not found!");
        }

        SendMailToSubscriber::dispatch(new TemplateMail($email2, $template), $email2);

        if (!$request->devonly) {
            SendMailToSubscriber::dispatch(new TemplateMail($email1, $template), $email1);
            SendMailToSubscriber::dispatch(new TemplateMail($email3, $template), $email3);
        }

        return redirect()->back()->with('message', "Test mail sent to " . $email1 . " " . $email3);
    }

    public function sendToAll(Request $request, $id)
    {

        $template = EmailTemplate::find($id);

        $employees = Employee::query();
        $employees = $employees->whereDate('accountCreationDate', '>=', Carbon::createFromDate(2020, 8, 15));
        $employees = $employees->get();

        if (!$template) {
            abort(404, "Not found!");
        }

        foreach ($employees as $employee) {
            SendMailToSubscriber::dispatch(new TemplateMail($employee->userId, $template), $employee->userId);
        }

        return redirect()->back()->with('message', "Template mail sent to " . $employees->count() . " users!");
    }

    public function update(Request $request, $id)
    {

        $template = EmailTemplate::find($id);

        if (!$template) {
            return redirect()->back()->with('error', 'Not found!');
        }

        $validator = Validator::make($request->all(), [
            "template_name" => "string|required",
            "template_identifier" => "string|required",
            "template_subject" => "string|required",
            "template_description" => "string|nullable",
            "template_content" => "string|required",
            "call_to_action_label" => "string|nullable",
            "call_to_action_screen" => "required_if:call_to_action_type,branch",
            "call_to_action_type" => "string",
            "call_to_action_link" => "string|nullable",
        ]);

        if ($validator->fails()) {
            return redirect()->back()->with('error', $validator->errors()->all()[0]);
        }

        $template->update($validator->validated());

        return redirect()->to(url('/email-templates'))->with('message', 'Template updated!');
    }

    public function delete(Request $request, $id)
    {

        $template = EmailTemplate::find($id);

        if (!$template) {
            abort(404, "Not found!");
        }

        $template->delete();

        return redirect()->to(url('/email-templates'))->with('message', 'Template delete!');
    }


    public function showThankYouPage(Request $request)
    {
        return view('admin.email_templates.thank-you');
    }
}
