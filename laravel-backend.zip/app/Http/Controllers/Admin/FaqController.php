<?php

namespace App\Http\Controllers\Admin;

use App\Faq;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class FaqController extends Controller
{
    public function index(Request $request)
    {
        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }
        $categories = Faq::distinct()->pluck('category');
        $faqs = Faq::paginate(10);
        return view('admin.faqs', ['categories' => $categories, 'faqs' =>  $faqs]);
    }

    public function get(Request $request) {
        if($request->search) {
            $faqs = Faq::where(function($query) use($request) {
                $query->where("category", "like", "%" . $request->search . "%")
                ->orWhere("question", "like", "%" . $request->search . "%")
                ->orWhere("answer", "like", "%" . $request->search . "%");
            })->get()->groupBy('category');
        } else {
            $faqs = Faq::all()->groupBy('category');
        }
        return response()->json($faqs);
    }

    public function saveFaq(Request $request)
    {
        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $category = $request->category === '-1' ? $request->new_category : $request->category;

        if (empty($category)) {
            return redirect()->back()->with('error', 'Please provide a valid category!');
        }

        $sort_order = empty($request->sort_order) ? 0 : $request->sort_order;

        if (empty($request->question)) {
            return redirect()->back()->with('error', 'Please provide a valid question!');
        }

        if (empty($request->answer)) {
            return redirect()->back()->with('error', 'Please provide a valid answer!');
        }

        Faq::create([
            'sort_order' => $sort_order,
            'category' => $category,
            'question' => $request->question,
            'answer' => $request->answer,
        ]);



        return redirect()->back()->with('message', 'Faq Saved successfully!');
    }

    public function editFaq(Request $request, $id)
    {
        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }
        $categories = Faq::distinct()->pluck('category');
        $faq = Faq::where('id', $id)->first();

        if (!$faq) {
            return redirect()->back()->with("error",  "Record not found!")->get();
        }

        return view('admin.faq-edit', ['categories' => $categories, 'faq' =>  $faq]);
    }



    public function updateFaq(Request $request, $id)
    {
        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $faq = Faq::where('id', $id)->first();

        if (!$faq) {
            return redirect()->back()->with("error",  "Record not found!")->get();
        }

        $category = $request->category === '-1' ? $request->new_category : $request->category;

        if (empty($category)) {
            return redirect()->back()->with('error', 'Please provide a valid category!');
        }

        $sort_order = empty($request->sort_order) ? 0 : $request->sort_order;

        if (empty($request->question)) {
            return redirect()->back()->with('error', 'Please provide a valid question!');
        }

        if (empty($request->answer)) {
            return redirect()->back()->with('error', 'Please provide a valid answer!');
        }

        $faq->sort_order = $sort_order;
        $faq->category = $category;
        $faq->question = $request->question;
        $faq->answer = $request->answer;

        $faq->save();

        return redirect('/faq')->with('message', 'Faq Updated successfully!');
    }

    public function deleteFaq(Request $request, $id)
    {
        $faq = Faq::where('id', $id)->first();

        if (!$faq) {
            return redirect()->back()->with("error",  "Record not found!")->get();
        }

        $faq->delete();

        return redirect()->back()->with("message", "Record deleted");
    }
}
