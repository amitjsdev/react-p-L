<?php

namespace App\Http\Controllers\Admin;

use App\Forum;
use App\Http\Controllers\Controller;
use App\Lesson;
use App\Module;
use App\V2Exercise;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;

class ForumController extends Controller
{

    protected $forumableTypes = [
        'v2exercise' => \App\V2Exercise::class,
        'listen' => \App\Lesson::class,
        'video' => \App\Lesson::class,
    ];

    public function index(Request $request)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $pageSize = $request->pageSize ? $request->pageSize : 50;
        $forums = Forum::query();

        $forums = $forums->paginate($pageSize);

        $forums->getCollection()->transform(function ($item) {
            $item->new_messages = getCountOfNewMessagesInForum($item, 'santanu@taplingua.com');
            return $item;
        });
        return view("admin/forum/index", compact('pageSize', 'forums'));
    }

    public function indexNewOnly(Request $request)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $forums = Forum::all();

        $forums->transform(function ($item) {
            $item->new_messages = getCountOfNewMessagesInForum($item, 'santanu@taplingua.com');
            return $item;
        });
        
        $forums = $forums->filter(function ($item, $index) {
            return $item->new_messages > 0;
        });

        return view("admin/forum/indexNewOnly", compact('forums'));
    }

    /**
     * For showing add form
     *
     * @param Request $request
     * @return void
     */
    public function add(Request $request)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }



        $modules = Module::where('status', "1")->orderBy("moduleno")->get();

        // get exercises that already do not have a forum
        $forums = Forum::whereForumableType(\App\V2Exercise::class)->pluck('forumable_id');
        $exercises = V2Exercise::whereNotIn('id', $forums)->get();

        $forum = new Forum();

        return view("admin/forum/add", compact('exercises', 'forum', 'modules'));
    }

    /**
     * To save new v2 exercise
     *
     * @param Request $request
     * @return void
     */
    public function save(Request $request)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $validator = Validator::make($request->all(), [
            "for" => "required|in:" . implode(",", array_keys($this->forumableTypes)),
            "exercise_id" => "required_if:forumable_type,App\Exercise",
            "lesson_no" => "required_if:forumable_type,App\Lesson",
            "title" => "nullable",
            "content" => "nullable",
        ], [
            "forumable_id.required" => "Entity id is required!"
        ]);

        // $validated = $validator->validated();

        if ($validator->fails()) {
            return redirect()->back()->with('error', $validator->errors()->all()[0])->withInput();
        }

        $validated = $validator->validated();

        // check if we have mrl
        if (in_array($validated['for'], ["listen", "video"])) {
            $lesson = Lesson::where('moduleno', $request->moduleNo)->where('routeno', $request->routeno)->where('lesson_no', $request->lesson_no)->first();
            $validated['forumable_id'] = $lesson->id;
            unset($validated['lesson_no']);
        }

        // check if we have exercise id
        if ($validated['for'] === 'v2exercise') {
            $validated['forumable_id'] = $validated['exercise_id'];
            unset($validated['exercise_id']);
        }

        $validated['forumable_type'] = $this->forumableTypes[$validated['for']];

        Forum::create($validated);

        return redirect()->back()->with('message', 'Forum saved successfully!');
    }

    /**
     * For showing edit form
     *
     * @param Request $request
     * @param [type] $id
     * @return void
     */
    public function edit(Request $request, $id)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        // get exercises that already do not have a forum
        $forum = Forum::whereId($id)->first();

        if (!$forum) {
            return redirect()->back()->with('error', "Forum not found!");
        }

        $modules = []; // initialize empty
        $exercises = []; // initialize empty

        switch ($forum->forumable_type) {
            case \App\V2Exercise::class:
                $exercises = V2Exercise::whereId($forum->forumable_id)->get();
                break;
            case \App\Lesson::class:
                // get current moduleNo routeno lessonno
                $lesson = $forum->forumFor;
                $modules = Module::where('status', "1")->where('moduleno', $lesson->moduleno)->orderBy("moduleno")->get();
                $forum->moduleNo = $lesson->moduleno;
                $forum->routeNo = $lesson->routeno;
                $forum->lessonNo = $lesson->lesson_no;
                break;
            default:
                break;
        }

        // to check if it is on edit mode
        $forum->isEditing = true;



        return view("admin/forum/add", compact('exercises', 'forum', 'modules'));
    }



    /**
     * To update existing v2 exercise
     *
     * @param Request $request
     * @return void
     */
    public function update(Request $request, $id)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        // get the forum
        $forum = Forum::find($id);

        if (!$forum) {
            return redirect()->back()->with('error', "Exercise not found!");
        }


        $validator = Validator::make($request->all(), [
            "title" => "nullable",
            "content" => "nullable",
        ]);

        // $validated = $validator->validated();

        if ($validator->fails()) {
            return redirect()->back()->with('error', $validator->errors()->all()[0])->withInput();
        }

        $validated = $validator->validated();

        $forum->update($validated);

        return redirect()->back()->with('message', 'Forum updated successfully!');
    }

    /**
     * Delete a forum
     *
     * @param Request $request
     * @param integer $id
     * @return void
     */
    public function delete(Request $request, $id)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $forum = Forum::find($id);

        if (!$forum) {
            return redirect()->back()->with('error', "Forum not found!");
        }

        $forum->delete();

        return redirect()->back()->with('message', "Forum with id " . $id . " deleted!");
    }

    public function openForum(Request $request, $id)
    {
        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        // get exercises that already do not have a forum
        $forum = Forum::whereId($id)->first();

        if (!$forum) {
            return redirect()->back()->with('error', "Forum not found!");
        }

        $url = url('/app/forum/');

        // get token
        $token = $request->cookie('token');

        if (empty($token)) {
            $token = getTokenForEmail('santanu@taplingua.com');
        }

        $commentIdSupport = "";

        if ($request->has('comment_id')) {
            $commentIdSupport = "&commentToFocusOn=" . $request->comment_id;
        }

        switch ($forum->for) {
            case 'v2exercise':
                $url = url('/uiforum?exerciseId=' . $forum->forumable_id);
                break;
            case 'listen':
                $lesson = $forum->forumFor;
                $url = url('/uiforum?forumFor=listen&moduleNo' . $lesson->moduleno . "&routeNo" . $lesson->routeno . "&lessonNo" . $lesson->lesson_no);
                break;
            case 'video':
                $lesson = $forum->forumFor;
                $url = url('/uiforum?forumFor=video&moduleNo' . $lesson->moduleno . "&routeNo" . $lesson->routeno . "&lessonNo" . $lesson->lesson_no);
                break;
        }

        return redirect()->to($url . $commentIdSupport . "&token=" . $token);
    }
}
