<?php

namespace App\Http\Controllers\Admin;

use App\Employee;
use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class PushCampaignController extends Controller
{
    // show basic push form
    public function index()
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        return view('admin.push-campaign-advanced');
    }

    // get list of employee email and fcm by name
    public function employeeAdvanced(Request $request)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }
        $validator = $request->validate([
            'name' => "string|nullable",
            'company-code' => "string|nullable",
            'course-registered' => "numeric|nullable",
            'date-activated-start' => "date|nullable",
            'date-activated-end' => "date|nullable",
            'lessons-comparator' => "in:<,>,=",
            'lessons-completed' => "numeric|nullable",
        ], $request->all());

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $users = DB::table('employee');
        if (!empty($request->get('name'))) {
            $users->where('userId', 'like', '%' . $request->get('name') . '%');
        }
        if (!empty($request->get('date-activated-start'))) {
            $users->whereDate('activationDate', '>=', \Carbon\Carbon::parse($request->get('date-activated-start')));
        }
        if (!empty($request->get('date-activated-end'))) {
            $users->whereDate('activationDate', '<=', \Carbon\Carbon::parse($request->get('date-activated-end')));
        }
        if (!empty($request->get('company-code'))) {
            $users->where('CompanyCode', trim($request->get('company-code')));
        }
        if (!empty($request->get('course-registered'))) {
            $users
                ->join('employeecourse', 'employee.userId', '=', 'employeecourse.userId')
                ->select('employee.i_d as i_d', 'employee.userId as userId', 'employee.fcmToken as fcmToken', DB::raw('count(employeecourse.Id) as count'))
                ->having('count', '>=', $request->get('course-registered'));
        }
        /* if(!empty($request->get('lessons-completed'))) {
            $u = DB::table('useractivitylog_api')->where('userId', 'santanu@taplingua.com')->select(DB::raw('sum(activityType)'), 'activityType')->distinct()->get();
            return response()->json($u);
        } */

        $users = $users->get();

        // return response()->json($users);
        $employees = [];
        foreach ($users as $user) {
            $employees[] = [
                'id' => $user->i_d,
                'email' => $user->userId,
                'fcm' => $user->fcmToken
            ];
        }
        return response()->json($employees);
    }

    // submit basic push
    public function pushBasic(Request $request)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        // get payload
        $payload = $request->all();

        // check if message exists
        if (!$payload['message']) {
            return response()->json(['error' => 'Message is required!'], 400);
        }

        // get all employee
        $employees = Employee::whereIn('i_d', $payload['users'])->get();

        // make key value pair
        $kvp = [
            "Nick" => "Mario",
            "Room" => "PortugalVSDenmark"
        ];
        if ($payload['key']) {
            $kvp[$payload['key']] = $payload['value'];
        }

        $result = [];


        if ($payload['type'] === 'push') {
            foreach ($employees as $employee) {
                // check if user has fcm token
                if ($employee->fcmToken) {
                    // get response and check response for atleast 1 success
                    $response = pushNotification($employee->fcmToken, $payload['message'], 'Some message', $kvp);
                    $result[] = [
                        'id' => $employee->i_d,
                        'type' => $payload['type'],
                        'email' => $employee->userId,
                        'status' => $response ? json_decode($response)->success == 1 ? true : false : false
                    ];
                } else {
                    // send false
                    $result[] = [
                        'id' => $employee->i_d,
                        'type' => $payload['type'],
                        'email' => $employee->userId,
                        'status' => false
                    ];
                }
            }
        }
        if ($payload['type'] === 'email') {
            foreach ($employees as $employee) {
                sendEmail($employee->userId, $payload['message'], null, 'Taplingua');
                $result[] = [
                    'id' => $employee->i_d,
                    'type' => $payload['type'],
                    'email' => $employee->userId,
                    'status' => true
                ];
            }
        }
        return response()->json(['message' => 'Success', 'result' => $result]);
    }

    // submit advanced push
    public function pushAdvanced(Request $request)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        // get payload
        $payload = $request->all();

        $request->validate([
            'message' => 'string|required',
            'kvm' => 'array',
        ], $request->all());

        // get all employee
        $employees = Employee::whereIn('i_d', $payload['users'])->get();

        // make key value pair
        $kvp = $request->kvm;

        $result = [];

        if ($payload['type'] === 'push') {
            foreach ($employees as $employee) {
                // check if user has fcm token
                if ($employee->fcmToken) {
                    // get response and check response for atleast 1 success
                    $response = pushNotification($employee->fcmToken, $payload['message'], 'Some message', $kvp);
                    $result[] = [
                        'id' => $employee->i_d,
                        'type' => $payload['type'],
                        'email' => $employee->userId,
                        'status' => $response ? json_decode($response)->success == 1 ? true : false : false
                    ];
                } else {
                    // send false
                    $result[] = [
                        'id' => $employee->i_d,
                        'type' => $payload['type'],
                        'email' => $employee->userId,
                        'status' => false
                    ];
                }
            }
        }
        if ($payload['type'] === 'email') {
            foreach ($employees as $employee) {
                sendEmail($employee->userId, $payload['message'], null, 'Taplingua');
                $result[] = [
                    'id' => $employee->i_d,
                    'type' => $payload['type'],
                    'email' => $employee->userId,
                    'status' => true
                ];
            }
        }
        return response()->json(['message' => 'Success', 'result' => $result]);
    }
}
