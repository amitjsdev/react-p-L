<?php

namespace App\Http\Controllers\Admin;

use App\Employee;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Jobs\SendPush;
use App\Lesson;
use App\PushCampaign;
use App\UserActivityLog;
use App\UserSegment;
use Carbon\Carbon;
use Illuminate\Support\Facades\Validator;
use Session;

class PushCampaignV2Controller extends Controller
{

    /**
     * Function index shows a form for push campaign
     *
     * @param Request $request
     * @return mixed
     */
    public function index(Request $request)
    {


        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $pageSize = $request->pageSize ? $request->pageSize : 50;
        $pushCampaigns = PushCampaign::query();

        // check for filters
        if (!empty($request->get('campaign_id'))) $pushCampaigns->where('campaign_id', "like", "%" . $request->campaign_id . "%");
        if (!empty($request->get('title'))) $pushCampaigns->where('title', "like", "%" . $request->title . "%");
        // check for filters end

        $pushCampaigns = $pushCampaigns->paginate($pageSize);

        return view('admin.push-campaign-v2.index', compact('pageSize', 'pushCampaigns'));
    }

    /**
     * Function shows the add form
     *
     * @param Request $request
     * @return void
     */
    public function add(Request $request)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $pushCampaign = new PushCampaign();

        return view("admin.push-campaign-v2.add", compact('pushCampaign'));
    }

    /**
     * Function saves push campaign
     */
    public function save(Request $request)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }


        $validator = Validator::make($request->all(), [
            "campaign_id" => "required|string|unique:push_campaigns",
            "title" => "nullable|string",
            "message" => "nullable|string",
        ]);

        // $validated = $validator->validated();

        if ($validator->fails()) {
            return redirect()->back()->with('error', $validator->errors()->all()[0])->withInput();
        }

        // check if the type is already used
        if (PushCampaign::where('campaign_id', $request->campaign_id)->exists()) {
            return redirect()->back()->with('error', 'Push Campaign with same code already exists!');
        }

        $validated = $validator->validated();

        PushCampaign::create($validated);

        return redirect()->back()->with('message', 'Push campaign type saved successfully!');
    }

    /**
     * Function to display edit
     *
     * @param Request $request
     * @param int $id
     * @return mixed
     */
    public function edit(Request $request, $id)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $pushCampaign = PushCampaign::find($id);

        if (!$pushCampaign) {
            return redirect()->back()->with('error', "Push Campaign not found!");
        }

        return view("admin.push-campaign-v2.add", compact('pushCampaign'));
    }

    /**
     * Function that updates values
     *
     * @param Request $request
     * @param [type] $id
     * @return void
     */
    public function update(Request $request, $id)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $validator = Validator::make($request->all(), [
            "campaign_id" => "required|string",
            "title" => "nullable|string",
            "message" => "nullable|string",
        ]);

        // $validated = $validator->validated();

        if ($validator->fails()) {
            return redirect()->back()->with('error', $validator->errors()->all()[0])->withInput();
        }



        $pushCampaign = PushCampaign::find($id);

        if (!$pushCampaign) {
            return redirect()->back()->with('error', "Push Campaign not found!");
        }

        // check if the type is already used
        if (PushCampaign::where('campaign_id', $request->campaign_id)->where('id', '!=', $pushCampaign->id)->exists()) {
            return redirect()->back()->with('error', 'Push Campaign with same campaign_id already exists!');
        }

        $validated = $validator->validated();

        $pushCampaign->update($validated);

        return redirect()->back()->with('message', 'Push Campaign updated successfully!');
    }


    /**
     * Function to delete campaign
     *
     * @param Request $request
     * @param [type] $id
     * @return void
     */
    public function delete(Request $request, $id)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $pushCampaign = PushCampaign::find($id);

        if (!$pushCampaign) {
            return redirect()->back()->with('error', "Push Campaign not found!");
        }

        $pushCampaign->delete();

        return redirect()->back()->with('message', 'Push Campaign deleted successfully!');
    }


    /**
     * Function to show form to send push notification
     *
     * @param Request $request
     * @return void
     */
    public function sendForm(Request $request)
    {
        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }
        $pushCampaigns = PushCampaign::all();
        $userSegments = UserSegment::all();

        return view('admin.push-campaign-v2.send', compact('pushCampaigns', 'userSegments'));
    }

    public function sendPush(Request $request)
    {
        // check for the session
        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        // validate the incoming data
        $validator = Validator::make($request->all(), [
            'push_campaign_id' => 'required|exists:push_campaigns,campaign_id',
            'user_segment_code' => 'required',
            'time' => 'required|in:now,after',
            'date_time' => 'required_if:time,after'
        ]);


        if ($validator->fails()) {
            return redirect()->back()->with('error', $validator->errors()->all()[0])->withInput();
        }

        // get push campaign
        $pushCampaign = PushCampaign::where('campaign_id', $request->push_campaign_id)->first();
        // get user segment
        $userSegment = UserSegment::where('code', $request->user_segment_code)->first();


        if ($request->user_segment_code === "all-users") {
            $users = Employee::whereDate('accountCreationDate', '>=', Carbon::createFromDate(2020, 8, 1));
        } else {
            $users = $userSegment->users;
        }

        // for each user
        foreach ($users as $user) {
            // generate payload
            $payload = [
                'title' => $this->parseText($pushCampaign->title, $user),
                'message' => $this->parseText($pushCampaign->message, $user),
            ];

            // if user has fcmToken
            if ($user->fcmToken || true) {
                // send the push
                SendPush::dispatch(
                    $user->userId,
                    $payload,
                    $pushCampaign->campaign_id,
                    113,
                    $payload['title'],
                    $payload['message'],
                    false,
                    $request->has('forced')
                )
                    ->delay(
                        $request->time === "now"
                            ? now()
                            : Carbon::createFromFormat('d/m/Y h:i a', $request->date_time, ($user->timezone ?? "UTC"))
                    );
            }
        }

        return redirect()->back()->with('message', 'Push Campaign Triggered successfully!');
    }

    /**
     * Parses text dynamically
     *
     * @param string $text text to parse
     * @param Employee $user employee
     * @return string parsed text
     */
    function parseText(string $text = "", Employee $user = null): string
    {
        /**
         * Following is the list of literals we will be looking at -
         * 
         * - [ ] {weekduration}
         * - [ ] {firstpartofconvo} ?? how will it be selected
         * - [x] {username}
         * - [ ] {vocabword} ?? how will it be selected
         * - [x] {progresspercentage}
         * - [ ] {badge:<badgename>} - this one can have more categories in it
         * - [x] {lessonname} ?? how will it be selected
         * - [x] {coursename} ?? how will it be selected
         */
        // for {username}
        if (strpos($text, "{username}") > -1) {
            $text = str_replace("{username}", empty($user->FirstName) ? "user" : $user->FirstName, $text);
        }
        // for {coursename}
        if (strpos($text, "{coursename}") > -1) {
            try {
                $text = str_replace("{coursename}", getModuleNameByCourse(getCourseModule($user->currentCourse)), $text);
            } catch (\Exception $e) {
                \Log::error("error at coursename parser", [$e]);
            }
        }
        // for {lessonname}
        if (strpos($text, "{lessonname}") > -1) {
            try {
                // get last exercise
                $lastActivityLog = UserActivityLog::where('userId', $user->userId)->orderBy('id', 'desc')->first();
                // get lesson from last exercise
                $lesson = Lesson::where('lesson_no', $lastActivityLog->lessonNo)->where('moduleno', $lastActivityLog->moduleNo)->first();
                // use the lesson->long_description as lesson name
                $text = str_replace("{lessonname}", $lesson->long_description, $text);
            } catch (\Exception $e) {
                \Log::error("error at lessonname parser", [$e]);
            }
        }
        // for {progresspercentage}
        if (strpos($text, "{progresspercentage}") > -1) {
            try {
                // get coursePercentage
                $coursePercentage = coursePercent(getCourseModule($user->currentCourse), $user->userId);
                // use the coursePercentage as progresspercentage
                $text = str_replace("{progresspercentage}", $coursePercentage . " %", $text);
            } catch (\Exception $e) {
                \Log::error("error at lessonname parser", [$e]);
            }
        }


        return $text;
    }
}
