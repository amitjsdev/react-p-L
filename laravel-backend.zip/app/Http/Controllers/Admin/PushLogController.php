<?php

namespace App\Http\Controllers;

use App\Employee;
use App\PushLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class PushLogController extends Controller
{
    public function index(Request $request)
    {
        return view('push-logs.index');
    }

    public function update(Request $request, $id) {
        // make validator
        $validator = Validator::make($request->all(), [
            "pushReceived" => "nullable|integer",
            "pushOpened" => "nullable|integer",
        ]);

        // validate and send error response if needed
        if($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        $pushLog = PushLog::find($id);

        if(!$pushLog) {
            return response()->json(['message' => 'Push log not found!'], 404);
        }

        // check if our push
        if($pushLog->userId !== auth()->user()->email) {
            return response()->json(['message' => 'Unauthorized!'], 403);
        }

        // update push
        $pushLog->update($validator->validated());

        // if user opened a push
        if($request->pushOpened) {
            // remove pause status, if necessary
            $employee = Employee::where('userId', $pushLog->userId)->first();
            if($employee->push_paused) {
                $employee->push_paused = false;
                $employee->push_paused_date = null;
                $employee->save();
            }
        }

        // return response
        return response()->json([
            "message" => "PushLog Updated",
            "pushLog" => $pushLog,
        ]);
    }
}
