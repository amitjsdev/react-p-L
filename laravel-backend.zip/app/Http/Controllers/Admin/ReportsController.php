<?php

namespace App\Http\Controllers\Admin;

use App\Console\Commands\CheckForUserStateUsingUserPoints;
use App\EmailLog;
use App\EmailTemplate;
use App\Employee;
use App\Http\Controllers\Controller;
use App\Module;
use App\PushLog;
use App\RoundLog;
use App\UserDailyGoalLog;
use App\UserDailyPhaseLog;
use App\UserPhaseLog;
use App\UserSegment;
use App\UserTimeLog;
use App\UserTimeLogReport;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;

class ReportsController extends Controller
{
    /**
     * Main report sends back user the data for user_loop_logs table
     *
     * @param Request $request
     * @return mixed
     */
    public function index(Request $request)
    {
        if (!Session::has('admin')) {
            return redirect('/admin-login');
        }

        $query = DB::table('user_loop_logs');

        if ($request->has('dateRange')) {
            $this->addDateRangeFilter($query, 'date', $request->dateRange);
        }

        $data = with(clone $query)->paginate();

        $count = with(clone $query)->count();

        return view('admin.reports.main', compact('data', 'count'));
    }


    /**
     * Main report sends back user the data for user_registration_loop_logs table
     *
     * @param Request $request
     * @return mixed
     */
    public function userRegistrationLoopLogs(Request $request)
    {
        if (!Session::has('admin')) {
            return redirect('/admin-login');
        }

        $query = DB::table('user_registration_loop_logs');

        if ($request->has('dateRange')) {
            $this->addDateRangeFilter($query, 'registrationDate', $request->dateRange);
        }

        $data = with(clone $query)->paginate();

        $count = with(clone $query)->count();

        return view('admin.reports.user_registration_loop_logs', compact('data', 'count'));
    }


    /**
     * Has data about use time logs
     *
     * @param Request $request
     * @return mixed
     */
    public function userTimeLogs(Request $request)
    {

        if (!Session::has('admin')) {
            return redirect('/admin-login');
        }

        // get case from groupby param
        $case = $request->groupBy;


        // select the columns according to the case
        switch ($case) {
            case "module":
                $columns = "moduleNo, courseNo";
                break;
            case "route":
                $columns = "moduleNo, courseNo, routeNo";
                break;
            default:
                $columns = "moduleNo, courseNo, routeNo, lessonNo";
                break;
        }

        // generate query
        $query = UserTimeLogReport::selectRaw("userId, dateRegistered, {$columns}, time_spent");


        // if the dateRange filter is available, filter by it
        if ($request->has('dateRange')) {
            $this->addDateRangeFilter($query, 'dateRegistered', $request->dateRange);
        }

        // get records according to case
        switch ($case) {
            case "module":
                $query->where('groupBy', 3);
                break;
            case "route":
                $query->where('groupBy', 2);
                break;
            default:
                $query->where('groupBy', 1);
                break;
        }

        // td($query->get());

        $data = with(clone $query)->paginate();

        $count = with(clone $query)->count();

        return view('admin.reports.user_time_logs', compact('data', 'count'));
    }

    public function userTimeLogsByUserId(Request $request, $userId)
    {
        // get employee details
        $user = \App\Employee::where('userId', $userId)->first();
        if (!$user) {
            abort(404, "User not found!");
        }
        // get lesson log
        $lessonLog = UserTimeLogReport::selectRaw('time_spent, moduleNo, routeNo, lessonNo')
            ->where('userId', $user->userId)
            ->where('groupBy', 1)
            ->get();
        // get route log
        $routeLog = UserTimeLogReport::selectRaw('time_spent, moduleNo, routeNo')
            ->where('userId', $user->userId)
            ->where('groupBy', 2)
            ->get();
        // get module log
        $moduleLog = UserTimeLogReport::selectRaw('time_spent, moduleNo')
            ->where('userId', $user->userId)
            ->where('groupBy', 3)
            ->get();
        $userTimeLog = UserTimeLog::selectRaw('screenCode, moduleNo, courseNo, routeNo, lessonNo, AppVersion, inTime, outTime, timediff(outTime, inTime) as time_spent, buttonsClicked, screenName')->where('userId', $user->userId)->get();
        // get push receive count
        $pushReceiveCount = UserTimeLog::where('userId', $user->userId)->whereBetween('screenCode', [200, 299])->count();
        // get push open count
        $pushOpenedCount = UserTimeLog::where('userId', $user->userId)->whereBetween('screenCode', [300, 399])->count();
        // get total time count
        $totalTimeInTheApp = UserTimeLog::selectRaw("sec_to_time(sum(time_to_sec(timediff(outTime, inTime)))) as total_time")
            ->where('userId', $user->userId)
            ->first();

        $totalTimeInTheApp = \Carbon\Carbon::parse($totalTimeInTheApp ? $totalTimeInTheApp->total_time : '00:00:00');

        $totalTimeInTheApp = $totalTimeInTheApp->hour . " Hours " . $totalTimeInTheApp->minute . " Minutes " . $totalTimeInTheApp->second . " Seconds";
        // return the view
        return view('admin.reports.user-time-logs-detail', compact('user', 'lessonLog', 'routeLog', 'moduleLog', 'userTimeLog', 'pushReceiveCount', 'pushOpenedCount', 'totalTimeInTheApp'));
    }



    /**
     * Main report sends back user the data for loop1detail_logs table
     *
     * @param Request $request
     * @return mixed
     */
    public function loopOneDetailLogs(Request $request)
    {
        if (!Session::has('admin')) {
            return redirect('/admin-login');
        }

        $query = DB::table('loop1detail_logs');

        $data = with(clone $query)->paginate();

        $count = with(clone $query)->count();

        return view('admin.reports.loop_one_detail_logs', compact('data', 'count'));
    }


    /**
     * Main report sends back user the data for loop1detail_logs_dates table
     *
     * @param Request $request
     * @return mixed
     */
    public function loopOneDetailLogsDateFilter(Request $request)
    {
        if (!Session::has('admin')) {
            return redirect('/admin-login');
        }

        $query = DB::table('loop1detail_logs_dates')
            ->selectRaw('dateRegistered, mobileOS, moduleNumber, sum(actTypeA) as actTypeA, sum(actTypeB) as actTypeB, sum(actTypeC) as actTypeC, sum(actTypeD) as actTypeD, 	sum(total) as total');
        //->where('dateRegistered', '2020-05-24');


        if ($request->has('dateRange')) {
            $this->addDateRangeFilter($query, 'dateRegistered', $request->dateRange);
        }

        $query->groupBy('moduleNumber');

        $data = with(clone $query)->paginate();

        $count = with(clone $query)->count();

        return view('admin.reports.loop_one_detail_logs_dates', compact('data', 'count'));
    }


    /**
     * Main report sends back user the data for user_loop_logs table
     *
     * @param Request $request
     * @return mixed
     */
    public function userLoopLogsByModule(Request $request)
    {
        if (!Session::has('admin')) {
            return redirect('/admin-login');
        }

        $query = DB::table('user_loop_logs')
            ->selectRaw('date, moduleNumber, courseNumber, sum(loopOneUsers) as loopOneUsers, sum(loopTwoUsers) as loopTwoUsers, sum(loopThreeUsers) as loopThreeUsers, sum(aheadOfTimes) as aheadOfTimes')
            ->groupBy('moduleNumber');

        if ($request->has('dateRange')) {
            $this->addDateRangeFilter($query, 'date', $request->dateRange);
        }

        $data = with(clone $query)->paginate();

        $count = with(clone $query)->count();

        return view('admin.reports.user_loop_logs', compact('data', 'count'));
    }


    /**
     * employeeCourseJsonWithEmail report sends back user the data for employee_course_json_with_email table
     *
     * @param Request $request
     * @return mixed
     */
    public function employeeCourseJsonWithEmailReport(Request $request)
    {
        if (!Session::has('admin')) {
            return redirect('/admin-login');
        }

        $query = DB::table('employee_course_json_with_email');

        if ($request->has('dateRange')) {
            $this->addDateRangeFilter($query, 'dateRegistered', $request->dateRange);
        }

        //$query->groupBy('moduleNumber');

        //$data = with(clone $query)->paginate();

        $data = with(clone $query)->paginate(10000000);

        $count = with(clone $query)->count();

        return view('admin.reports.employee_course_json_with_email', compact('data', 'count'));
    }

    public function pushLogs(Request $request)
    {
        if (!Session::has('admin')) {
            return redirect('/admin-login');
        }


        // find overall completion push sent
        $completionPush = PushLog::select('type', DB::raw('DATE(created_at) as date'), DB::raw('count(*) as pushes_sent'))
            ->where('type', 'weekly-completion')
            ->groupBy('date')
            ->get();

        // get all push logs
        $pushLogs = PushLog::select('id', 'type', DB::raw('DATE(created_at) as date'))->where('type', 'weekly-completion')->get();
        // for eachpush log, get the push received and push opened count
        foreach ($pushLogs as $pushSent) {
            // switch on push type
            if ($pushSent->type === 'weekly-completion') {
                // get push received
                $pushSent->pushes_received = UserTimeLog::where('screenCode', 201)->where('pushId', $pushSent->id)->exists() ? 1 : 0;
                $pushSent->pushes_opened = UserTimeLog::where('screenCode', 301)->where('pushId', $pushSent->id)->exists() ? 1 : 0;
            } else if ($pushSent->type === "weekly-task") {
                $pushSent->pushes_received = UserTimeLog::where('screenCode', 202)->where('pushId', $pushSent->id)->exists() ? 1 : 0;
                $pushSent->pushes_opened = UserTimeLog::where('screenCode', 302)->where('pushId', $pushSent->id)->exists() ? 1 : 0;
            }
        }

        // filter completion and weekly-task and grouby date
        $completionReportPushes = $pushLogs->filter(function ($value, $key) {
            return $value->type === 'weekly-completion';
        })->groupBy("date");

        $weeklyTaskPushes = $pushLogs->filter(function ($value, $key) {
            return $value->type === 'weekly-task';
        })->groupBy("date");


        // now that we have a data set, we can reduce the values to a specific value

        // first for completion report
        $completionReport = [];
        foreach ($completionReportPushes as $key => $report) {
            $completionReport[$key] = [
                'sent' => count($report),
                'received' => $report->reduce(function ($carry, $value) {
                    return $carry + $value->pushes_received;
                }),
                'opened' => $report->reduce(function ($carry, $value) {
                    return $carry + $value->pushes_opened;
                })
            ];
        }

        // now for weekly report
        $weeklyTask = [];
        foreach ($weeklyTaskPushes as $key => $report) {
            $weeklyTask[$key] = [
                'sent' => count($report),
                'received' => $report->reduce(function ($carry, $value) {
                    return $carry + $value->pushes_received;
                }),
                'opened' => $report->reduce(function ($carry, $value) {
                    return $carry + $value->pushes_opened;
                }),
            ];
        }

        return view('admin.reports.push-logs', compact('completionReport', 'weeklyTask'));
    }


    /**
     * Adds filter on basis of a date range
     *
     * @param Illuminate\Database\Query\Builder $query The already made query
     * @param string $dateRange The $daterangepicker date range
     * @param string $columnName The name of the column in table it has to be applied to
     * @return Illuminate\Database\Query\Builder $query
     */
    private function addDateRangeFilter($query, $columnName, $dateRange)
    {
        $explodedDateRange = explode(' - ', $dateRange);
        if (count($explodedDateRange) === 2) {
            list($startDate, $endDate) = $explodedDateRange;
            $startDate = \Carbon\Carbon::createFromFormat('m/d/Y', $startDate);
            $endDate = \Carbon\Carbon::createFromFormat('m/d/Y', $endDate);
            $query->whereDate($columnName, '<=', $endDate)
                ->whereDate($columnName, '>=', $startDate);
        }
        return $query;
    }


    /* employee Retention Report */

    public function employeeRetentionReport(Request $request)
    {


        if (!Session::has('admin')) {
            return redirect('/admin-login');
        }

        $query = DB::table('employee_cohort_final');

        if ($request->has('dateRange')) {
            $this->addDateRangeFilter($query, 'cohort_day', $request->dateRange);
        }

        //$query->groupBy('moduleNumber');

        //$data = with(clone $query)->paginate();

        $data = with(clone $query)->paginate(10000000);

        $count = with(clone $query)->count();

        //echo "<pre>"; print_r($data);

        $cohort_day = array();
        $cohort = "";

        foreach ($data as $rec) {

            if ($cohort != $rec->cohort_day)
                $cohort_day[$rec->cohort_day] = array("cohort_day" => $rec->cohort_day, "total_users" => $rec->total_users);

            //echo "Diff for ".$rec->cohort_day." = " . dateDiffInDays( date("Y-m-d"), $rec->cohort_day )."<br>"; 

            $dateDiff = dateDiffInDays(date("Y-m-d"), $rec->cohort_day);

            if ($dateDiff >= $rec->day_number)
                $cohort_day[$rec->cohort_day]["Day" . $rec->day_number] = $rec->totalOnDay;

            $cohort = $rec->cohort_day;
        }

        //print_r($cohort_day);




        return view('admin.reports.employee_cohort_final')->with(['data' => $cohort_day]);
    }

    public function employeeCompositeData(Request $request)
    {
        /**
         * Show the following data
         * 
         * userId, firstName, lastName, score, 
         * last_lesson, number_push_sent, number_push_received,
         * number_of_screen_opened, push_enabled,
         * last_7_Day_logins, last_1_Day_logins, module
         */
        $orderByOptions = [
            'Account Creation Date' => 'accountCreationDate',
            'User ID (Email)' => 'userId',
            'First Name' => 'FirstName',
        ];
        $orderBy = in_array($request->orderBy, $orderByOptions) ? $request->orderBy : 'accountCreationDate';
        // get all employees after august 01 2020
        $employees = Employee::whereDate('accountCreationDate', '>=', Carbon::createFromDate(2020, 8, 1))
            ->orderBy($orderBy)
            ->paginate();

        $data = [];

        // prepare data for each employee
        foreach ($employees as $employee) {
            // get number of pushes sent
            $pushStats = DB::select(DB::raw("select sum(pushReceived) as pushesReceived, SUM(pushOpened) as pushesOpened, count(*) as total from push_logs where userId=\"{$employee->userId}\""))[0];
            // get module details
            $moduleNumber = $employee->currentCourse ? getCourseModule($employee->currentCourse) : null;
            $module = Module::where('moduleno', $moduleNumber)->first();

            $last7DaysRaw = UserTimeLog::selectRaw("count(*) > 0 as count, DATE(inTime) as date")
                ->where('userId', $employee->userId)
                ->whereDate('inTime', '>=', today()->subDays(7))
                ->groupBy('date')
                ->orderBy('date', 'DESC')
                ->get();

            $last7Days = [
                now()->subDays(1)->format('Y-m-d') => 0,
                now()->subDays(2)->format('Y-m-d') => 0,
                now()->subDays(3)->format('Y-m-d') => 0,
                now()->subDays(4)->format('Y-m-d') => 0,
                now()->subDays(5)->format('Y-m-d') => 0,
                now()->subDays(6)->format('Y-m-d') => 0,
                now()->subDays(7)->format('Y-m-d') => 0,
            ];

            foreach ($last7DaysRaw as $day) {
                $last7Days[$day->date] = $day->count;
            }

            $firstDay = now()->subDays(7);

            $screensOpened = UserTimeLog::where('userId', $employee->userId)->count();

            // add the data
            $data[] = [
                'employee' => $employee,
                'pushStats' => $pushStats,
                'module' => $module,
                'last7Days' => $last7Days,
                'screensOpened' => $screensOpened,
            ];
        }
        // return view
        return view('admin.reports.employee-composite-data')->with(['data' => $data, 'employees' => $employees, 'orderBy' => $orderBy, 'orderByOptions' => $orderByOptions]);
    }


    public function employeeGoalsHistory(Request $request)
    {

        $orderByOptions = [
            'Account Creation Date' => 'accountCreationDate',
            'User ID (Email)' => 'userId',
            'First Name' => 'FirstName',
        ];
        $orderBy = in_array($request->orderBy, $orderByOptions) ? $request->orderBy : 'accountCreationDate';
        // get all employees after august 01 2020
        $employees = Employee::whereDate('accountCreationDate', '>=', Carbon::createFromDate(2020, 8, 1))
            ->orderBy($orderBy);

        // user id filter
        if ($request->userId) {
            $employees->where('userId', 'like', "%{$request->userId}%")->orWhere('FirstName', 'like', "%{$request->userId}%");
        }

        $employees = $employees
            ->paginate();

        $data = [];

        // prepare data for each employee
        foreach ($employees as $employee) {
            // add the data
            $data[] = getUserGoalDataForLast7Days($employee);
        }

        // return view
        return view('admin.reports.employee-goals-hostory')->with([
            'data' => $data,
            'employees' => $employees,
            'orderBy' => $orderBy,
            'orderByOptions' => $orderByOptions
        ]);
    }


    public function phasedUserReport(Request $request)
    {

        $userSegments = UserSegment::whereIn('code', array_keys(CheckForUserStateUsingUserPoints::SEGMENTS))->get();

        // return view
        return view('admin.reports.phased-users-log')->with([
            'data' => $userSegments,
        ]);
    }

    public function inactiveDayXUserReport(Request $request)
    {

        $userSegments = UserSegment::whereIn('code', array_keys(CheckForUserStateUsingUserPoints::INACTIVE_DAYS_SEGMENTS))->get();

        // return view
        return view('admin.reports.inactive-day-x-users-log')->with([
            'data' => $userSegments,
        ]);
    }


    public function userPhaseReport(Request $request, $userId)
    {

        $userPhaseLog = UserDailyPhaseLog::where('userId', $userId)->latest()->get();

        // return view
        return view('admin.reports.user-phase-log')->with([
            'data' => $userPhaseLog,
        ]);
    }

    public function additionalLivesClaimedReport(Request $request)
    {
        $users = Employee::select(
            'employee.userId',
            'employee.last_lesson',
            'employee.totalScore',
            'employee.lastLoginDate',
            'employee.mobileOS',
            'accountCreationDate',
            DB::raw('sum(additionalLivesClaimed) as additionalLivesClaimed')
        )
            ->join('round_logs', 'employee.userId', '=', 'round_logs.userId')
            ->groupBy('userId');

        if ($request->has('email')) {
            $users->where('employee.userId', 'like', '%' . $request->email . '%');
        }

        // check orderby
        if ($request->sortBy) {
            list($sortBy, $direction) = explode('-', $request->sortBy);
        } else {
            $sortBy = 'additionalLivesClaimed';
            $direction = 'desc';
        }

        $users = $users
            ->orderBy($sortBy, $direction)
            ->paginate(50);

        // return view
        return view('admin.reports.additional-lives-claimed')->with([
            'data' => $users,
        ]);
    }

    // report to see how email templates are doing

    /**
     * // report to see how email templates are doing
     *
     * @param Request $request
     * @return mixed
     */
    public function emailTemplatePerformance(Request $request)
    {
        if (!Session::has('admin')) {
            return redirect('/admin-login');
        }

        // get all email templates
        $emailTemplates = EmailTemplate::all();
        $emailTemplateIdentifiers = $emailTemplates->pluck('template_identifier');

        // get email logs for each email templates
        $emailLogs = EmailLog::selectRaw('type, sum(emailSent) as emailSent, sum(emailOpened) as emailOpened, sum(ctaClicked) as ctaClicked')
            ->whereIn('type', $emailTemplateIdentifiers)
            ->groupBy('type')
            ->get();

        return view('admin.reports.email-template-performance-index', compact('emailLogs'));
    }

    // report to see how certail email template is doing

    /**
     * // report to see how certail email template is doing
     *
     * @param Request $request
     * @return mixed
     */
    public function emailTemplatePerformanceDetail(Request $request, $template_identifier)
    {
        if (!Session::has('admin')) {
            return redirect('/admin-login');
        }

        // get all email templates
        $emailTemplate = EmailTemplate::findByIdentifier($template_identifier);

        if (!$emailTemplate) {
            return abort(404);
        }
        $emailBounceCount = 0;
        $emailUnsubscribeCount = 0;

        $today = today();

        // get email log dates for this email
        $datesThisEmailWasSentOn = EmailLog::selectRaw('DISTINCT(DATE(updated_at)) as date')
            ->where('type', $template_identifier)
            ->pluck('date');

        // get emails that have received this campaign
        $emailsWhoHaveReceivedThisTemplate =  EmailLog::where('type', $template_identifier)
        ->pluck('userId');

        //  get count of bounces and unsubscribes
        $ses = DB::table('ses_sns_email_list')
        ->selectRaw("emailType, DATE(emailDate) as date, userId")
        ->whereIn('userId', $emailsWhoHaveReceivedThisTemplate);

        // get records for the dates
        if ($datesThisEmailWasSentOn->count() > 0) {
            foreach ($datesThisEmailWasSentOn as $key => $date) {
                if ($key === 0) {
                    $ses = $ses->having('date', $date);
                } else {
                    $ses = $ses->orHaving('date', $date);
                }
            }
        } else {
            // no bounce or unsub
            $ses = $ses->orHaving('date', '9999-99-99');
        }

        $ses = $ses->get();

        // for each ses, check what email type it is and update count likewise
        foreach ($ses as $unsub) {
            if ($unsub->emailType === "b") {
                $emailBounceCount++;
            }
            if ($unsub->emailType === "u") {
                $emailUnsubscribeCount++;
            }
        }

        // getting users that have unsubscribed
        $usersThatHaveUnsubscribed = $ses->filter(function($unsub) {
            return $unsub->emailType === "u";
        });
        
        // getting users that have bounced
        $usersThatHaveBounced = $ses->filter(function($bounce) {
            return $bounce->emailType === "b";
        });

        // get count of sent and opens
        $elogByCampaign = EmailLog::selectRaw("type, DATE(created_at) as date, sum(emailSent) as emailSent, sum(emailOpened) as emailOpened, sum(ctaClicked) as ctaClicked")
            ->where('type', $template_identifier)
            ->groupBy('type')
            ->get();

        // per user log
        $emailLogs = EmailLog::where('type', $template_identifier)->get();

        return view('admin.reports.email-template-performance-detail', compact(
            'today',
            'emailTemplate',
            'emailBounceCount',
            'emailUnsubscribeCount',
            'elogByCampaign',
            'emailLogs',
            'usersThatHaveUnsubscribed',
            'usersThatHaveBounced'
        ));
    }



    // get the list of users that are annoyed!
    function getAnnoyedUsers(Request $request)
    {
        $employees = Employee::select('userId', 'FirstName', 'was_on_break', 'accountCreationDate')->whereDate('accountCreationDate', '>=', Carbon::createFromDate(2020, 8, 15))->get();

        $annoyedUsers = [];
        $notAnnoyedUsers = [];

        // check if user is annoyed
        foreach($employees as $employee) {
            $isAnnoyed = isTheUserAnnoyed($employee);
            $employee->isAnnoyed = $isAnnoyed;
            if ($isAnnoyed) {
                $annoyedUsers[] = $employee;
            } else {
                $notAnnoyedUsers[] = $employee;
            }
        }

        return view('admin.reports.annoyed-user-list', compact(
            'annoyedUsers',
            'notAnnoyedUsers'
        ));
    }

    public function additionalLivesClaimedCSV(Request $request)
    {

        // get users with score more than 500
        $cutoffUsers  = UserDailyGoalLog::selectRaw('sum(points) as total, userId')->groupBy('userId')->having('total', '>', 500)->pluck('userId');

        // Get report for all users
        $users = Employee::select(
            'employee.userId',
            'accountCreationDate',
            'employee.last_lesson',
            'employee.totalScore',
            'employee.lastLoginDate',
            'employee.mobileOS',
            DB::raw('sum(additionalLivesClaimed) as additionalLivesClaimed')
        )
            ->whereIn('employee.userId', $cutoffUsers->toArray())
            ->join('round_logs', 'employee.userId', '=', 'round_logs.userId')
            ->groupBy('userId')->get();


        // prep headers
        $headers = array(
            "Content-type" => "text/csv",
            "Content-Disposition" => "attachment; filename=additiona-lives-claimed-" . now()->toDateString() . ".csv",
            "Pragma" => "no-cache",
            "Cache-Control" => "must-revalidate, post-check=0, pre-check=0",
            "Expires" => "0"
        );

        $columns = array('Email', 'Account Creation Date', 'Last Lesson', 'Total Score', 'Last Login Date', 'Mobile OS', 'Additional Claimed Life');

        $callback = function () use ($users, $columns) {
            $file = fopen('php://output', 'w');
            fputcsv($file, $columns);

            foreach ($users as $user) {
                fputcsv($file, $user->toArray());
            }
            fclose($file);
        };

        $response = response()->stream($callback, 200);

        foreach ($headers as $headerKey => $header) {
            $response->headers->set($headerKey, $header);
        }

        return $response;
    }

    function userThatHaveMade3OrMoreMistakesNTimes(Request $request)
    {
        $user_count = DB::select("SELECT count(DISTINCT userId) as user_count FROM ( SELECT round_logs.id, round_logs.userId, COUNT(*) AS fails FROM round_logs JOIN round_exercise_logs ON round_logs.id = round_exercise_logs.roundLogId WHERE round_exercise_logs.status != 1 GROUP BY round_logs.id, userId HAVING fails >= 3 ) as user_fails")[0]->user_count;

        $failed_users = DB::select("SELECT userId, COUNT(*) AS fails FROM ( SELECT     round_logs.id,     round_logs.userId,     COUNT(*) AS fails FROM     `round_logs` JOIN round_exercise_logs ON round_logs.id = round_exercise_logs.roundLogId WHERE     round_exercise_logs.status != 1 GROUP BY     round_logs.id,     userId HAVING     fails >= 3) AS fails GROUP BY userId");
        // return view
        return view('admin.reports.users-that-have-made-3-or-more-mistakes-n-times')->with([
            'user_count' => $user_count,
            'data' => $failed_users,
        ]);
    }
}
