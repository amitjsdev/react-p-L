<?php

namespace App\Http\Controllers\Admin;

use App\Console\Commands\CheckForUserStateUsingUserPoints;
use App\Employee;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Resources\UserSegmentUsersResource;
use App\UserSegment;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Session;

class UserSegmentController extends Controller
{

    public function refreshUserCount(Request $request)
    {
        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $userSegments = UserSegment::all();

        // update the count

        foreach($userSegments as $userSegment) {
            // save the updated count
            $userSegment->user_count = $userSegment->users->count();
            $userSegment->save();
        }

        return redirect()->back()->with('message', 'Refreshed the user count for all segment!');
    }

    /**
     * Function index shows a form for push campaign
     *
     * @param Request $request
     * @return mixed
     */
    public function index(Request $request)
    {


        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $pageSize = $request->pageSize ? $request->pageSize : 50;
        $userSegments = UserSegment::query();

        // check for filters
        if (!empty($request->get('code'))) $userSegments->where('code', "like", "%" . $request->code . "%");
        if (!empty($request->get('name'))) $userSegments->where('name', "like", "%" . $request->name . "%");
        // check for filters end

        $userSegments = $userSegments->paginate($pageSize);

        return view('admin.user-segment.index', compact('pageSize', 'userSegments'));
    }

    public function viewSegment(Request $request, $id)
    {
        $userSegment = UserSegment::find($id);

        $users = $userSegment->users()->orderBy('userId')->get();

        return view('admin.user-segment.view')->with([
            'segment' => $userSegment,
            'data' => $users
        ]);
    }

    /**
     * Function shows the add form
     *
     * @param Request $request
     * @return void
     */
    public function add(Request $request)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $userSegment = new UserSegment();

        $allUsers = Employee::whereDate('accountCreationDate', '>', Carbon::create('2020', '6')
            ->startOfMonth())
            ->orderBy('userId')
            ->orderBy('FirstName')
            ->get(['userId', 'FirstName']);

        return view("admin.user-segment.add", compact('userSegment', 'allUsers'));
    }

    /**
     * Function shows the add form to upload csv
     *
     * @param Request $request
     * @return void
     */
    public function addFromMix(Request $request)
    {

        if (!Session::get('admin') || !Session::get('marketing')) {
            return redirect('/admin-login');
        }

        return view("admin.user-segment.add-from-mix");
    }

    /**
     * Function saves the csv from mix panel
     *
     * @param Request $request
     * @return void
     */
    public function saveFromMix(Request $request)
    {
        if (!Session::get('admin') || !Session::get('marketing')) {
            return redirect('/admin-login');
        }


        $validator = Validator::make($request->all(), [
            "code" => "required|string|unique:user_segments",
            "name" => "required|string",
            "description" => "nullable|string",
            "csv" => "required|file",
        ]);

        // $validated = $validator->validated();
        if ($validator->fails()) {
            return redirect()->back()->with('error', $validator->errors()->all()[0])->withInput();
        }


        // check if the type is already used
        if (UserSegment::where('code', $request->code)->exists()) {
            return redirect()->back()->with('error', 'User Segment with same code already exists!');
        }

        // read csv
        $csv = \League\Csv\Reader::createFromPath($request->csv->getPathName(), 'r');
        $csv->setHeaderOffset(0);
        $header = $csv->getHeader();
        $records = $csv->getRecords();


        // get all userIds from csv
        $userIds = [];
        foreach ($records as $record) {
            if (isset($record['$properties.$email'])) {
                $userIds[] = $record['$properties.$email'];
            }
        }

        // get valid employees from csv
        $employees = Employee::whereIn('userId', $userIds)->get();

        $employeeCount = $employees->count();
        if ($employeeCount > 0) {
            // we have sufficient users, create the segment
            $validated = $validator->validated();


            // add user count to validated
            $validated['user_count'] = $employees->count();


            $userSegment = UserSegment::create($validated);

            // add every selected user
            foreach ($employees as $user) {
                DB::table('user_user_segment')
                    ->insert([
                        'user_segment_id' => $userSegment->id,
                        'userId' => $user->userId
                    ]);
            }
        }

        return redirect()->back()->with('message', 'User Segment import complete with ' . $employeeCount . ' users!');
    }

    /**
     * Function shows the add form using rules
     *
     * @param Request $request
     * @return void
     */
    public function addFromRules(Request $request)
    {

        if (!Session::get('admin') || !Session::get('marketing')) {
            return redirect('/admin-login');
        }

        return view("admin.user-segment.add-from-rules");
    }

    /**
     * Function shows the save form using rules
     *
     * @param Request $request
     * @return void
     */
    public function saveFromRules(Request $request)
    {


        $validator = Validator::make($request->all(), [
            "code" => "required|string|unique:user_segments",
            "name" => "required|string",
            "description" => "nullable|string",
        ]);

        // $validated = $validator->validated();
        if ($validator->fails()) {
            return redirect()->back()->with('error', $validator->errors()->all()[0])->withInput();
        }


        // check if the type is already used
        if (UserSegment::where('code', $request->code)->exists()) {
            return redirect()->back()->with('error', 'User Segment with same code already exists!');
        }

        // get users
        $employees = Employee::query();

        // if request has is_point_constrained
        if ($request->is_point_constrained) {
            $pointConstraint = (int) $request->point_constraint;
            $employees = $employees->where('totalScore', '>', $pointConstraint);
        }

        // if request isDateRangeConstrained
        if ($request->isDateRangeConstrained) {
            $this->addDateRangeFilter($employees, 'accountCreationDate', $request->dateRange);
        }

        // get employees from db
        $employees = $employees->orderBy('userId')->get();
        $employeeCount = $employees->count();

        // if request does not have save_it param, save it
        if (!$request->has('save_it')) {
            $url = url()->current() . "-save?" . http_build_query(array_merge($request->except(['_token']), ['save_it' => true]));
            $a = '<a href="' . $url . '">Click here to continue!</a>';
            echo '<span>This will create a user segment for ' . $employeeCount . ' users.</span> ' . $a;
            echo '<br /> or go back <a href="javascript:history.back()">Back</a>';
            echo "<p>";
            foreach ($employees as $employee) {
                echo $employee->userId . "<br />";
            }
            echo "</p>";
            return response('');
        }

        // create the segment
        if ($employeeCount > 0) {
            // we have sufficient users, create the segment
            $validated = $validator->validated();

            // add user count to validated
            $validated['user_count'] = $employees->count();

            $userSegment = UserSegment::create($validated);

            // add every selected user
            foreach ($employees as $user) {
                DB::table('user_user_segment')
                    ->insert([
                        'user_segment_id' => $userSegment->id,
                        'userId' => $user->userId
                    ]);
            }
        }

        // return with message
        return redirect()->back()->with('message', 'User Segment import complete with ' . $employeeCount . ' users!');
    }


    /**
     * Adds filter on basis of a date range
     *
     * @param Illuminate\Database\Query\Builder $query The already made query
     * @param string $dateRange The $daterangepicker date range
     * @param string $columnName The name of the column in table it has to be applied to
     * @return Illuminate\Database\Query\Builder $query
     */
    private function addDateRangeFilter($query, $columnName, $dateRange)
    {
        $explodedDateRange = explode(' - ', $dateRange);
        if (count($explodedDateRange) === 2) {
            list($startDate, $endDate) = $explodedDateRange;
            $startDate = \Carbon\Carbon::createFromFormat('m/d/Y', $startDate);
            $endDate = \Carbon\Carbon::createFromFormat('m/d/Y', $endDate);
            $query->whereDate($columnName, '<=', $endDate)
                ->whereDate($columnName, '>=', $startDate);
        }
        return $query;
    }

    /**
     * Function saves push campaign
     */
    public function save(Request $request)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }


        $validator = Validator::make($request->all(), [
            "code" => "required|string|unique:user_segments",
            "name" => "required|string",
            "description" => "nullable|string",
        ]);

        // $validated = $validator->validated();

        if ($validator->fails()) {
            return redirect()->back()->with('error', $validator->errors()->all()[0])->withInput();
        }

        // check if the type is already used
        if (UserSegment::where('code', $request->code)->exists()) {
            return redirect()->back()->with('error', 'User Segment with same code already exists!');
        }

        $validated = $validator->validated();
        
        // add user count to validated
        $validated['user_count'] = count($request->users);
        
        
        $userSegment = UserSegment::create($validated);


        // check for users
        // add every selected user
        foreach ($request->users as $user) {
            DB::table('user_user_segment')
                ->insert([
                    'user_segment_id' => $userSegment->id,
                    'userId' => $user
                ]);
        }
        // check for users end

        return redirect()->back()->with('message', 'User Segment saved successfully!');
    }

    /**
     * Function to display edit
     *
     * @param Request $request
     * @param int $id
     * @return mixed
     */
    public function edit(Request $request, $id)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $userSegment = UserSegment::find($id);

        if (!$userSegment) {
            return redirect()->back()->with('error', "User Segment not found!");
        }

        $allUsers = Employee::whereDate('accountCreationDate', '>', Carbon::create('2020', '6')
            ->startOfMonth())
            ->orderBy('userId')
            ->orderBy('FirstName')
            ->get(['userId', 'FirstName']);

        return view("admin.user-segment.add", compact('userSegment', 'allUsers'));
    }

    /**
     * Function that updates values
     *
     * @param Request $request
     * @param [type] $id
     * @return void
     */
    public function update(Request $request, $id)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $validator = Validator::make($request->all(), [
            "code" => "required|string",
            "name" => "nullable|string",
            "description" => "nullable|string",
        ]);

        // $validated = $validator->validated();

        if ($validator->fails()) {
            return redirect()->back()->with('error', $validator->errors()->all()[0])->withInput();
        }



        $userSegment = UserSegment::find($id);

        if (!$userSegment) {
            return redirect()->back()->with('error', "User Segment not found!");
        }

        // check if the type is already used
        if (UserSegment::where('code', $request->code)->where('id', '!=', $userSegment->id)->exists()) {
            return redirect()->back()->with('error', 'User Segment with same campaign_id already exists!');
        }

        $validated = $validator->validated();

        // add user count to validated
        $validated['user_count'] = count($request->users);

        $userSegment->update($validated);

        // check for users
        // for ease we are removing older users first and then adding new users
        DB::table('user_user_segment')->truncate();
        // add every selected user
        foreach ($request->users as $user) {
            DB::table('user_user_segment')
                ->insert([
                    'user_segment_id' => $id,
                    'userId' => $user
                ]);
        }
        // check for users end


        return redirect()->back()->with('message', 'User Segment updated successfully!');
    }

    /**
     * Function to delete any user segment
     *
     * @param Request $request
     * @param [type] $id
     * @return void
     */
    public function delete(Request $request, $id)
    {


        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $userSegment = UserSegment::find($id);

        if (!$userSegment) {
            return redirect()->back()->with('error', "User Segment not found!");
        }
        $userSegment->delete();

        return redirect()->back()->with('message', 'User Segment deleted successfully!');
    }

    /**
     * Get all the employees
     *
     * @param Request $request
     * @return void
     */
    public function users(Request $request)
    {
        if (!Session::get('admin')) {
            return response()->json(["message" => "unauthenticated!"]);
        }
        $employee = Employee::query();

        if ($request->q) {
            $employee = $employee
                ->where('FirstName', 'like', '%' . $request->q . '%')
                ->orWhere('LastName', 'like', '%' . $request->q . '%')
                ->orWhere("userId", "like", "%" . $request->q . "%");
        }

        return response()->json(UserSegmentUsersResource::collection($employee->get()));
    }
}
