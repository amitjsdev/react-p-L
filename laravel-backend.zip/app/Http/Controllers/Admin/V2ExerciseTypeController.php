<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\V2ExerciseType;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;

class V2ExerciseTypeController extends Controller
{
    /**
     * Show all the records
     *
     * @param Request $request
     * @return void
     */
    public function index(Request $request)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $pageSize = $request->pageSize ? $request->pageSize : 50;
        $exerciseTypes = V2ExerciseType::query();

        // check for filters
        if (!empty($request->get('type'))) $exerciseTypes->where('type', "like", "%" . $request->type . "%");
        if (!empty($request->get('title'))) $exerciseTypes->where('title', "like", "%" . $request->title . "%");
        // check for filters end

        $exerciseTypes = $exerciseTypes->paginate($pageSize);

        return view('admin.exercise-v2-type.index', compact('pageSize', 'exerciseTypes'));
    }


    /**
     * For showing add form
     *
     * @param Request $request
     * @return void
     */
    public function add(Request $request)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $exerciseType = new V2ExerciseType();

        return view("admin/exercise-v2-type/add", compact('exerciseType'));
    }

    /**
     * To save new record
     *
     * @param Request $request
     * @return void
     */
    public function save(Request $request)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }


        $validator = Validator::make($request->all(), [
            "type" => "required|string",
            "title" => "nullable|string",
            "description" => "nullable|string",
            "description_es" => "nullable|string",
            "is_active" => "required|boolean",
        ]);

        // $validated = $validator->validated();

        if ($validator->fails()) {
            return redirect()->back()->with('error', $validator->errors()->all()[0])->withInput();
        }

        // check if the type is already used
        if(V2ExerciseType::where('type', $request->type)->exists()) {
            return redirect()->back()->with('error', 'Exercise type with same code already exists!');
        }

        $validated = $validator->validated();

        V2ExerciseType::create($validated);

        return redirect()->back()->with('message', 'Exercise type saved successfully!');
    }


    /**
     * For showing edit form
     *
     * @param Request $request
     * @param [type] $id
     * @return void
     */
    public function edit(Request $request, $id)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $exerciseType = V2ExerciseType::find($id);

        if (!$exerciseType) {
            return redirect()->back()->with('error', "Exercise Type not found!");
        }

        return view("admin/exercise-v2-type/add", compact('exerciseType'));
    }


    /**
     * To update existing v2 exercise
     *
     * @param Request $request
     * @return void
     */
    public function update(Request $request, $id)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $validator = Validator::make($request->all(), [
            "type" => "required|string",
            "title" => "nullable|string",
            "description" => "nullable|string",
            "description_es" => "nullable|string",
            "is_active" => "required|boolean",
        ]);

        // $validated = $validator->validated();

        if ($validator->fails()) {
            return redirect()->back()->with('error', $validator->errors()->all()[0])->withInput();
        }



        $exerciseType = V2ExerciseType::find($id);



        // check if the type is already used
        if (V2ExerciseType::where('type', $request->type)->where('id', '!=', $exerciseType->id)->exists()) {
            return redirect()->back()->with('error', 'Exercise type with same code already exists!');
        }

        if (!$exerciseType) {
            return redirect()->back()->with('error', "Exercise Type not found!");
        }

        $validated = $validator->validated();

        $exerciseType->update($validated);

        return redirect()->back()->with('message', 'Exercise Type updated successfully!');
    }


    public function delete(Request $request, $id)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $exerciseType = V2ExerciseType::find($id);

        if (!$exerciseType) {
            return redirect()->back()->with('error', "Exercise Type not found!");
        }

        $exerciseType->delete();

        return redirect()->back()->with('message', 'Exercise Type deleted successfully!');
    }
}
