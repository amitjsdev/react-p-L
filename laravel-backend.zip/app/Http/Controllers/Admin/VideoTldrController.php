<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

use App\Http\Controllers\Controller;
use App\Lesson;
use App\Module;
use App\Route;
use App\VideoTldr;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class VideoTldrController extends Controller
{
    // List all
    public function ui(Request $request)
    {

        $sql = "select * from module where status='1' order by moduleno ";
        $modules = DB::select(DB::raw($sql));

        $tldrs = VideoTldr::query();

        if (!empty($request->moduleNo)) {
            $tldrs->where('moduleNo', (int) $request->moduleNo);
        }
        if (!empty($request->routeNo)) {
            $tldrs->where('routeNo', $request->routeNo);
        }
        if (!empty($request->lessonNo)) {
            $tldrs->where('lessonNo', $request->lessonNo);
        }

        if(!empty($request->sortBy)) {
            $sortByParams = explode("-", $request->sortBy);
            $sortBy = $sortByParams[0];
            $sortDirection = $sortByParams[1];
            $tldrs->orderBy($sortBy, $sortDirection);
        }

        $tldrs = $tldrs->paginate(50);

        return view('admin.video-tldr', compact('tldrs'));
    }

    public function new(Request $request)
    {

        $sql = "select * from module where status='1' order by moduleno ";
        $modules = DB::select(DB::raw($sql));

        if ($request->has('clone')) {
            $videoTLDR = VideoTldr::find($request->clone);
            $videoTLDR->id = null; // so that the edit does not get triggered
        } else {
            $videoTLDR = new VideoTldr();
        }

        return view('admin.add-video-tldr', compact('modules', 'videoTLDR'));
    }

    public function get(Request $request)
    {
        $validated = $request->validate([
            "moduleNo" => "required",
            "routeNo" => "required",
            "lessonNo" => "required",
        ]);

        $tldrs = VideoTldr::where($validated)->get();

        foreach ($tldrs as $tldr) {
            $tldr->image = $tldr->image ? url(str_replace('public', 'storage', $tldr->image)) : "";
        }

        return response()->json($tldrs);
    }

    public function show(Request $request, $id)
    {

        $sql = "select * from module where status='1' order by moduleno ";
        $modules = DB::select(DB::raw($sql));

        $videoTLDR = VideoTldr::find($id);

        if (!$videoTLDR) {
            return redirect()->back()->with("error", "Not found!");
        }

        return view('admin.add-video-tldr', compact('modules', 'videoTLDR'));
    }

    // Add new
    public function add(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'moduleNo' => 'required',
            'routeno' => 'required',
            'lesson_no' => 'required',
            'title' => 'nullable|string',
            'description' => 'nullable|string',
            'voice' => 'nullable|string',
            'extra_info' => 'nullable|string',
            'miniLesson' => 'nullable|string',
            'videoTime' => 'nullable|string',
            'image' => 'image'
        ]);

        if ($validator->fails()) {
            return redirect()->back()->with('error', $validator->errors()->all()[0])->withInput();
        }

        $data = [];

        // create data
        $data = [
            'moduleNo' => $request->moduleNo,
            'routeNo' => $request->routeno,
            'lessonNo' => $request->lesson_no,
            'title' => $request->title,
            'description' => $request->description,
            'voice' => $request->voice,
            'extra_info' => $request->extra_info,
            'miniLesson' => $request->miniLesson,
            'videoTime' => $request->videoTime,
        ];

        if ($request->hasFile('image')) {
            $data['image'] = $request->file('image')->store('public/images/tldr');
        }

        $videoTldr = VideoTldr::create($data);

        return redirect()->back()->with('message', 'Video TLDR created!');
    }

    // Update existings
    public function update(Request $request, $id)
    {

        $tldr = VideoTldr::find($id);

        if (!$tldr) {
            return redirect()->back()->with('error', 'Not found!');
        }

        $validator = Validator::make($request->all(), [
            'moduleNo' => 'required',
            'routeno' => 'required',
            'lesson_no' => 'required',
            'title' => 'nullable|string',
            'description' => 'nullable|string',
            'voice' => 'nullable|string',
            'extra_info' => 'nullable|string',
            'image' => 'image',
            'miniLesson' => 'nullable|string',
            'videoTime' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return redirect()->back()->with('error', $validator->errors()->all()[0]);
        }

        $data = [];

        // create data
        $data = [
            'moduleNo' => $request->moduleNo,
            'routeNo' => $request->routeno,
            'lessonNo' => $request->lesson_no,
            'title' => $request->title,
            'description' => $request->description,
            'voice' => $request->voice,
            'extra_info' => $request->extra_info,
            'miniLesson' => $request->miniLesson,
            'videoTime' => $request->videoTime,
        ];

        if ($request->hasFile('image')) {
            Storage::delete($tldr->image);
            $data['image'] = $request->file('image')->store('public/images/tldr');
        }

        $tldr->update($data);

        return redirect()->back()->with('message', 'Video TLDR updated!');
    }

    // delete
    public function delete(Request $request, $id)
    {
        $videoTLDR = VideoTldr::find($id);

        if (!$videoTLDR) {
            return redirect()->back()->with("error", "Not found!");
        }

        $videoTLDR->delete();

        return redirect()->back()->with('message', 'Video TLDR deleted!');
    }
}
