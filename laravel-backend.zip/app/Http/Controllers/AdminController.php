<?php

namespace App\Http\Controllers;

use App\Group;
use App\Api;
use Illuminate\Http\Request;
//use Illuminate\Support\Facades\Input;
use Session;
use DB;
use Validator;

use App\Course;
use App\Http\Resources\Course as CourseResource;


class AdminController extends Controller
{
    /**
     * Handles Registration Request
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function login(Request $request)
    {
          $input =   $request->all();
          //$data = Input::all();
          extract($input); 

          $user = DB::table('admin_login')->where('username', $username)
               ->where('password', md5($password))->first();

          //print_r($results);   die;   
           if($user){
             if($user->role === 'admin') {
                Session::put('admin', 'true');
                return redirect('/dashboard');
             }

             if($user->role === 'marketing') {
                Session::put('marketing', 'true'); // will do later
                Session::put('admin', 'true');
                return redirect('/reports/main');
             }

           }else{
            return redirect('/admin-login?status=false');

           }    
          //print_r($results );
 
    } 

   public function index(Request $request)
    {
       if(!Session::get('admin')){
        return redirect('/admin-login');
       }
        $groups = DB::table('groups')->select('id','name')->orderBy('id', 'desc')->get();
        $apies = DB::table('apis')->select('id','name','method')->orderBy('id', 'desc')->get();
   
        return view('admin.Dashboard')->with(['groups'=>$groups,'apies'=>$apies,'size'=>sizeof($apies)]);
 
    }

   public function adminLogin(Request $request)
    {

        if(Session::get('admin')){
          return redirect('/dashboard');
         }

         return view('admin.Adminlogin');
 
    }


    public function addGroup(Request $request)
    {
      if(!Session::get('admin')){
        return redirect('/admin-login');
       }
        $group =  new Group;
        $group->name = $request->input('group');
        if($group->save()){
            return redirect()->back()->with('message', 'Group added successfully!');

        }
 
    }

    public function deleteGroup(Request $request)
    {
      if(!Session::get('admin')){
        return redirect('/admin-login');
       }
        Group::where('id', $request->id)->delete();
         return redirect()->back()->with('message', 'Group deleted successfully!');

 
    }

    public function manageApi(Request $request)
    {
      if(!Session::get('admin')){
        return redirect('/admin-login');
       }
        $apies = DB::table('apis')->select('id','name','method')->orderBy('id', 'desc')->get();

        return view('admin.ManageApi')->with('apies', $apies);

 
    }

    public function addApi(Request $request)
    {
      if(!Session::get('admin')){
        return redirect('/admin-login');
       }
        $api =  new Api;
        $api->name = $request->input('api_name');
        $api->method = implode(',',$request->input('method'));
        if($api->save()){
            return redirect('/manage-api');
        }
 
    }

    public function deleteApi(Request $request)
    {
      if(!Session::get('admin')){
        return redirect('/admin-login');
       }
         Api::where('id', $request->id)->delete();

 
    } 

  public function assignApi(Request $request)
    {
      if(!Session::get('admin')){
        return redirect('/admin-login');
       }
       
        $input =   $request->all();
        //$data = Input::all();
        extract($input); 

  
      if($new_arr != 'false'){
       
          DB::table('group_api_maping')->where('group_id', $group_id)->delete();

        foreach($new_arr as $value) { 

         
         //echo $value['api_id'];
            $results = DB::table('group_api_maping')->select('api_id','group_id')->where('group_id', $group_id)
               ->where('api_id', $value['api_id'])->get();

                $data=array('group_id'=>$group_id,
                    "api_id"=>$value['api_id'],
                    "get"=>$value['get_method'],
                    "post"=>$value['post_method'],
                    "delete"=>$value['delete_method'],
                    "put"=>$value['put_method'],
                );

           if(sizeof($results) == 0){

           
              DB::table('group_api_maping')->insert($data);

           }else{

              DB::table('group_api_maping')->where('group_id', $group_id)
               ->where('api_id', $value['api_id'])->update($data);
           }

        
        } 
       }else{

             DB::table('group_api_maping')->where('group_id', $group_id)->delete();
       } 
    
       
        //return redirect('api/dashboard');

 
    }

  public function manageUserPermission(Request $request)
    {
      if(!Session::get('admin')){
        return redirect('/admin-login');
       }
        $groups = DB::table('groups')->select('id','name')->orderBy('id', 'desc')->get();
        $users = DB::table('users')->select('id','name','email','group_id')->orderBy('id', 'desc')->get();

        return view('admin.ManageUserPermission')->with(['groups'=>$groups,'users'=>$users]);

 
    } 

  public function assignGroup(Request $request)
    {  
      if(!Session::get('admin')){
        return redirect('/admin-login');
       }
        
        if(!$request->input('group_id')){
              DB::update('update users set group_id = ? where id = ?',['',$request->input('user_id')]);
        }else{
             DB::update('update users set group_id = ? where id = ?',[implode(',',$request->input('group_id')),$request->input('user_id')]);
        }
       
        return redirect('/manage-user-permission');


 
    }

  public function getassignedgroups(Request $request)
    {

      if(!Session::get('admin')){
        return redirect('/admin-login');
       }
       $input =   $request->all();
       //$data = Input::all();
       extract($input); 
       $results = DB::select('select * from group_api_maping where group_id = ?', [$group_id]);

        return response()
          ->json(['results' => $results]);



 
    }

   public function  logout(){

         Session::forget('admin');
         Session::forget('marketing');
         return redirect('/admin-login');
   }


   public function automatedEmails()
   {

    return view('admin.AutomatedEmails');


   }



   public function profile(Request $request)
    {

      if(!Session::get('admin')){
        return redirect('/admin-login');
       }

        return view('admin.EditProfile'); 

    }


    public function editProfile(Request $request)
    {


      if(!Session::get('admin')){
        return redirect('/admin-login');
       }


       $validator = Validator::make($request->all(), [
        "username"=>"required",
        "old_password"=>"required",
        "new_password"=>"required"
       ]);
    

    if ($validator->fails()) {
        
        $allErrors = $validator->errors()->all();
        return redirect()->back()->with('error', $allErrors[0]);
    }
        
      $results = DB::table('admin_login')->select('username','password')->where('username', $request->input('username'))->where('password', md5($request->input('old_password')))->get();

      //print_r($results);

      if(sizeof($results) != 0){
 
        DB::update('update admin_login set password = ? where username = ?',[md5($request->input('new_password')), $request->input('username')]);

        return redirect()->back()->with('message', 'Profile saved successfully!');

      }
      else
      {

        return redirect()->back()->with('error', 'Admin Profile Update Failed!');


      }  
         
      //return redirect()->back()->with('message', 'Profile saved successfully!');


    }



    public function s3Public(Request $request)
    {

      if(!Session::get('admin')){
        return redirect('/admin-login');
       }

        return view('admin.EditS3Public'); 

    }


    public function editS3Public(Request $request)
    {

      if(!Session::get('admin')){
        return redirect('/admin-login');
       }


       $validator = Validator::make($request->all(), [
        "folder"=>"required"
       ]);
    

      if ($validator->fails()) {
          
          $allErrors = $validator->errors()->all();
          return redirect()->back()->with('error', $allErrors[0]);
      }



      $cmd = "AWS_ACCESS_KEY_ID=".env("S3_ACCESSKEY")." AWS_SECRET_ACCESS_KEY=".env("S3_SECRETKEY")." ".env("AWS_CLI")." s3 ls s3://".env("S3_MEDIA_BUCKET")."/".$request->input('folder')." --recursive | awk '{cmd=\"AWS_ACCESS_KEY_ID=".env("S3_ACCESSKEY")." AWS_SECRET_ACCESS_KEY=".env("S3_SECRETKEY")." ".env("AWS_CLI")." s3api put-object-acl --acl public-read --bucket ".env("S3_MEDIA_BUCKET")." --key \"$4;system(cmd)}'";
      exec($cmd." 2>&1", $out);

      //echo $cmd;
      //print_r($out); die;

      return redirect()->back()->with('message', 'AWS S3 Folder '.$request->input('folder').' made public successfully!');


    }  


   
}