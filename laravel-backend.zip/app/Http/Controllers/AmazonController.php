<?php

namespace App\Http\Controllers;

use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use App\Http\Requests;
use DB;
use Session;
use Illuminate\Support\Facades\Validator;


class AmazonController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    

    public function handleBounceOrComplaint(Request $request)
    {
        
        $data = $request->json()->all();

        file_put_contents(storage_path()."/logs/response.txt",print_r($data,true), FILE_APPEND);

        if($request->json('Type') == 'SubscriptionConfirmation')
        {

            $curl = curl_init();

            $headers[] = 'Accept: application/json';
            $headers[] = 'Content-Type: application/json';
            $headers[] = 'Content-length: 0';

            curl_setopt_array($curl, array(
            CURLOPT_URL => $request->json('SubscribeURL'),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => $headers,
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);

            curl_close($curl);


        }

        


        if($request->json('Type') == 'Notification'){

            $message = json_decode($request->json('Message'), true);

            switch($message['notificationType']){
             case 'Bounce':
               $bounce = $message['bounce'];
               foreach ($bounce['bouncedRecipients'] as $bouncedRecipient){
                 $emailAddress = $bouncedRecipient['emailAddress'];

                 $this->logEmail($emailAddress, "b");                 
                 
               }
               break;

               case 'Complaint':
               $complaint = $message['complaint'];
               foreach($complaint['complainedRecipients'] as $complainedRecipient){
                 $emailAddress = $complainedRecipient['emailAddress'];
                 
                 $this->logEmail($emailAddress, "c");
                 
               }
               break;

               case 'Delivery':
               // Do Nothing
               break;

               default:
               // Do Nothing
               break;

             }
           }



    }

    
    public function logEmail($email, $emailType)
    {


                /* Check if email already sent or not */    
                $logs = "SELECT id from `ses_sns_email_list` where userId='".trim($email)."'";

                $sent = DB::select(DB::raw($logs));


                if(sizeof($sent)<=0)
                {


                  $logs = "INSERT INTO `ses_sns_email_list` (`id`, `userId`, `emailType`, `emailDate`) VALUES (NULL, '".trim($email)."', '".$emailType."', now())";

                  DB::select(DB::raw($logs));


                } 



    }  
      


     
}
