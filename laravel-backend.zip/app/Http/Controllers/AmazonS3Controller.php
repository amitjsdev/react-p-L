<?php

namespace App\Http\Controllers;
use AWS;
use Aws\Common\Exception\MultipartUploadException;
use Aws\S3\MultipartUploader;
use Aws\S3\S3Client;
use Illuminate\Support\Facades\Log;
use App\SignedUrl;
use Illuminate\Http\Request;
use App\QuizAttemptLog;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
class AmazonS3Controller extends Controller
{

    public function s3Test(){
        $bucket = 'langappnew';
        $keyname = 'lkm/';
        $s3 = AWS::createClient('s3');
        $fileName ='lk.txt';


    //     return response()->json($result);
    $response = $s3->createMultipartUpload(array(
        'Bucket' => $bucket,
        'Key' => $keyname.'/'.$fileName
    ));

    $uploadId = $response['UploadId'];
    $part_no =2;

    // $signed_url = $s3->generatePresignedUrl(array(
    //     'ClientMethod' =>'upload_part',
    //     'Params' => [
    //        'Bucket'=> $bucket,
    //        'Key'=>  $keyname.'/'.$fileName,
    //        'UploadId'=> $uploadId,
    //        'PartNumber'=> $part_no
    //     ]
    //     ));
      $s3Client = AWS::createClient('s3');
$cmd = $s3Client->getCommand('UploadPart', [
    'Bucket'=> $bucket,
    'Key'=>  $keyname.'/'.$fileName,
    'UploadId'=> $uploadId,
     'PartNumber'=> $part_no,
     'Body' => '',
]);

$request = $s3Client->createPresignedRequest($cmd, '+60 minutes');



// // Get the actual presigned-url
$presignedUrl = (string)$request->getUri();
$isCompleted =$s3Client->completeMultipartUpload([
    'Bucket'   => $bucket,
    'Key'=>  $keyname.'/'.$fileName,
    'UploadId' => $uploadId,
]);
//    $isAborted =$s3Client->abortMultipartUpload([
//     'Bucket'   => $bucket,
//     'Key'=>  $keyname.'/'.$fileName,
//     'UploadId' => $uploadId,
// ]);
     echo '<pre>';

        var_dump($isAborted);
        // var_dump($presignedUrl);
        // var_dump($request);
        die;
        return response()->json($uploadId);
       // $listMultipartUpload =$s3Client->listMultipartUploads([
//         'Bucket'   => $bucket,
//     ]);
    }
}
