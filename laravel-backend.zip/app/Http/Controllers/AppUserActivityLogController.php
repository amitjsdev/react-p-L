<?php

namespace App\Http\Controllers;

use App\Events\UserActivitySave;
use App\UserActivityLog;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class AppUserActivityLogController extends Controller
{
    public function index(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'userId' => 'nullable',
            'moduleNo' => 'nullable',
            'routeNo' => 'nullable',
            'levelNo' => 'nullable',
            'lessonNo' => 'nullable',
        ]);


        if ($validator->fails()) {
            // TODO: Add the mail functionality
            $allErrors = $validator->errors()->all();
            error_logger($allErrors);
            return response()->json(["error" => $allErrors[0]], 412);
        }

        $userActivityLog = UserActivityLog::where('userId', $request->userId);

        if ($request->has('moduleNo')) {
            $userActivityLog->where('moduleNo', $request->moduleNo);
        }
        if ($request->has('lessonNo')) {
            $userActivityLog->where('lessonNo', $request->lessonNo);
        }
        if ($request->has('routeNo')) {
            $userActivityLog->where('routeNo', $request->routeNo);
        }
        if ($request->has('levelNo')) {
            $userActivityLog->where('levelNo', $request->levelNo);
        }

        $userActivityLog = $userActivityLog->orderBy('activityDateFrom', 'desc')->get();

        return response()->json($userActivityLog);
    }

    public function store(Request $request)
    {
        try {

            date_default_timezone_set("Europe/Madrid");

            $validator = Validator::make($request->all(), [
                "activityDateFrom" => "nullable", // nullable
                "totalQuestions" => "nullable", // nullable
                "activityType" => "required", // required
                "lessonNo" => "required", // required
                "levelNo" => "nullable", // nullable
                "moduleNo" => "required", // required
                "routeNo" => "required", // required
                "userId" => "required", // required
                "courseNumber" => "nullable", // nullable
            ]);

            if ($validator->fails()) {
                // TODO: Add the mail functionality
                $allErrors = $validator->errors()->all();
                error_logger($allErrors);
                return response()->json(["error" => $allErrors[0]], 412);
            }

            $res = app('App\Http\Controllers\AppUserSessionLogController')->update($request)->getData();
            $userActivityLog = UserActivityLog::create([
                "routeNo" => $request->routeNo ?? "-1",
                "activityDateFrom" => $request->activityDateFrom ?? "-1",
                "moduleNo" => $request->moduleNo ?? "-1",
                "lessonNo" => $request->lessonNo ?? "-1",
                "levelNo" => $request->levelNo ?? "-1",
                "levelNoFull" => $request->levelNoFull ?? "-1",
                "activityType" => $request->activityType ?? "-1",
                "userId" => $request->userId ?? "-1",
                "activityDateTo" => $request->activityDateTo ?? "-1",
                "totalQuestions" => $request->totalQuestions ?? "-1",
                "sessionId" => $request->sessionId ?? "-1",
                "courseNumber" => $request->courseNumber ?? "-1",
                "pointsScored" => $request->pointsScored ?? "-1",
                "Id" => $request->Id ?? "-1",
                "statusFlag" => $request->statusFlag ?? "-1",
                "totalTime" => $request->totalTime ?? "-1",
                "watchedTime" => $request->watchedTime ?? "-1",
            ]);

            //  fire the userActivityLogSaved event
            event(new UserActivitySave($userActivityLog));

            // update user loop status
            $numberOfLessonsDone = \App\UserActivityLog::where('userId', $request->userId)
                ->where('moduleNo', $request->moduleNo)
                ->distinct('moduleNo', 'routeNo', 'levelNo', 'lessonNo')
                ->count();
            if (userIsAheadOfTimeInModule($request->userId, $request->moduleNo, $request->courseNumber)) { // check if user is head of time in current module
                $newLoopStatus = 10; // 10 is for ahead of times
            } else {
                $newLoopStatus = 1;
                if ($numberOfLessonsDone > 3 && $numberOfLessonsDone <= 15) {
                    $newLoopStatus = 2;
                } else if ($numberOfLessonsDone > 15) {
                    $newLoopStatus = 3;
                }
            }
            DB::table('employeecourse')
                ->where('userId', $request->userId)
                ->where('courseNumber', $request->courseNumber)
                ->update(['loopStatus' => $newLoopStatus]);
            // update user loop status end

            activity_logger(['AppUserActivityLogController-log-Success', $request->all()]);
            return response()->json(["message" => "Data saved successfully"]);
        } catch (\Exception $e) {
            // TODO: Add the mail functionality
            error_logger(['AppUserActivityLogController-log-Error', $e->getMessage(), $request->all()]);
            return response()->json(["error" => $e->getMessage()]);
        }
    }
}
