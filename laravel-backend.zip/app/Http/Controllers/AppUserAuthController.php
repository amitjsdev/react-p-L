<?php

namespace App\Http\Controllers;

use App\User;
use App\AppUserToken;
use App\Employee;
use App\Events\UserLoggedIn;
use App\Events\UserRegistered;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Jobs\SendPush;
use App\PushCampaign;
use Faker\Provider\Uuid;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;

class AppUserAuthController extends Controller
{
    public function getDeatils(Request $request)
    {
        $userId= auth()->user()->email;
        $user = User::where('email', $userId)->orWhere('alternate_email', $userId)->first();
        if (empty($user)) {
            logCredentialsLoginAction($userId ?? "", $userId ?? "", "email does not exist!");
            return response()->json([
                "code" => "202",
                "message" => "Email or password isn't correct"
            ]);
        }
        
        $employee = $this->getEmp($userId);

        if (empty($employee)) {
            logCredentialsLoginAction($userId ?? "", $userId ?? "", "email isnt registered to any courses!");
            return response()->json([
                "code" => "201",
                "code1" => "1",
                "message" => "Email isn't registered for any courses."
            ]);
        }


        /* Update lastLoginDate on each login and activationDate only once */

        //$params = array("lastLoginDate" => date("Y-m-d H:i:s"));
        //$newRequest = new \Illuminate\Http\Request($params);
        //$res = app(\App\Http\Controllers\EmployeeController::class)->update($newRequest, strtolower($json->email));

        $currentModule = "";
        $levelOfLanguage = "";

        if ((int) $employee->CompanyCode === 0) {

            if ($request->currentModule) {
                $currentModule = ", `currentModule` = " . $request->currentModule;
            }

            $levelOfLanguage = "";

            if ($request->levelOfLanguage) {
                $levelOfLanguage = ", `levelOfLanguage` = '" . $request->levelOfLanguage . "'";
            }
        }

        /* Update lastLoginDate on each login  and activationDate only once */
        event(new UserLoggedIn(Employee::where('userId', strtolower($user->email))->first()));


        $q = "UPDATE `employee` SET `lastLoginDate` = '" . date("Y-m-d H:i:s") . "' " . $currentModule . $levelOfLanguage . " WHERE userId = '" . strtolower($user->email) . "'";
        $query = DB::select(DB::raw($q));

        $q = "select activationDate from `employee` where userId = '" . strtolower($user->email) . "'";
        $activation_date = DB::select(DB::raw($q));

        //print_r($activation_date);
        //echo $activation_date[0]->activationDate;

        if ($activation_date[0]->activationDate == "" || $activation_date[0]->activationDate == "0000-00-00 00:00:00" || $activation_date[0]->activationDate == NULL) {

            $q = "UPDATE `employee` SET `activationDate` = '" . date("Y-m-d H:i:s") . "' WHERE userId = '" . strtolower($user->email) . "'";
            $query = DB::select(DB::raw($q));
        }

        // $cohort =$this->getCohortOfUser($user->email);

        $dataList = "select DISTINCT cohorts.* from `employeecourse` JOIN courses ON employeecourse.courseNumber = courses.courseNumber JOIN cohorts ON courses.cohort_id = cohorts.id where userId = '" . strtolower($user->email) . "'";
        $cohortList = DB::select(DB::raw($dataList));
        $response = [
            'cohort'=>$cohortList,
            'firstName' => $employee->FirstName,
            'email'  => $user->email,
            'alternate_email'  => $user->alternate_email,
            'updatedAt'   => $user->updatedAt,
            'submittedAt'   => $user->submittedAt,
            'accesslevel'  => $user->accesslevel,
            'CompanyCode' => $employee->CompanyCode,
            'companyName' => $employee->company
        ];

        $response['token'] = $user->createToken('TapLingua')->accessToken;

        $response['acceptedGDPR'] = $employee->acceptedGDPR ?? "";

        reactivateUserIfNeeded($employee);

        logCredentialsLoginAction($userId ?? "", $userId ?? "");
        return response()->json($response);

    }
    public function signup(Request $request)
    {
        $json = json_decode($request->getContent());

        if (empty($json) || !isset($json->email)) {
            return response()->json([
                "message" => "Could not signup user because of validation errors."
            ]);
        }

        if (User::where('email', $json->email)->exists()) {
            return response()->json([
                "message" => "Email already exists. We aren't able to create an account"
            ]);
        }

        $user = User::create([
            'email' => strtolower($json->email),
            'fullname' => $json->fullname ?? '',
            'password' => time(),
            'token' => md5($json->email . time()),
            'uid' => uniqid(),
            'accesslevel' => $json->accesslevel ?? ''
        ]);

        // TODO: Add Email code here

        return response()->json([
            "message" => "Please check email for login password."
        ]);
    }


    public function getCohortOfUser ($userId) {

        $cohort_ids = \App\Course::join('employeecourse', 'courses.courseNumber', '=', 'employeecourse.courseNumber')
                ->whereNotNull('cohort_id')
                ->where('userId', $userId)
                ->pluck("cohort_id");
            $cohort_ids =$cohort_ids && count($cohort_ids) >0  ? $cohort_ids[0] :null;
            $cohort =\App\Cohort::find($cohort_ids);
            return $cohort;
    }

    public function login(Request $request)
    {

        $json = json_decode($request->getContent());

        if (empty($json) || !isset($json->email)) {
            logCredentialsLoginAction($json->email ?? "", $json->email ?? "", "email not provided!");
            return response()->json([
                "message" => "It looks like an error in cache. Please close the tab and try again."
            ]);
        }

        // check if is bypassing
        $emails = explode(";", $json->email); // 0 index has bypasser, 1 has the bypassee
        $isBypassing = false;
        $bypasser = null;
        // if ($emails[0] === 'santanu@taplingua.com' && count($emails) === 2) {
        //     // set bypassing to true
        //     $isBypassing = true;
        //     $bypasser = User::where('email', $emails[0])->orWhere('alternate_email', $emails[0])->first();
        //     // set the email id accordingly
        //     $json->email = $emails[1];
        // }
        // check if is bypassing end


        $user = User::where('email', $json->email)->orWhere('alternate_email', $json->email)->first();

        // print_r($user);

        if (empty($user)) {
            logCredentialsLoginAction($json->email ?? "", $json->email ?? "", "email does not exist!");
            return response()->json([
                "code" => "202",
                "message" => "Email or password isn't correct"
            ]);
        }
        
        if (!empty($json->password) && ($isBypassing ? Hash::check($json->password, $bypasser->password) : Hash::check($json->password, $user->password))) {

            $employee = $this->getEmp($user->email);

            if (empty($employee)) {
                logCredentialsLoginAction($json->email ?? "", $json->email ?? "", "email isnt registered to any courses!");
                return response()->json([
                    "code" => "201",
                    "code1" => "1",
                    "message" => "Email isn't registered for any courses."
                ]);
            }


            /* Update lastLoginDate on each login and activationDate only once */

            //$params = array("lastLoginDate" => date("Y-m-d H:i:s"));
            //$newRequest = new \Illuminate\Http\Request($params);
            //$res = app(\App\Http\Controllers\EmployeeController::class)->update($newRequest, strtolower($json->email));

            $currentModule = "";
            $levelOfLanguage = "";

            if ((int) $employee->CompanyCode === 0) {

                if ($request->currentModule) {
                    $currentModule = ", `currentModule` = " . $request->currentModule;
                }

                $levelOfLanguage = "";

                if ($request->levelOfLanguage) {
                    $levelOfLanguage = ", `levelOfLanguage` = '" . $request->levelOfLanguage . "'";
                }
            }

            /* Update lastLoginDate on each login  and activationDate only once */
            event(new UserLoggedIn(Employee::where('userId', strtolower($user->email))->first()));


            $q = "UPDATE `employee` SET `lastLoginDate` = '" . date("Y-m-d H:i:s") . "' " . $currentModule . $levelOfLanguage . " WHERE userId = '" . strtolower($user->email) . "'";
            $query = DB::select(DB::raw($q));

            $q = "select activationDate from `employee` where userId = '" . strtolower($user->email) . "'";
            $activation_date = DB::select(DB::raw($q));

            //print_r($activation_date);
            //echo $activation_date[0]->activationDate;

            if ($activation_date[0]->activationDate == "" || $activation_date[0]->activationDate == "0000-00-00 00:00:00" || $activation_date[0]->activationDate == NULL) {

                $q = "UPDATE `employee` SET `activationDate` = '" . date("Y-m-d H:i:s") . "' WHERE userId = '" . strtolower($user->email) . "'";
                $query = DB::select(DB::raw($q));
            }

            // $cohort =$this->getCohortOfUser($user->email);

            $dataList = "select DISTINCT cohorts.* from `employeecourse` JOIN courses ON employeecourse.courseNumber = courses.courseNumber JOIN cohorts ON courses.cohort_id = cohorts.id where userId = '" . strtolower($user->email) . "' and archived=0";
            $cohortList = DB::select(DB::raw($dataList));
            if(!$cohortList || $cohortList && count($cohortList)==0){
                return response()->json([
                    "code" => "201",
                    "code1" => "1",
                    "codeMsg" => "No cohort or cohort archived",
                    "message" => "Email isn't registered for any courses."
                ]);
            }
            $response = [
                'cohort'=>$cohortList,
                'firstName' => $employee->FirstName,
                'email'  => $user->email,
                'alternate_email'  => $user->alternate_email,
                'updatedAt'   => $user->updatedAt,
                'submittedAt'   => $user->submittedAt,
                'accesslevel'  => $user->accesslevel,
                'CompanyCode' => $employee->CompanyCode,
                'companyName' => $employee->company
            ];

            $response['token'] = $user->createToken('TapLingua')->accessToken;

            $response['acceptedGDPR'] = $employee->acceptedGDPR ?? "";

            reactivateUserIfNeeded($employee);

            logCredentialsLoginAction($json->email ?? "", $json->email ?? "");
            return response()->json($response);

        } else {
            logCredentialsLoginAction($request->email, $request->password, "email and password not valid!");
            return response()->json([
                "message" => "Email & Password is not valid."
            ]);
        }
    }

    public function logout(Request $request)
    {
        $request->user()->token()->revoke();
        return response()->json(["message" => "You are logged out."]);
    }

    public function profile(Request $request)
    {
        $user = $request->user();
        $userObj = $user->toArray();
        $userObj["fcmToken"] = $user->employee->fcmToken;

        return response()->json($userObj);
    }

    public function create(Request $request)
    {

        $json = json_decode($request->getContent());


        if (empty($json) || !isset($json->email) || !isset($json->password)) {
            return response()->json([
                "message" => "Could not signup user because of validation errors."
            ]);
        }

        $user = User::where('email', $json->email)->first();

        if ($user) {
            return response()->json([
                "message" => "There is an existing account already with the email. If you have forgotten the password, please reset your password"
            ]);
        }

        $user = User::create([
            'email' => strtolower($json->email),
            'fullname' => $json->fullname ?? '',
            'password' => bcrypt($json->password),
            'token' => md5($json->email . time()),
            'uid' => uniqid(),
            'accesslevel' => $json->accesslevel ?? ''
        ]);


        /* when a randomuser is creating an account in our system, createUser, If the user has not entry in the EMployee table, we create a record for the user with company code 0 */

        if ($json->fullname != "") {

            $Name = explode(" ", $json->fullname);
            $FirstName = $Name[0] ?? '';
            $LastName = $Name[1] ?? '';
        } else {

            $FirstName = "";
            $LastName = "";
        }

        $employee = Employee::where('userId', $json->email)->first();

        // if employee is not there, create it
        if (!$employee) {
            $params = array("userId" => strtolower($json->email), "CompanyCode" => "0", "FirstName" => $FirstName, "LastName" => $LastName);

            $newRequest = new \Illuminate\Http\Request($params);

            $res = app(\App\Http\Controllers\EmployeeController::class)->store($newRequest);
        }

        // add user to registered_users segment
        addUserToSegment('registered_users', $json->email);

        // try employee if not exist and scheduling push a day after at 8 AM
        // need to have push campaign with campaign_id badge-streak in the system
        try {
            // check if employee is there
            $employee = Employee::where('userId', $json->email)->first();
            // if not, create it
            if (!$employee) {
                $employee = Employee::create([
                    'CompanyCode' => 0,
                    'userId' => $json->email,
                    'Location' => 'Unknown',
                    'accountCreationDate' => date("Y-m-d H:i:s"), //// save system date
                    'FirstName' => $FirstName,
                    'LastName' => $LastName,
                    'timezone' => $json->timezone,
                    'levelOfLanguage' => isset($json->levelOfLanguage) ? $json->levelOfLanguage : null,
                    'currentModule' => isset($json->currentModule) ? $json->currentModule : 3
                ]);
            }

            // add details here
            $employee->levelOfLanguage = isset($json->levelOfLanguage) ? $json->levelOfLanguage : null;
            $employee->currentModule = isset($json->currentModule) ? $json->currentModule : 3;
            $employee->save();

            event(new UserRegistered($employee));
            // schedule a push the user to return back tomorrow
            // get campaign for badge-streak
            $pushCampaign = PushCampaign::where('campaign_id', 'badge-streak')->first();
            // FIXME: disabled-all-push-except-flash
            // SendPush::dispatch($json->email, [
            //     "title" => $pushCampaign->title,
            //     "message" => $pushCampaign->message
            // ])->delay(now()->timezone($employee->timezone)->next("08:00")); // send it at 8 AM tomorrow
        } catch (\Exception $e) {
            \Log::error('error at user/create  employee creation or sending push', [$e]);
        }

        //return $res;

        /* when a randomuser is creating an account in our system, createUser, If the user has not entry in the EMployee table, we create a record for the user with company code 0 */



        return response()->json([
            "message" => "Email registered successfully."
        ]);
    }

    /**
     * This function creates a new guest user and identifies it by uuid
     *
     * @param Request $request
     * @return void
     */
    public function guest(Request $request)
    {
        // create uuid
        $uuid = Uuid::uuid();
        // create user
        $user = User::create([
            'email' => strtolower($uuid),
            'fullname' => 'Guest',
            'password' => 'guest-login',
            'token' => md5($uuid . time()),
            'uid' => uniqid(),
            'accesslevel' => 0
        ]);
        $isNewUser = true;
        // create employee
        $employee = Employee::create([
            'CompanyCode' => 0,
            'userId' => $user->email,
            'Location' => 'Unknown',
            'accountCreationDate' => date("Y-m-d H:i:s"), //// save system date
            'FirstName' => "Guest",
            'LastName' => "family_name",
            'lastLoginDate' => date("Y-m-d H:i:s"),
        ]);

        event(new UserRegistered($employee));

        // create response
        $response = [
            'firstName' => $employee->FirstName,
            'email'  => $user->email,
            'updatedAt'   => $user->updatedAt,
            'submittedAt'   => $user->submittedAt,
            'accesslevel'  => $user->accesslevel,
            'CompanyCode' => $employee->CompanyCode,
            'companyName' => $employee->company,
            'isNewUser' => $isNewUser
        ];

        $response['token'] = $user->createToken('TapLingua')->accessToken;

        $response['acceptedGDPR'] = $employee->acceptedGDPR ?? "";

        return response()->json($response);
    }


    /**
     * THis function registers an email to a guest user by token
     *
     * @param Request $request
     * @return void
     */
    public function guestRegister(Request $request)
    {
        $request->validate([
            "email" => "required|email|unique:userLogin,alternate_email|unique:userLogin,email",
            "FirstName" => "string",
            "LastName" => "string",
            "password" => "required|string"
        ]);

        // get user
        $user = $request->user();

        // check if user has already registered
        if ($user->alternate_email || $user->password !== "guest-login") {
            return response()->json([
                "message" => "User already registered"
            ]);
        }

        // update alternate email
        $user->alternate_email = $request->email;

        // update name if available
        if ($request->has("FirstName") || $request->has("LastName")) {
            $user->fullName = trim($request->FirstName . " " . $request->LastName);
        }

        // update password
        $user->password = bcrypt($request->password);

        // save user
        $user->save();

        // update employee data
        $employee = $user->employee;

        if ($request->has("FirstName")) {
            $employee->FirstName = $request->FirstName;
        }

        if ($request->has("LastName")) {
            $employee->LastName = $request->LastName;
        }

        $employee->save();

        return response()->json([
            "message" => "User registered!"
        ]);
    }

    public function passwordReset(Request $request)
    {

        $json = json_decode($request->getContent());

        if (empty($json) || !isset($json->email)) {
            return response()->json([
                "message" => "Validation errors."
            ]);
        } else {
            $cohort =$this->getCohortOfUser($json->email);
            if($cohort && $cohort->type_id ==2 && $cohort->social_login_optional == true){
                return response()->json([
                    "code" => "202",
                    "message" => "Please login  with your Google or Facebook account.",
                ]);
            }
            $user = User::where('email', $json->email)->first();

            if (empty($user)) {
                return response()->json([
                    "message" => "Email or password isn't correct"
                ]);
            }

            $langCode = isset($json->lang) ? $json->lang : "EN";
            $urlToken = encrypt(['email' => $user->email, 'timestamp' => (time() + (60 * 60 * 3))]);
            $user->token = md5($urlToken);
            $user->save();

            $baseUrl = url(route('password-reset-view'));

            $resetLink = "{$baseUrl}?token={$urlToken}&lang={$langCode}";

            $subject = [
                "EN" => "Taplingua password reset request",
                "ES" => "Contraseña de Taplingua API",
                "PT" =>  "Senha da API Taplingua",
                "FR" => "Mot de passe de l'API Taplingua"
            ];

            $body = [
                "EN" => 'Hi ' . $user->fullname . ',<br/>
                <p>We have received a request to reset your password for the Taplingua App. Please tap on the link below to change your password.</p>
                <a href="' . $resetLink . '">Click here to set a new password.</a>
                <p>If you face any problems, give us a holler at info@taplingua.com</p>
                <br/>
                <img src="' . url("/images/polly_email.gif") . '" width="200px" />
                <br/>
                <p>
                    Thanks<br />
                    Taplingua Team
                </p>',
                "ES" => "Por favor, reinicie la contraseña para Taplingua API<br><br>{$resetLink}<br><br>Gracias",
                "PT" => "Por favor, redefina a senha para a API Taplingua<br><br>{$resetLink}<br><br>Obrigada",
                "FR" => "Veuillez réinitialiser le mot de passe pour l'API Taplingua<br><br>{$resetLink}<br><br>Merci"
            ];
            sendEmail($user->email, $body[$langCode]);

            return response()->json(["message" => "Please check email for reset link."]);
        }
    }

    public function passwordResetView(Request $request)
    {
        try {
            $payload = decrypt($request->token);
            $md5 = md5($request->token);

            $user = User::where('email', $payload['email'])->firstOrFail();

            $messages =  session()->get('messages') ?? [];

            if ($user->token !== $md5) {
                $messages[] = 'Invalid token checksum';
            }
            if (time() > $payload['timestamp']) {
                $messages[] = 'Token expired!';
            }
            return view('app.password-reset', [
                'token' => $request->token,
                'email' => $user->email,
                'messages' => $messages
            ]);
        } catch (\Exception $e) {
            if ($e instanceof ModelNotFoundException) {
                return abort(404, "User not found!");
            }
            return abort(400, $e->getMessage());
        }
    }

    public function passwordSubmit(Request $request)
    {
        try {
            $payload = decrypt($request->token);
        } catch (\Exception $e) {
            session()->flash('messages', ['Token Invalid']);
            return redirect()->back();
        }
        $md5 = md5($request->token);

        $user = User::where('email', $payload['email'])->firstOrFail();

        $messages = [];

        if ($user->token !== $md5) {
            $messages[] = 'Invalid token checksum';
        }
        if (time() > $payload['timestamp']) {
            $messages[] = 'Token expired!';
        }

        if (count($messages) > 0) {
            session()->flash('messages', $messages);
            return redirect()->back();
        }

        $request->validate([
            'password' => 'required|confirmed|string'
        ]);

        $user->password = bcrypt($request->password);
        $user->token = "";
        foreach ($user->tokens as $token) {
            $token->revoke();
        }
        $user->save();

        session()->flash('success', 'Password changed successfully!');
        return redirect()->back();
    }

    /**
     * Request OTP
     *
     * @param Request $request
     * @return void
     */
    public function requestOTP(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'mobile' => 'required|digits:10|exists:employee,Mobile'
        ]);

        if ($validator->fails()) {
            logOTPLoginAction($request->mobile, "", "request - user not found!");
            return response()->json([
                'message' => 'No account was found with that mobile number. Please send a WhatsApp to 9007885217 for more information!',
                'code' => 400
            ]);
        }

        // get employee
        $employee = Employee::where('Mobile', $request->mobile)->first();

        // get user for employee
        $user = $employee->user;

        if (!$user) {
            logOTPLoginAction($request->mobile, "", "request - user not found!");
            return response()->json([
                'message' => 'No account was found with that mobile number. Please send a WhatsApp to 9007885217 for more information!',
                'code' => 400
            ]);
        }

        // generate otp
        $user->otp = rand(1000, 9999);
        $user->otp_valid_until = now()->addMinutes(30);
        $user->save();

        // send the OTP
        sendSMS("+91" . $request->mobile, "Hi " . $employee->FirstName . "
            \nYour OTP for logging in Taplingua is " . $user->otp . ".
            \nNz1T/BqFDLY");

        logOTPLoginAction($request->mobile, "", "request - none");
        return response()->json([
            'message' => 'OTP sent to ' . $request->mobile,
            'code' => 200,
        ]);
    }

    /**
     * Verify OTP sent
     *
     * @param Request $request
     * @return void
     */
    public function verifyOTP(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'mobile' => 'required|digits:10|exists:employee,Mobile'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'message' => 'No account was found with that mobile number. Please send a WhatsApp to 9007885217 for more information!',
                'code' => 400
            ]);
        }

        // get employee
        $employee = Employee::where('Mobile', $request->mobile)->first();

        // get user for employee
        $user = $employee->user;

        if (!$user) {
            logOTPLoginAction($request->mobile, $request->otp, "user not found!");
            return response()->json([
                'message' => 'No account was found with that mobile number. Please send a WhatsApp to 9007885217 for more information!',
                'code' => 400
            ]);
        }

        // check if otp matches
        if ($user->otp !== $request->otp) {
            logOTPLoginAction($request->mobile, $request->otp, "otp incorrect!");
            return response()->json([
                'message' => 'OTP Incorrect!',
                'code' => 400
            ]);
        }

        // check if otp not expired
        if (now()->gte($user->otp_valid_until)) {
            logOTPLoginAction($request->mobile, $request->otp, "otp expired!");
            return response()->json([
                'message' => 'OTP expired, please try again!',
                'code' => 400
            ]);
        }

        // otp verified, send response
        $user->otp = null;
        $user->otp_valid_until = null;
        $user->save();

        /* Update lastLoginDate on each login  and activationDate only once */
        event(new UserLoggedIn($employee));

        $employee->lastLoginDate = date("Y-m-d H:i:s");
        $employee->save();

        $response = [
            'firstName' => $employee->FirstName,
            'email'  => $user->email,
            'alternate_email'  => $user->alternate_email,
            'updatedAt'   => $user->updatedAt,
            'submittedAt'   => $user->submittedAt,
            'accesslevel'  => $user->accesslevel,
            'CompanyCode' => $employee->CompanyCode,
            'companyName' => $employee->company,
            'token' => $user->createToken('TapLingua')->accessToken,
            'acceptedGDPR' => $employee->acceptedGDPR ?? ""
        ];

        logOTPLoginAction($request->mobile, $request->otp);
        return response()->json([
            'message' => 'user logged in!',
            'code' => 200,
            "user" => $response
        ]);
    }

    public function SetProfileImage(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'key' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json($validator);
        }
        $id = \Auth::user()->email;
        $isSaved = Employee::where('userId', $id)->update(['profile_image' => $request->post('key')]);
        return response()->json(['status' => $isSaved]);
    }
    public function profileImageUploadUrl(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'type' => 'required ',
        ]);

        if ($validator->fails()) {
            return response()->json($validator);
        }
        // // create the signed URL
        // `https://qnoa4x8gbc.execute-api.us-east-1.amazonaws.com/upload?fileName=${data.name}&path=profile-pics&fileContentType=${data.tyep}`,
        $signedUrlResponse = Http::get('https://qnoa4x8gbc.execute-api.us-east-1.amazonaws.com/upload?' . http_build_query([

            'fileName' => $request->post('name'),
            'path' => 'profile-pics',
            'fileContentType' => $request->post('type'),
        ]));

        $signedUrlResponseJSON = $signedUrlResponse->json();

        if (is_array($signedUrlResponseJSON) && isset($signedUrlResponseJSON['Key'])) {

            return response()->json([
                'status' => 1,
                'data' => $signedUrlResponseJSON
            ], 201);
        } else {
            return response()->json([
                'message' => "Could not generated signed URL!",
                'response' => $signedUrlResponseJSON
            ], 400);
        }
    }

    public function getUserAccessLevel(Request $request, $email)
    {
        $user = \App\User::where('email', $email)->first();

        if ($user) {
            return response()->json([
                "accessLevel" => $user->accesslevel
            ]);
        } else {
            return response()->json([
                "message" => "User not found!"
            ], 404);
        }
    }


    public function makeUserLevel3(Request $request, $email)
    {

        // get authenticated user
        $authEmployee = \App\Employee::where('userId', auth()->user()->email)->first();
        if (!$authEmployee) {
            return response()->json([
                "message" => "Your Employee account not found!"
            ], 400);
        }
        $authUser = \App\User::where('email', $authEmployee->userId)->first();
        if (!$authUser || ($authUser->accesslevel != "3" && $authUser->accesslevel != "1")) {
            return response()->json([
                "message" => "Your account is not admin!"
            ], 400);
        }

        $user = \App\User::where('email', $email)
            ->first();

        if (!$user) {
            return response()->json([
                "message" => "Selected account not found!"
            ], 400);
        }

        // update the access level
        $user->accesslevel = 3;
        $user->save();

        return response()->json([
            "accessLevel" => $user->accesslevel
        ]);
    }

    private function getEmp($email)
    {
        return Employee::where('UserId', $email)->first();
    }
}
