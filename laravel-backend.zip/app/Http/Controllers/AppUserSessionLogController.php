<?php

namespace App\Http\Controllers;

use App\UserActivityLog;
use App\UserSessionLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class AppUserSessionLogController extends Controller
{
    public function index(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'userId' => 'required',
            'sessionId' => 'nullable'
        ]);

        if ($validator->fails()) {
            // TODO: Add the mail functionality
            $allErrors = $validator->errors()->all();
            error_logger($allErrors);
            return response()->json(["error" => $allErrors[0]], 412);
        }

        extract($validator->validated());

        $userSessionLog = UserSessionLog::where('userId', $userId);
        if ($request->has('sessionId')) {
            $userSessionLog->where('sessionId', $sessionId);
        }
        $userSessionLog = $userSessionLog->orderBy('i_d', 'desc')->get();

        return response()->json($userSessionLog);
    }
    public function store(Request $request)
    {

        date_default_timezone_set("Europe/Madrid");

        $validator = Validator::make($request->all(), [
            'userId' => 'required',
            'moduleNo' => 'required',
            'routeNo' => 'required',
            'routeNo' => 'required',
            'activityType' => 'required',
            'activityDateFrom' => 'required',
        ]);

        if ($validator->fails()) {
            // TODO: Add the mail functionality
            $allErrors = $validator->errors()->all();
            error_logger($allErrors);
            return response()->json(["error" => $allErrors[0]], 412);
        }

        $data = $request->only([
            "activityDateFrom",
            "activityDateTo",
            "activityType",
            "lessonNo",
            "levelNo",
            "moduleNo",
            "routeNo",
            "userId",
            "courseNumber",
        ]);

        $activityDateFrom = str_replace('/', '-', $data['activityDateFrom']);
        $activityDateFrom = date("Y-m-d H:i:s", strtotime($activityDateFrom));
        $data['activityDateFrom'] = $activityDateFrom;

        if ($data['activityDateTo'] != "") {
            $activityDateTo = str_replace('/', '-', $data['activityDateTo']);
            $activityDateTo = date("Y-m-d H:i:s", strtotime($activityDateTo));
            $data['activityDateTo'] = $activityDateTo;
        }
        /* Set startTime for usersessionlog_api as activityDateFrom  */
        $startTime = $data['activityDateFrom'];

        /* Set endTime for usersessionlog_api as activityDateTo OR activityDateFrom */
        if ($data['activityDateTo'] != "")
            $endTime = date("Y-m-d H:i:s", strtotime($data['activityDateTo'] . " +2 minutes"));  // 120 SECS
        else
            $endTime = date("Y-m-d H:i:s", strtotime($data['activityDateFrom'] . " +2 minutes"));  // 120 SECS 

        /* Using adddate for checking sessionId Expiry  */
        if (isset($data['adddate']) && $data['adddate'] != "") {
            $adddate = $data['adddate'];
        } else {
            $adddate = date("Y-m-d H:i:s");
        }

        if (isset($data['ipAddress']) && $data['ipAddress'] != "") {
            $ipAddress = $data['ipAddress'];
        } else {
            $ipAddress = "";
        }

        try {

            $interval = 5;

            /* LLP Listen, Learn, Play interval for sessionId Expire */
            if (intval($data['activityType']) == 1) {
                $interval = 5;
            } else {
                $interval = 8;
            }

            $userSessionLog = UserSessionLog::select('sessionId')
                ->where('userId', $data['userId'])
                ->where('adddate', ">", "date_sub(now(), interval $interval minute)");

            if ($request->has('moduleNo')) {
                $userSessionLog->where('moduleNo', $data['moduleNo']);
            }

            if ($request->has('routeNo')) {
                $userSessionLog->where('routeNo', $data['routeNo']);
            }

            $userSessionLog = $userSessionLog->first();

            if ($userSessionLog) {
                $sessionId = $userSessionLog->sessionId;
                $isInserted = false;
            } else {
                $sessionId = getGUID();
                $isInserted = true;
            }

            if ($isInserted) {
                UserSessionLog::create([
                    'userId' => $data['userId'],
                    'moduleNo' => $data['moduleNo'],
                    'routeNo' => $data['routeNo'],
                    'sessionId' => $sessionId,
                    'startTime' => $startTime,
                    'endTime' => $endTime,
                    'adddate' => $adddate,
                    'ipAddress' => $ipAddress,
                ]);
            } else {
                if (!empty($data['routeNo']) && !empty($data['moduleNo'])) {
                    $userSessionLog = UserSessionLog::where('sessionId', $sessionId)
                        ->where('moduleNo', $data['moduleNo'])
                        ->where('routeNo', $data['routeNo'])->first();
                    if ($userSessionLog) {
                        $userSessionLog->update([
                            'endTime' => $endTime,
                            'adddate' => $adddate
                        ]);
                    }
                } else {
                    $userSessionLog = UserSessionLog::where('sessionId', $sessionId)->first();
                    if ($userSessionLog) {
                        $userSessionLog->update([
                            'endTime' => $endTime,
                            'adddate' => $adddate
                        ]);
                    }
                }
            }

            $userActivityLog = UserActivityLog::create([
                'routeNo' => $data['routeNo'] ?? "",
                'activityDateFrom' => $data['activityDateFrom'] ?? "",
                'moduleNo' => $data['moduleNo'] ?? "",
                'lessonNo' => $data['lessonNo'] ?? "",
                'levelNo' => $data['levelNo'] ?? "",
                'levelNoFull' => $data['levelNoFull'] ?? "",
                'activityType' => $data['activityType'] ?? "",
                'userId' => $data['userId'] ?? "",
                'activityDateTo' => $data['activityDateTo'] ?? "",
                'totalQuestions' => $data['totalQuestions'] ?? "",
                'sessionId' => $sessionId,
                'courseNumber' => $data['courseNumber'] ?? "",
                'pointsScored' => $data['pointsScored'] ?? "",
                'Id' => $data['Id'] ?? "",
                'statusFlag' => $data['statusFlag'] ?? "",
                'totalTime' => $data['totalTime'] ?? "",
                'watchedTime' => $data['watchedTime'] ?? "",
            ]);

            activity_logger(['AppUserSessionLogController-success', $data]);
            return response()->json(["sessionId" => $sessionId, "message" => "Data saved successfully"]);
        } catch (\Exception $e) {
            error_logger(['AppUserSessionLogController-Error', $e->getMessage(), $data]);
            return response()->json(["error" => $e->getMessage()]);
        }
    }

    public function update(Request $request)
    {
        date_default_timezone_set("Europe/Madrid");
        if (!$request->has('sessionId')) {
            return response()->json(["error" => "sessionId is required"], 412);
        }

        $sessionId = $request->sessionId;

        if ($request->has('endTime')) {
            $endTime = $request->endTime;
        } else {
            $endTime = date("Y-m-d H:i:s");
        }

        try {
            $userSessionLog = UserSessionLog::where('sessionId', $sessionId)->firstOrFail();
            if ($request->has('routeNo')) {
                $userSessionLog->routeNo = $request->routeNo;
                if ($request->has('moduleNo')) {
                    $userSessionLog->moduleNo = $request->moduleNo;
                }
                if ($request->has('ipAddress')) {
                    $userSessionLog->ipAddress = $request->ipAddress;
                }
                if ($request->has('routeNo')) {
                    $userSessionLog->routeNo = $request->routeNo;
                }
            }
            $userSessionLog->endTime = $endTime;
            $userSessionLog->save();

            return response()->json(["message" => "Data updated successfully"]);
        } catch (\Exception $e) {
            return response()->json(["error" => $e->getMessage()]);
        }
    }
}
