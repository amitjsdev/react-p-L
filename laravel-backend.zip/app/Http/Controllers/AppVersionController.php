<?php

namespace App\Http\Controllers;

use Illuminate\Database\Eloquent\ModelNotFoundException;
use App\AppVersion;
use Illuminate\Http\Request;

use DB;
use Session;
use Validator;

class AppVersionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        
        
        if($request->input('androidVersion')!="")
        {
        

        
        $sql = "SELECT * FROM appversion WHERE OS='android'";        
        $query = DB::select(DB::raw($sql));

        
        $results = array();
        
        foreach ($query as $key => $value) {
            
            $results = array("androidVersion" => array("minimumBuildVersion" => $value->minimumBuildVersion, 
                                                    "minimumAppVersion" => $value->minimumAppVersion, 
                                                    "recommendedBuildVersion" => $value->recommendedBuildVersion, 
                                                    "recommendedAppVersion" => $value->recommendedAppVersion),
                            "updateMessage" => array("minimumUpdatesMessage" => $value->minimumUpdatesMessage, 
                                                    "recommendedUpdatesMessage" => $value->recommendedUpdatesMessage));

        }


        return response()->json($results);


        }


        if($request->input('iOSVersion')!="")
        {
        

        
        $sql = "SELECT * FROM appversion WHERE OS='ios'";
        $query = DB::select(DB::raw($sql));

        
        $results = array();
        
        foreach ($query as $key => $value) {
            
            $results = array("version" => array("minimumBuildVersion" => $value->minimumBuildVersion, 
                                                    "minimumAppVersion" => $value->minimumAppVersion, 
                                                    "recommendedBuildVersion" => $value->recommendedBuildVersion, 
                                                    "recommendedAppVersion" => $value->recommendedAppVersion),
                            "updateMessage" => array("minimumUpdatesMessage" => $value->minimumUpdatesMessage, 
                                                    "recommendedUpdatesMessage" => $value->recommendedUpdatesMessage));

        }


        return response()->json($results);


        }   
        

        

    }

}
