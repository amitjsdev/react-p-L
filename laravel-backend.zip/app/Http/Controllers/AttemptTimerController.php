<?php

namespace App\Http\Controllers;

use App\AttemptTimer;
use Illuminate\Http\Request;
use Auth;
class AttemptTimerController extends Controller
{

    public function update(Request $request, AttemptTimer $attemptTimer)
    {
        $userId = (Auth::user());
        $add['time'] = $request->post('time');
        if($request->post('aiTimer')){
            $add['aiTimer'] = json_encode($request->post('aiTimer'));
        }
        $isCreated = AttemptTimer::updateOrCreate(
            ['quizSetId' =>  $request->post('quizSetId'), 'userId' => $userId->email],
            $add
        );
        // if($isCreated && $request->post('time')==0){
        //     // $isCreated->delete();
        // }
        return \response()->json(['status'=>true ]);
    }
}
