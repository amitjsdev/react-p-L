<?php

namespace App\Http\Controllers\Auth\Social;

use App\Http\Controllers\Controller;
use App\Employee;
use App\Events\UserLoggedIn;
use App\Events\UserRegistered;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Laravel\Socialite\Facades\Socialite;

class AppleAuthController extends Controller
{
    public function redirect()
    {
        return Socialite::driver('sign-in-with-apple')->redirect();
    }

    public function callback()
    {
        try {
            $user = Socialite::driver('sign-in-with-apple')->user();
        } catch (\Exception $e) {
            return redirect('/');
        }
    }

    public function profile(Request $request)
    {
        try {


            try {
                $aUser = Socialite::driver('sign-in-with-apple')->userFromToken($request->bearerToken());
            } catch (\Exception $e) {
                return response()->json(["message" => "Token invalid"], 401);
            }

            if (empty($aUser->user["email"])) {
                // the user email is empty return with error
                return response()->json(["message" => "The linked account does not have any email, cannot register without email!"], 401);
            }


            $user = User::where('email', $aUser->user["email"])->orWhere('alternate_email', $aUser->user["email"])->first();

            if (empty($user)) {
                // create user
                $user = User::create([
                    'email' => strtolower($aUser->user["email"]),
                    'fullname' => $aUser->name ?? "New User",
                    'password' => 'apple-login',
                    'token' => md5($aUser->user["email"] . time()),
                    'uid' => uniqid(),
                    'accesslevel' => 0
                ]);
            }

            // TODO: add facebook id etc to userLoginTable
            $employee = $user->employee()->first();

            if (empty($employee)) {
                // create employee
                $employee = Employee::create([
                    'CompanyCode' => 0,
                    'userId' => $aUser->user["email"],
                    'Location' => 'Unknown',
                    'accountCreationDate' => date("Y-m-d H:i:s"), //// save system date
                    'FirstName' => $aUser->name ?? "New User",
                    'LastName' => $aUser->name ?? "",
                    'levelOfLanguage' => isset($request->levelOfLanguage) ? $request->levelOfLanguage : null,
                    'currentModule' => isset($request->currentModule) ? $request->currentModule : 3
                ]);

                event(new UserRegistered($employee));
            } else {
                // user is just loggin in
                $employee->currentModule = isset($request->currentModule) ? $request->currentModule : $employee->currentModule;
                $employee->levelOfLanguage = isset($request->levelOfLanguage) ? $request->levelOfLanguage : $employee->levelOfLanguage;
                $employee->save();
                // fire login event
                event(new UserLoggedIn($employee));
            }

            $employee->lastLoginDate = date("Y-m-d H:i:s");
            $employee->save();

            reactivateUserIfNeeded($employee);

            $response = [
                'firstName' => $employee->FirstName,
                'email'  => $user->email,
                'updatedAt'   => $user->updatedAt,
                'submittedAt'   => $user->submittedAt,
                'accesslevel'  => $user->accesslevel,
                'CompanyCode' => $employee->CompanyCode,
                'companyName' => $employee->company
            ];

            $response['token'] = $user->createToken('TapLingua')->accessToken;

            $response['acceptedGDPR'] = $employee->acceptedGDPR ?? "";

            return response()->json($response);
        } catch (\Throwable $th) {
            Log::error("error at apple login", [$th]);
            return response()->json(["message" => "Server was unable to process your request!"], 400);
        }
    }



    public function profileGuest(Request $request)
    {
        try {


            try {
                $aUser = Socialite::driver('sign-in-with-apple')->userFromToken($request->bearerToken());
            } catch (\Exception $e) {
                return response()->json(["message" => "Token invalid"], 401);
            }

            if (empty($aUser->user["email"])) {
                // the user email is empty return with error
                return response()->json(["message" => "The linked account does not have any email, cannot register without email!"], 401);
            }


            $user = User::where('email', $request->userId)->first();

            if (empty($user)) {
                return response()->json(["message" => "User not found!"], 401);
            }

            // update userInfo
            $user->fullname = $aUser->name ?? "New User";
            $user->alternate_email = strtolower($aUser->user["email"]);
            $user->save();

            // TODO: add facebook id etc to userLoginTable
            $employee = $user->employee()->first();

            if (empty($employee)) {
                // create employee
                $employee = Employee::create([
                    'CompanyCode' => 0,
                    'userId' => $aUser->user["email"],
                    'Location' => 'Unknown',
                    'accountCreationDate' => date("Y-m-d H:i:s"), //// save system date
                    'FirstName' => $aUser->name ?? "New User",
                    'LastName' => $aUser->name ?? "",
                ]);
            }


            $employee->FirstName = $aUser->name ?? "New User";
            $employee->LastName = $aUser->name ?? "";
            $employee->lastLoginDate = date("Y-m-d H:i:s");
            $employee->save();

            reactivateUserIfNeeded($employee);

            $response = [
                'firstName' => $employee->FirstName,
                'email'  => $user->email,
                'updatedAt'   => $user->updatedAt,
                'submittedAt'   => $user->submittedAt,
                'accesslevel'  => $user->accesslevel,
                'CompanyCode' => $employee->CompanyCode,
                'companyName' => $employee->company
            ];

            $response['token'] = $user->createToken('TapLingua')->accessToken;

            $response['acceptedGDPR'] = $employee->acceptedGDPR ?? "";

            return response()->json($response);
        } catch (\Throwable $th) {
            Log::error("error at apple login", [$th]);
            return response()->json(["message" => "Server was unable to process your request!"], 400);
        }
    }
}
