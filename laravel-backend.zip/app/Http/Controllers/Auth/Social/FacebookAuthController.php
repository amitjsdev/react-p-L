<?php

namespace App\Http\Controllers\Auth\Social;

use App\Http\Controllers\Controller;
use App\Employee;
use App\Events\UserLoggedIn;
use App\Events\UserRegistered;
use App\User;
use Illuminate\Http\Request;
use Laravel\Socialite\Facades\Socialite;

class FacebookAuthController extends Controller
{
    public function redirect()
    {
        return Socialite::driver('facebook')->redirect();
    }

    public function callback()
    {
        try {
            $user = Socialite::driver('facebook')->user();
        } catch (\Exception $e) {
            return redirect('/');
        }
    }
    public function getCohortOfUser ($userId) {
        $cohort_ids = \App\Course::distinct('cohort_id')
                ->join('employeecourse', 'courses.courseNumber', '=', 'employeecourse.courseNumber')
                ->whereNotNull('cohort_id')
                ->where('userId', $userId)
                ->pluck("cohort_id");
            $cohort_ids =$cohort_ids && count($cohort_ids) >0  ? $cohort_ids[0] :null;
            $cohort =\App\Cohort::find($cohort_ids);
            return $cohort;
    }

    public function profile(Request $request)
    {

        try {
            $fUser = Socialite::driver('facebook')->userFromToken($request->bearerToken());
        } catch  (\Exception $e) {
            return response()->json(["status"=> false, "message" => "Token invalid"], 200);
            return response()->json(["message" => "Token invalid"], 401);
        }

        $isNewUser = false;

        if(empty($fUser->email)) {
            return response()->json(["status"=> false, "message" => "You are not registered for any tests. Please contact your administrator for help"], 200);
         // the user email is empty return with error
        //  return response()->json(["message" => "The linked account does not have any email, cannot register without email!"], 401);
        }


        $user = User::where('email', $fUser->email)->orWhere('alternate_email', $fUser->email)->first();

        if (empty($user)) {
            // create user
            $user = User::create([
                'email' => strtolower($fUser->email),
                'fullname' => $fUser->name,
                'password' => 'facebook-login',
                'token' => md5($fUser->email . time()),
                'uid' => uniqid(),
                'accesslevel' => 0
            ]);
            $isNewUser = true;
        }

        // TODO: add facebook id etc to userLoginTable
        $employee = $user->employee()->first();

        if (empty($employee)) {
            // create employee
            $employee = Employee::create([
                'CompanyCode' => 0,
                'userId' => $fUser->email,
                'Location' => 'Unknown',
                'accountCreationDate' => date("Y-m-d H:i:s"), //// save system date
                'FirstName' => $fUser->name,
                'LastName' => $fUser->name,
                'levelOfLanguage' => isset($request->levelOfLanguage) ? $request->levelOfLanguage : null,
                'currentModule' => isset($request->currentModule) ? $request->currentModule : 3
            ]);

            event(new UserRegistered($employee));
            $isNewUser = true;
        } else {
            // user is just loggin in
            $employee->currentModule = isset($request->currentModule) ? $request->currentModule : $employee->currentModule;
            $employee->levelOfLanguage = isset($request->levelOfLanguage) ? $request->levelOfLanguage : $employee->levelOfLanguage;
            $employee->save();
            // fire login event
            event(new UserLoggedIn($employee));
        }

        $employee->lastLoginDate = date("Y-m-d H:i:s");
        $employee->save();

        reactivateUserIfNeeded($employee);
        $cohort =$this->getCohortOfUser($user->email);
        $response = [
            'cohort'=>$cohort,
            'firstName' => $employee->FirstName,
            'email'  => $user->email,
            'updatedAt'   => $user->updatedAt,
            'submittedAt'   => $user->submittedAt,
            'accesslevel'  => $user->accesslevel,
            'CompanyCode' => $employee->CompanyCode,
            'companyName' => $employee->company,
            'isNewUser' => $isNewUser
        ];

        $response['token'] = $user->createToken('TapLingua')->accessToken;

        $response['acceptedGDPR'] = $employee->acceptedGDPR ?? "";

        return response()->json($response);
    }

    public function profileGuest(Request $request)
    {

        try {
            $fUser = Socialite::driver('facebook')->userFromToken($request->bearerToken());
        } catch (\Exception $e) {
            return response()->json(["message" => "Token invalid"], 401);
        }

        $isNewUser = false;

        if (empty($fUser->email)) {
            // the user email is empty return with error
            return response()->json(["message" => "The linked account does not have any email, cannot register without email!"], 401);
        }


        $user = User::where('email', $request->userId)->first();

        if (empty($user)) {
            return response()->json(["message" => "User not found!"], 401);
        }

        // update userInfo
        $user->fullname = $fUser->name;
        $user->alternate_email = strtolower($fUser->email);
        $user->save();

        // TODO: add facebook id etc to userLoginTable
        $employee = $user->employee()->first();

        if (empty($employee)) {
            // create employee
            $employee = Employee::create([
                'CompanyCode' => 0,
                'userId' => $fUser->email,
                'Location' => 'Unknown',
                'accountCreationDate' => date("Y-m-d H:i:s"), //// save system date
                'FirstName' => $fUser->name,
                'LastName' => $fUser->name,
                'levelOfLanguage' => isset($request->levelOfLanguage) ? $request->levelOfLanguage : null,
                'currentModule' => isset($request->currentModule) ? $request->currentModule : 3
            ]);
            $isNewUser = true;
        }

        $employee->FirstName = $fUser->name;
        $employee->LastName = $fUser->name;
        $employee->lastLoginDate = date("Y-m-d H:i:s");
        $employee->save();

        reactivateUserIfNeeded($employee);

        $response = [
            'firstName' => $employee->FirstName,
            'email'  => $user->email,
            'updatedAt'   => $user->updatedAt,
            'submittedAt'   => $user->submittedAt,
            'accesslevel'  => $user->accesslevel,
            'CompanyCode' => $employee->CompanyCode,
            'companyName' => $employee->company,
            'isNewUser' => $isNewUser
        ];

        $response['token'] = $user->createToken('TapLingua')->accessToken;

        $response['acceptedGDPR'] = $employee->acceptedGDPR ?? "";

        return response()->json($response);
    }
}
