<?php

namespace App\Http\Controllers\Auth\Social;

use App\Employee;
use App\Events\UserLoggedIn;
use App\Events\UserRegistered;
use App\Http\Controllers\AppUserAuthController;
use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Socialite;

class GoogleAuthController extends Controller
{
    function redirect()
    {
        return Socialite::driver('google')->redirect();
    }


    function callback()
    {
        try {
            $user = Socialite::driver('google')->user();
            // dd($user);
        } catch (\Exception $e) {
            // dd($e);
            return redirect('/');
        }
    }

    public function getCohortOfUser ($userId) {
        $cohort_ids = \App\Course::distinct('cohort_id')
                ->join('employeecourse', 'courses.courseNumber', '=', 'employeecourse.courseNumber')
                ->whereNotNull('cohort_id')
                ->where('userId', $userId)
                ->pluck("cohort_id");
            $cohort_ids =$cohort_ids && count($cohort_ids) >0  ? $cohort_ids[0] :null;
            $cohort =\App\Cohort::find($cohort_ids);
            return $cohort;
    }

    // get taplingua user from google token
    function profile(Request $request)
    {

            // create user

        try {
            $gUser =  Socialite::driver('google')->userFromToken($request->bearerToken());
        } catch (\Exception $e) {
            return response()->json(["status"=> false, "message" => "Token invalid"], 200);
        }

        $isNewUser = false;

        $user = User::where('email', $gUser->email)->orWhere('alternate_email', $gUser->email)->first();

        if (empty($user)) {
            return response()->json(["status"=> false,"message" => "You are not registered for any tests. Please contact your administrator for help"], 200);
            // create user
            $user = User::create([
                'email' => strtolower($gUser->email),
                'fullname' => $gUser->name,
                'password' => 'google-login',
                'token' => md5($gUser->email . time()),
                'uid' => uniqid(),
                'accesslevel' => 0
            ]);
            $isNewUser = true;
        }

        // TODO: add google id etc to userLoginTable
        $employee = $user->employee()->first();

        if (empty($employee)) {
            // create employee
            $employee = Employee::create([
                'CompanyCode' => 0,
                'userId' => $gUser->email,
                'Location' => 'Unknown',
                'accountCreationDate' => date("Y-m-d H:i:s"), //// save system date
                'FirstName' => $gUser->user["given_name"],
                'LastName' => $gUser->user["family_name"],
                'levelOfLanguage' => isset($request->levelOfLanguage) ? $request->levelOfLanguage : null,
                'currentModule' => isset($request->currentModule) ? $request->currentModule : 3
            ]);

            event(new UserRegistered($employee));
            $isNewUser = true;
        } else {
            // user is just loggin in
            $employee->currentModule = isset($request->currentModule) ? $request->currentModule : $employee->currentModule;
            $employee->levelOfLanguage = isset($request->levelOfLanguage) ? $request->levelOfLanguage : $employee->levelOfLanguage;
            $employee->save();
            // fire login event
            event(new UserLoggedIn($employee));
        }

        $employee->lastLoginDate = date("Y-m-d H:i:s");
        $employee->save();

        reactivateUserIfNeeded($employee);
        $cohort =$this->getCohortOfUser($user->email);
        $response = [
            'cohort'=>$cohort,
            'firstName' => $employee->FirstName,
            'email'  => $user->email,
            'updatedAt'   => $user->updatedAt,
            'submittedAt'   => $user->submittedAt,
            'accesslevel'  => $user->accesslevel,
            'CompanyCode' => $employee->CompanyCode,
            'companyName' => $employee->company,
            'isNewUser' => $isNewUser
        ];

        $response['token'] = $user->createToken('TapLingua')->accessToken;

        $response['acceptedGDPR'] = $employee->acceptedGDPR ?? "";
        $response['status'] =true;

        return response()->json($response);
    }



    // get taplingua guest user from google token
    function profileGuest(Request $request)
    {

        try {
            $gUser =  Socialite::driver('google')->userFromToken($request->bearerToken());
        } catch (\Exception $e) {
            return response()->json(["message" => "Token invalid"], 401);
        }

        $isNewUser = false;

        $user = User::where('email', $request->userId)->first();

        if (empty($user)) {
            return response()->json(["message" => "User not found!"], 401);
        }

        // update userInfo
        $user->fullname = $gUser->name;
        $user->alternate_email = strtolower($gUser->email);
        $user->save();

        // TODO: add google id etc to userLoginTable
        $employee = $user->employee()->first();

        if (empty($employee)) {
            // create employee
            $employee = Employee::create([
                'CompanyCode' => 0,
                'userId' => $request->userId,
                'Location' => 'Unknown',
                'accountCreationDate' => date("Y-m-d H:i:s"), //// save system date
                'FirstName' => $gUser->user["given_name"],
                'LastName' => $gUser->user["family_name"],
            ]);
            $isNewUser = true;
        }

        $employee->FirstName = $gUser->user["given_name"];
        $employee->LastName = $gUser->user["family_name"];
        $employee->lastLoginDate = date("Y-m-d H:i:s");
        $employee->save();

        reactivateUserIfNeeded($employee);

        $response = [
            'firstName' => $employee->FirstName,
            'email'  => $user->email,
            'updatedAt'   => $user->updatedAt,
            'submittedAt'   => $user->submittedAt,
            'accesslevel'  => $user->accesslevel,
            'CompanyCode' => $employee->CompanyCode,
            'companyName' => $employee->company,
            'isNewUser' => $isNewUser
        ];

        $response['token'] = $user->createToken('TapLingua')->accessToken;

        $response['acceptedGDPR'] = $employee->acceptedGDPR ?? "";

        return response()->json($response);
    }
}
