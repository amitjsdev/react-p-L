<?php

namespace App\Http\Controllers;

use App\Http\Resources\BadgeResource;
use App\Http\Resources\UserBadgeResource;
use App\UserBadge;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BadgeController extends Controller
{
    public function all(Request $request) {
        $userId = auth()->user()->email;
        // get user badges , using db query just for practice
        $badges = UserBadge::with('badge')->where("userId", $userId)->get();
        // return badges
        return response()->json(UserBadgeResource::collection($badges));
    }
}
