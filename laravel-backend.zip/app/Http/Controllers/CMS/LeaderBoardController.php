<?php

namespace App\Http\Controllers\CMS;

use App\Employee;
use App\Http\Resources\LeaderboardResource;
use App\Http\Resources\LeaderboardWeeklyResource;
use App\LingoCoinLog;
use App\UserDailyGoalLog;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class LeaderBoardController extends Controller
{
    const emailExceptions = [
        "exercises@taplingua.com",
        "french01@taplingua.com",
        "satishreddyb@datavolt.com",
        "oct07@taplingua.com",
        "ashutosh@taplingua.com",
        "italian01@taplingua.com",
        "oct1403@taplingua.com",
        'santanu@taplingua.com'
    ];

    public function weekly(Request $request)
    {
        $startOfWeek = null; // last saturday
        // $endOfWeek = today()->endOfDay(); // today
        // check if saturday for current week has passed
        if (now()->dayOfWeek >= 6) {
            // today is saturday or more
            $startOfWeek = today()->addDays(6 - now()->dayOfWeek)->startOfDay();
            $endOfWeek = today()->addWeek()->addDays(5 - now()->dayOfWeek)->endOfDay();
        } else {
            // saturday yet to come
            $startOfWeek = today()->subWeek()->addDays(6 - now()->dayOfWeek)->startOfDay();
            $endOfWeek = today()->addDays(5 - now()->dayOfWeek)->endOfDay();
        }

        $leaderboard = $this->getLeaderboardByDateRange($startOfWeek, $endOfWeek, $request->user()->email, $request->has('withNewUsers'), 'weekly', $request->companyCode ? $request->companyCode : 0);

        return response()->json($leaderboard);
    }

    public function lastWeek(Request $request)
    {
        $startOfWeek = null; // last saturday
        // $endOfWeek = today()->endOfDay(); // today
        // check if saturday for current week has passed
        if (now()->dayOfWeek >= 6) {
            // today is saturday or more
            $startOfWeek = today()->subWeek()->addDays(6 - now()->dayOfWeek)->startOfDay();
            $endOfWeek = today()->subWeek()->addWeek()->addDays(5 - now()->dayOfWeek)->endOfDay();
        } else {
            // saturday yet to come
            $startOfWeek = today()->subWeek()->subWeek()->addDays(6 - now()->dayOfWeek)->startOfDay();
            $endOfWeek = today()->subWeek()->addDays(5 - now()->dayOfWeek)->endOfDay();
        }

        $leaderboard = $this->getLeaderboardByDateRange($startOfWeek, $endOfWeek, $request->user()->email, $request->has('withNewUsers'), 'weekly');

        return response()->json($leaderboard);
    }

    public function today(Request $request)
    {
        $leaderboard = $this->getLeaderboardByDateRange(today()->startOfDay(), today()->endOfDay(), $request->user()->email, $request->has('withNewUsers'), 'daily', $request->companyCode ? $request->companyCode : 0);
        return response()->json($leaderboard);
    }

    private function getLeaderboardByDateRange($startDate, $endDate, $userId, $withNewUsers = false, $type, $companyCode = 0)
    {
        $you = Employee::where('userId', $userId)->first();

        $yourTotal = $you->totalScore ?? 0;
        $current = UserDailyGoalLog::where('userId', $userId)
            ->whereBetween('dated', [$startDate, $endDate])
            ->sum('points');

        // get top 50 records
        $leaderboard = getLeaderboardByDateRange($startDate, $endDate, $userId, $withNewUsers, $type, $companyCode);

        return [
            'you' => [
                'userId' => $userId,
                'current' => $current,
                "dailyThumbsUp" => $you->daily_thumbs_up ?? 0,
                "weeklyThumbsUp" => $you->weekly_thumbs_up ?? 0,
                'total' => $yourTotal
            ],
            'secondsLeft' => now()->diffInSeconds($endDate),
            'leaderboard' => $type === 'daily'
                ? LeaderboardResource::collection($leaderboard)
                : LeaderboardWeeklyResource::collection($leaderboard)
        ];
    }
}
