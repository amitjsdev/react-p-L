<?php

namespace App\Http\Controllers\CMS;

use App\Employee;
use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class UserController extends Controller
{
    public function index(Request $request)
    {
        if (!Session::has('admin') && !Session::has('marketing')) {
            return redirect('/admin-login');
        }

        $userId = $request->userId;

        //  get matches if user
        if($userId) {
            $users = Employee::where('userId', 'like', '%' . $userId . '%')->get();
        } else {
            $users = [];
        }

        return view('admin.users.user-index', [
            'users' => $users,
            'userId' => $userId
        ]);
    }

    public function delete(Request $request, $userId)
    {
        if (!Session::has('admin') && !Session::has('marketing')) {
            return redirect('/admin-login');
        }

        // delete the employee record
        Employee::where('userId', $userId)->delete();
        // delete the userLogin record
        User::where('email', $userId)->delete();
        // delete the employeecourse record
        DB::table('employeecourse')->where('userId', $userId)->delete();

        return redirect()->back()->with('message', "User data purged!");
    }
}
