<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\ModelNotFoundException;

use App\Http\Requests;
use App\Card;
use App\Http\Resources\Card as CardResource;

use DB;
use Session;
use Illuminate\Support\Facades\Validator;


class CardController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        
        $moduleNo = $request->input('moduleNo');
        $routeNo = $request->input('routeNo');
        $lessonNo = $request->input('lessonNo');

        $filter = array();
        if($moduleNo != ""){
        $filter[] = " moduleNo = '" . trim($moduleNo) . "'";
        }
        if($routeNo != ""){
        $filter[] = " routeNo = '" . trim($routeNo) . "'";
        }
        if($lessonNo != ""){
            $filter[] = " lesssonNo = '" . trim($lessonNo) . "'";
        }

        $where = "";
        if(count($filter)){
        $where = " where ". implode(" and ",$filter);
        }

        $query = "SELECT * from `cards` $where";

        $query = DB::select(DB::raw($query));

        $cards = array(); 

        foreach($query as $row){

            $cards[] = array("id" => $row->id, 
                              "moduleNo" => $row->moduleNo, 
                              "routeNo" => $row->routeNo, 
                              "lesssonNo" => $row->lesssonNo, 
                              "levelNo" => ceil($row->lesssonNo/3),
                              "translatedText" => $row->translatedText, 
                              "originalText" => $row->originalText
                             );

        }    
        

        return response()->json($cards);

        


    }

    public function list(Request $request)
    {
        
        $moduleNo = $request->input('moduleNo');
        $routeNo = $request->input('routeNo');

        /*$filter = array();
        if($moduleNo != ""){
        $filter[] = " moduleNo = '" . trim($moduleNo) . "'";
        }
        if($routeNo != ""){
        $filter[] = " routeNo = '" . trim($routeNo) . "'";
        }

        $where = "";
        if(count($filter)){
        $where = " where ". implode(" and ",$filter);
        }

        $query = "SELECT * from `cards` $where";

        $query = DB::select(DB::raw($query));

        $cards = array(); 

        foreach($query as $row){

            $cards[] = array("id" => $row->id, 
                              "moduleNo" => $row->moduleNo, 
                              "routeNo" => $row->routeNo, 
                              "lesssonNo" => $row->lesssonNo, 
                              "translatedText" => $row->translatedText, 
                              "originalText" => $row->originalText
                             );

        }    
        

        return response()->json($cards);*/

        //$cards = DB::table('cards');

        $cards = Card::query(); 

        $cards->orderBy('id','asc');

        if ($request->input('moduleNo') != "") {

            $cards->where('moduleNo', $request->input('moduleNo'));
        }

        if ($request->input('routeNo') != "") {

            $cards->where('routeNo', $request->input('routeNo'));
        }

        if ($request->input('lesssonNo') != "") {

            $cards->where('lesssonNo', $request->input('lesssonNo'));
        }

        if ($request->input('query') != "") {

            $query = $request->input('query');
            
            //$cards->where('translatedText', 'LIKE', "%{$query}%")->orWhere('originalText', 'LIKE', "%{$query}%");

            //SQL AND + OR + Brackets
            $cards->where(function($cards) use ($query) {
                $cards->where('translatedText', 'LIKE', '%'.$query.'%')
                      ->orWhere('originalText', 'LIKE', '%'.$query.'%');
            });

        }

        //echo $cards->toSql();
        //select * from `cards` where `moduleNo` = ? and `routeNo` = ? and (`translatedText` LIKE ? or `originalText` LIKE ?) order by `id` asc
        
        $cards = $cards->paginate(50);

        return CardResource::collection($cards);


    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $request->validate([
            "moduleNo"=>"required",
            "routeNo"=>"required",
            "lesssonNo"=>"required",
            "translatedText"=>"required",
            "originalText"=>"required"
        ]);

        
        $Card = Card::findOrFail($id);
        
        $Card->update($request->all());

        return response()->json(['message' => 'Data Saved!'], 200);


    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            "moduleNo"=>"required",
            "routeNo"=>"required",
            "lesssonNo"=>"required",
            "translatedText"=>"required",
            "originalText"=>"required"
        ]);


        $Card = $request->isMethod('put') ? Card::findOrFail($request->id) : new Card;

        $Card->id = $request->input('id');

        //$post->fill($request->input())->save();
        
        $Card->moduleNo = $request->input('moduleNo'); 
        $Card->routeNo = $request->input('routeNo'); 
        $Card->lesssonNo = $request->input('lesssonNo'); 
        $Card->translatedText = $request->input('translatedText'); 
        $Card->originalText = $request->input('originalText'); 

        $Card->addDate = date("Y-m-d H:i:s");
         
       
        if($Card->save()){
            //return new EmployeeResource($Employee);
            return response()->json(['message' => 'Data Saved!'], 200);
        }


    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        
        //echo "Test...";

        try{  

          $Card = Card::findOrFail($id);

          if($Card->delete()){
            return response()->json(['message' => 'Removed!'], 200);
          }

        }        
        // catch(Exception $e) catch any exception
        catch(ModelNotFoundException $e)
        {
            return response()->json(['message' => 'Not Found!'], 404);
        }

        
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $id)
    {
        
       try{

          $Card = Card::findOrFail($id);
          return new CardResource($Card);
        
        } 
        // catch(Exception $e) catch any exception
        catch(ModelNotFoundException $e)
        {
            return response()->json(['message' => 'Not Found!'], 404);
        } 

    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function saveFlashCardActivity(Request $request)
    {
        date_default_timezone_set("Europe/Madrid");

        $validator = Validator::make($request->all(), [
            "cardId" => "required",
            "userId" => "required",
        ]);

        if ($validator->fails()) {
            // TODO: Add the mail functionality
            $allErrors = $validator->errors()->all();
            error_logger($allErrors);
            return response()->json(["error" => $allErrors[0]], 412);
        }

        
        if($request->input('dateNext')=="")
        {

        $dateNext = date("Y-m-d H:i:s");

        }
        else
        {	

        $dateNext = str_replace('/', '-', $request->input('dateNext')); 
        $dateNext = date("Y-m-d H:i:s", strtotime($dateNext));
        
        }

        
        $results = DB::table('flash_card_activity')->select('id')->where('userId', $request->input('userId'))
            ->where('cardId', $request->input('cardId'))->get();

        
        if (sizeof($results) > 0) {  
            
            $query = "UPDATE `flash_card_activity` set difficultyLevel='".trim($request->input('difficultyLevel'))."', dateNext='".trim($dateNext)."', dateAdd=now()  WHERE cardId='".trim($request->input('cardId'))."' AND userId='".trim($request->input('userId'))."'";

        } else {
        
            $query = "INSERT INTO `flash_card_activity` (`id`, `cardId`, `userId`, `difficultyLevel`, `dateNext`, `dateAdd`) VALUES (NULL, '".trim($request->input('cardId'))."', '".trim($request->input('userId'))."', '".trim($request->input('difficultyLevel'))."', '".trim($dateNext)."', now())";

        }

        $query = DB::select(DB::raw($query));

        if(sizeof($query)){

            return response()->json(['error' => $query->getMessage()], 500);

        }
        else{
            return response()->json(["message" => "Data saved successfully."]);
        }
         
        //echo json_encode( array("message" => "Data saved successfully") );


    }

    
    public function getFlashCardActivity(Request $request)
    {

        /*$validator = Validator::make($request->all(), [
            'userId' => 'required',
        ]);

        if ($validator->fails()) {
            // TODO: Add the mail functionality
            $allErrors = $validator->errors()->all();
            error_logger($allErrors);
            return response()->json(["error" => $allErrors[0]], 412);
        }

        $data = $request->validated();*/

        $request->validate([
            "userId" => "required"
        ]);


        /*if (!$request->has('userId')) {
            return response()->json(["error" => "Malformed request"], 500);
        }*/


        $query = "SELECT * from `flash_card_activity` as fca JOIN `cards` as c ON fca.cardId = c.id where fca.userId='".trim($request->input('userId'))."'";

        $query = DB::select(DB::raw($query));

        $cards = array(); 

        foreach($query as $row){

            $cards[] = array("id" => $row->id, 
                              "moduleNo" => $row->moduleNo,
                              "routeNo" => $row->routeNo,
                              "LevelNo" => ceil($row->lesssonNo/3),
                              "dateAdd" => $row->dateAdd,
                              "cardId" => $row->cardId, 
                              "userId" => $row->userId, 
                              "difficultyLevel" => $row->difficultyLevel, 
                              "dateNext" => $row->dateNext,
                              "translatedText" => $row->translatedText, 
                              "originalText" => $row->originalText, 
                             );

        }    
        

        return response()->json($cards);

    }  
    
    

    /* CMS */


    public function listCards(Request $request)
    {

        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

           $cards = Card::query(); 

           $cards->orderBy('id','asc');
   
           if ($request->input('moduleNo') != "") {
   
               $cards->where('moduleNo', $request->input('moduleNo'));
           }
   
           if ($request->input('routeNo') != "") {
   
               $cards->where('routeNo', $request->input('routeNo'));
           }
   
           if ($request->input('lessonNo') != "") {
   
               $cards->where('lesssonNo', $request->input('lessonNo'));
           }
   
           if ($request->input('query') != "") {
   
               $query = $request->input('query');
               
               //$cards->where('translatedText', 'LIKE', "%{$query}%")->orWhere('originalText', 'LIKE', "%{$query}%");
   
               //SQL AND + OR + Brackets
               $cards->where(function($cards) use ($query) {
                   $cards->where('translatedText', 'LIKE', '%'.$query.'%')
                         ->orWhere('originalText', 'LIKE', '%'.$query.'%');
               });
   
           }


        if ($request->input('pageSize') != "") 
         $pageSize = $request->input('pageSize');
        else
         $pageSize = 50;  

        $cards = $cards->paginate($pageSize);


        
        
        return view('admin.ListCards')->with(['cards'=>$cards, "pageSize" => $pageSize]);


    }


    public function editCard(Request $request)
    {

        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        
        if($request->input('id')=="")
          $Card = new Card;
        else
          $Card = Card::findOrFail( $request->input('id') );


        $sql="select * from module where status='1' order by moduleno ";
        $modules = DB::select(DB::raw($sql));

        //$sql="select * from route where status='1' order by routeno ";
        //$routes = DB::select(DB::raw($sql));

        
        return view('admin.EditCard')->with(["card" => $Card, "modules" => $modules]);   
      

    }



    public function saveCard(Request $request)
    {

        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        
        if($request->input('id')!="")
        {
           
           
            $validator = Validator::make($request->all(), [
                "moduleNo"=>"required",
                "routeNo"=>"required",
                "lesssonNo"=>"required",
                "translatedText"=>"required",
                "originalText"=>"required"
            ]);
            
    
            if ($validator->fails()) {
                
                $allErrors = $validator->errors()->all();
                return redirect()->back()->with('error', $allErrors[0]);
            }


            $reqNew = array();
            foreach($request->all() as $key=>$value)
            {

                if($value!="")
                  $reqNew[$key] = $value;
                else
                  $reqNew[$key] = ''; 

            }
    
            //print_r($reqNew); die;
            
            $Card = Card::findOrFail( $request->input('id') );
            
            //$Card->update($request->all());

            $Card->update($reqNew);

            return redirect()->back()->with('message', 'Card saved successfully!');


        }
        else
        {

            $validator = Validator::make($request->all(), [
                "moduleNo"=>"required",
                "routeNo"=>"required",
                "lesssonNo"=>"required",
                "translatedText"=>"required",
                "originalText"=>"required"
            ]);
    
            if ($validator->fails()) {
                
                $allErrors = $validator->errors()->all();
                return redirect()->back()->with('error', $allErrors[0]);
            }
    

            $reqNew = array();
            foreach($request->all() as $key=>$value)
            {

                if($value!="")
                  $reqNew[$key] = $value;
                else
                  $reqNew[$key] = ''; 

            }
                    


            //$Card = Card::create($request->all());  

            $Card = Card::create($reqNew);  


            return redirect()->back()->with('message', 'Card saved successfully!');



        }


    }




    public function deleteCard(Request $request)
    {
        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        $Card = Card::findOrFail( $request->input('id'));

          if($Card->delete()){
            return redirect()->back()->with('message', 'Card removed successfully!');
          }

    }


}
