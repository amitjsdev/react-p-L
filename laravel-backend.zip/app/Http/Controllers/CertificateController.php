<?php

namespace App\Http\Controllers;

use App\Certificate;
use App\Course;
use App\Employee;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CertificateController extends Controller
{
    public function getForCourse(Request $request)
    {
        $userId = auth()->user()->email;
        $employeeCourse = DB::table('employeecourse')->where('userId', $userId)->where('courseNumber', $request->courseNumber)->first();
        if (!$employeeCourse) {
            return response()->json(['message' => 'You are not registered for that course!'], 400);
        }
        $course = Course::where('courseNumber', $employeeCourse->courseNumber)->first();
        if (!$course) {
            return response()->json(['message' => 'This course does not exist!'], 400);
        }

        $employee = Employee::where('userId', $userId)->first();
        if (!$employee) {
            return response()->json(['message' => 'Employee not found!'], 400);
        }

        // get percentange of course completed
        $coursePercentage = coursePercent($course->moduleNumber, $userId);

        // if course completed is below 30% then return no certificate
        // if ($coursePercentage < 30) {
        //     return response()->json([
        //         "code" => "1", // 1 is for below 30, 2 is for 30 to 75, 3 is for 75+
        //         "certificateUrl" => null,
        //     ]);
        // }

        $certificate = getCertificateIfExists($userId, $request->courseNumber);

        if (!$certificate) {
            return response()->json([
                "code" => "404", // 1 is for below 30, 2 is for 30 to 75, 3 is for 75+
                "certificateUrl" => null,
            ], 404);
        }

        if ($coursePercentage < 75) {
            return response()->json([
                "code" => "2", // 1 is for below 30, 2 is for 30 to 75, 3 is for 75+
                "certificateUrl" => $certificate->url(),
            ]);
        } else {
            return response()->json([
                "code" => "3", // 1 is for below 30, 2 is for 30 to 75, 3 is for 75+
                "certificateUrl" => $certificate->url(),
            ]);
        }
    }

    /**
     * Create certificate for user
     *
     * @param Request $request
     * @return void
     */
    function createCertificateForCourse(Request $request)
    {
        $courseNo = $request->courseNo;
        if (!$courseNo) {
            return response()->json([
                "message" => "Course number required!"
            ], 400);
        }
        $userId = $request->userId;
        $interviewSimulator = $request->interviewSimulator;
        $employee = \App\Employee::where('userId', $userId)->first();
        if($interviewSimulator && $employee && $employee->CompanyCode !=172){
            return response()->json([
                "message" => "Cannot create Certificate for candidate company",
                "code"=>$employee->CompanyCode,
                "error"=>true
            ], 200);
        }
        if (!$userId) {
            return response()->json([
                "message" => "User Id required!"
            ], 400);
        }
        // get certificate for user
        try {
            $certificate = getCertificate($userId, $courseNo, [
                "date" => today()
            ],$interviewSimulator);

            return response()->json([
                "certificate" => $certificate
            ]);
        } catch (\Throwable $th) {
            \Log::error("Could not create the certificate", [$th]);
            return response()->json([
                "message" => "Could not create the certificate"
            ], 400);
        }
    }
}
