<?php

namespace App\Http\Controllers;

use App\Cohort;
use App\Company;
use App\Course;
use App\Employee;
use App\CohortPracticeSet;
use App\EmployeeCourse;
use App\PracticeSet;
use App\Events\UserAddedToCohort;
use App\Http\Resources\AttemptLogResource;
use App\InstructorReview;
use App\InterviewVideo;
use App\Mail\EnrolledEmployeeWelcomeEmail;
use App\Mail\VpiEmployeeWelcomeEmail;
use App\Mail\ExcelMail;
use App\Mail\MultiSheetExcelMail;
use App\Mail\VpiDataForScoreMail;

use App\Program;
use App\ProgramPlacementTestResult;
use App\QuickbloxGroup;
use App\QuickbloxGroupUser;
use App\QuizAttemptLog;
use App\QuizSet;
use App\QuizSetQuestion;
use App\StudentPracticeAnswer;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Kreait\Firebase\Util\JSON;
use App\Exports\UsersExport;
use App\Exports\UserMultiSheetExport;
use Maatwebsite\Excel\Facades\Excel;
use App\PracticeQuestion;
use App\Exports\UsersExportVpiData;




class CohortController extends Controller
{
    /**
     * get all cohorts
     *
     * @param Request $request
     * @return void
     */
    public function index(Request $request)
    {
        if (!Session::has('admin') && !Session::has('marketing')) {
            return redirect('/admin-login');
        }
        // get all cohorts
        $cohorts = Cohort::all();

        // return view
        return view('admin.cohorts.cohort-index', compact('cohorts'));
    }

    /**
     * show create cohort view
     *
     * @param Request $request
     * @return void
     */
    public function createView(Request $request, $id = null)
    {
        if (!Session::has('admin') && !Session::has('marketing')) {
            return redirect('/admin-login');
        }
        // get all programs
        $programs = Program::all();

        $companies = Company::all();

        $cohort = Cohort::find($id);

        if (!$cohort) {
            $cohort = new Cohort();
        }

        // return view
        return view('admin.cohorts.cohort-create', compact('programs', 'cohort', 'companies'));
    }

    /**
     * save cohort
     *
     * @param Request $request
     * @return void
     */
    public function saveCohort(Request $request)
    {
        if (!Session::has('admin') && !Session::has('marketing')) {
            return redirect('/admin-login');
        }
        // validate the request
        $request->validate([
            "id" => "nullable|exists:cohorts,id",
            "name" => "required|string",
            "program_id" => "required|exists:programs,id",
            "company_code" => "required|exists:company,Id",
            "start_date" => "required|date",
        ]);

        $cohort = Cohort::find($request->id);

        $isBeingCreated = false;

        // get a start date
        $startDate = Carbon::parse($request->start_date);

        // create the cohort if the id is empty
        if (!$cohort) {
            // check if cohort name already take
            if (Cohort::where("name", $request->name)->exists()) {
                return redirect()->back()->withInput()->with('error', 'Cohort name is already in use');
            }
            $isBeingCreated = true;
            $cohort = Cohort::create($request->all());
            // QUICKBLOX: create cohort group - start
            \App\Services\QuickBlox::createCohortGroupIfNeededHelper($cohort->id);
            // QUICKBLOX: create cohort group - end
            // create course for every program in that module, for this cohort
            $modules = $cohort->program->modules->sort(function ($a, $b) {
                return $a->sort_order - $b->sort_order;
            });

            // sort index
            $moduleSortIndex = [];
            foreach ($modules as $module) {
                $moduleSortIndex[] = $module->module_number;
            }

            $moduleSortIndex = array_flip($moduleSortIndex);

            // for each module, create the course
            foreach ($modules as $index => $module) {
                Course::create([
                    "cohort_id" => $cohort->id,
                    "Company" => $request->company_code,
                    "courseStartDate" => Carbon::parse($startDate)->addWeeks(($moduleSortIndex[$module->module_number]) * 3),
                    "courseEndDate" => Carbon::parse($startDate)->addWeeks(($moduleSortIndex[$module->module_number] + 1) * 3),
                    "courseName" => $module->module->description,
                    "courseNumber" => time() . $index,
                    "moduleNumber" => $module->module_number,
                    "numberOfWeeks" => 3
                ]);
            }
        } else {

            $modules = $cohort->program->modules;
            $modulesToKeep = $modules->map(function ($module) {
                return $module->module_number;
            });

            // sort index
            $moduleSortIndex = [];
            foreach ($modules->sort(function ($a, $b) {
                return $a->sort_order - $b->sort_order;
            }) as $module) {
                $moduleSortIndex[] = $module->module_number;
            }

            $moduleSortIndex = array_flip($moduleSortIndex);

            // get all the courses that needs to be deleted
            Course::whereNotIn('moduleNumber', $modulesToKeep)->delete();

            // get model of each module
            $modulesToKeepModel = \App\Module::whereIn('moduleno', $modulesToKeep)
                ->get()->sort(function ($a, $b) use ($moduleSortIndex) {
                    return $moduleSortIndex[$a->moduleno] - $moduleSortIndex[$b->moduleno];
                });
            // for each module, upsert the course
            foreach ($modulesToKeepModel as $index => $module) {
                $prevCourse = Course::where([
                    "cohort_id" => $cohort->id,
                    "moduleNumber" => $module->moduleno,
                    "Company" => $request->company_code
                ])->first();

                $toBeUpdated = [
                    "courseName" => $module->description,
                    "courseStartDate" => Carbon::parse($startDate)->addWeeks(($moduleSortIndex[$module->moduleno]) * 3),
                    "courseEndDate" => Carbon::parse($startDate)->addWeeks(($moduleSortIndex[$module->moduleno] + 1) * 3),
                    "numberOfWeeks" => 3
                ];

                // if previous course doesnt have course no, update it
                if ($prevCourse) {
                    if (!$prevCourse->courseNumber) {
                        $toBeUpdated['courseNumber'] = time() . $index;
                    }
                }


                Course::updateOrCreate([
                    "cohort_id" => $cohort->id,
                    "moduleNumber" => $module->moduleno,
                    "Company" => $request->company_code
                ], $toBeUpdated);
            }

            // update cohort elsewise
            $cohort->update($request->all());
        }

        if ($isBeingCreated) {
            return redirect('/cohorts')->with('message', 'Cohort created successfully!');
        } else {
            return redirect('/cohorts')->with('message', 'Cohort updated successfully!');
        }
    }

    /**
     * save cohort [based on saveCohort, modify that also if needed]
     *
     * @param Request $request
     * @return void
     */
    public function saveCohortAPI(Request $request)
    {
        // validate the request
        $postData = $request->post();
        $postData['program_id'] = ($postData['type_id'] == 2 || $postData['type_id'] == 3) ? 9999 : $postData['program_id'];

        $request->validate([
            "id" => "nullable|exists:cohorts,id",
            "name" => "required|string",
            "type_id" => "required|exists:cohort_types,id",
            "program_id" => $postData['type_id'] != 4  ? "" : "required|exists:programs,id",
            "exam_start_time" => $postData['type_id'] != 2  ? "" : "required",
            "exam_end_time" => $postData['type_id'] != 2 ? "" : "required",
            "allotted_time" => $postData['type_id'] != 2 ? "" : "required",
            "company_code" => "required|exists:company,Id",
            "start_date" => "required|date",
            "archived" => "required|bool",
        ]);
        $cohort = Cohort::find($request->id);

        $isBeingCreated = false;

        // get a start date
        $startDate = Carbon::parse($request->start_date);

        // create the cohort if the id is empty
        if (!$cohort) {
            // check if cohort name already take
            if (Cohort::where("name", $request->name)->exists()) {
                return response()->json([
                    "errors" => [
                        "name" => [
                            "Cohort name is already in use"
                        ]
                    ]
                ]);
            }
            $isBeingCreated = true;
            $cohort = Cohort::create($postData);
            // create course for every program in that module, for this cohort
            $modules = $cohort->program->modules->sort(function ($a, $b) {
                return $a->sort_order - $b->sort_order;
            });

            // sort index
            $moduleSortIndex = [];
            foreach ($modules as $module) {
                $moduleSortIndex[] = $module->module_number;
            }

            $moduleSortIndex = array_flip($moduleSortIndex);

            // for each module, create the course
            foreach ($modules as $index => $module) {
                Course::create([
                    "cohort_id" => $cohort->id,
                    "Company" => $request->company_code,
                    "courseStartDate" => Carbon::parse($startDate)->addWeeks(($moduleSortIndex[$module->module_number]) * 3),
                    "courseEndDate" => Carbon::parse($startDate)->addWeeks(($moduleSortIndex[$module->module_number] + 1) * 3),
                    "courseName" => $module->module->description,
                    "courseNumber" => time() . $index,
                    "moduleNumber" => $module->module_number,
                    "numberOfWeeks" => 3
                ]);
            }
        } else {

            $modules = $cohort->program->modules;
            $modulesToKeep = $modules->map(function ($module) {
                return $module->module_number;
            });

            // sort index
            $moduleSortIndex = [];
            foreach ($modules->sort(function ($a, $b) {
                return $a->sort_order - $b->sort_order;
            }) as $module) {
                $moduleSortIndex[] = $module->module_number;
            }

            $moduleSortIndex = array_flip($moduleSortIndex);

            // get all the courses that needs to be deleted
            Course::whereNotIn('moduleNumber', $modulesToKeep)->delete();

            // get model of each module
            $modulesToKeepModel = \App\Module::whereIn('moduleno', $modulesToKeep)
                ->get()->sort(function ($a, $b) use ($moduleSortIndex) {
                    return $moduleSortIndex[$a->moduleno] - $moduleSortIndex[$b->moduleno];
                });
            // for each module, upsert the course
            foreach ($modulesToKeepModel as $index => $module) {
                $prevCourse = Course::where([
                    "cohort_id" => $cohort->id,
                    "moduleNumber" => $module->moduleno,
                    "Company" => $request->company_code
                ])->first();

                $toBeUpdated = [
                    "courseName" => $module->description,
                    "courseStartDate" => Carbon::parse($startDate)->addWeeks(($moduleSortIndex[$module->moduleno]) * 3),
                    "courseEndDate" => Carbon::parse($startDate)->addWeeks(($moduleSortIndex[$module->moduleno] + 1) * 3),
                    "numberOfWeeks" => 3
                ];

                // if previous course doesnt have course no, update it
                if ($prevCourse) {
                    if (!$prevCourse->courseNumber) {
                        $toBeUpdated['courseNumber'] = time() . $index;
                    }
                }


                Course::updateOrCreate([
                    "cohort_id" => $cohort->id,
                    "moduleNumber" => $module->moduleno,
                    "Company" => $request->company_code
                ], $toBeUpdated);
            }

            // update cohort elsewise
            $cohort->update($request->all());
        }

        return response()->json([
            "message" => "Cohort created successfully!"
        ]);
    }

    /**
     * Toggle notification
     *
     * @param Request $request
     * @return void
     */
    public function toggleCohortNotification(Request $request)
    {
        if (!Session::has('admin') && !Session::has('marketing')) {
            return redirect('/admin-login');
        }

        $cohort = Cohort::find($request->id);

        $cohort->notification_on = !$cohort->notification_on;

        $cohort->save();

        return redirect()->back()->with('message', 'Notification toggled for ' . $cohort->name);
    }

    public function deleteCohort(Request $request, $id)
    {
        if (!Session::has('admin') && !Session::has('marketing')) {
            return redirect('/admin-login');
        }

        $cohort = Cohort::find($id);

        if (!$cohort) {
            return redirect()->back()->with('error', 'Cohort not found!!');
        }

        $cohort->delete();

        return redirect()->back()->with('message', 'Cohort deleted!');
    }


    /**
     * Show ui to register user to cohort
     *
     * @param Request $request
     * @param [type] $cohort_id
     * @return void
     */
    public function registerUserToCohortView(Request $request, $cohort_id)
    {
        $cohort = Cohort::find($cohort_id);

        if (!$cohort) {
            abort(404, "Course No Missing");
        }

        return view('app.employee-cohort-registration-form', [
            'cohort' => $cohort
        ]);
    }

    /**
     * Get user cohorts
     *
     * @param Request $request
     * @return void
     */
    public function getUserCohorts(Request $request)
    {
        $user = \App\User::with('programs.modules')
            ->where('email', $request->user()->email)
            ->first();

        $cohort_ids = \App\Course::distinct('cohort_id')
            ->join('employeecourse', 'courses.courseNumber', '=', 'employeecourse.courseNumber')
            ->whereNotNull('cohort_id')
            ->where('userId', $user->email)
            ->pluck("cohort_id");

        // get all cohorts
        $cohorts = \App\Cohort::whereIn('id', $cohort_ids)->get();

        $userId = $user->email;

        // create program structure
        $programs = $cohorts->map(function ($cohort) use ($userId) {
            $levels = [];

            // get program for cohort
            $program = $cohort->program;

            $modules = $program->modules()->orderBy('level_number')->orderBy('sort_order')->get();

            // get all modules and make levels
            foreach ($modules as $module) {
                // check if level array there, create if not
                if (!isset($levels[$module->level_number])) {
                    $levels[$module->level_number] = [];
                }
                // check if certification available
                $course = getCourseNoFromModuleNo($module->module_number, $userId, true);
                $module->course_number = $course->courseNumber;
                $module->description = $module->module ? $module->module->description : null;
                $module->long_description = $module->module ? $module->module->long_description : null;
                $module->totalLessons = getLessonCountForModule($module->module_number);
                $module->startDate = $course->courseStartDate;
                $module->endDate = $course->courseEndDate;
                $module->completed = getCertificateIfExists($userId, $course->courseNumber) ? true : false;
                unset($module->module);
                // add to level
                $levels[$module->level_number][] = $module;
            }

            // restructure the level
            $levels = array_values(array_map(function ($modules) {
                return [
                    "level_number" => $modules[0]->level_number,
                    "modules" => $modules
                ];
            }, $levels));

            $program->cohort_id = $cohort->id;

            // set placement test result
            $placementTestResult = ProgramPlacementTestResult::where('userId', $userId)
                ->where('programId', $program->id)
                ->latest()
                ->first();

            if ($placementTestResult) {
                $program->placementScore = $placementTestResult->placementScore;
            } else {
                $program->placementScore = 0;
            }
            // set placement test result end


            $program->levels = $levels;
            unset($program->modules);
            $program->startDate = $cohort->start_date;
            return $program;
        });

        return response()->json([
            "message" => "Cohorts",
            "programs" => $programs
        ]);
    }
    /**
     * Get user cohort by Id
     *
     * @param Request $request
     * @return void
     */
    public function getUserCohortDetail(Request $request, $cohort_id, $userId)
    {
        $user = \App\User::with('programs.modules')
            ->where('email', $userId)
            ->first();

        // get all cohorts
        $cohort = \App\Cohort::where('id', $cohort_id)->first();

        // create program structure

        $levels = [];

        // get program for cohort
        $program = $cohort->program;

        // get all modules and make levels
        foreach ($program->modules as $module) {
            // check if level array there, create if not
            if (!isset($levels[$module->level_number])) {
                $levels[$module->level_number] = [];
            }
            // check if certification available
            $course = getCourseNoFromModuleNo($module->module_number, $userId, true);
            $module->course_number = $course->courseNumber;
            $module->description = $module->module ? $module->module->description : null;
            $module->long_description = $module->module ? $module->module->long_description : null;
            $module->totalLessons = getLessonCountForModule($module->module_number);
            $module->startDate = $course->courseStartDate;
            $module->endDate = $course->courseEndDate;
            $module->completed = getCertificateIfExists($userId, $course->courseNumber) ? true : false;
            unset($module->module);
            // add to level
            $levels[$module->level_number][] = $module;
        }

        // restructure the level
        $levels = array_values(array_map(function ($modules) {
            return [
                "level_number" => $modules[0]->level_number,
                "modules" => array_values(collect($modules)->sort(function ($a, $b) {
                    return $a->sort_order - $b->sort_order;
                })->toArray())
            ];
        }, $levels));

        $program->cohort_id = $cohort->id;
        $program->levels = $levels;
        unset($program->modules);
        $program->startDate = $cohort->start_date;

        return response()->json([
            "message" => "Cohort",
            "user" => [
                "name" => $user->fullname,
                "email" => $user->email
            ],
            "cohort" => $cohort
        ]);
    }





    public function getUserCohortId(Request $request)
    {
        $user = \Auth::user();
        $cohort_ids = \App\Course::distinct('cohort_id')
            ->join('employeecourse', 'courses.courseNumber', '=', 'employeecourse.courseNumber')
            ->whereNotNull('cohort_id')
            ->where('userId', $user->email)
            ->pluck("cohort_id");

        return response()->json($cohort_ids);
    }
    public function deleteUserCourses(Request $request)
    {
        $userId =$request->userId;
        $courseNumber =$request->courseNumber;
        if(!$userId || !$courseNumber){
            return response()->json(['status'=>false, 'msg'=>'Invalid data']);
        }
        $ck = EmployeeCourse::where(['courseNumber'=>$courseNumber, 'userId'=> $userId])->delete();
        return response()->json(['status'=>$ck, 'msg'=>$ck]);
    }

    public function getCompanyCohorts(Request $request)
    {
        // get cohorts
        // $cohorts = Cohort::where('company_code', $request->company_code)
        // ->get();

        if (!!$request->status && $request->status != '') {
            $cohorts = Cohort::where('company_code', $request->company_code)
                ->join('quiz_sets', 'quiz_sets.companyCode', "=", 'cohorts.company_code')
                ->where('archive', $request->status)->get();
        } else {
            $cohorts = Cohort::where('company_code', $request->company_code)->get();
        }
        // get users count for cohort
        foreach ($cohorts as $cohort) {
            $cohort->users = Course::select(['userId','courses.courseNumber'])->distinct('userId')
                ->join('employeecourse', 'courses.courseNumber', "=", "employeecourse.courseNumber")
                ->where('cohort_id', $cohort->id)
                ->get();
            // echo $cohort->id;
            // echo "<br>";
            $cohort->CohortPracticeSet = CohortPracticeSet::select('practiceSetId')->where('cohortId', $cohort->id)->get();

            $questionId = [];
            if (count($cohort->CohortPracticeSet) > 0) {

                foreach ($cohort->CohortPracticeSet as $val) {
                    $questionId[] = $val['practiceSetId'];
                }
            }
            $practiceQuestions = [];
            if (count($questionId) > 0) {

                $practiceQuestions = PracticeQuestion::where('practiceSetId', $questionId[0])->orderBy('practiceQuestionId')->get();
            }
            $cohort->quesionCount = count($practiceQuestions);

            $cohort->allIds = count($cohort->users);
            // get user ids
            $userIds = $cohort->users->map(function ($user) {

                return $user->userId;
            });
        }

        // return response
        return response()->json([
            "message" => "Cohorts",
            "programs" => $cohorts,
        ]);
    }

    public function getCompanyCohortUsersWhoAttemptedQuiz(Request $request, $cohort_id)
    {
        // get cohorts
        $cohort = Cohort::find($cohort_id);

        $cohort->users = Course::select('userId')->distinct('userId')
            ->join('employeecourse', 'courses.courseNumber', "=", "employeecourse.courseNumber")
            ->where('cohort_id', $cohort->id)
            ->get();

        // get user ids
        $userIds = $cohort->users->map(function ($user) {
            return $user->userId;
        });

        // get the users who have quiz attempts
        $quizAttemptUsers = QuizAttemptLog::whereIn('userId', $userIds)->selectRaw('userId, quizSetId, COUNT(*) as attemptCount')
            ->groupBy('userId', 'quizSetId')->get()->map(function ($attempt) {
                $attempt->FirstName = $attempt->employee->FirstName;
                $attempt->LastName = $attempt->employee->LastName;

                $attempt->quizTopic = $attempt->quizSet ? $attempt->quizSet->quizTopic : "";

                unset($attempt->employee);

                return $attempt;
            });

        // for each user get their attempt count
        return [
            "program" => $cohort,
            "users" => $quizAttemptUsers
        ];
    }

    public function ProctoredTest(Request $request, $companyId)
    {

        // $cohort = Cohort::join('quiz_sets', 'quiz_sets.companyCode', "=", "cohorts.company_code")
        //     // ->join('quiz_attempt_logs', 'quiz_sets.quizSetId', "=", "quiz_attempt_logs.quizSetId")

        //     ->where('type_id', 2)
        //     ->where('company_code', $companyId)
        //     ->groupBy('cohorts.id', 'quiz_sets.quizSetId')
        //     $cohort = Cohort::join('quiz_sets', 'quiz_sets.cohortId', "=", "cohorts.id")
        //    ->where('type_id', 2)
        //    ->where('company_code', $companyId)
        //     ->groupBy('cohorts.id', 'quiz_sets.quizSetId')
        //         ->select('name', 'start_date', 'quizSetId', 'cohorts.id', 'quizTopic','type_id','exam_start_time','exam_end_time')

        //         ->get();
        $cohort = Cohort::Leftjoin('quiz_sets', 'quiz_sets.cohortId', "=", "cohorts.id")
            ->where('type_id', 2)
            ->where('company_code', $companyId)
            ->groupBy('cohorts.id', 'quiz_sets.quizSetId')
            ->select('name', 'start_date', 'quizSetId', 'cohorts.id', 'quizTopic', 'type_id', 'exam_start_time', 'exam_end_time')

            ->get();
        foreach ($cohort as $c) {
            $attempt = QuizAttemptLog::where('quizSetId', $c->quizSetId)
                ->where('cohortId', $c->id)->get();
            $c->total = $attempt->count();
            $c->completed = $attempt->where('attemptStatus', 1)->count();
            $c->pending = $attempt->where('attemptStatus', 0)->count();
            $c->students = $attempt->groupBy('userId')->count();
        }
        return [
            "data" => $cohort,
        ];
    }
    public function ProctoredTestDetail(Request $request, $cohortId, $quizId)
    {
        $cohort = Cohort::where('id', $cohortId)->first();
        // $attempt = QuizAttemptLog::where('cohortId', $cohortId)
        // ->where('quizSetId', $quizId)
        // ->with('resume')
        // ->with('employee')
        // ->orderBy('id', 'DESC')
        // ->paginate(20);
        if ($request->input('search') != "") {
            $attempt = QuizAttemptLog::where('cohortId', $cohortId)
                ->where('userId',  'LIKE', '%' . $request->input('search') . "%")
                ->with('resume')
                ->with('employee')
                ->orderBy('id', 'DESC')->paginate(20);
        } else {
            $attempt = QuizAttemptLog::where('cohortId', $cohortId)
                ->where('quizSetId', $quizId)
                ->with('resume')
                ->with('employee')
                ->orderBy('id', 'DESC')->paginate(20);
        }
        $users = [];
        foreach ($attempt as $key => &$a) {
            $answer = json_decode($a->answerJSON, 1);
            $right = 0;
            $wrong = 0;
            $total = 0;
            if ($answer && count($answer) > 0) {
                foreach ($answer as $ans) {
                    if ($ans['isAnswerCorrect']) {
                        $right++;
                    } else {
                        $wrong++;
                    }
                    $total++;
                }
            }

            $a->right = $right;
            $a->wrong = $wrong;
            $a->total = $total;
            $a->ans = $answer;
            $percent = ($total > 0 ? (($right / $total) * 100) : 0);
            $a->percent = number_format($percent, 2, '.', "");
            if (in_array($a->userId, $users)) {
                unset($attempt[$key]);
            } else {
                if ($a->resume && $a->resume->resumeContent) {
                    $d = json_decode($a->resume->resumeContent);
                    $a->resumeContent = $d;
                } else {
                    $a->resumeContent = null;
                }
                $users[] = $a->userId;
            }
        }
        return [
            "data" => $attempt,
            "cohort" => $cohort,
        ];
    }


    public function exportCohort(Request $request)
    {


        $cohorts = Cohort::where('company_code', $request->company_code)->get();
        $company_code = $request->company_code;
        $companyNameCohort = [];
        $companyIdCohort = [];

        // get users count for cohort
        foreach ($cohorts as $cohort) {
            $cohort->users = Course::select('userId')->distinct('userId')
                ->join('employeecourse', 'courses.courseNumber', "=", "employeecourse.courseNumber")
                ->where('cohort_id', $cohort->id)
                ->get();

            $cohortData = Cohort::find($cohort->id);
            $companyName = $cohortData->company->Name;
            $companyId = $cohortData->company->Id;
            $companyNameCohort[] = $companyName;
            $companyIdCohort[] = $companyId;

            // get user ids

            $userIds = $cohort->users->map(function ($user) {
                return $user->userId;
            });

            // get the users who have quiz attempts
            $cohort->quizAttempts = QuizAttemptLog::whereIn('userId', $userIds)->distinct('userId')->count();
        }

        $name = 'Cohort_engagement_report_' . date("d-m-Y", time()) . '.xlsx';
        $subjectName = 'Cohort summary report ' . date("d-m-Y", time());
        $filename = preg_replace('/\s+/', '_', $name);
        $user = \Auth::user();
        $companyNameCohortVal = 'Taplingua';
        if (isset($companyNameCohort)) {
            $companyNameCohortVal = $companyNameCohort[0];
        } else {
            $companyNameCohortVal = 'Taplingua';
        }
        $companyIdCohortVal = '0';
        if (isset($companyNameCohort)) {
            $companyIdCohortVal = $companyNameCohort[0];
        } else {
            $companyIdCohortVal = '0';
        }

        $file = Excel::store(new UserMultiSheetExport($cohorts, $company_code), $filename);

        \Mail::to($user->email)
            // \Mail::to('test.official92@gmail.com')
            ->send(new MultiSheetExcelMail(
                $user->fullname,
                $user->email,
                $filename,
                $subjectName,
                $companyNameCohortVal,
                $companyIdCohortVal

            ));
        return response()->json(['status' => true, $filename]);
    }

    public function ProctoredExport($cohortId, $quizId)
    {
        $QuizSetQuestion = QuizSetQuestion::where('quizSetId', $quizId)->get();
        $questions = $QuizSetQuestion->pluck('questionText');
        $questionsIds = $QuizSetQuestion->pluck('quizSetQuestionId');
        $rc = ["eeRank", "location", "companyName", "stateExamRank", "currentAddress", "whatsappNumber", "workExperience", "areYouWorkingYN", "branchOrDepartment", "class10GPAorPercent", "collegeEntranceName", "plansToWorkFullTime", "graduationCollegeName", "graduationGPAorPercent", "finalExamStartIfStudent", "graduationDateIfStudent"];
        $attempt = QuizAttemptLog::where('cohortId', $cohortId)
            ->where('quizSetId', $quizId)
            ->with('employee')
            ->orderBy('id', 'DESC')
            ->get();
        $users = [];
        $dataRow = [];
        foreach ($attempt as $key => &$a) {
            $answer = json_decode($a->answerJSON, 1);
            $answer = $answer && count($answer) > 0 ? $answer : [];
            $ai_result = json_decode($a->ai_result);
            // UFM Score	Percentage
            $answerArr = [$a->id, $a->employee->FirstName . ' ' . $a->employee->LastName, $a->employee->userId, $a->employee->Mobile];
            $answerArr[] = $a->created_at;


            $answerArr[] = $a->streamId ? 'https://langappnew.s3.amazonaws.com/' . $a->streamId : ''; //reasonIncomplete
            // $answerArr[] =$a->proctoredVideo ? 'https://langappnew.s3.amazonaws.com/'.$a->proctoredVideo : ''; //reasonIncomplete
            if ($ai_result && isset($ai_result->processed) && isset($ai_result->processed->finalResult)) {
                $processedItmes = $ai_result->processed;
                $lookingUp = 0;
                $lookingDown = 0;
                $persons = 0;
                $totalTime = 0;
                //global Value
                $up_looking = 0.1;
                $away_looking = 0.1;
                $multi_user = 0.45;
                $zero_candidate = 0.35;

                if ($processedItmes->up_looking_percent) {
                    $lookingUp = floatval($processedItmes->up_looking_percent) * floatval($up_looking);
                }
                if ($processedItmes->away_looking_percent) {
                    $lookingDown = floatval($processedItmes->away_looking_percent) * floatval($away_looking);
                }

                if ($processedItmes->multi_user_percent > 0) {
                    $persons = floatval($processedItmes->multi_user_percent) * floatval($multi_user);
                }

                if ($processedItmes->zero_candidate_time > 0) {
                    $totalTime = (floatval($processedItmes->zero_candidate_time) / floatval($processedItmes->total_time)) * 100;
                    $totalTime = $totalTime * floatval($zero_candidate);
                }
                $totalFinal = $lookingUp + $lookingDown + $persons + $totalTime;

                $answerArr[] = round($totalFinal, 0) . '%'; //ufm score
                $answerArr[] = $ai_result->processed->away_looking_percent . '%'; //ufm score
                $answerArr[] = $ai_result->processed->up_looking_percent . '%'; //ufm score
                $answerArr[] = $ai_result->processed->total_time . ' Seconds'; //ufm score
                $answerArr[] = $ai_result->processed->zero_candidate_time . ' Seconds'; //ufm score
                $answerArr[] = $ai_result->processed->multi_user_percent . '%'; //ufm score

            } else {
                $answerArr[] = '';
                $answerArr[] = '';
                $answerArr[] = '';
                $answerArr[] = '';
                $answerArr[] = '';
                $answerArr[] = '';
            }
            $answerArr[] = $a->attemptStatus; //Complete
            $answerArr[] = $a->attemptNumber; //attemptNumber
            $answerArr[] = $a->reasonIncomplete; //reasonIncomplete

            $right = 0;
            $wrong = 0;
            $total = 0;
            $notAttempted = 0;
            $qAnsArr = [];
            foreach ($questionsIds as $qId) {
                $total++;
                $val = '';
                $selectedAnswer = '';
                $key = array_search($qId, array_column($answer, 'quizSetQuestionId'));
                if (is_int($key) && array_key_exists($key, $answer)) {
                    if ($answer[$key]['selectedAnswer'] != '') {
                        $selectedAnswer = $answer[$key]['selectedAnswer'];
                        if ($answer[$key]['isAnswerCorrect']) {
                            $val = 1;
                            $right++;
                        } else {
                            $val = 0;
                            $wrong++;
                        }
                    } else {
                        $val = 0;
                        $notAttempted++;
                    }
                } else {
                    $val = 0;
                    $notAttempted++;
                }
                $qAnsArr[] = $selectedAnswer;
                $qAnsArr[] = $val;
            }


            $a->right = $right;
            $a->wrong = $wrong;
            $a->total = $total;
            $percent = ($total > 0 ? (($right / $total) * 100) : 0);
            $a->percent = number_format($percent, 2, '.', "");
            $answerArr[] = $a->percent . '%';
            $answerArr[] = $right;
            $answerArr[] = $wrong;
            $answerArr[] = $notAttempted;
            // print(count($answerArr));
            // die;
            $finalUserData = array_merge($answerArr, $qAnsArr);
            $dataForRc = []; //resume question
            if ($a->resume && $a->resume->resumeContent) {
                $dataForRc = json_decode($a->resume->resumeContent, 1);
            }
            foreach ($rc as $r) {
                if ($dataForRc && count($dataForRc) > 0 && array_key_exists($r, $dataForRc)) {
                    $finalUserData[] = $dataForRc[$r];
                } else {
                    $finalUserData[] = '';
                }
            }

            if (in_array($a->userId, $users)) {
                unset($attempt[$key]);
            } else {
                $users[] = $a->userId;
            }

            $dataRow[] = $finalUserData;
        }

        return ['questions' => $questions, 'users' => $dataRow];
    }

    public function exportVpiData(Request $request, $cohort_id)
    {
        // get cohorts
        $cohortData = Cohort::find($cohort_id);
        $startDate = $request->get('startDate');
        $endDate = $request->get('endDate');
        $startDate = new Carbon($startDate);
        $endDate = new Carbon($endDate);

        // $cohortName =Cohort::find($cohort_id);
        // $cohortName =$cohortName ? $cohortName->name :'';

        // $cohortData = Cohort::find($cohort->id);
        $companyName = $cohortData->company->Name;
        $companyId = $cohortData->company->Id;
        $cohortName = $cohortData ? $cohortData->name : '';


        $name = 'VPI_Report_' . $cohortName . '_' . date("d-m-Y", time()) . '.xlsx';
        $subjectName = 'VPI Report ' . $cohortName . ' ' . date("d-m-Y", time());

        $filename = preg_replace('/\s+/', '_', $name);
        $user = \Auth::user();
        // $d =$this->vpiExportData($cohort_id,$startDate,$endDate);
        // return \response()->json($d);
        $file = Excel::store(new UsersExportVpiData($cohort_id, $startDate, $endDate), $filename);
        \Mail::to($user->email)
            // \Mail::to('test.official92@gmail.com')
            ->send(new VpiDataForScoreMail(
                $user->fullname,
                $user->email,
                $filename,
                $subjectName,
                $companyName,
                $companyId
            ));
        return \response()->json(['status' => 'Email sent!', $filename]);
    }



    public function vpiExportData($cohortId, $startDate, $endDate)
    {
        // get users count for cohort
        $all_users = Course::select('userId', 'employeecourse.courseNumber', 'manual_rating')->distinct('userId')
            ->join('employeecourse', 'courses.courseNumber', "=", "employeecourse.courseNumber")
            ->where('cohort_id', $cohortId)
            ->get();
        // return response()->json($users);
        $allUser = [];

        $distinctAttemptsCountNew = [];
        $countAskReview = array();
        $vpi_scores = array();
        $vpi_score = array();
        $Reviews_Completed_count = array();
        $Practice_Answer_count = array();
        $distinctAttempts = [];
        $totalAttempts = [];
        $practice_set_questions = [];
        $Asked_for_Review = [];
        $Reviews_Completed = [];
        $Practice_Answer = [];
        $user = [];
        foreach ($all_users as $user) {

            $user->courseNumber = $user->courseNumber;
            $user->manual_rating = $user->manual_rating;

            $distinctAttemptsCount = InterviewVideo::select('moduleNo')
                ->whereBetween('created_at', [$startDate->format('Y-m-d') . " 00:00:00", $endDate->format('Y-m-d') . " 23:59:59"])
                ->where([
                    ['userId', $user->userId],
                ])
                ->groupBy('moduleNo', 'routeNo', 'lessonNo')->get();

            $findUnique = array();
            if (count($distinctAttemptsCount) > 0) {
                foreach ($distinctAttemptsCount as $val) {
                    $findUnique[] = $val['moduleNo'];
                }
            }
            $CohortPracticeSet = CohortPracticeSet::select('practiceSetId')->where('cohortId', $cohortId)->get();
            if (count($findUnique) > 0) {
                $distinctAttemptsCountNew = array();
                $countAskReview = array();
                $vpi_scores = array();
                $Reviews_Completed_count = array();
                $Practice_Answer_count = array();
                $vpiValArray = [];
                $distinctAttemptsRecord = [];
                // foreach(array_unique($findUnique) as $key=>$val){
                $CohortPracticeCount = CohortPracticeSet::select('practiceSetId')->where('practiceSetId', $findUnique[0])->where('cohortId', $cohortId)->get();
                if (count($CohortPracticeCount) > 0) {
                    //total attempts
                    $distinctAttemptsRecord = InterviewVideo::distinct('routeNo', 'lessonNo')
                        ->whereBetween('created_at', [$startDate->format('Y-m-d') . " 00:00:00", $endDate->format('Y-m-d') . " 23:59:59"])
                        ->where([
                            ['userId', $user->userId],
                        ])
                        ->where([
                            ['moduleNo', $findUnique[0]],
                        ])
                        ->groupBy('moduleNo', 'routeNo', 'lessonNo')->get();

                    // get the total attempts by the user
                    $vpi_score = InterviewVideo::select('vpi_score')->where([
                        ['userId', $user->userId]
                    ])
                        ->whereBetween('created_at', [$startDate->format('Y-m-d') . " 00:00:00", $endDate->format('Y-m-d') . " 23:59:59"])
                        ->where([
                            ['moduleNo', $findUnique[0]],
                        ])
                        ->get();
                    foreach ($vpi_score as $vpiVal) {
                        if (!empty($vpiVal['vpi_score'])) {
                            $vpiValArray[] = $vpiVal['vpi_score'];
                        }
                    }

                    $Practice_Answer =   StudentPracticeAnswer::where('userId', $user->userId)
                        ->where('practiceSetId', $findUnique[0])->get();

                    $practice_set = PracticeSet::where('practiceSetId', $findUnique[0])->first();
                    // $practice_set = PracticeSet::where('practiceSetId', $val)->first();
                    $userId = $user->userId;
                    $practice_set_questions = $practice_set->questions()->orderBy('practiceQuestionId')->get()->map(function ($question) use ($userId) {
                        $question->long_description = $question->practiceSetQuestion;
                        $question->routeno = 0;
                        $question->lesson_no = $question->practiceQuestionId;

                        $question->completed = \App\InterviewVideo::where([
                            ['moduleNo', $question->practiceSetId],
                            ['routeNo', 0],
                            ['lessonNo', $question->practiceQuestionId],
                            ['userId', $userId],
                        ])->exists();

                        $question->tldrs = \App\PracticeQuestionTldr::select(['title', 'description'])
                            ->where([
                                ['practiceSetId', $question->practiceSetId],
                                ['practiceQuestionId', $question->practiceQuestionId],
                            ])->get();
                        return $question;
                    });

                    $userId = $user->userId;
                    $distinctAttempts[] = $distinctAttemptsRecord;
                    $distinctAttemptsCountNew = $practice_set_questions;
                }

                //}
                //  $user->distinctAttempts = $distinctAttemptsRecord;
                $user->distinctAttemptsCountNew = $practice_set_questions;
                $userAnswered = [];
                if (isset($practice_set_questions)) {
                    foreach ($practice_set_questions as $key => $val) {
                        $arrVal = true;
                        $newUserArr;
                        foreach ($distinctAttemptsRecord as $ansVal) {
                            if (isset($ansVal->lessonNo)) {
                                if ($val->lesson_no == $ansVal->lessonNo) {
                                    $newUserArr = $ansVal;
                                    $arrVal = false;
                                }
                            }
                        }
                        if ($arrVal) {
                            $userAnswered[] = [];
                        } else {
                            $userAnswered[]   = $newUserArr;
                        }
                    }
                }

                $user->userAnswered  = $userAnswered;
            }
            $employee = Employee::where('userId', $user->userId)->first();
            $user->email = $user->userId;

            if (isset($employee)) {
                $user->FirstName = $employee->FirstName ? $employee->FirstName : '';
                $user->LastName = $employee->LastName;
            }
            $allUser[] = $user;
        }
        return ['success' => 'Email sent', 'questions' => $all_users[0]->distinctAttemptsCountNew, 'users' => $allUser];

        // return [$all_users];

    }

    public function cohortExport($cohortId, $summary)
    {
        if ($summary == 'Summary') {
            $cohorts = Cohort::where('company_code', $cohortId)->where('type_id', 3)->get();

            // get users count for cohort
            $allData = [];


            foreach ($cohorts as $cohort) {
                if ($cohort->type_id != '4') {
                    $cohort->users = Course::select('userId')->distinct('userId')
                        ->join('employeecourse', 'courses.courseNumber', "=", "employeecourse.courseNumber")
                        ->where('cohort_id', $cohort->id)
                        ->get();
                    $cohort->CohortPracticeSet = CohortPracticeSet::select('practiceSetId')->where('cohortId', $cohort->id)->get();
                    $questionId = [];
                    if (count($cohort->CohortPracticeSet) > 0) {

                        foreach ($cohort->CohortPracticeSet as $val) {
                            $questionId[] = $val['practiceSetId'];
                        }
                    }
                    $practiceQuestions = [];
                    if (count($questionId) > 0) {

                        $practiceQuestions = PracticeQuestion::where('practiceSetId', $questionId[0])->orderBy('practiceQuestionId')->get();
                    }
                    $cohort->quesionCount = count($practiceQuestions);


                    $cohort->allIds = count($cohort->users);
                    $countAllUsers = count($cohort->users);


                    // get users count for cohort

                    // return response()->json($users);
                    $allUser = [];

                    // $distinctAttempts=[];
                    // $user=[];
                    $userLessPecentage = [];
                    $userBetweenPecentage = [];
                    $userGreaterPecentage = [];
                    foreach ($cohort->users as $user) {

                        $distinctAttemptsCount = InterviewVideo::select('moduleNo')
                            ->where([
                                ['userId', $user->userId],
                            ])
                            ->groupBy('moduleNo', 'routeNo', 'lessonNo')->get();

                        // $findUnique = array();
                        //     if(count($distinctAttemptsCount) > 0){
                        //         foreach($distinctAttemptsCount as $val){
                        //             $findUnique[] = $val['moduleNo'];
                        //     }
                        //   }
                        // $CohortPracticeSet = CohortPracticeSet::select('practiceSetId')->where('cohortId', $cohortId)->get();
                        // if(count($findUnique) > 0){
                        // foreach(array_unique($findUnique) as $key=>$val){
                        //     $CohortPracticeCount = CohortPracticeSet::select('practiceSetId')->where('practiceSetId', $val)->where('cohortId', $cohortId)->get();
                        //     if(count($CohortPracticeCount)>0){
                        //     //total attempts
                        //         $distinctAttempts = InterviewVideo::distinct('routeNo', 'lessonNo')
                        //         ->where([
                        //             ['userId', $user->userId],
                        //         ])
                        //         ->where([
                        //             ['moduleNo', $val],
                        //         ])
                        //         ->groupBy('moduleNo','routeNo','lessonNo')->get();

                        //         // get the total attempts by the user
                        //         $totalAttempts = InterviewVideo::where([
                        //             ['userId', $user->userId]
                        //         ])->where([
                        //                 ['moduleNo', $val],
                        //             ])
                        //             ->get();

                        //             $Asked_for_Review =  DB::select('select `instructor_reviews`.`videoId` from `interview_videos` inner join `instructor_reviews` on `interview_videos`.`uuid` = `instructor_reviews`.`videoId`
                        //             where (`interview_videos`.`userId` = "'.$user->userId.'") AND (`interview_videos`.`moduleNo` = "'.$val.'")');

                        //             $Reviews_Completed =  DB::select('select `instructor_reviews`.`videoId` from `interview_videos` inner join `instructor_reviews` on `interview_videos`.`uuid` = `instructor_reviews`.`videoId`
                        //             where (`interview_videos`.`userId` = "'.$user->userId.'") AND (`interview_videos`.`moduleNo` = "'.$val.'") AND (`instructor_reviews`.`reviewCompleted` = "1")');


                        //             $vpi_score = InterviewVideo::select('vpi_score')->where([
                        //                 ['userId', $user->userId]
                        //             ])->where([
                        //                     ['moduleNo', $val],
                        //                 ])
                        //                 ->get();
                        //                     $vpiValArray = [];
                        //                     foreach($vpi_score as $vpiVal){
                        //                         if(!empty($vpiVal['vpi_score'])){
                        //                             $vpiValArray[] = $vpiVal['vpi_score'];
                        //                         }

                        //                     }


                        //         $Practice_Answer =   StudentPracticeAnswer::where('userId', $user->userId)
                        //         ->where('practiceSetId', $val)->get();


                        //         $practice_set = PracticeSet::where('practiceSetId', $val)->first();
                        //         $userId = $user->userId;
                        //         $practice_set_questions = $practice_set->questions()->orderBy('practiceQuestionId')->get()->map(function ($question) use ($userId) {
                        //             $question->long_description = $question->practiceSetQuestion;
                        //             $question->routeno = 0;
                        //             $question->lesson_no = $question->practiceQuestionId;

                        //             $question->completed = \App\InterviewVideo::where([
                        //                 ['moduleNo', $question->practiceSetId],
                        //                 ['routeNo', 0],
                        //                 ['lessonNo', $question->practiceQuestionId],
                        //                 ['userId', $userId],
                        //             ])->exists();

                        //             $question->tldrs = \App\PracticeQuestionTldr::select(['title', 'description'])
                        //                 ->where([
                        //                     ['practiceSetId', $question->practiceSetId],
                        //                     ['practiceQuestionId', $question->practiceQuestionId],
                        //                 ])->get();
                        //             return $question;
                        //         });
                        //     }


                        // }

                        // $distinctAttemptsCountNew[] = count($practice_set_questions);
                        $user->distinctAttemptsCount = count($distinctAttemptsCount);
                        if (count($distinctAttemptsCount) > 0) {
                            $userPecentage = number_format((count($distinctAttemptsCount) * 100) / count($practiceQuestions), 2, '.', '');
                            if (floatval($userPecentage) <= 50) {
                                $userLessPecentage[] = $userPecentage;
                            }
                            if (floatval($userPecentage) > 50 && floatval($userPecentage) <= 80) {
                                $userBetweenPecentage[] = $userPecentage;
                            }
                            if (floatval($userPecentage) > 80) {
                                $userGreaterPecentage[] = $userPecentage;
                            }
                        } else {
                            $userLessPecentage[] = 0;
                        }
                        $user->userLessPecentage = $userLessPecentage;
                        $user->userBetweenPecentage = $userBetweenPecentage;
                        $user->userGreaterPecentage = $userGreaterPecentage;
                        $user->countAllUsers = $countAllUsers;

                        // get the total attempts by the user

                        // if(isset($user)){
                        $allUser[] = $user;
                        // }else{
                        //     $allUser[] = [];

                        // }

                        //}
                        foreach ($allUser as $valArry) {
                            $userLess = number_format((count($valArry->userLessPecentage) * 100) / $valArry->countAllUsers, 2, '.', '');
                            $cohort->userLessPecentage = $userLess;

                            $userBetween = number_format((count($valArry->userBetweenPecentage) * 100) / $valArry->countAllUsers, 2, '.', '');
                            $cohort->userBetweenPecentage = $userBetween;

                            $userGreater = number_format((count($valArry->userGreaterPecentage) * 100) / $valArry->countAllUsers, 2, '.', '');
                            $cohort->userGreaterPecentage = $userGreater;
                        }
                        $cohort->user = $allUser;
                    }
                    // get user ids

                    $userIds = $cohort->users->map(function ($user) {

                        return $user->userId;
                    });
                }
            }

            return [$cohorts];
        } else {
            // get users count for cohort
            $all_users = Course::select('userId', 'employeecourse.courseNumber', 'manual_rating')->distinct('userId')
                ->join('employeecourse', 'courses.courseNumber', "=", "employeecourse.courseNumber")
                ->where('cohort_id', $cohortId)
                ->get();
            // return response()->json($users);
            $allUser = [];

            $distinctAttemptsCountNew = [];
            $countAskReview = array();
            $vpi_scores = array();
            $vpi_score = array();
            $Reviews_Completed_count = array();
            $Practice_Answer_count = array();
            $distinctAttempts = [];
            $totalAttempts = [];
            $practice_set_questions = [];
            $Asked_for_Review = [];
            $Reviews_Completed = [];
            $Practice_Answer = [];
            $user = [];
            foreach ($all_users as $user) {
                $employee = Employee::where('userId', $user->userId)->first();
                $user->email = $user->userId;
                if (isset($employee)) {
                    $user->FirstName = $employee->FirstName ? $employee->FirstName : '';
                    $user->LastName = $employee->LastName;
                }
                $user->courseNumber = $user->courseNumber;
                $user->manual_rating = $user->manual_rating;


                $distinctAttemptsCount = InterviewVideo::select('moduleNo')
                    ->where([
                        ['userId', $user->userId],
                    ])
                    ->groupBy('moduleNo', 'routeNo', 'lessonNo')->get();

                $findUnique = array();
                if (count($distinctAttemptsCount) > 0) {
                    foreach ($distinctAttemptsCount as $val) {
                        $findUnique[] = $val['moduleNo'];
                    }
                }
                $CohortPracticeSet = CohortPracticeSet::select('practiceSetId')->where('cohortId', $cohortId)->get();
                if (count($findUnique) > 0) {
                    $distinctAttemptsCountNew = array();
                    $countAskReview = array();
                    $vpi_scores = array();
                    $Reviews_Completed_count = array();
                    $Practice_Answer_count = array();
                    $distinctAttemptsAnswered = [];
                    foreach (array_unique($findUnique) as $key => $val) {
                        $CohortPracticeCount = CohortPracticeSet::select('practiceSetId')->where('practiceSetId', $val)->where('cohortId', $cohortId)->get();
                        if (count($CohortPracticeCount) > 0) {
                            //total attempts
                            $distinctAttempts = InterviewVideo::distinct('routeNo', 'lessonNo')
                                ->where([
                                    ['userId', $user->userId],
                                ])
                                ->where([
                                    ['moduleNo', $val],
                                ])
                                ->groupBy('moduleNo', 'routeNo', 'lessonNo')->get();

                            // get the total attempts by the user
                            $totalAttempts = InterviewVideo::where([
                                ['userId', $user->userId]
                            ])->where([
                                ['moduleNo', $val],
                            ])
                                ->get();

                            $Asked_for_Review =  DB::select('select `instructor_reviews`.`videoId` from `interview_videos` inner join `instructor_reviews` on `interview_videos`.`uuid` = `instructor_reviews`.`videoId`
                                where (`interview_videos`.`userId` = "' . $user->userId . '") AND (`interview_videos`.`moduleNo` = "' . $val . '")');

                            $Reviews_Completed =  DB::select('select `instructor_reviews`.`videoId` from `interview_videos` inner join `instructor_reviews` on `interview_videos`.`uuid` = `instructor_reviews`.`videoId`
                                where (`interview_videos`.`userId` = "' . $user->userId . '") AND (`interview_videos`.`moduleNo` = "' . $val . '") AND (`instructor_reviews`.`reviewCompleted` = "1")');


                            $vpi_score = InterviewVideo::select('vpi_score')->where([
                                ['userId', $user->userId]
                            ])->where([
                                ['moduleNo', $val],
                            ])
                                ->get();
                            $vpiValArray = [];
                            foreach ($vpi_score as $vpiVal) {
                                if (!empty($vpiVal['vpi_score'])) {
                                    $vpiValArray[] = $vpiVal['vpi_score'];
                                }
                            }


                            $Practice_Answer =   StudentPracticeAnswer::where('userId', $user->userId)
                                ->where('practiceSetId', $val)->get();


                            $practice_set = PracticeSet::where('practiceSetId', $val)->first();
                            $userId = $user->userId;
                            $practice_set_questions = $practice_set->questions()->orderBy('practiceQuestionId')->get()->map(function ($question) use ($userId) {
                                $question->long_description = $question->practiceSetQuestion;
                                $question->routeno = 0;
                                $question->lesson_no = $question->practiceQuestionId;

                                $question->completed = \App\InterviewVideo::where([
                                    ['moduleNo', $question->practiceSetId],
                                    ['routeNo', 0],
                                    ['lessonNo', $question->practiceQuestionId],
                                    ['userId', $userId],
                                ])->exists();

                                $question->tldrs = \App\PracticeQuestionTldr::select(['title', 'description'])
                                    ->where([
                                        ['practiceSetId', $question->practiceSetId],
                                        ['practiceQuestionId', $question->practiceQuestionId],
                                    ])->get();
                                return $question;
                            });

                            $distinctAttemptsAnswered[] = $distinctAttempts;
                            $distinctAttemptsCountNew[] = $practice_set_questions;
                        }
                    }

                    if (count($distinctAttemptsAnswered) > 0) {
                        $distinctAttempts = $distinctAttemptsAnswered[0];
                    } else {
                        $distinctAttempts = [];
                    }
                    // $user->distinctAttemptsCount = array_sum($distinctAttemptsCount);

                    if (count($distinctAttemptsCountNew) > 0) {
                        $distinctAttemptsCountNew = $distinctAttemptsCountNew[0];
                    } else {
                        $distinctAttemptsCountNew = [];
                    }

                    // $distinctAttemptsCountNew = count($practice_set_questions);
                    $countAskReview[] = $Asked_for_Review;
                    $Reviews_Completed_count[] = $Reviews_Completed;
                    // $vpi_scores[] = $vpi_score;
                    $Practice_Answer_count[] = count($Practice_Answer);
                    $user->vpi_score = $vpi_score;
                    $vpi_scores_data = [];
                    $vpi_scores_fluency_score = [];

                    foreach ($vpi_score as $vpiVal) {
                        if ($vpiVal['vpi_score'] != null) {
                            $vpi_scores_data[] = $vpiVal['vpi_score'];
                        }
                    }
                    if (count($vpi_scores_data) > 0) {
                        foreach ($vpi_scores_data as $vpiScores) {
                            $item_data_decode = json_decode($vpiScores, true);

                            $vpi_scores_fluency_score[] = $item_data_decode['fluency_score'];
                        }
                    }


                    $finalMaxMin = '';
                    if (count($vpi_scores_fluency_score) > 0) {

                        if (count($vpi_scores_fluency_score) == 1) {
                            $finalMaxMin = max($vpi_scores_fluency_score);
                        } else if (count($vpi_scores_fluency_score) > 1) {
                            $maxVal =  max($vpi_scores_fluency_score);
                            $minVal = min($vpi_scores_fluency_score);
                            $finalMaxMin = number_format(floatval($maxVal), 2, '.', '') . ' - ' . number_format(floatval($minVal), 2, '.', '');
                        }
                    }
                    if (count($vpi_scores_fluency_score) == 1) {
                        $user->vpi_scores_fluency_score = number_format(floatval($finalMaxMin), 2, '.', '');
                    } else {
                        $user->vpi_scores_fluency_score = $finalMaxMin;
                    }

                    $user->distinctAttempts = count($distinctAttemptsCountNew);
                    // $user->distinctAttemptsCount = array_sum($distinctAttemptsCount);
                    if (count($distinctAttempts) > 0) {
                        $user->distinctAttemptsCount = number_format((count($distinctAttempts) * 100) / count($distinctAttemptsCountNew), 2, '.', '');
                    }
                    // get the total attempts by the user

                    $user->totalAttempts = count($totalAttempts);

                    if (count($totalAttempts) > 0 && count($distinctAttemptsCountNew) > 0 && count($distinctAttemptsCountNew) > 0) {
                        $user->attemptsPerQuestion = number_format(count($totalAttempts) / count($distinctAttemptsCountNew), 2, '.', '');
                    }

                    $user->Asked_for_Review = count($countAskReview[0]);
                    if (count($countAskReview[0]) > 0 && count($distinctAttemptsCountNew) > 0) {
                        $user->reviewsRequested = number_format(count($countAskReview[0])  / count($distinctAttemptsCountNew));
                    }
                    $user->Reviews_Completed = count($Reviews_Completed_count[0]);
                    if (count($Reviews_Completed_count[0]) > 0 && count($distinctAttemptsCountNew) > 0) {
                        $user->percentage_reviews_completed = number_format(count($Reviews_Completed_count[0]) * 100 / count($distinctAttemptsCountNew), 2, '.', '');
                    }
                    $user->notes = $Practice_Answer_count[0];
                    if ($Practice_Answer_count[0] > 0 && count($distinctAttemptsCountNew) > 0) {
                        $user->percentageNotes = number_format($Practice_Answer_count[0] * 100 / count($distinctAttemptsCountNew), 2, '.', '');
                    }
                    $user->certificate = getCertificateIfExists($user->userId, $user->courseNumber);

                    // if(isset($user)){
                    $allUser[] = $user;
                    // }else{
                    //     $allUser[] = [];

                    // }

                }
            }
            return [$all_users];
        }
    }
    public function export(Request $request, $cohortId, $quizId)
    {
        $cohortName = Cohort::find($cohortId);
        $cohortName = $cohortName ? $cohortName->name : '';

        $quizName = QuizSet::where('quizSetId', $quizId)->first();
        $quizName = $quizName ? $quizName->quizTopic : '';

        $name = 'Report_' . $cohortName . '_' . $quizName . '_' . date("d-m-Y", time()) . '.xlsx';
        $filename = preg_replace('/\s+/', '_', $name);
        $user = \Auth::user();
        // $d =$this->ProctoredExport($cohortId,$quizId);
        // return \response()->json($d);
        $file = Excel::store(new UsersExport($cohortId, $quizId), $filename);
        \Mail::to($user->email)
            // \Mail::to('lkm1developer@gmail.com')
            ->send(new ExcelMail(
                $user->fullname,
                $user->email,
                $cohortName,
                $quizName,
                $filename
            ));
        return \response()->json(['status' => true, $filename, $quizName]);
    }

    public function ProctoredTestUserDetail(Request $request, $id)
    {

        $attempt = QuizAttemptLog::where('id', $id)
            ->with('resume')
            ->with('employee')
            ->get();
        foreach ($attempt as &$a) {
            $answer = json_decode($a->answerJSON, 1);
            $right = 0;
            $wrong = 0;
            $total = 0;

            foreach ($answer as &$ans) {
                $q = QuizSetQuestion::where([
                    'quizSetQuestionId' => $ans['quizSetQuestionId'],
                    'quizSetId' => $ans['quizSetId'],
                ])->first();
                $ans['q'] = $q && $q->questionText ?  $q->questionText : "";
                if ($ans['isAnswerCorrect']) {
                    $right++;
                } else {
                    $wrong++;
                }
                $total++;
            }
            // var_dump($answer);

            $a->answers = $answer;
            $a->right = $right;
            $a->wrong = $wrong;
            $a->total = $total;
            $a->percent = $total > 0 ? (($right / $total) * 100) : '';
            if ($a->resume && $a->resume->resumeContent) {
                $d = json_decode($a->resume->resumeContent);
                $a->resumeContent = $d;
            } else {
                $a->resumeContent = null;
            }
        }
        return [
            "data" => $attempt && $attempt[0] ? $attempt[0] : null
        ];
    }
    public function UnlockProctoredTest(Request $request)
    {
        $id = $request->post('id');
        $status = $request->post('status');
        if (!$id) {
            return [
                "data" => false
            ];
        }
        $attempt = QuizAttemptLog::where('id', $id)->update(['allowedReattempt' => $status]);
        return [
            "data" => true
        ];
    }
    public function QuizProctoredScore(Request $request, $cohort_id)
    {
        // get cohorts
        $cohort = Cohort::find($cohort_id);

        $cohort->users = Course::select('userId')->distinct('userId')
            ->join('employeecourse', 'courses.courseNumber', "=", "employeecourse.courseNumber")
            ->where('cohort_id', $cohort->id)
            ->get();

        // get user ids
        $userIds = $cohort->users->map(function ($user) {
            return $user->userId;
        });
        $quizSetIds = QuizSet::with('proctoredCohort')->get();
        $ids = [];
        foreach ($quizSetIds as $m) {
            if ($m->proctoredCohort) {
                $ids[] = $m->quizSetId;
            }
        }
        $quizAttemptUsers = QuizAttemptLog::whereIn('userId', $userIds)
            ->whereIn('quizSetId', $ids)
            ->where('attemptStatus', 1)
            ->with('QuizSet')
            ->orderBy('id', 'ASC')
            ->groupBy('userId', 'quizSetId')

            ->get();

        foreach ($quizAttemptUsers as &$item) {
            $answer = json_decode($item->answerJSON, 1);
            $right = 0;
            $wrong = 0;
            $total = 0;
            foreach ($answer as $ans) {
                if ($ans['isAnswerCorrect']) {
                    $right++;
                } else {
                    $wrong++;
                }
                $total++;
            }

            $item->right = $right;
            $item->wrong = $wrong;
            $item->total = $total;
            $item->percent = $total > 0 ? (($right / $total) * 100) : '';
        }

        // for each user get their attempt count
        return [
            "program" => $cohort,
            "userIds" => $userIds,
            "users" => $quizAttemptUsers
        ];
    }

    /**
     * GEt log for specific user
     *
     * @param Request $request
     * @param [type] $cohort_id
     * @return void
     */
    public function getCompanyCohortUserLogWhoAttemptedQuiz(Request $request, $cohort_id, $quizSetId, $userId)
    {
        // get cohorts
        $cohort = Cohort::find($cohort_id);

        $cohort->users = Course::select('userId')->distinct('userId')
            ->join('employeecourse', 'courses.courseNumber', "=", "employeecourse.courseNumber")
            ->where('cohort_id', $cohort->id)
            ->get();

        // get the employee
        $employee = Employee::where('userId', $userId)->first();

        //get the attempt
        $attempts = QuizAttemptLog::where([
            'userId' => $userId,
            'quizSetId' => $quizSetId,
        ])
            ->get();

        // for each user get their attempt count
        return [
            "program" => $cohort,
            "employee" => [
                "userId" => $employee->userId,
                "FirstName" => $employee->FirstName,
                "LastName" => $employee->LastName,
            ],
            "attempts" => AttemptLogResource::collection($attempts)
        ];
    }

    public function getCompanyCohortSingle(Request $request, $cohort_id)
    {
        // get cohorts
        $cohort = Cohort::find($cohort_id);

        // get users count for cohort
        $cohort->users = Course::select('userId')->distinct('userId')
            ->join('employeecourse', 'courses.courseNumber', "=", "employeecourse.courseNumber")
            ->where('cohort_id', $cohort->id)
            ->get()->map(function ($user) {
                // get firstname and last name
                $employee = Employee::where('userId', $user->userId)->first();

                $user->FirstName = $employee->FirstName;
                $user->LastName = $employee->LastName;

                // get total distinct attempt by the user
                $user->distinctAttempts = InterviewVideo::distinct('moduleNo', 'routeNo', 'lessonNo')
                    ->where([
                        ['userId', $user->userId]
                    ])->groupBy(['moduleNo', 'routeNo', 'lessonNo'])
                    ->count();
                // get the total attempts by the user
                $user->totalAttempts = InterviewVideo::where([
                    ['userId', $user->userId]
                ])->count();
                $user->Asked_for_Review = InstructorReview::where([
                    ['userId', $user->userId],
                ])->count();
                $user->Reviews_Completed = InstructorReview::where([
                    ['userId', $user->userId],
                    ['reviewCompleted', 1],
                ])->count();

                return $user;
            });

        // return response
        return response()->json([
            "message" => "Cohort",
            "program" => $cohort
        ]);
    }
    //add vpi Manual Rating
    public function addManualRating(Request $request)
    {
        $result = DB::table('employeecourse')
            ->where('userId', $request->data['email'])
            ->where('courseNumber', $request->data['courseNumber'])
            ->update([
                'manual_rating' => $request->data['manual_rating']
            ]);
        if (!$result) {
            return response()->json([
                "message" => "Request not found!",
                'result' => $result,
                'courseNumber' => $request->data['courseNumber'],
                'manual_rating' => $request->data['manual_rating'],
            ], 404);
        }
        // get cohorts

        return response()->json([
            "message" => "Updated successfully",
            "result" => $request->data['manual_rating'],
        ]);
    }
    public function getCompanyCohortSingleReport(Request $request, $cohort_id)
    {
        // get cohorts
        $cohort = Cohort::find($cohort_id);
        $startDate = $request->get('startDate');
        $endDate = $request->get('endDate');
        $startDate = new Carbon($startDate);
        $endDate = new Carbon($endDate);
        $dataSets = [];


        // get users count for cohort
        $users = Course::select('userId', 'employeecourse.courseNumber', 'manual_rating')->distinct('userId')
            ->join('employeecourse', 'courses.courseNumber', "=", "employeecourse.courseNumber")
            ->where('cohort_id', $cohort->id)
            ->get();
        // return response()->json($users);
        foreach ($users as $user) {
            $employee = Employee::where('userId', $user->userId)->first();
            if (isset($employee)) {
                $user->FirstName = $employee->FirstName ? $employee->FirstName : '';
                $user->LastName = $employee->LastName;
            }
            $user->courseNumber = $user->courseNumber;
            $user->manual_rating = $user->manual_rating;


            $distinctAttemptsCount = InterviewVideo::select('moduleNo')
                ->where([
                    ['userId', $user->userId],
                ])
                ->groupBy('moduleNo', 'routeNo', 'lessonNo')
                ->whereBetween('created_at', [$startDate->format('Y-m-d') . " 00:00:00", $endDate->format('Y-m-d') . " 23:59:59"])
                ->get();

            $findUnique = array();
            if (count($distinctAttemptsCount) > 0) {
                foreach ($distinctAttemptsCount as $val) {
                    $findUnique[] = $val['moduleNo'];
                }
            }
            $distinctAttempts = [];
            $distinctAttemptsAnswered = [];
            $distinctAttemptsCountNew = array();
            $totalAttempts = [];
            $countAskReview = array();
            $vpi_scores = array();
            $Reviews_Completed_count = array();
            $Practice_Answer_count = array();
            $vpi_score = [];
            $Asked_for_Review = null;
            $Reviews_Completed = null;
            $Practice_Answer = null;

            $CohortPracticeSet = CohortPracticeSet::select('practiceSetId')->where('cohortId', $cohort_id)->get();
            if (count($findUnique) > 0) {
                foreach (array_unique($findUnique) as $key => $val) {
                    $CohortPracticeCount = CohortPracticeSet::select('practiceSetId')->where('practiceSetId', $val)->where('cohortId', $cohort_id)->get();
                    if (count($CohortPracticeCount) > 0) {
                        //total attempts
                        $distinctAttempts = InterviewVideo::distinct('routeNo', 'lessonNo')
                            ->where([
                                ['userId', $user->userId],
                            ])
                            ->where([
                                ['moduleNo', $val],
                            ])
                            ->groupBy('moduleNo', 'routeNo', 'lessonNo')
                            ->whereBetween('created_at', [$startDate->format('Y-m-d') . " 00:00:00", $endDate->format('Y-m-d') . " 23:59:59"])
                            ->get();

                        // get the total attempts by the user
                        $totalAttempts = InterviewVideo::where([
                            ['userId', $user->userId]
                        ])->whereBetween('created_at', [$startDate->format('Y-m-d') . " 00:00:00", $endDate->format('Y-m-d') . " 23:59:59"])
                            ->where([
                                ['moduleNo', $val],
                            ])
                            ->get();

                        $Asked_for_Review =  DB::select('select `instructor_reviews`.`videoId` from `interview_videos` inner join `instructor_reviews` on `interview_videos`.`uuid` = `instructor_reviews`.`videoId`
                                where (`interview_videos`.`userId` = "' . $user->userId . '") AND (`interview_videos`.`moduleNo` = "' . $val . '") AND (`interview_videos`.`created_at` between "' . $startDate->format('Y-m-d') . ' 00:00:00" and "' . $endDate->format('Y-m-d') . ' 23:59:59")');

                        $Reviews_Completed =  DB::select('select `instructor_reviews`.`videoId` from `interview_videos` inner join `instructor_reviews` on `interview_videos`.`uuid` = `instructor_reviews`.`videoId`
                                where (`interview_videos`.`userId` = "' . $user->userId . '") AND (`interview_videos`.`moduleNo` = "' . $val . '") AND (`instructor_reviews`.`reviewCompleted` = "1")');


                        $vpi_score = InterviewVideo::select('vpi_score')->where([
                            ['userId', $user->userId]
                        ])->whereBetween('created_at', [$startDate->format('Y-m-d') . " 00:00:00", $endDate->format('Y-m-d') . " 23:59:59"])
                            ->where([
                                ['moduleNo', $val],
                            ])
                            ->get();
                        $vpiValArray = [];
                        foreach ($vpi_score as $vpiVal) {
                            if (!empty($vpiVal['vpi_score'])) {
                                $vpiValArray[] = $vpiVal['vpi_score'];
                            }
                        }


                        $Practice_Answer =   StudentPracticeAnswer::where('userId', $user->userId)
                            ->where('practiceSetId', $val)
                            ->whereBetween('updated_at', [$startDate->format('Y-m-d') . " 00:00:00", $endDate->format('Y-m-d') . " 23:59:59"])
                            ->get();
                        $practice_set = PracticeSet::where('practiceSetId', $val)->first();
                        $userId = $user->userId;
                        $practice_set_questions = $practice_set->questions()->orderBy('practiceQuestionId')->get()->map(function ($question) use ($userId) {
                            $question->long_description = $question->practiceSetQuestion;
                            $question->routeno = 0;
                            $question->lesson_no = $question->practiceQuestionId;
                            $question->completed = \App\InterviewVideo::where([
                                ['moduleNo', $question->practiceSetId],
                                ['routeNo', 0],
                                ['lessonNo', $question->practiceQuestionId],
                                ['userId', $userId],
                            ])->exists();

                            $question->tldrs = \App\PracticeQuestionTldr::select(['title', 'description'])
                                ->where([
                                    ['practiceSetId', $question->practiceSetId],
                                    ['practiceQuestionId', $question->practiceQuestionId],
                                ])->get();
                            return $question;
                        });
                        $distinctAttemptsAnswered[] = $distinctAttempts;
                        $distinctAttemptsCountNew[] = $practice_set_questions;
                    }
                }
                // $distinctAttemptsCountNew[] = $practice_set_questions->count();
                $countAskReview[] = $Asked_for_Review;
                $Reviews_Completed_count[] = $Reviews_Completed;
                $vpi_scores[] = $vpi_score;
                $Practice_Answer_count[] = $Practice_Answer ? $Practice_Answer->count() : 0;
            }
            if (count($distinctAttemptsAnswered) > 0) {
                $user->distinctAttempts = count($distinctAttemptsAnswered[0]);
            } else {
                $user->distinctAttempts = 0;
            }
            // $user->distinctAttemptsCount = array_sum($distinctAttemptsCount);
            if (count($distinctAttemptsCountNew) > 0) {
                $user->distinctAttemptsCount = count($distinctAttemptsCountNew[0]);
            } else {
                $user->distinctAttemptsCount = 0;
            }
            // get the total attempts by the user
            $user->totalAttempts = count($totalAttempts);
            $user->vpi_score = $vpi_score;
            $vpi_scores_data = [];
            $vpi_scores_fluency_score = [];
            foreach ($vpi_score as $vpiVal) {
                if ($vpiVal['vpi_score'] != null) {
                    $vpi_scores_data[] = $vpiVal['vpi_score'];
                }
            }
            if (count($vpi_scores_data) > 0) {
                foreach ($vpi_scores_data as $vpiScores) {
                    $item_data_decode = json_decode($vpiScores, true);

                    $vpi_scores_fluency_score[] = $item_data_decode['fluency_score'];
                }
            }

            $finalMaxMin = '';
            if (count($vpi_scores_fluency_score) > 0) {

                if (count($vpi_scores_fluency_score) == 1) {
                    $finalMaxMin = max($vpi_scores_fluency_score);
                } else if (count($vpi_scores_fluency_score) > 1) {
                    $finalMaxMin = max($vpi_scores_fluency_score) . ' - ' . min($vpi_scores_fluency_score);
                }
            }
            $user->vpi_scores_fluency_score = $finalMaxMin;
            $user->Asked_for_Review = $countAskReview;
            $user->Reviews_Completed = $Reviews_Completed_count;
            $user->Practice_Answer = $Practice_Answer_count;
            $user->certificate = getCertificateIfExists($user->userId, $user->courseNumber);
        }

        // return response
        return response()->json([
            "message" => "Cohort",
            "program" => $cohort,
            "users" => $users,
            "dataSets" => []
        ]);
    }
    public function getCohort(Request $request, $cohort_id)
    {
        $cohort = \App\Cohort::find($cohort_id);

        // cohort
        if (!$cohort) {
            return response()->json([
                "message" => "Cohort not found!"
            ], 404);
        }
        return response()->json($cohort, 200);
    }
    public function updateCohort(Request $request, $cohort_id)
    {
        $cohort = \App\Cohort::find($cohort_id);

        // cohort
        if (!$cohort) {
            return response()->json([
                "message" => "Cohort not found!"
            ], 404);
        }
        $postData = $request->post();
        $cohort = $cohort->update($postData);
        return response()->json($cohort, 200);
    }

    public function getCohortDetail(Request $request, $cohort_id)
    {
        // get cohort
        $cohort = \App\Cohort::find($cohort_id);

        // cohort
        if (!$cohort) {
            return response()->json([
                "message" => "Cohort not found!"
            ], 404);
        }

        $levels = [];

        // get program for cohort
        $program = $cohort->program;
        if (!$program) {
            return $cohort;
        }
        $program->cohort_name = $cohort->name;

        $modules = $program->modules()->orderBy('level_number')->orderBy('sort_order')->get();

        // get all modules and make levels
        foreach ($modules as $module) {
            // check if level array there, create if not
            if (!isset($levels[$module->level_number])) {
                $levels[$module->level_number] = [];
            }
            // check if certification available
            $course = getCourseNoByCohortIdAndModuleNumber($cohort->id, $module->module_number, true);
            $module->course_number = $course->courseNumber;
            $module->description = $module->module ? $module->module->description : null;
            $module->courseStartDate = $course->courseStartDate;
            $module->courseEndDate = $course->courseEndDate;
            $module->long_description = $module->module ? $module->module->long_description : null;
            $module->totalLessons = getLessonCountForModule($module->module_number);

            // add users to module
            $module->users = \DB::table('employeecourse')
                ->select('userId')
                ->where('courseNumber', $module->course_number)
                ->get()
                ->map(function ($user) use ($course) {
                    $user->completed = getCertificateIfExists($user->userId, $course->courseNumber) ? true : false;
                    return $user;
                });
            // add users completed status to module

            unset($module->module);
            // add to level
            $levels[$module->level_number][] = $module;
        }

        // restructure the level
        $levels = array_values(array_map(function ($modules) {
            return [
                "level_number" => $modules[0]->level_number,
                "modules" => $modules
            ];
        }, $levels));


        $program->levels = $levels;
        unset($program->modules);
        $program->startDate = $cohort->start_date;
        $program->exam_start_time = $cohort->exam_start_time;
        $program->exam_end_time = $cohort->exam_end_time;
        $program->instructorEmails = $cohort->instructorEmails;
        $program->instructorReviewsOnly = $cohort->instructorReviewsOnly;
        return $program;
    }


    /**
     * register user to cohort
     *
     * @param Request $request
     * @param [type] $cohort_id
     * @return void
     */
    public function registerUserToCohort(Request $request)
    {
        $this->validate($request, [
            'cohort_id' => 'required|exists:cohorts,id',
            'email' => 'required|email',
            'FirstName' => 'nullable|string',
            'LastName' => 'nullable|string',
            'mobile' => 'nullable|numeric|digits:10',
            'location' => 'nullable|string',
        ]);

        $cohort = Cohort::find($request->cohort_id);

        $program = $cohort->program;
        $companyName = $cohort->company->Name;
        $companyId = $cohort->company->Id;

        if ($cohort->senderEmail) {
            $senderEmail = $cohort->senderEmail;
        } else {
            $senderEmail = 'test@taplingua.com';
        }

        // get the module
        $module = $program->first_module;
        $type_id = $cohort->type_id;
        $vpi_value = $cohort->vpi_value;
        $cohortName = $cohort->name;
        $course = $cohort->getCourseByModuleNo($module->moduleno);
        // return response()->json(['a'=>$cohort, 'b'=>$program, 'c'=>$module,'d'=>$company]);
        try {
            // create an employee with the information
            $employee = \App\Employee::where('userId', $request->email)->first();        // check employee companyCode

            if (!$employee) {
                // check if mobile already token
                // if (\App\Employee::where('Mobile', $request->mobile)->exists()) {
                //     return response()->json([
                //         "message" => "Validator error!",
                //         "errors" => [
                //             "mobile" => ["Mobile already taken by other user!"]
                //         ]
                //     ]);
                // }

                $employee = \App\Employee::create([
                    'currentCourse' => $course->courseNumber,
                    'currentModule' => $course->moduleNumber,
                    'CompanyCode' => $course->Company,
                    'FirstName' => $request->FirstName ?? "",
                    'LastName' => $request->LastName ?? "",
                    'userId' => $request->email,
                    'Mobile' => $request->mobile ?? "",
                    'Location' => $request->location ?? "",
                    'accountCreationDate' => now(),
                    'subscriptionExpires' => now()->addDays(15),
                ]);
            }

            // for each cohort module register user if not already registered
            $userRegisteredToCohortFirstTime = false;
            foreach ($program->modules as $module) {
                // the module related course
                $moduleCourse = $cohort->getCourseByModuleNo($module->module_number);
                // check if course already there
                $courseSubscribed = \DB::table('employeecourse')->where('userId', $employee->userId)
                    ->where('courseNumber', $moduleCourse->courseNumber)->first();
                if ($courseSubscribed) {
                    //  do nothing
                    // return redirect()->back()->withInput()->with('error', 'Course already subscribed to!');
                } else {
                    // assign the employee to the said course
                    \DB::table('employeecourse')->insert([
                        'dateRegistered' => now(),
                        'userId' => $employee->userId,
                        'courseNumber' => $moduleCourse->courseNumber,
                    ]);
                    $userRegisteredToCohortFirstTime = true;
                }
            }

            $password = substr(md5(now()), 0, 8);
            // $password = 100;

            // get the user
            $user = \App\User::where('email', $employee->userId)->first();

            if (!$user) {
                // create the user
                $user = \App\User::create([
                    "email" => $employee->userId,
                    "fullname" => $employee->FirstName . " " . $employee->LastName,
                    "password" => bcrypt($password),
                    'token' => md5($employee->userId . time()),
                    'uid' => uniqid(),
                    'accesslevel' => 0
                ]);
                $isNewUser = true;
                // send mail
                if ($vpi_value == 1) {
                    \Mail::to($employee->userId)
                        ->send(new VpiEmployeeWelcomeEmail(
                            $user->fullname,
                            $module->description,
                            $employee->userId,
                            $password,
                            $type_id,
                            $companyName,
                            $companyId,
                            $senderEmail,
                            $cohortName
                        ));
                    // Send SMS
                    sendSMS("+91" . $request->mobile, "Hi " . $request->FirstName . "
                    \nYour taplingua account has been created.
                    \nPlease download the Taplingua Language app:
                    \nhttps://play.google.com/store/apps/details?id=com.taplingua.languages
                    \nPlease check your email for account login details.
                    \nThanks
                    \nTaplingua Team");
                } else {
                    \Mail::to($employee->userId)
                        ->send(new EnrolledEmployeeWelcomeEmail(
                            $user->fullname,
                            $module->description,
                            $employee->userId,
                            $password,
                            $type_id,
                            $companyName,
                            $companyId,
                            $senderEmail,
                            $cohortName
                        ));

                    // Send SMS
                    sendSMS("+91" . $request->mobile, "Hi " . $request->FirstName . "
                \nYour taplingua account has been created.
                \nPlease download the Taplingua Language app:
                \nhttps://play.google.com/store/apps/details?id=com.taplingua.languages
                \nPlease check your email for account login details.
                \nThanks
                \nTaplingua Team");
                }
            } else {

                if ($vpi_value == 1) {
                    \Mail::to($employee->userId)
                        ->send(new VpiEmployeeWelcomeEmail(
                            $user->fullname,
                            $module->description,
                            $employee->userId,
                            '',
                            $type_id,
                            $companyName,
                            $companyId,
                            $senderEmail,
                            $cohortName
                        ));
                    // Send SMS
                    sendSMS("+91" . $request->mobile, "Hi " . $request->FirstName . "
                    \nYour taplingua account has been created.
                    \nPlease download the Taplingua Language app:
                    \nhttps://play.google.com/store/apps/details?id=com.taplingua.languages
                    \nPlease check your email for account login details.
                    \nThanks
                    \nTaplingua Team");
                } else {
                    // send mail anyway
                    Mail::to($employee->userId)
                        ->send(new EnrolledEmployeeWelcomeEmail(
                            $user->fullname,
                            $module->description,
                            $employee->userId,
                            '',
                            $type_id,
                            $companyName,
                            $companyId,
                            $senderEmail,
                            $cohortName
                        ));

                    // Send SMS
                    sendSMS("+91" . $request->mobile, "Hi " . $request->FirstName . "
                    \nYou are registered to a new course.
                    \nPlease download the Taplingua Language app:
                    \nhttps://play.google.com/store/apps/details?id=com.taplingua.languages
                    \nThanks
                    \nTaplingua Team");
                }
            }

            event(new UserAddedToCohort($employee->userId, $cohort->id));

            // QUICKBLOX: add user to group - start
            try {
                \App\Services\QuickBlox::createUserIfNeededAndAddToGroup($cohort->id, $employee->userId);
            } catch (\Throwable $th) {
                \Log::error("Could not add user to quickblox!", [$th]);
            }
            // QUICKBLOX: add user to group - end

            // return success message
            return redirect()->to('/app/employee-course-registration-success')->with('message', 'Thanks for registering for the ' . $cohort->name);
        } catch (\Throwable $th) {
            \Log::error("Could not register user to course!", [$th]);
            return redirect()->back()->withInput()->with('error', 'Registered to course ' . $cohort->name . ' failed!')
                ->with('debug', $th->getMessage());
        }
    }


    /**
     * register user to cohort
     *
     * @param Request $request
     * @param [type] $cohort_id
     * @return void
     */
    public function registerUserToCohortUsingCSV(Request $request)
    {

        $request->validate([
            "cohort_id" => "required|exists:cohorts,id",
            "csv" => "required|mimes:csv,txt"
        ]);

        // read csv
        $csv = \League\Csv\Reader::createFromPath($request->csv->getPathName(), 'r');
        $csv->setHeaderOffset(0);
        $header = $csv->getHeader();
        $records = $csv->getRecords();

        $successful = 0;
        $response = [];

        $cohort = Cohort::find($request->cohort_id);

        foreach ($records as $record) {
            $result = $this->registerUserToManagedCohortUsingData([
                'cohort_id' => $request->cohort_id,
                'email' => $record['Email'],
                'FirstName' => $record['FirstName'],
                'LastName' => $record['LastName'],
                'mobile' => $record['PhoneNumber'],
                'location' => $record['Location'],
                'password' => (int) $cohort->company_code == 155 ? 100 : null,
            ]);
            $response[] = $result;
            if ($result['status']) {
                $successful++;
            }
        }

        return response()->json([
            'records' => $records,
            'successful' => $successful,
            "results" => $response
        ]);
    }

    public function registerUserToUnmanagedCohortView(Request $request, $company_code = null, $program_id = null)
    {
        $program = Program::find($program_id);

        $company = Company::where("Id", $company_code)->first();

        if (!$program) {
            abort(404, "Course No Missing");
        }

        if (!$company) {
            abort(404, "Company No Missing");
        }

        return view('app.employee-unmanaged-cohort-registration-form', [
            'program' => $program,
            'company' => $company,
        ]);
    }

    public function registerUserToUnmanagedCohortView2(Request $request)
    {
        return view('app.employee-unmanaged-cohort-registration-form', [
            'program' => null,
            'company' => null,
        ]);
    }

    // gateflix form
    public function registerUserToUnmanagedCohortViewGateflix(Request $request, $company_code)
    {

        $company = Company::where("Id", $company_code)->first();

        $company_name = $company->Name;

        if (!$company) {
            return abort(404);
        }

        return view('app.employee-unmanaged-cohort-registration-page.gateflix', compact('company_code', 'company_name'));
    }

    /**
     * Register user to unmanaged progrm, will create the cohort on the go
     *
     * @param Request $request
     * @param [type] $company_code
     * @param [type] $program_id
     * @return void
     */
    public function registerUserToUnmanagedCohort(Request $request)
    {
        $this->validate($request, [
            'program_id' => 'required|exists:programs,id',
            'company_code' => 'required|exists:company,Id',
            'email' => 'required|email',
            'FirstName' => 'nullable|string',
            'LastName' => 'nullable|string',
            'mobile' => 'nullable|numeric|digits:10',
            'location' => 'nullable|string',
        ]);

        $program_id = $request->program_id;
        $company_code = $request->company_code;

        // get program
        $program = Program::find($program_id);

        // get company
        $company = Company::where("Id", $company_code)->first();
        $senderEmail = $company = $company->Email;
        // check if any cohort for curretn user already there
        $cohortAlreadyExists = Cohort::distinct('userId')
            ->join("courses", "courses.cohort_id", "=", 'cohorts.id')
            ->join("employeecourse", "employeecourse.courseNumber", "=", "courses.courseNumber")
            ->where("program_id", $program_id)
            ->where("company_code", $company_code)
            ->where("employeecourse.userId", $request->email)
            ->exists();

        // get the module
        $module = $program->first_module;

        if ($cohortAlreadyExists) {
            // send mail anyway
            Mail::to($request->email)
                ->send(new EnrolledEmployeeWelcomeEmail(
                    $request->FirstName,
                    $module->description,
                    $request->email,
                    "",
                    "",
                    "",
                    "",
                    $senderEmail,
                    ""
                ));

            // Send SMS
            sendSMS("+91" . $request->mobile, "Hi " . $request->FirstName . "
                    \nYou are registered to a new course.
                    \nPlease download the Taplingua Language app:
                    \nhttps://play.google.com/store/apps/details?id=com.taplingua.languages
                    \nThanks
                    \nTaplingua Team");
            // return success message
            return redirect()->to('/app/employee-course-registration-success')->with('message', 'Thanks for registering for the ' . $program->name);
        }

        // get employee with the information
        $employee = \App\Employee::where('userId', $request->email)->first();

        // check employee companyCode
        if ($employee && $employee->CompanyCode !== $company_code) {
            return redirect()->back()->withInput()->with('error', 'The email is registered to another company.!');
        }

        // create cohort for this program
        $cohort = $this->createCohortFromCompanyCodeAndProgramId($program->id, $company->Id, null, null, true);

        // get the module
        $module = $program->first_module;

        $course = $cohort->getCourseByModuleNo($module->moduleno);

        try {

            if (!$employee) {
                // check if mobile already token
                if (\App\Employee::where('Mobile', $request->mobile)->exists()) {
                    return response()->json([
                        "message" => "Validator error!",
                        "errors" => [
                            "mobile" => ["Mobile already taken by other user!"]
                        ]
                    ]);
                }

                $employee = \App\Employee::create([
                    'currentCourse' => $course->courseNumber,
                    'currentModule' => $course->moduleNumber,
                    'CompanyCode' => $course->Company,
                    'FirstName' => $request->FirstName ?? "",
                    'LastName' => $request->LastName ?? "",
                    'userId' => $request->email,
                    'Mobile' => $request->mobile ?? "",
                    'Location' => $request->location ?? "",
                    'accountCreationDate' => now(),
                    'subscriptionExpires' => now()->addDays(15),
                    'utm_source' => 'unmanaged-view'
                ]);
            }

            // for each cohort module register user if not already registered
            foreach ($program->modules as $module) {
                // the module related course
                $moduleCourse = $cohort->getCourseByModuleNo($module->module_number);
                // check if course already there
                $courseSubscribed = \DB::table('employeecourse')->where('userId', $employee->userId)
                    ->where('courseNumber', $moduleCourse->courseNumber)->first();
                if ($courseSubscribed) {
                    //  do nothing
                    // return redirect()->back()->withInput()->with('error', 'Course already subscribed to!');
                } else {
                    // assign the employee to the said course
                    \DB::table('employeecourse')->insert([
                        'dateRegistered' => now(),
                        'userId' => $employee->userId,
                        'courseNumber' => $moduleCourse->courseNumber,
                    ]);
                }
            }

            $password = substr(md5(now()), 0, 8);

            // get the user
            $user = \App\User::where('email', $employee->userId)->first();

            if (!$user) {
                // create the user
                $user = \App\User::create([
                    "email" => $employee->userId,
                    "fullname" => $employee->FirstName . " " . $employee->LastName,
                    "password" => bcrypt($password),
                    'token' => md5($employee->userId . time()),
                    'uid' => uniqid(),
                    'accesslevel' => 0
                ]);
                $isNewUser = true;
                // send mail
                \Mail::to($employee->userId)
                    ->send(new EnrolledEmployeeWelcomeEmail(
                        $user->fullname,
                        $module->description,
                        $employee->userId,
                        $password,
                        "",
                        "",
                        "",
                        "",
                        $senderEmail,
                        ""
                    ));

                // Send SMS
                sendSMS("+91" . $request->mobile, "Hi " . $request->FirstName . "
                    \nYour taplingua account has been created.
                    \nPlease download the Taplingua Language app:
                    \nhttps://play.google.com/store/apps/details?id=com.taplingua.languages
                    \nPlease check your email for account login details.
                    \nThanks
                    \nTaplingua Team");
            } else {
                // send mail anyway
                Mail::to($employee->userId)
                    ->send(new EnrolledEmployeeWelcomeEmail(
                        $user->fullname,
                        $module->description,
                        $employee->userId,
                        "",
                        "",
                        "",
                        "",
                        "",
                        $senderEmail,
                        ""
                    ));

                // Send SMS
                sendSMS("+91" . $request->mobile, "Hi " . $request->FirstName . "
                    \nYou are registered to a new course.
                    \nPlease download the Taplingua Language app:
                    \nhttps://play.google.com/store/apps/details?id=com.taplingua.languages
                    \nThanks
                    \nTaplingua Team");
            }
            // return success message
            return redirect()->to('/app/employee-course-registration-success')->with('message', 'Thanks for registering for the ' . $cohort->name);
        } catch (\Throwable $th) {
            \Log::error("Could not register user to course!", [$th]);
            return redirect()->back()->withInput()->with('error', 'Registered to course ' . $cohort->name . ' failed!');
        }
    }


    private function createCohortFromCompanyCodeAndProgramId($program_id, $company_code, $start_date = null, $name = null, $is_dynamic = false)
    {
        // get a start date
        $startDate = $start_date ? Carbon::parse($start_date) : null;

        $program = Program::find($program_id);

        // create the cohort
        $cohort = Cohort::create([
            "name" => $name ? $name : $program->name,
            "program_id" => $program_id,
            "company_code" => $company_code,
            "start_date" => $startDate,
            "is_dynamic" => $is_dynamic,
        ]);
        // create course for every program in that module, for this cohort
        $modules = $cohort->program->modules->sort(function ($a, $b) {
            return $a->sort_order - $b->sort_order;
        });

        // sort index
        $moduleSortIndex = [];
        foreach ($modules as $module) {
            $moduleSortIndex[] = $module->module_number;
        }

        $moduleSortIndex = array_flip($moduleSortIndex);

        // for each module, create the course
        foreach ($modules as $index => $module) {
            Course::create([
                "cohort_id" => $cohort->id,
                "Company" => $company_code,
                "courseStartDate" => $startDate ? Carbon::parse($startDate)->addWeeks(($moduleSortIndex[$module->moduleno]) * 3) : today(),
                "courseEndDate" => $startDate ? Carbon::parse($startDate)->addWeeks(($moduleSortIndex[$module->moduleno] + 1) * 3) : today(),
                "courseName" => $module->module->description,
                "courseNumber" => time() . $index,
                "moduleNumber" => $module->module_number,
                "numberOfWeeks" => 3
            ]);
        }

        // return $cohort;
        return $cohort;
    }

    /**
     * Register user to managed cohort using data
     *
     * @param Request $request
     * @return void
     */
    //     public function  checkemail($str) {
    //         return (!preg_match("/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix", $str)) ? FALSE : TRUE;
    //   }
    private function registerUserToManagedCohortUsingData($data = [])
    {

        $validator = Validator::make($data, [
            'cohort_id' => 'required|exists:cohorts,id',
            'email' => 'required|email',
            'FirstName' => 'nullable|string',
            'LastName' => 'nullable|string',
            'mobile' => 'nullable|numeric|digits:10',
            'location' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return [
                'status' => false,
                'email' => $data['email'],
                'message' => "Validation error",
                "errors" => $validator->errors()
            ];
        }

        $cohort = Cohort::find($data['cohort_id']);

        if ($cohort->senderEmail) {
            $senderEmail = $cohort->senderEmail;
        } else {
            $senderEmail = 'test@taplingua.com';
        }

        // $senderEmail= $cohort->instructorEmails;
        $program = $cohort->program;
        $companyName = $cohort->company->Name;
        $companyId = $cohort->company->id;
        $type_id = $cohort->type_id;
        // get the module
        $module = $program->first_module;
        $vpi_value = $cohort->vpi_value;
        $cohortName = $cohort->name;
        $course = $cohort->getCourseByModuleNo($module->moduleno);

        try {
            // create an employee with the information
            $employee = \App\Employee::where('userId', $data["email"])->first();
            if ($employee && $employee->CompanyCode != $cohort->company_code) {
                return [
                    'status' => false,
                    'email' => $data['email'],
                    'message' => "Validation error",
                    "errors" => [
                        "email" => [
                            "The email is registered to another company."
                        ]
                    ]
                ];
            }

            if (!$employee) {
                // check if mobile already token
                if (\App\Employee::where('Mobile', $data['mobile'])->exists()) {
                    return [
                        'status' => false,
                        'mobile' => $data['mobile'],
                        'message' => "Validation error",
                        "errors" => [
                            "mobile" => ["Mobile already taken by other user!"]
                        ]
                    ];
                }

                $employee = \App\Employee::create([
                    'currentCourse' => $course->courseNumber,
                    'currentModule' => $course->moduleNumber,
                    'CompanyCode' => $course->Company,
                    'FirstName' => $data["FirstName"] ?? "",
                    'LastName' => $data["LastName"] ?? "",
                    'userId' => $data["email"],
                    'Mobile' => $data["mobile"] ?? "",
                    'Location' => $data["location"] ?? "",
                    'accountCreationDate' => now(),
                    'subscriptionExpires' => now()->addDays(15),
                ]);
            }

            // for each cohort module register user if not already registered
            $userRegisteredToCohortFirstTime = false;
            foreach ($program->modules as $module) {
                // the module related course
                $moduleCourse = $cohort->getCourseByModuleNo($module->module_number);
                // check if course already there
                $courseSubscribed = \DB::table('employeecourse')->where('userId', $employee->userId)
                    ->where('courseNumber', $moduleCourse->courseNumber)->first();
                if ($courseSubscribed) {
                    //  do nothing
                    // return redirect()->back()->withInput()->with('error', 'Course already subscribed to!');
                } else {
                    // assign the employee to the said course
                    \DB::table('employeecourse')->insert([
                        'dateRegistered' => now(),
                        'userId' => $employee->userId,
                        'courseNumber' => $moduleCourse->courseNumber,
                    ]);
                    $userRegisteredToCohortFirstTime = true;
                }
            }

            $password = substr(md5(now()), 0, 8);

            // get the user
            $user = \App\User::where('email', $employee->userId)->first();

            if (!$user) {
                // create the user
                $user = \App\User::create([
                    "email" => $employee->userId,
                    "fullname" => $employee->FirstName . " " . $employee->LastName,
                    "password" => bcrypt($data["password"] ?? $password),
                    'token' => md5($employee->userId . time()),
                    'uid' => uniqid(),
                    'accesslevel' => 0
                ]);
                $isNewUser = true;
                if ($vpi_value == 1) {
                    \Mail::to($employee->userId)
                        ->send(new VpiEmployeeWelcomeEmail(
                            $user->fullname,
                            $module->description,
                            $employee->userId,
                            $password,
                            $type_id,
                            $companyName,
                            $companyId,
                            $senderEmail,
                            $cohortName
                        ));
                    // Send SMS
                    sendSMS("+91" . $data["mobile"], "Hi " . $data["FirstName"] . "
                        \nYour taplingua account has been created.
                        \nPlease download the Taplingua Language app:
                        \nhttps://play.google.com/store/apps/details?id=com.taplingua.languages
                        \nPlease check your email for account login details.
                        \nThanks
                        \nTaplingua Team");
                } else {
                    // send mail
                    \Mail::to($employee->userId)
                        ->send(new EnrolledEmployeeWelcomeEmail(
                            $user->fullname,
                            $module->description,
                            $employee->userId,
                            $password,
                            $type_id,
                            $companyName,
                            $companyId,
                            $senderEmail,
                            $cohortName
                        ));

                    // Send SMS
                    sendSMS("+91" . $data["mobile"], "Hi " . $data["FirstName"] . "
                    \nYour taplingua account has been created.
                    \nPlease download the Taplingua Language app:
                    \nhttps://play.google.com/store/apps/details?id=com.taplingua.languages
                    \nPlease check your email for account login details.
                    \nThanks
                    \nTaplingua Team");
                }
            } else {
                if ($vpi_value == 1) {
                    \Mail::to($employee->userId)
                        ->send(new VpiEmployeeWelcomeEmail(
                            $user->fullname,
                            $module->description,
                            $employee->userId,
                            '',
                            $type_id,
                            $companyName,
                            $companyId,
                            $senderEmail,
                            $cohortName
                        ));
                    // Send SMS
                    sendSMS("+91" . $data["mobile"], "Hi " . $data["FirstName"] . "
                        \nYour taplingua account has been created.
                        \nPlease download the Taplingua Language app:
                        \nhttps://play.google.com/store/apps/details?id=com.taplingua.languages
                        \nPlease check your email for account login details.
                        \nThanks
                        \nTaplingua Team");
                } else {
                    // send mail anyway
                    Mail::to($employee->userId)
                        ->send(new EnrolledEmployeeWelcomeEmail(
                            $user->fullname,
                            $module->description,
                            $employee->userId,
                            "",
                            $type_id,
                            $companyName,
                            $companyId,
                            $senderEmail,
                            $cohortName
                        ));

                    // Send SMS
                    sendSMS("+91" . $data["mobile"], "Hi " . $data["FirstName"] . "
                    \nYou are registered to a new course.
                    \nPlease download the Taplingua Language app:
                    \nhttps://play.google.com/store/apps/details?id=com.taplingua.languages
                    \nThanks
                    \nTaplingua Team");
                }
            }

            event(new UserAddedToCohort($employee->userId, $cohort->id));

            // QUICKBLOX: add user to group - start
            try {
                \App\Services\QuickBlox::createUserIfNeededAndAddToGroup($cohort->id, $employee->userId);
            } catch (\Throwable $th) {
                \Log::error("Quick blox failed createUserIfNeededAndAddToGroup!", [$th]);
            }
            // QUICKBLOX: add user to group - end

            // return success message
            return ['email' => $data['email'], 'status' => true];
        } catch (\Throwable $th) {
            // print($th);
            \Log::error("Could not register user to course!", [$th]);
            return [
                'status' => false,
                'email' => $data['email'],
                'th' => $th,
                'message' => "Something went wrong!"
            ];
        }
    }

    public function getMentorCohorts(Request $request)
    {
        // get cohorts where user is instructor
        $cohorts = Cohort::where('instructorEmails', 'like', '%' . auth()->user()->email . '%')->get();

        return response()->json([
            'message' => 'Cohorts for instructor.',
            'userId' => auth()->user()->email,
            'cohorts' => $cohorts
        ]);
    }

    public function getCohortUsersInterviewVideoStatistics(Request $request, $cohort_id)
    {
        // get cohort
        $cohort = \App\Cohort::find($cohort_id);

        // cohort
        if (!$cohort) {
            return response()->json([
                "message" => "Cohort not found!"
            ], 404);
        }

        // get program for cohort
        $program = $cohort->program;
        $program->cohort_name = $cohort->name;

        $modules = $program->modules()->orderBy('level_number')->orderBy('sort_order')->get();

        $userIds = [];
        // get all modules and make levels
        foreach ($modules as $module) {
            // check if certification available
            $course = getCourseNoByCohortIdAndModuleNumber($cohort->id, $module->module_number, true);

            // add users to user table
            foreach (\DB::table('employeecourse')
                ->where('courseNumber', $course->courseNumber)
                ->get()->pluck('userId') as $userId) {
                array_push($userIds, $userId);
            }
        }

        // get the employees
        $employees = Employee::whereIn('userId', $userIds)->select('userId', 'FirstName', 'LastName')
            ->get()->map(function ($employee) {
                // add more data
                $employee->videosRecorded = InterviewVideo::where('userId', $employee->userId)->count();
                $employee->reviewsAsked = InstructorReview::where('userId', $employee->userId)->count();
                $employee->reviewsCompleted = InstructorReview::where('userId', $employee->userId)
                    ->where('reviewCompleted', true)
                    ->count();
                $employee->reviewsPending = InstructorReview::where('userId', $employee->userId)
                    ->where('reviewCompleted', false)
                    ->count();
                $employee->interviewReviewLogs = InstructorReview::where('userId', $employee->userId)->select('videoId', 'reviewCompleted')->get();
                return $employee;
            });

        return response()->json([
            'message' => "Users in cohort " . $cohort->name,
            'users' => $employees
        ]);
    }
}
