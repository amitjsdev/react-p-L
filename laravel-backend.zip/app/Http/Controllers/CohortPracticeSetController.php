<?php

namespace App\Http\Controllers;

use App\Cohort;
use App\CohortPracticeSet;
use App\PracticeSet;
use Illuminate\Http\Request;

class CohortPracticeSetController extends Controller
{
    public function getPracticeSetFromCohort(Request $request, $cohortId)
    {
        // get practice sets
        $cohortPracticeSets = CohortPracticeSet::with('practiceSet')
            ->where('cohortId', $cohortId)
            ->get()
            ->map(function ($e) {
                if($e && $e->practiceSet && $e->practiceSet->questions){
                    $e->practiceSet->questionCount =   $e->practiceSet->questions->count();
                    unset($e->practiceSet->questions);
                    return $e->practiceSet;
                } else {
                    // $e->practiceSet->questionCount=0;
                }

                return $e;
            });

        return response()->json([
            "message" => "Cohort Practice Sets",
            "cohortPracticeSets" => $cohortPracticeSets
        ]);
    }



    /**
     * Api to get all Available Practice Sets
     */
    public function getAllAvailablePracticeSets(Request $request)
    {

        $user = auth()->user()->email;
        $employee = \App\Employee::where('userId', $user)->first();

        // get all practice sets
        $data = PracticeSet::where("companyCode", $employee->CompanyCode)
            ->orWhereNull("companyCode")
            ->get();

        return response()->json([
            "practiceSets" => $data
        ]);
    }

    public function addPracticeSetsToCohort(Request $request)
    {

        // validate the request
        $request->validate([
            'cohortId' => "required|exists:cohorts,id",
            'practiceSetIds' => "required|array",
            'practiceSetIds.*' => "required|exists:practice_sets,practiceSetId",
        ]);

        // add practice set to cohort
        foreach ($request->practiceSetIds as $practiceSetId) {
            CohortPracticeSet::updateOrCreate([
                'cohortId' => $request->cohortId,
                'practiceSetId' => $practiceSetId,
            ], []);
        }

        // get practice sets
        $cohortPracticeSets = CohortPracticeSet::with('practiceSet')
            ->where('cohortId', $request->cohortId)
            ->whereIn('practiceSetId', $request->practiceSetIds)
            ->get()
            ->map(function ($e) {
                $e->practiceSet->questionCount = $e->practiceSet->questions->count();
                unset($e->practiceSet->questions);
                return $e->practiceSet;
            });

        // return response
        return response()->json([
            'message' => 'Practice set added!',
            'cohortPracticeSets' => $cohortPracticeSets
        ]);
    }

    public function removePracticeSetFromCohort(Request $request, $cohortId, $practiceSetId)
    {

        $cohortPracticeSet = CohortPracticeSet::where([
            ['cohortId', $cohortId],
            ['practiceSetId', $practiceSetId],
        ])->delete();

        // return response
        return response()->json([
            'message' => 'Practice set removed!'
        ]);
    }
}
