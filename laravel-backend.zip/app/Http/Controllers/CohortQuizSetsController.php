<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\QuizSet;

class CohortQuizSetsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $cohortId =$request->get('cohortId');
        $sets =QuizSet::where('cohortId',$cohortId)->get();
        foreach($sets as &$set){
            $set->questionsCount=$set->questions->count();
        }
        return \response()->json($sets);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $quizSetId = QuizSet::max('quizSetId');
        $postedData =$request->post();
        $postedData['quizSetId']=(int)$quizSetId+1;
        $sets =QuizSet::create($postedData);
        return \response()->json($sets);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

        $sets =QuizSet::find($id);
        if($sets){
            $sets->questions;
        }

        return \response()->json($sets);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $sets =QuizSet::find($id);
        return \response()->json($sets);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $sets =QuizSet::where('id',$id)->update($request->post());
        return \response()->json($request->post());
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $sets =QuizSet::destroy($id);
        return \response()->json($sets);
    }
}
