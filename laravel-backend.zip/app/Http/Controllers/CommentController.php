<?php

namespace App\Http\Controllers;

use App\Comment;
use App\Events\UserCommented;
use App\FollowingForum;
use App\Http\Resources\ForumCommentResource;
use App\V2Exercise;
use Illuminate\Http\Request;

class CommentController extends Controller
{


    /**
     * Add comment on comment and redirect back
     *
     * @param Request $request
     * @param [type] $id
     * @return void
     */
    public function add(Request $request, $id)
    {
        $email = auth()->user()->email;

        // get comment by user
        $commentMsg = $request->comment;

        if (empty($commentMsg)) {
            return response()->json([
                'error' => 'Comment is required!'
            ], 422);
        }

        // fetch comment
        $prevComment = Comment::where('id', $id)->first();

        if (!$prevComment) {
            return response()->json([
                'error' => "Comment Not found!"
            ], 404);
        }

        // create new comment
        $comment = new Comment();
        $comment->userId = $email;
        $comment->comment = $commentMsg;
        $prevComment->comments()->save($comment);

        event(new UserCommented($comment));

        // follow the forum
        followTheForum($email, $comment);
        followTheCommunityForum($email, $comment);

        return response()->json([
            "success" => "Comment Added!",
            "comment" => new ForumCommentResource($comment)
        ]);
    }


    /**
     * Edit the comment and redirect back
     *
     * @param Request $request
     * @param [type] $id
     * @return void
     */
    public function update(Request $request, $id)
    {
        $email = auth()->user()->email;

        // get comment by user
        $commentMsg = $request->comment;

        if (empty($commentMsg)) {
            return response()->json([
                'error' => 'Comment is required!'
            ], 422);
        }

        // fetch comment
        $comment = Comment::where('userId', $email)->where('id', $id)->first();

        if (!$comment) {
            return response()->json([
                'error' => "Comment Not found!"
            ], 404);
        }

        $comment->comment = $commentMsg;
        $comment->save();

        return response()->json([
            'success' => "Comment updated!",
            "comment" => new ForumCommentResource($comment)
        ]);
    }

    /**
     * Delete the comment and redirect back
     *
     * @param Request $request
     * @param [type] $id
     * @return void
     */
    public function delete($id)
    {
        $email = auth()->user()->email;

        // fetch comment
        $comment = Comment::where('userId', $email)->where('id', $id)->first();

        if (!$comment) {
            return response()->json([
                'error' => "Comment Not found!"
            ], 422);
        }

        $comment->delete();

        return response()->json([
            'success' => "Comment deleted!",
            'comment' => new ForumCommentResource($comment)
        ]);
    }
}
