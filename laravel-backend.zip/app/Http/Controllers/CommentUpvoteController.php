<?php

namespace App\Http\Controllers;

use App\Comment;
use App\CommentUpvote;
use App\CommentUpvotes;
use Illuminate\Http\Request;

class CommentUpvoteController extends Controller
{
    public function add(Request $request, $id)
    {
        // get Comment from db
        $comment = Comment::find($id);

        if (!$comment) {
            return response()->json([
                'error' => "Comment Not found!"
            ], 404);
        }

        $email = auth()->user()->email;

        // check if the user already has an upvote for current comment
        if ($comment->upvotes()->where("userId", $email)->exists()) {
            return response()->json([
                'error' => "Already upvoted!"
            ], 422);
        }

        // if not, add the upvote
        $upvote = new CommentUpvote();
        $upvote->userId = $email;
        $comment->upvotes()->save($upvote);

        return response()->json([
            'success' => "Upvoted!"
        ]);
    }


    public function remove(Request $request, $id)
    {
        // get Comment from db
        $comment = Comment::find($id);

        if (!$comment) {
            return response()->json([
                'error' => "Comment Not found!"
            ], 404);
        }

        $email = auth()->user()->email;

        // check if the user already has an upvote for current comment
        $upvote = $comment->upvotes()->where("userId", $email)->first();
        if (!$upvote) {
            return response()->json([
                'error' => "Not upvoted!"
            ], 422);
        }

        // if upvote exists, delete it
        $upvote->delete();

        return response()->json([
            'success' => "Upvote deleted!"
        ]);
    }
}
