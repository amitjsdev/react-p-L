<?php

namespace App\Http\Controllers;

use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\CompanyBatch;
use App\Http\Resources\CompanyBatch as CompanyBatchResource;

use App\Http\Resources\CheckUserApiAccess as CheckUserApiAccess;
use DB;
use checkUserPermissionController;
use Session;
use Validator;

class CompanyBatchController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        
        
        // http://taplingua.test/api/company?companyCode=133

        if($request->input('companyCode')!="")
        {

            if (in_array(auth()->user()->accesslevel, [0, 3])) {
                $CompanyBatch = CompanyBatch::where('companyCode', auth()->user()->employee->CompanyCode);
            } else {
                $CompanyBatch = CompanyBatch::where('companyCode', $request->input('companyCode'));
            }

            $CompanyBatch = $CompanyBatch->get()->makeHidden(['i_d']);
            //return $CompanyBatch;
            return response()->json($CompanyBatch);
            return CompanyBatchResource::collection($CompanyBatch);

        }

        

    }


    public function companyBatch(Request $request)
    {

        if($request->input('companyCode')!="")
        {

            $results = DB::table('companybatch')->select()->where('companyCode', $request->input('companyCode'))->orderBy('batchNumber', 'asc')->get();

        }
        else
        {
            $results = array();
        }


        return view('admin.CompanyBatch')->with(["results" => $results]);   

    }
    
}
