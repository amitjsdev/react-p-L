<?php

namespace App\Http\Controllers;

use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Company;
use App\Http\Resources\Company as CompanyResource;

use App\Http\Resources\CheckUserApiAccess as CheckUserApiAccess;
use DB;
use checkUserPermissionController;
use Session;
use Validator;


class CompanyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        
        // http://taplingua.test/api/company?companyCode=133

        //echo env(DB_PASSWORD);

        if (in_array(auth()->user()->accesslevel, [0, 3])) {
            $company = auth()->user()->employee->company()->get();
            return CompanyResource::collection($company);
        } else {
            if ($request->input('CompanyCode') != "") {
                $company = Company::where('Id', $request->input('companyCode'))->get();
                return CompanyResource::collection($company);
            }
        }

        $Companies = Company::all();
        return CompanyResource::collection($Companies);

    }


    public function list(Request $request)
    {
        
        $company = Company::query(); 

        $company->orderBy('i_d','asc');

        if ($request->input('moduleNo') != "") {

            $company->where('moduleNumber', $request->input('moduleNo'));
        }

        if ($request->input('courseBatch') != "") {

            $company->where('courseBatch', $request->input('courseBatch'));
        }

        if ($request->input('Company') != "") {

            $company->where('Company', $request->input('Company'));
        }

        if ($request->input('query') != "") {

            $query = $request->input('query');
            
            //SQL AND + OR + Brackets
            $company->where(function($company) use ($query) {
                $company->where('Name', 'LIKE', '%'.$query.'%')
                      ->orWhere('Description', 'LIKE', '%'.$query.'%');
            });

        }

             
        $company = $company->paginate(50);

        return CompanyResource::collection($company);


    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        

        $request->validate([
            "Email"=>"required|unique:company",
            "Id"=>"required|unique:company"
        ]);

        
        //$Company = new Company;
        //$Company->create($request->all());
        //return new CompanyResource($Company);


        try{ 

            $Company = Company::create($request->all());
            //return new CompanyResource($Company);

            return response()->json(['message' => 'Data Saved!'], 200);
            
        }
        catch(ModelNotFoundException $e)
        {
            return response()->json(['message' => $e], 404);
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Company  $company
     * @return \Illuminate\Http\Response
     */
    public function show(Company $company, Request $request, $id)
    {
        
        

        try{

          $Companies = Company::findOrFail($id);
          return new CompanyResource($Companies);
        
        } 
        // catch(Exception $e) catch any exception
        catch(ModelNotFoundException $e)
        {
            return response()->json(['message' => 'Not Found!'], 404);
        }

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Company  $company
     * @return \Illuminate\Http\Response
     */
    public function edit(Company $company)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Company  $company
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Company $company, $id)
    {
                

        /*$request->validate([
            "Email"=>"required|unique:company" 
        ]);*/

        
        $Company = Company::findOrFail($id);
        
        $Company->update($request->all());

        //return new CompanyResource($Company);
        return response()->json(['message' => 'Data Saved!'], 200);


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Company  $company
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, Company $company, $id)
    {
        
       

        try{  

          $Company = Company::findOrFail($id);

          if($Company->delete()){
            return response()->json(['message' => 'Removed!'], 200);
          }

        }        
        // catch(Exception $e) catch any exception
        catch(ModelNotFoundException $e)
        {
            return response()->json(['message' => 'Not Found!'], 404);
        }

        //print_r($Employee->id); die();


    }
}
