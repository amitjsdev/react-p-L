<?php

namespace App\Http\Controllers;

use App\Employee;
use App\PracticeQuestion;
use App\PracticeSet;
use Illuminate\Http\Request;

class CompanyPracticeSetController extends Controller
{
    // practice set related
    public function createPracticeSet(Request $request)
    {
        $validated = $request->validate([
            'name' => "required|string",
        ]);

        $user = auth()->user()->email;
        $employee = Employee::where('userId', $user)->first();

        $practiceSet = PracticeSet::create([
            'practiceSetId' => time(),
            'practiceSetName' => $request->name,
            'companyCode' => $employee->CompanyCode
        ]);

        return response()->json([
            "message" => "Practice set created!",
            "practiceSet" => $practiceSet,
        ]);
    }

    public function editPracticeSet(Request $request, $practiceSetId)
    {
        $validated = $request->validate([
            'name' => "required|string",
        ]);

        $user = auth()->user()->email;
        $employee = Employee::where('userId', $user)->first();

        $practiceSet = PracticeSet::updateOrCreate([
            'practiceSetId' => $practiceSetId,
            'companyCode' => $employee->CompanyCode
        ], [
            'practiceSetName' => $request->name,
        ]);

        return response()->json([
            "message" => "Practice set updated!",
            "practiceSet" => $practiceSet,
        ]);
    }

    public function deletePracticeSet(Request $request, $practiceSetId)
    {
        $user = auth()->user()->email;
        $employee = Employee::where('userId', $user)->first();

        $practiceSet = PracticeSet::where([
            'practiceSetId' => $practiceSetId,
            'companyCode' => $employee->CompanyCode
        ])->delete();

        return response()->json([
            "message" => "Practice set deleted!",
            "practiceSetId" => $practiceSetId,
        ]);
    }

    // practice set question related
    public function getPracticeSetQuestions(Request $request, $practiceSetId)
    {
        $user = auth()->user()->email;
        $employee = Employee::where('userId', $user)->first();

        $practiceSet = PracticeSet::where([
            'practiceSetId' => $practiceSetId,
            'companyCode' => $employee->CompanyCode
        ])->first();

        if (!$practiceSet) {
            return response()->json([
                "message" => "Practice set not found!"
            ], 404);
        }
        // get all cohorts
        $practiceQuestions = PracticeQuestion::where('practiceSetId', $practiceSetId)->orderBy('practiceQuestionId')->get();

        return response()->json([
            "message" => "Practice set questions!",
            "practiceQuestions" => $practiceQuestions,
        ]);
    }

    public function addPracticeSetQuestion(Request $request, $practiceSetId)
    {
        $validated = $request->validate([
            'type' => "required",
            'practiceSetQuestion' => "required|string",
            'practiceSetTip' => "nullable|string",
            'practiceSetDfficultyLevel' => "nullable|string",
            'practiceQuestionText' => "nullable|string",
            'referenceAnswer' => "nullable|string",
        ]);

        $user = auth()->user()->email;
        $employee = Employee::where('userId', $user)->first();

        $practiceSet = PracticeSet::where([
            'practiceSetId' => $practiceSetId,
            'companyCode' => $employee->CompanyCode
        ])->first();

        if (!$practiceSet) {
            return response()->json([
                "message" => "Practice set not found!"
            ], 404);
        }
        if($request->type == 1 && $request->video_type){

            $video_type = $request->video_type;
            $videoType = explode(".",$video_type);
            $validated['video_type'] = $videoType[1];

        }else{
            $validated['video_type'] = 0;

            if (!$request->referenceAnswer) {
                return response()->json([
                    "message" => "Reference Answer is required!"
                ], 422);
            }

        }
       

        $validated['practiceSetId'] = $practiceSetId;
        $validated['practiceQuestionId'] = time();
        // $validated['type'] = $request->type;
        $validated['practicetype'] = $request->post('practicetype') ? $request->post('practicetype') :0;

        // add question
        $practiceQuestion = PracticeQuestion::create($validated);

        // save the video as well, if available
      if($request->type == 1){
        if($videoType[1] == 'mp4'){
            if ($video = $request->file('video')) {
            $mrl = $practiceSetId . "_0_" . $validated['practiceQuestionId'];

            // generate the dir for s3
            $dir = 'interviewprep/' . $practiceSetId;

            // upload to s3

            uploadToS3Exact($dir, $video->getPathname(), $mrl . ".mp4"); // mrl creates the file name
            }
        }else{
            if ($video = $request->file('video')) {
            $mrl = $practiceSetId . "_0_" . $validated['practiceQuestionId'];

            // generate the dir for s3
            $dir = 'interviewprep/' . $practiceSetId;

            // upload to s3

            uploadToS3Exact($dir, $video->getPathname(), $mrl . ".webm"); // mrl creates the file name
            }
        }
    }
        return response()->json([
            "message" => "Practice set question added!",
            "practiceQuestion" => $practiceQuestion,
        ]);
    }

    public function editPracticeSetQuestion(Request $request, $practiceSetId, $practiceQuestionId)
    {
        $validated = $request->validate([
            'practiceSetQuestion' => "required|string",
            'practiceSetTip' => "nullable|string",
            'practiceSetDfficultyLevel' => "nullable|string",
            'practiceQuestionText' => "nullable|string",
            'referenceAnswer' => "nullable|string",
        ]);

        $user = auth()->user()->email;
        $employee = Employee::where('userId', $user)->first();

        $practiceSet = PracticeSet::where([
            'practiceSetId' => $practiceSetId,
            'companyCode' => $employee->CompanyCode
        ])->first();

        if (!$practiceSet) {
            return response()->json([
                "message" => "Practice set not found!"
            ], 404);
        }

        // update question
        $practiceQuestion = PracticeQuestion::updateOrCreate([
            'practiceSetId' => $practiceSetId,
            "practiceQuestionId" => $practiceQuestionId
        ], $validated);

        // save the video as well, if available
        if ($video = $request->file('video')) {
            $mrl = $practiceSetId . "_0_" . $practiceQuestionId;

            // generate the dir for s3
            $dir = 'interviewprep/' . $practiceSetId;

            // upload to s3
            uploadToS3Exact($dir, $video->getPathname(), $mrl . ".mp4"); // mrl creates the file name
        }

        // return response
        return response()->json([
            "message" => "Practice set question updated!",
            "practiceQuestion" => $practiceQuestion,
        ]);
    }

    public function deletePracticeSetQuestion(Request $request, $practiceSetId, $practiceQuestionId)
    {

        $user = auth()->user()->email;
        $employee = Employee::where('userId', $user)->first();

        $practiceSet = PracticeSet::where([
            'practiceSetId' => $practiceSetId,
            'companyCode' => $employee->CompanyCode
        ])->first();

        if (!$practiceSet) {
            return response()->json([
                "message" => "Practice set not found!"
            ], 404);
        }

        // delete question
        PracticeQuestion::where([
            'practiceSetId' => $practiceSetId,
            "practiceQuestionId" => $practiceQuestionId
        ])->delete();

        // return response
        return response()->json([
            "message" => "Practice set question deleted!",
            "practiceQuestionId" => $practiceQuestionId,
        ]);
    }
}
