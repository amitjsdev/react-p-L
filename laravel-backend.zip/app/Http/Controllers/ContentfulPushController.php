<?php

namespace App\Http\Controllers;

use App\Card;
use App\ContentfulExerciseLog;
use App\ContentfulFlashLog;
use App\V2Exercise;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class ContentfulPushController extends Controller
{
    // saves the mini round log request
    public function saveExercise(Request $request)
    {

        // create validator
        $validator = \Illuminate\Support\Facades\Validator::make($request->all(), [
            'roundId' => 'required|exists:contentful_exercise_logs,id',

        ]);

        // return if error
        if ($validator->fails()) {
            return response()->json($validator->errors());
        }

        $userId = auth()->user()->email;

        // get the contentful exercise log by roundId
        $contentfulExerciseLog = ContentfulExerciseLog::find($request->roundId);

        $v2Exercise = V2Exercise::find($contentfulExerciseLog->questionId);

        if ($contentfulExerciseLog->userId !== $userId) {
            return response()->json([
                'message' => 'Access denied!'
            ], 403);
        }

        if ($contentfulExerciseLog->status === '-1') {
            // save the details
            $contentfulExerciseLog->type = $request->type;
            $contentfulExerciseLog->additionalInfo = $request->additionalInfo;
            $contentfulExerciseLog->livesLeft = $request->livesLeft;
            $contentfulExerciseLog->additionalLivesClaimed = $request->additionalLivesClaimed;
            $contentfulExerciseLog->status = $request->status;
            $contentfulExerciseLog->save();

            // save the userScore $request->score
            $courseNumber = getCourseNoFromModuleNo($v2Exercise->moduleNo, $userId);
            if (isset($courseNumber)) {
                // always use this function it triggers update check for badge event
                updateUserScoreForCourse($userId, $courseNumber, (int) $request->score ?? 0);
            } else {
                Log::error("getCourseNoFromModuleNo helper function returned null, while update score on save roundlog", [$request->all()]);
            }


            return response()->json($contentfulExerciseLog);
        } else {
            return response()->json([
                "message" => "Invalid Request"
            ], 400);
        }
    }


    /**
     * Saved the contentful flash activity
     *
     * @param Request $request
     * @return void
     */
    public function saveFlashes(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'pushId' => 'required|exists:push_logs,id',
            'activities' => 'array',
            'activities.*.cardId' => 'required',
            'activities.*.difficulty_level' => 'required|numeric',
            'activities.*.next_date' => 'nullable|date',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        $userId = auth()->user()->email;

        // foreach activity
        $activities = array_map(function($activity) use($userId, $request) {
            $activity["userId"] = $userId;
            $activity["pushLogId"] = $request->pushId;
            $activity["created_at"] = $activity["updated_at"] = now();
            return $activity;
        },$request->activities);
        
        ContentfulFlashLog::insert($activities);



        // save the userScore $request->score
        if(count($activities) > 0) {
            // get card from first activity card Id
            $card = Card::find($activities[0]['cardId']);
            if($card) {

                $courseNumber = getCourseNoFromModuleNo($card->moduleNo, $userId);
                if (isset($courseNumber)) {
                    // always use this function it triggers update check for badge event
                    updateUserScoreForCourse($userId, $courseNumber, (int) $request->score ?? 0);
                } else {
                    Log::error("getCourseNoFromModuleNo helper function returned null, while update score on save roundlog", [$request->all()]);
                }

                return response()->json([
                    "message" => "Activities logged!",
                    "activities" => $activities
                ]);
            }
        }
    }
}
