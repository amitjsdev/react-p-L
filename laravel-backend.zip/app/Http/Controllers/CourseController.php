<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\ModelNotFoundException;

use App\Http\Requests;
use App\Course;
use App\Http\Resources\Course as CourseResource;
use App\Employee;

use App\Http\Resources\CheckUserApiAccess as CheckUserApiAccess;
use DB;
use checkUserPermissionController;
use Session;
use Validator;

class CourseController extends Controller
{
    //

    public function index(Request $request)
    {
        
        // http://taplingua.test/api/course?companyCode=133&moduleNumber=11
        
        if($request->input('companyCode')!="" && $request->input('moduleNumber')!="")
        {

            $Course = Course::where('Company', $request->input('companyCode'))->where('moduleNumber', $request->input('moduleNumber'))->get();  //moduleNumber
            //return $Course;

            return $Course;
            
            //return CourseResource::collection($Course);

        } 


        // http://taplingua.test/api/course?courseNumber=7878
          
        if($request->input('courseNumber')!="")
        {

            $Course = Course::where('courseNumber', $request->input('courseNumber'))->get();
            //return $Course;

            return CourseResource::collection($Course);

        } 
       
        // http://taplingua.test/api/course?companyCode=104

        if($request->input('companyCode')!="")
        {

            $Course = Course::where('Company', $request->input('companyCode'))->get();
            //return $Course;

            return CourseResource::collection($Course);

        } 


        // Show Pagination if page passed else All        
        if($request->input('page')!="") {
            $Courses = Course::paginate(50);
        }
        else 
        { 
            $Courses = Course::All();
        }    

        return CourseResource::collection($Courses);

    }



    public function list(Request $request)
    {
        
        $courses = Course::query(); 

        $courses->orderBy('i_d','asc');

        if ($request->input('moduleNo') != "") {

            $courses->where('moduleNumber', $request->input('moduleNo'));
        }

        if ($request->input('courseBatch') != "") {

            $courses->where('courseBatch', $request->input('courseBatch'));
        }

        if ($request->input('Company') != "") {

            $courses->where('Company', $request->input('Company'));
        }

        if ($request->input('query') != "") {

            $query = $request->input('query');
            
            //SQL AND + OR + Brackets
            $courses->where(function($courses) use ($query) {
                $courses->where('courseName', 'LIKE', '%'.$query.'%')
                      ->orWhere('courseNumber', 'LIKE', '%'.$query.'%');
            });

        }

             
        $courses = $courses->paginate(50);

        return CourseResource::collection($courses);


    }



    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $id)
    {
        
        try{

          $Courses = Course::findOrFail($id);
          return new CourseResource($Courses);
        
        } 
        // catch(Exception $e) catch any exception
        catch(ModelNotFoundException $e)
        {
            return response()->json(['message' => 'Not Found!'], 404);
        } 

    }

    

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        $request->validate([
            "courseNumber"=>"required|unique:courses",
            "Company"=>"required",
            "courseName"=>"required",
            "courseNumber"=>"required",
            "moduleNumber"=>"required",
            "numberOfWeeks"=>"required"
        ]);

        
        //$Course = new Course;
        //$Course->create($request->all());
        //return new CourseResource($Course);


        $results = DB::table('courses')->select('i_d')->where('courseNumber', $request->input('courseNumber'))->get();

        if(sizeof($results)>0)
          return response()->json(['message' => 'Course is already exist!'], 200);

        //return new CourseResource($Courses);    



        try{ 
       
        $Course = Course::create($request->all());
        //return new CourseResource($Course);
        return response()->json(['message' => 'Data Saved!'], 200);
        
        }
        catch(ModelNotFoundException $e)
        {
            return response()->json(['message' => $e], 404);
        }

        
        

    }



    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Company  $company
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Course $course, $id)
    {
        
       $request->validate([
            "courseNumber"=>"required|unique:courses",
            "Company"=>"required",
            "courseName"=>"required",
            "courseNumber"=>"required",
            "moduleNumber"=>"required"
        ]);

        
        $Course = Course::findOrFail($id);
        
        $Course->update($request->all());

        //return new CourseResource($Course);
        return response()->json(['message' => 'Data Saved!'], 200);


    }



    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Company  $company
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, Course $course, $id)
    {
        
        try{  

          $Course = Course::findOrFail($id);

          if($Course->delete()){
            return response()->json(['message' => 'Removed!'], 200);
          }

        }        
        // catch(Exception $e) catch any exception
        catch(ModelNotFoundException $e)
        {
            return response()->json(['message' => 'Not Found!'], 404);
        }

        //print_r($Employee->id); die();


    }


    public function courseListBatch(Request $request)
    {

        $request->validate([
            "companyCode" => "required"
        ]);

        /// course-list-batch?companyCode=133&batchNumber=1

        $course = DB::table('courses')
         ->leftJoin('module', 'courses.moduleNumber', '=', 'module.moduleno');
         
         
        if ($request->input('companyCode') != "") {
            $course->where('courses.Company', $request->input('companyCode'));
        }

        if ($request->input('batchNumber') != "") {

            $course->where('courses.courseBatch', $request->input('batchNumber'));
        }

        if ($request->input('cohortId') != "") {

            $course->where('courses.cohort_id', $request->input('cohortId'));
        }  

        $course->where('module.status', "1"); 

        $course = $course->groupBy('courses.courseName')->get();

        //return $course;
        $Modules = [];

        foreach($course as $rows) {

            //print_r($rows);

            $enrolled = $this->countEmployeeEnrolledInCourse($rows->courseNumber, $request->input('batchNumber'));
            $courseStartDate = ($rows->courseStartDate != "") ? formatDate($rows->courseStartDate) : "";
            $Modules[] = array("batchNumber" => $rows->courseBatch, "moduleNo" => $rows->moduleNumber, "moduleName" => $rows->description, "courseNumber" => $rows->courseNumber, "courseName" => $rows->courseName, "courseStartDate" => $courseStartDate, "enrolled" => $enrolled );
     
         }

         return $Modules;

    }


    public function countEmployeeEnrolledInCourse($courseNumber, $batchNumber)
    {
    
      
      if($batchNumber!="")
       $sql = "SELECT count(a.userId) as cnt FROM  `employeecourse` a Join courses b on a.courseNumber = b.courseNumber WHERE  b.courseBatch = '".$batchNumber."' and a.courseNumber = '".$courseNumber."'";  
      else
       $sql = "SELECT count(userId) as cnt FROM  `employeecourse` WHERE  courseNumber = '".$courseNumber."'";   
     

      $query = DB::select(DB::raw($sql));

      return $query[0]->cnt; 
           
    
    }


    public function courseRoom(Request $request)
    {


        $request->validate([
            "companyId"=>"required",
            "courseId"=>"required"
        ]);

      //print($request->companyId);
      ///return "Chat Room";


      try{ 


        /// Get All Employee of Company

        $emps = array();
        $emps_email = array();

        $sql = "SELECT distinct(userId), FirstName, LastName, Location, Mobile FROM employee WHERE CompanyCode='".$request->companyId."' ";

        $query = DB::select(DB::raw($sql));

        $results = array();


        foreach($query as $rows) {        

        //print_r($rows);
        $emps[] = $rows;

        $emps_email[] = $rows->userId; 


        }

        
        $whr = "";

        if(isset($request->userId) && $request->userId!="")
        $whr .= " and ec.userId='".$userId."' ";

        if($request->courseId!="")
        $whr .= " and ec.courseNumber='".$request->courseId."' ";

        //$sql = "SELECT * FROM employeecourse WHERE i_d!='' $whr ";
        $sql = "SELECT distinct(ec.`i_d`), ec.`dateRegistered`, ec.`completedStatus`, ec.`userId`,ec.`evaluationCompleted`,ec.`Id`,ec.`couseGroup`, e.`FirstName`, e.`LastName`, e.`fcmToken` FROM employeecourse ec JOIN employee e ON e.`userId` = ec.`userId` WHERE ec.`i_d`!='' ". $whr;

        $query = DB::select(DB::raw($sql));

        $results = array();


        $registered = array();

        foreach($query as $rows) {  
        
            
        if(in_array($rows->userId, $emps_email))
        {  
        
        
         
            
        $value1 = array("i_d" => $rows->i_d, "FirstName" => $rows->FirstName, "LastName" => $rows->LastName, "userId" => $rows->userId, 'fcmToken' => $rows->fcmToken);

        $results[] = $value1;



        $registered[] = $rows->userId;

        } 


        }

        $emp = array("companyId" => $request->companyId, "courseId" => $request->courseId, "courseRoomName" => $this->getCourseName($request->courseId), "registered" => $results, "moduleNo" => Course::where('courseNumber', $request->courseId)->first()->moduleNumber);

        return $emp;
        
        }
        catch(ModelNotFoundException $e)
        {
            return response()->json(['message' => $e], 404);
        }

    } 

    
    /* 
    addCourse
    
    { "userId": "user@domain.com", "courseNumber": "2019091" }
    - Add Employee to Course "employeecourse"
    
    */
    public function addCourse(Request $request)
    {

        /**/

        $validator = Validator::make($request->all(), [
            'moduleNumber' => 'required',
            'courseStartDate' => 'required',
            'Company' => 'required'
        ]);

        if ($validator->fails()) {
            // TODO: Add the mail functionality
            $allErrors = $validator->errors()->all();
            error_logger($allErrors);
            return response()->json(["error" => $allErrors[0]], 412);
        }

        //extract($validator->validated());

        $moduleNumber = $request->input('moduleNumber') ?? "";
        $courseStartDate = $request->input('courseStartDate') ?? "";
        $Company = $request->input('Company') ?? "";
        $courseNumber = $request->input('courseNumber') ?? time();
        $courseEndDate = $request->input('courseEndDate') ?? "";
        $courseFlag = $request->input('courseFlag') ?? "";
        $holidayInCourseFlag = $request->input('holidayInCourseFlag') ?? "";
        $holidayWeek = $request->input('holidayWeek') ?? "";
        $courseBatch = $request->input('courseBatch') ?? "";
        $courseNumberOfStudents = $request->input('courseNumberOfStudents') ?? "";
        $numRoutes = $request->input('numRoutes') ?? "";
        $evaluation_required = $request->input('evaluation_required') ?? "";
        $weeklyEmail = $request->input('weeklyEmail') ?? "";
        $Status = $request->input('Status') ?? "";
        $numberOfWeeks = $request->input('numberOfWeeks') ?? "";


        $moduleCourseName = getModuleNameByCourse($moduleNumber)." ".$Company;
        $courseName = $request->input('courseName') ?? $moduleCourseName;

        //echo $courseName;

        /* Check if course already there */ 
        $sql = "SELECT courseNumber FROM  `courses` WHERE courseName = '".$courseName."' and Company = '".$Company."' and moduleNumber = '".$moduleNumber."' "; 

        //$rowCourse = DB::connection('mysql2')->select($sql);
        $rowCourse = DB::select(DB::raw($sql));
        
        //print_r($rowCourse);

        if (sizeof($rowCourse) > 0) {

 
            $courseNumber = $rowCourse[0]->courseNumber;

            return response()->json(["message" => "Course already exists", "courseNumber" => $courseNumber], 412);
                      
           
        }
        else
        {
           
           
           $query="insert into courses set Id='".time()."', courseNumberOfStudents='".$courseNumberOfStudents."', numRoutes='".$numRoutes."', holidayInCourseFlag='".$holidayInCourseFlag."', courseFlag='".$courseFlag."', courseName='".$courseName."', Company='".$Company."', holidayWeek='".$holidayWeek."', courseStartDate = '".$courseStartDate."', courseEndDate='".$courseEndDate."', evaluationRequired='".$evaluation_required."', courseNumber='".$courseNumber."', moduleNumber='".$moduleNumber."', courseBatch='".$courseBatch."', weeklyEmail='".$weeklyEmail."', numberOfWeeks='".$numberOfWeeks."', Status='".$Status."'";
           
           //DB::connection('mysql2')->select($query);   
           DB::select(DB::raw($query));   
           
           
            /* Update / Add module in Company table if added in course */

            $sql = "select Modules from company where Status='1' and Id='".$Company."'"; 

            //$compRow = DB::connection('mysql2')->select($sql);
            $compRow = DB::select(DB::raw($sql));

            //print_r($compRow); die;

            $module = explode(",", $compRow[0]->Modules);

            if (in_array($moduleNumber, $module)) 
            {	

            }
            else
            {

            $module[] = $moduleNumber;	

            $query="update company set Modules = '".implode(",", $module)."' where Id='".$Company."'";

            //DB::connection('mysql2')->update($query);  
            DB::update(DB::raw($query));  

            }

           
           return response()->json(["message" => "Course saved successfully", "courseNumber" => $courseNumber], 200);
                    
           
           
           }


    }

    /* 
    addCourseRegisterEmployee
    
    { "userId": "user@domain.com", "moduleNumber": "0", "courseStartDate": "2019-06-01 00:00:00" }

    - check if Employee Exists
    - check if course exists else create course Name (UserId + Module + Company)
    - Update / Add module in Company table if added in course
    - Register Employee to This Course

    add-course-register-employee-api.php
    
    */
    public function addCourseRegisterEmployee(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'userId' => 'required',
            'courseStartDate' => 'required',
            'moduleNumber' => 'required'
        ]);

        if ($validator->fails()) {
            // TODO: Add the mail functionality
            $allErrors = $validator->errors()->all();
            error_logger($allErrors);
            return response()->json(["error" => $allErrors[0]], 412);
        }


        $userId = $request->input('userId') ?? "";
        $moduleNumber = $request->input('moduleNumber') ?? "";
        $courseStartDate = $request->input('courseStartDate') ?? "";
        $Company = $request->input('Company') ?? "";
        $courseNumber = $request->input('courseNumber') ?? time();
        $courseEndDate = $request->input('courseEndDate') ?? "";
        $courseFlag = $request->input('courseFlag') ?? "";
        $holidayInCourseFlag = $request->input('holidayInCourseFlag') ?? "";

        $holidayWeek = $request->input('holidayWeek') ?? "";
        $courseBatch = $request->input('courseBatch') ?? "";
        $courseNumberOfStudents = $request->input('courseNumberOfStudents') ?? "";
        $numRoutes = $request->input('numRoutes') ?? "";
        $evaluation_required = $request->input('evaluation_required') ?? "";
        $weeklyEmail = $request->input('weeklyEmail') ?? "";
        $Status = $request->input('Status') ?? "";
        $numberOfWeeks = $request->input('numberOfWeeks') ?? "";

        
        /* check if Employee Exists */

        //echo "check if Employee Exists";

        if(Employee::where('userId', $userId)->exists())
        {

            $CompanyCode = DB::table('employee')->select('CompanyCode')->where('userId', $userId)->get();

            $Company = $CompanyCode[0]->CompanyCode;

        }
        else
        {

            return response()->json(["message" => "Employee doesn't exist"], 412);

        }

        
        $userIdName = explode("@", $userId);



        $moduleCourseName = $userIdName[0]." ".getModuleNameByCourse($moduleNumber)." ".$Company;
        $courseName = $request->input('courseName') ?? $moduleCourseName;


        /* Create Course */
        // check if course exists

        //echo "Create Course";

        $sql = "SELECT courseNumber FROM  `courses` WHERE courseName = '".$courseName."' and Company = '".$Company."' and moduleNumber = '".$moduleNumber."' "; 

        //$rowCourse = DB::connection('mysql2')->select($sql);
        $rowCourse = DB::select(DB::raw($sql));


        if (sizeof($rowCourse) > 0) {

            $courseNumber = $rowCourse[0]->courseNumber; 

        }   
        else
        {

           $query="insert into courses set Id='".time()."', courseNumberOfStudents='".$courseNumberOfStudents."', numRoutes='".$numRoutes."', holidayInCourseFlag='".$holidayInCourseFlag."', courseFlag='".$courseFlag."', courseName='".$courseName."', Company='".$Company."', holidayWeek='".$holidayWeek."', courseStartDate = '".$courseStartDate."', courseEndDate='".$courseEndDate."', evaluationRequired='".$evaluation_required."', courseNumber='".$courseNumber."', moduleNumber='".$moduleNumber."', courseBatch='".$courseBatch."', weeklyEmail='".$weeklyEmail."', numberOfWeeks='".$numberOfWeeks."', Status='".$Status."'";
           
           //DB::connection('mysql2')->select($query);   
           DB::select(DB::raw($query));   
           
           
            /* Update / Add module in Company table if added in course */

            $sql = "select Modules from company where Status='1' and Id='".$Company."'"; 

            //$compRow = DB::connection('mysql2')->select($sql);
            $compRow = DB::select(DB::raw($sql));

            //print_r($compRow); die;

            $module = explode(",", $compRow[0]->Modules);

            if (in_array($moduleNumber, $module)) 
            {	

            }
            else
            {

            $module[] = $moduleNumber;	

            $query="update company set Modules = '".implode(",", $module)."' where Id='".$Company."'";

            //DB::connection('mysql2')->update($query);
            DB::update(DB::raw($query));

            }


        }
        
        /* Register Employee to Course */

        //echo "Register Employee to Course";

        /* Add This Course to DASHBoard DB   (Master/Slave MySQL Server) */
        //include_once("saveCourseDashboard.php");


        /*$sql = "SELECT courseNumber FROM  `courses` WHERE courseName = '".$courseName."' and Company = '".$Company."' and moduleNumber = '".$moduleNumber."' "; 

        $rowCourse = DB::select(DB::raw($sql));


        if (sizeof($rowCourse) > 0) {

            //$courseNumber = $rowCourse[0]->courseNumber; 

            return response()->json(["message" => "Course already exists", "courseNumber" => $courseNumber], 412);

        } 
        else
        {

           $query="insert into courses set Id='".time()."', courseNumberOfStudents='".$courseNumberOfStudents."', numRoutes='".$numRoutes."', holidayInCourseFlag='".$holidayInCourseFlag."', courseFlag='".$courseFlag."', courseName='".$courseName."', Company='".$Company."', holidayWeek='".$holidayWeek."', courseStartDate = '".$courseStartDate."', courseEndDate='".$courseEndDate."', evaluationRequired='".$evaluation_required."', courseNumber='".$courseNumber."', moduleNumber='".$moduleNumber."', courseBatch='".$courseBatch."', weeklyEmail='".$weeklyEmail."', numberOfWeeks='".$numberOfWeeks."', Status='".$Status."'";
           
           DB::select(DB::raw($query));  


        }*/


        //// https://api1.taplingua.com/preprod/add-course-api.php?moduleNumber=0&Company=104&courseStartDate=2019-05-25


        //file_get_contents("https://api1.taplingua.com/v1/add-employee-course.php?userId=".$userId."&companyCode=".$Company."&courseNumber=".$courseNumber);
        //echo "addEmployeeCourse";

        //{ "userId": "xarlyxarly@gmai.com", "courseNumber": "2019091" }

        $params = array("userId" => $userId, "courseNumber" => $courseNumber);

        $newRequest = new \Illuminate\Http\Request($params);

        $res = app(\App\Http\Controllers\EmployeeController::class)->addEmployeeCourse($newRequest);
       
        // add certificate to user 
        getCertificate($userId, $courseNumber);
        // add certificate to user end 

        return $res;



    }


    public function getCourseName($c)
    {

        $sql = "SELECT courseName FROM `courses` where courseNumber = '".$c."' ";

        $query = DB::select(DB::raw($sql));

        return $query[0]->courseName;

    }



    /* CMS */

    
    public function listCourses(Request $request)
    {

        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        $courses = Course::query(); 

        
        if ($request->input('companyCode') != "") {

            $courses->where('Company', $request->input('companyCode'));
        }

        if ($request->input('batchNo') != "") {

            $courses->where('courseBatch', $request->input('batchNo'));
        }

        if ($request->input('moduleNo') != "") {

            $courses->where('moduleNumber', $request->input('moduleNo'));
        }

        if ($request->input('status') != "") {

            $courses->where('Status', $request->input('status'));
        }

        if ($request->input('query') != "") {

            $query = $request->input('query');
            
            //SQL AND + OR + Brackets
            $courses->where(function($courses) use ($query) {
                $courses->where('courseName', 'LIKE', '%'.$query.'%')
                      ->orWhere('courseNumber', 'LIKE', '%'.$query.'%');
            });

        }


        if ($request->input('pageSize') != "") 
         $pageSize = $request->input('pageSize');
        else
         $pageSize = 50;  

        $courses = $courses->paginate($pageSize);


        $sql="select * from company where Status='1'";
        $companies = DB::select(DB::raw($sql));
        
        return view('admin.ListCourses')->with(['courses'=>$courses, "companies" => $companies, "pageSize" => $pageSize]);


    }

    public function editCourse(Request $request)
    {

        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        
        if($request->input('id')=="")
          $course = new Course;
        else
          $course = Course::findOrFail( $request->input('id') );


        $sql="select * from tutor where status='1' order by id ";
        $tutors = DB::select(DB::raw($sql));

        $sql="select * from module where status='1' order by moduleno ";
        $modules = DB::select(DB::raw($sql));

        $sql="select * from company where Status='1' order by Id";
        $companies = DB::select(DB::raw($sql));

        return view('admin.EditCourse')->with(["course" => $course, "tutors" => $tutors, "modules" => $modules, "companies" => $companies]);   
      

    }


    
    public function saveCourse(Request $request)
    {

        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        
        if($request->input('id')!="")
        {
           
           
            $validator = Validator::make($request->all(), [
                "courseNumber"=>"required|unique:courses",
                "Company"=>"required",
                "courseName"=>"required",
                "courseNumber"=>"required",
                "moduleNumber"=>"required",
                "courseStartDate"=>"required"                
            ]);
            
    
            if ($validator->fails()) {
                
                $allErrors = $validator->errors()->all();
                return redirect()->back()->with('error', $allErrors[0]);
            }

            $reqNew = array();
            foreach($request->all() as $key=>$value)
            {

                if($value!="")
                  $reqNew[$key] = $value;
                else
                  $reqNew[$key] = ''; 

            }
    
            
            $Course = Course::findOrFail( $request->input('id') );
            
            //$Course->update($request->all());

            $Course->update($reqNew);

            return redirect()->back()->with('message', 'Course saved successfully!');


        }
        else
        {

            $validator = Validator::make($request->all(), [
                "courseNumber"=>"required|unique:courses",
                "Company"=>"required",
                "courseName"=>"required",
                "courseNumber"=>"required",
                "moduleNumber"=>"required",
                "courseStartDate"=>"required"                
            ]);
    
            if ($validator->fails()) {
                
                $allErrors = $validator->errors()->all();
                return redirect()->back()->with('error', $allErrors[0]);
            }
    

            $reqNew = array();
            foreach($request->all() as $key=>$value)
            {

                if($value!="")
                  $reqNew[$key] = $value;
                else
                  $reqNew[$key] = ''; 

            }
            
             
            $results = DB::table('courses')->select('i_d')->where('courseNumber', $request->input('courseNumber'))->get();
    
            if(sizeof($results)>0)
              return redirect()->back()->with('error', 'Course is already exist!');
              


            //$Course = Course::create($request->all());  

            $Course = Course::create($reqNew);  


            return redirect()->back()->with('message', 'Course saved successfully!');



        }


    }


    public function deleteCourse(Request $request)
    {
        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        $Course = Course::findOrFail( $request->input('id'));

          if($Course->delete()){
            return redirect()->back()->with('message', 'Course removed successfully!');
          }

    }


}
