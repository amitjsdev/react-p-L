<?php

namespace App\Http\Controllers;

use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use App\Http\Requests;
use DB;
use Session;
use Illuminate\Support\Facades\Validator;


class DashboardController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        //
    }

    
    /**
     * Display the specified resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function overview(Request $request)
    {
        
        

        $request->validate([
            "companyCode" => "required"
        ]);

        $results = array("totalUsers" => totalEmployees($request->input('companyCode')), "activeCourses" => activeCourses($request->input('companyCode')), "ongoingBatches" => ongoingBatches($request->input('companyCode')));

        return $results;

    }


    public function send_email(Request $request)
    {
 
        //$email = "svnlabs@gmail.com"; 
        //$email = "santanu@taplingua.com"; 

        $email = "any_randomemail_address@info.com";

        //$email = "html5tap@gmail.com"; 

        $message = "<h1>SES Email Test</h1>";
        $subject = "SES Email Test";

        sendEmail($email, $message, $subject);

        //$csv = DB::connection('mysql2')->select("select * from dialogs where id=2");
        //dd($csv);

    }


    


     
}
