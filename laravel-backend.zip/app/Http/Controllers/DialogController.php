<?php

namespace App\Http\Controllers;

use Illuminate\Database\Eloquent\ModelNotFoundException;
use App\Dialog;
use Illuminate\Http\Request;
use App\Http\Resources\Dialog as DialogResource;

use App\Http\Resources\CheckUserApiAccess as CheckUserApiAccess;
use DB;
use checkUserPermissionController;
use Session;
use Validator;

class DialogController extends Controller
{
    

    public function list(Request $request)
    {
        
        $Dialog = Dialog::query(); 

        $Dialog->orderBy('id','asc');

        if ($request->input('moduleNo') != "") {

            $Dialog->where('moduleno', $request->input('moduleNo'));
        }

        if ($request->input('routeNo') != "") {

            $Dialog->where('routeno', $request->input('routeNo'));
        }

        if ($request->input('lessonNo') != "") {

            $Dialog->where('lesson_no', $request->input('lessonNo'));
        }

        if ($request->input('dialogNo') != "") {

            $Dialog->where('dialog_no', $request->input('dialogNo'));
        }

       
        if ($request->input('query') != "") {

            $query = $request->input('query');
            
            //SQL AND + OR + Brackets
            $Dialog->where(function($Dialog) use ($query) {
                $Dialog->where('title', 'LIKE', '%'.$query.'%')
                      ->orWhere('voice_id', 'LIKE', '%'.$query.'%');
            });

        }

             
        $Dialog = $Dialog->paginate(50);

        return DialogResource::collection($Dialog);


    }

      

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $id)
    {
        
        try{

          $Dialog = Dialog::findOrFail($id);
          return new DialogResource($Dialog);
        
        } 
        // catch(Exception $e) catch any exception
        catch(ModelNotFoundException $e)
        {
            return response()->json(['message' => 'Not Found!'], 404);
        } 

    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $request->validate([
            "moduleno"=>"required",
            "routeno"=>"required",
            "lesson_no"=>"required",
            "dialog_no"=>"required"
        ]);

        
        $Dialog = Dialog::findOrFail($id);

        /* save encoded for special chars & lang */

        $request->merge(array('voice_id' => json_encode($request->input('voice_id'), JSON_UNESCAPED_UNICODE) ));

        $request->merge(array('voice_ssml' => base64_encode(json_encode($request->input('voice_ssml'), JSON_UNESCAPED_UNICODE)) ));
        
        /* save encoded for special chars & lang */

        //print_r($request->all());
        
        $Dialog->update($request->all());

        $this->pollyGen($request->input('moduleno'), $request->input('routeno'), $request->input('lesson_no'), $request->input('voice_id'), $request->input('voice_ssml'), $request->input('debug'), $Dialog->title);

        return response()->json(['message' => 'Data Saved!'], 200);


    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            "moduleno"=>"required",
            "routeno"=>"required",
            "lesson_no"=>"required",
            "dialog_no"=>"required"
        ]);


        $Dialog = $request->isMethod('put') ? Dialog::findOrFail($request->id) : new Dialog;

        $Dialog->id = $request->input('id');

        //$post->fill($request->input())->save();
        
        $Dialog->lesson_id = $request->input('lesson_id') ? $request->input('lesson_id') : '';
        $Dialog->moduleno = $request->input('moduleno'); 
        $Dialog->routeno = $request->input('routeno'); 
        $Dialog->lesson_no = $request->input('lesson_no'); 
        $Dialog->dialog_no = $request->input('dialog_no') ? $request->input('dialog_no') : ''; 
        $Dialog->title = $request->input('title') ? $request->input('title') : ''; 
        
        //$Dialog->voice_id = $request->input('voice_id') ? $request->input('voice_id') : ''; 
        //$Dialog->voice_ssml = $request->input('voice_ssml') ? $request->input('voice_ssml') : '';
        
        /* save encoded for special chars & lang */

        $voice_id = $request->input('voice_id') ? json_encode($request->input('voice_id'), JSON_UNESCAPED_UNICODE) : '';  
        $Dialog->voice_id = $voice_id;

        $voice_ssml = $request->input('voice_ssml') ? base64_encode(json_encode($request->input('voice_ssml'), JSON_UNESCAPED_UNICODE)) : '';
        $Dialog->voice_ssml = $voice_ssml;

        /* save encoded for special chars & lang */

        $Dialog->status = $request->input('status') ? $request->input('status') : ''; 
        $Dialog->sequence = $request->input('sequence') ? $request->input('sequence') : ''; 
        
        //$Dialog->adddate = date("Y-m-d H:i:s");

        
         
       
        if($Dialog->save()){
            //return new EmployeeResource($Employee);

            $this->pollyGen($request->input('moduleno'), $request->input('routeno'), $request->input('lesson_no'), $request->input('voice_id'), $request->input('voice_ssml'), $request->input('debug'), $Dialog->title);

            return response()->json(['message' => 'Data Saved!'], 200);
        }


    }


     /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        
        //echo "Test...";

        try{  

          $Dialog = Dialog::findOrFail($id);

          if($Dialog->delete()){
            return response()->json(['message' => 'Removed!'], 200);
          }

        }        
        // catch(Exception $e) catch any exception
        catch(ModelNotFoundException $e)
        {
            return response()->json(['message' => 'Not Found!'], 404);
        }

        
    }



    public function pollyGen($moduleno, $routeno, $lesson_no, $voice_id, $voice_ssml, $debug="", $title = "")
    {

        $shouldUseGoogle = true;

        // // should be from google?
        // if(strpos(strtolower($title), "google") !== false) {
        //     $shouldUseGoogle = true;
        // }

        $voice_id = json_decode($voice_id, true); 

        $voice_ssml = json_decode(base64_decode($voice_ssml), true);

        //echo $debug."----";

        $voice_c = count($voice_id);

        $packs = $moduleno."_".$routeno."_".$lesson_no;

        for($ivc=0; $ivc < $voice_c; $ivc++)
        { 

            $mp3folder = storage_path()."/Lesson_Module_Packs/Lesson_".$packs."_Pack/dialogs/";
            $cmd = "mkdir -p ".$mp3folder;
            exec($cmd, $pp1);

            //if($debug!="") print_r($pp1);

            $mp3file = $mp3folder.$lesson_no.".".($ivc+1).".mp3";

            $mp3textfile = $mp3folder.$lesson_no.".".($ivc+1).".json";

            if($shouldUseGoogle) {
                // get correct voice id
                $voiceName = null;
                if(strtolower(trim($voice_id[$ivc])) === "aditi") {
                    $voiceName = "en-IN-Standard-D";
                }
                if (strtolower(trim($voice_id[$ivc])) === "raveena") {
                    $voiceName = "en-IN-Wavenet-A";
                }

                // create the content
                $decodedAudioContent = getTextToDecodedSpeechFromGoogle(str_replace('*', ',', str_replace('"', "'", trim($voice_ssml[$ivc]))), "en-IN", $voiceName);

                // put the file at position
                file_put_contents($mp3file, $decodedAudioContent);
            } else {
                /* Make MP3 Polly Files */
                $cmd = 'LANG=en_US.UTF-8; AWS_ACCESS_KEY_ID=' . env("POLLY_ACCESSKEY") . ' AWS_SECRET_ACCESS_KEY=' . env("POLLY_SECRETKEY") . ' ' . env("AWS_CLI") . ' polly synthesize-speech --region ' . env("POLLY_REGION") . ' --text-type ssml --text "' . str_replace('"', "'", trim($voice_ssml[$ivc])) . '" --output-format mp3 --voice-id ' . trim($voice_id[$ivc]) . ' ' . $mp3file . ' 2>&1';
                exec($cmd, $pp2);
             }


            /* Make Text Polly Files */
            $cmd = 'LANG=en_US.UTF-8; AWS_ACCESS_KEY_ID='.env("POLLY_ACCESSKEY").' AWS_SECRET_ACCESS_KEY='.env("POLLY_SECRETKEY").' '.env("AWS_CLI").' polly synthesize-speech --region '.env("POLLY_REGION").' --text-type ssml --text "'.str_replace('"', "'", trim($voice_ssml[$ivc])).'" --speech-mark-types=\'["sentence", "word", "ssml"]\' --output-format json --voice-id '.trim($voice_id[$ivc]).' '.$mp3textfile.' 2>&1';
            exec($cmd, $pp3);

            // write to modify file content as proper json and wrap in array
            $previous_content = file_get_contents($mp3textfile);
            $new_content = "[" . str_replace("\n", ",\n", trim($previous_content)) . "]";
            $new_content_decoded = json_decode($new_content);
            // add new translations to new content
            $lesson = \App\Lesson::where('moduleno', $moduleno)->where('routeno', $routeno)->where('lesson_no', $lesson_no)->first();
            $translations = explode("\r\n", $lesson->video);
            foreach ($new_content_decoded as $key => $dec) {
                if(isset($translations[$key])) {
                    $dec->translation = $translations[$key];
                } else {
                    $dec->translation = "";
                }
            }
            $new_content = json_encode($new_content_decoded, JSON_UNESCAPED_UNICODE);
            file_put_contents($mp3textfile, $new_content);
            // write to modify file content as proper json and wrap in array end

            if($debug!="") print_r($pp3);

            /* Copy Polly MP3 files on S3 Media Folder */
            $S3Dir = "s3://" . env("S3_MEDIA_BUCKET") . "/Lesson_" . $packs . "_Pack/dialogs/";
            exec("LANG=en_US.UTF-8; AWS_ACCESS_KEY_ID=" . env("S3_ACCESSKEY") . " AWS_SECRET_ACCESS_KEY=" . env("S3_SECRETKEY") . " " . env("AWS_CLI") . " s3 cp '" . $mp3file . "' " . $S3Dir . " --acl public-read 2>&1", $pp3);

            /* Copy Polly Text files on S3 Media Folder */
            $S3Dir = "s3://".env("S3_MEDIA_BUCKET")."/Lesson_".$packs."_Pack/dialogs/";
            exec("LANG=en_US.UTF-8; AWS_ACCESS_KEY_ID=".env("S3_ACCESSKEY")." AWS_SECRET_ACCESS_KEY=".env("S3_SECRETKEY")." ".env("AWS_CLI")." s3 cp '".$mp3textfile."' ".$S3Dir." --acl public-read 2>&1", $pp3);
            
            if($debug!="") print_r($pp3);

            /* Remove Polly MP3 files from storage_path() */
            @unlink($mp3file);
            
            /* Remove Polly Text files from storage_path() */
            @unlink($mp3textfile);



        }


    }




    /* CMS */


    public function listDialogs(Request $request)
    {

        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

           $Dialog = Dialog::query(); 

           $Dialog->orderBy('id','asc');
   
           if ($request->input('moduleNo') != "") {
   
               $Dialog->where('moduleno', $request->input('moduleNo'));
           }
   
           if ($request->input('routeNo') != "") {
   
               $Dialog->where('routeno', $request->input('routeNo'));
           }
   
           if ($request->input('lessonNo') != "") {
   
               $Dialog->where('lesson_no', $request->input('lessonNo'));
           }
   
           if ($request->input('dialogNo') != "") {
   
               $Dialog->where('dialog_no', $request->input('dialogNo'));
           }

           if ($request->input('status') != "") {
   
            $Dialog->where('status', $request->input('status'));
           }
   
          
           if ($request->input('query') != "") {
   
               $query = $request->input('query');
               
               //SQL AND + OR + Brackets
               $Dialog->where(function($Dialog) use ($query) {
                   $Dialog->where('title', 'LIKE', '%'.$query.'%')
                         ->orWhere('voice_id', 'LIKE', '%'.$query.'%');
               });
   
           }


        if ($request->input('pageSize') != "") 
         $pageSize = $request->input('pageSize');
        else
         $pageSize = 50;  

        $Dialog = $Dialog->paginate($pageSize);


        //$sql="select * from company where Status='1'";
        //$companies = DB::select(DB::raw($sql));
        
        return view('admin.ListDialogs')->with(['dialogs'=>$Dialog, "pageSize" => $pageSize]);


    }


    public function editDialog(Request $request)
    {

        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        
        if($request->input('id')=="")
          $Dialog = new Dialog;
        else
          $Dialog = Dialog::findOrFail( $request->input('id') );


        $sql="select * from module where status='1' order by moduleno ";
        $modules = DB::select(DB::raw($sql));

        //$sql="select * from route where status='1' order by routeno ";
        //$routes = DB::select(DB::raw($sql));

        //$mp3Polly = env("S3_MEDIA_LINK");

        
        return view('admin.EditDialog')->with(["dialog" => $Dialog, "modules" => $modules]);   
      

    }


    public function saveDialog(Request $request)
    {

        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        
        if($request->input('id')!="")
        {
           
           
            $validator = Validator::make($request->all(), [
                "moduleno"=>"required",
                "routeno"=>"required",
                "lesson_no"=>"required",
                "dialog_no"=>"required"
            ]);
            
    
            if ($validator->fails()) {
                
                $allErrors = $validator->errors()->all();
                return redirect()->back()->with('error', $allErrors[0]);
            }


            /* save encoded for special chars & lang */

            $request->merge(array('voice_id' => json_encode($request->input('voice_id'), JSON_UNESCAPED_UNICODE) ));

            $request->merge(array('voice_ssml' => base64_encode(json_encode($request->input('voice_ssml'), JSON_UNESCAPED_UNICODE)) ));
        
            /* save encoded for special chars & lang */


            $reqNew = array();
            foreach($request->all() as $key=>$value)
            {

                if($value!="")
                  $reqNew[$key] = $value;
                else
                  $reqNew[$key] = ''; 

            }
    
            //print_r($reqNew); die;
            
            $Dialog = Dialog::findOrFail( $request->input('id') );
            
            //$Card->update($request->all());

            $Dialog->update($reqNew);

            $this->pollyGen($request->input('moduleno'), $request->input('routeno'), $request->input('lesson_no'), $request->input('voice_id'), $request->input('voice_ssml'), $request->input('debug'), $Dialog->title);

            return redirect()->back()->with('message', 'Dialog saved successfully!');


        }
        else
        {

            $validator = Validator::make($request->all(), [
                "moduleno"=>"required",
                "routeno"=>"required",
                "lesson_no"=>"required",
                "dialog_no"=>"required"
            ]);
    
            if ($validator->fails()) {
                
                $allErrors = $validator->errors()->all();
                return redirect()->back()->with('error', $allErrors[0]);
            }


            // check if dialog with same module route lesson exists
            if(Dialog::where('moduleno', $request->moduleno)->where('routeno', $request->routeno)->where('lesson_no', $request->lesson_no)->exists()) {
                return redirect()->back()->with("error", "Dialog with same module route lesson Exists!");
            }


            /* save encoded for special chars & lang */

            $request->merge(array('voice_id' => json_encode($request->input('voice_id'), JSON_UNESCAPED_UNICODE) ));

            $request->merge(array('voice_ssml' => base64_encode(json_encode($request->input('voice_ssml'), JSON_UNESCAPED_UNICODE)) ));
        
            /* save encoded for special chars & lang */
    

            $reqNew = array();
            foreach($request->all() as $key=>$value)
            {

                if($value!="")
                  $reqNew[$key] = $value;
                else
                  $reqNew[$key] = ''; 

            }
                    


            //$Dialog = Dialog::create($request->all());  

            $Dialog = Dialog::create($reqNew);  


            $this->pollyGen($request->input('moduleno'), $request->input('routeno'), $request->input('lesson_no'), $request->input('voice_id'), $request->input('voice_ssml'), $request->input('debug'), $Dialog->title);


            return redirect()->back()->with('message', 'Dialog saved successfully!');



        }


    }



    public function deleteDialog(Request $request)
    {
        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        $Dialog = Dialog::findOrFail( $request->input('id'));

          if($Dialog->delete()){
            return redirect()->back()->with('message', 'Dialog removed successfully!');
          }

    }


}
