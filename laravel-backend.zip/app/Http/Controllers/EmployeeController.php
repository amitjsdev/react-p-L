<?php

namespace App\Http\Controllers;

use App\Course;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Employee;
use App\Events\UserCourseAdded;
use App\UserActivityLog;
use App\Http\Resources\Employee as EmployeeResource;
use App\Http\Resources\CheckUserApiAccess as CheckUserApiAccess;
use App\Http\Resources\UserBadgeResource;
use App\Lesson;
use App\Module;
use App\Route;
use App\User;
use App\UserBadge;
use DB;
use App\Mail\EnrolledEmployeeWelcomeEmail;
use Carbon\Carbon;
use Illuminate\Support\Facades\Mail;
use checkUserPermissionController;
use CourseController;
use Session;
use Illuminate\Support\Facades\Validator;

class EmployeeController extends Controller
{

    public function index(Request $request)
    {


        $employee = DB::table('employee')->distinct()
            ->select('employee.userId', 'employee.*', 'courses.courseBatch', 'company.unmanagedStatus as unManagedStatus', 'company.fundaeCourses as fundaeCourses',  'company.Status as companyStatus')
            ->leftJoin('employeecourse', 'employee.userId', '=', 'employeecourse.userId')
            ->leftJoin('courses', 'courses.courseNumber', '=', 'employeecourse.courseNumber')
            ->leftJoin('company', 'company.Id', '=', 'employee.CompanyCode');


        if ($request->input('userId') != "") {
            $employee->where('employee.userId', $request->input('userId'));
        }

        /*
        * check if user has access level of 0 or 3, if so uses the users companyCode in the filter, 
        * if user access level is not 0 or 3 then it applies the companycode filter if available
        */

        if (in_array(auth()->user()->accesslevel, [0, 3])) {
            $employee->where('employee.CompanyCode', auth()->user()->employee->CompanyCode);
        } else {
            if ($request->input('CompanyCode') != "") {
                $employee->where('employee.CompanyCode', $request->input('CompanyCode'));
            }
        }

        if ($request->input('batchNumber') != "") {

            $employee->where('courses.courseBatch', $request->input('batchNumber'));
        }

        if ($request->input('batchno') != "") {

            $employee->where('courses.courseBatch', $request->input('batchno'));
        }

        if ($request->input('acceptedGDPR') != "") {

            $employee->where('employee.acceptedGDPR', $request->input('acceptedGDPR'));
        }

        $employee = $employee->groupBy('employee.userId')->get();

        foreach ($employee as $person) {

            $courses = employeeCourses($person->userId);
            $courseList = [];
            foreach ($courses as $course) {
                $modulePercent = coursePercent($course->moduleNumber, $course->userId);
                $courseList[] = [
                    "courseNumber" => $course->courseNumber,
                    "courseName" => getModuleNameByCourse($course->moduleNumber),
                    "moduleCompletion_percent" => $modulePercent,
                    'lesssonLevel' => "",
                    'moduleNumber' => $course->moduleNumber,
                    "score" => $course->score,
                ];
            }

            $person->courseRegistered = $courseList;
            $person->courseCount = count($courses);

            // find out the current module and current module name
            $currentModule = Module::where('moduleno', $person->currentModule)->first();
            if ($currentModule) {
                $person->currentModuleNumber = $currentModule->moduleno;
                $person->currentModuleName = $currentModule->description;
                $person->currentModuleToLanguage = $currentModule->tolanguage;
            }
            // find out the current module and current module name end


            // get current course score
            $currentEmployeeCourse = DB::table("employeecourse")->where('userId', $person->userId)->where('courseNumber', $person->currentCourse)->first();
            if ($currentEmployeeCourse) {
                $person->currentCourseScore = $currentEmployeeCourse->score;
            } else {
                $person->currentCourseScore = 0;
            }
            // get current course score end

            // get latest milestone
            $person->latestMilestone = getMilestonesCompleted($person->userId, $person->currentModule);

            try {
                $user = User::where('email', $person->userId)->first();
                $person->alternate_email =  $user->alternate_email;
                $person->isGuest =  empty($user->alternate_email) && strpos($user->email, "@") === false ? true : false;
            } catch (\Throwable $th) {
                $person->isGuest = false;
            }

            // add quickblox password if needed
            $qbu = \App\QuickbloxGroupUser::where('email', $person->userId)->first();
            if ($qbu) {
                $person->quickblox_password = $qbu->password;
            } else {
                $person->quickblox_password = "";
            }
        }

        if ($request->has('userId')) {
            return new EmployeeResource($employee[0]);
        }

        return EmployeeResource::collection($employee);
    }

    public function indexPaginated(Request $request)
    {


        $employee = DB::table('employee')->distinct()
            ->select('employee.*', 'courses.courseBatch', 'company.unmanagedStatus as unManagedStatus', 'company.fundaeCourses as fundaeCourses',  'company.Status as companyStatus')
            ->leftJoin('employeecourse', 'employee.userId', '=', 'employeecourse.userId')
            ->leftJoin('courses', 'courses.courseNumber', '=', 'employeecourse.courseNumber')
            ->leftJoin('company', 'company.Id', '=', 'employee.CompanyCode');


        if ($request->input('userId') != "") {
            $employee->where('employee.userId', $request->input('userId'));
        }

        if ($request->input('search') != "") {
            $employee->where('employee.userId', 'LIKE', '%' . $request->input('search') . "%");
        }

        /*
        * check if user has access level of 0 or 3, if so uses the users companyCode in the filter, 
        * if user access level is not 0 or 3 then it applies the companycode filter if available
        */

        if (in_array(auth()->user()->accesslevel, [0, 3])) {
            $employee->where('employee.CompanyCode', auth()->user()->employee->CompanyCode);
        } else {
            if ($request->input('CompanyCode') != "") {
                $employee->where('employee.CompanyCode', $request->input('CompanyCode'));
            }
        }

        if ($request->input('batchNumber') != "") {

            $employee->where('courses.courseBatch', $request->input('batchNumber'));
        }

        if ($request->input('batchno') != "") {

            $employee->where('courses.courseBatch', $request->input('batchno'));
        }

        if ($request->input('acceptedGDPR') != "") {

            $employee->where('employee.acceptedGDPR', $request->input('acceptedGDPR'));
        }

        $employee = $employee->groupBy('employee.userId')->paginate(10);

        foreach ($employee as $person) {

            $courses = employeeCourses($person->userId);
            $courseList = [];
            foreach ($courses as $course) {
                $modulePercent = coursePercent($course->moduleNumber, $course->userId);
                $courseList[] = [
                    "courseNumber" => $course->courseNumber,
                    "courseName" => getModuleNameByCourse($course->moduleNumber),
                    "moduleCompletion_percent" => $modulePercent,
                    'lesssonLevel' => "",
                    'moduleNumber' => $course->moduleNumber,
                    "score" => $course->score,
                ];
            }

            $person->courseRegistered = $courseList;
            $person->courseCount = count($courses);

            // find out the current module and current module name
            $currentModule = Module::where('moduleno', $person->currentModule)->first();
            if ($currentModule) {
                $person->currentModuleNumber = $currentModule->moduleno;
                $person->currentModuleName = $currentModule->description;
                $person->currentModuleToLanguage = $currentModule->tolanguage;
            }
            // find out the current module and current module name end


            // get current course score
            $currentEmployeeCourse = DB::table("employeecourse")->where('userId', $person->userId)->where('courseNumber', $person->currentCourse)->first();
            if ($currentEmployeeCourse) {
                $person->currentCourseScore = $currentEmployeeCourse->score;
            } else {
                $person->currentCourseScore = 0;
            }
            // get current course score end

            // get latest milestone
            $person->latestMilestone = getMilestonesCompleted($person->userId, $person->currentModule);

            try {
                $user = User::where('email', $person->userId)->first();
                $person->alternate_email =  $user->alternate_email;
                $person->isGuest =  empty($user->alternate_email) && strpos($user->email, "@") === false ? true : false;
            } catch (\Throwable $th) {
                $person->isGuest = false;
            }

            // add quickblox password if needed
            $qbu = \App\QuickbloxGroupUser::where('email', $person->userId)->first();
            if ($qbu) {
                $person->quickblox_password = $qbu->password;
            } else {
                $person->quickblox_password = "";
            }
        }

        if ($request->has('userId')) {
            return new EmployeeResource($employee[0]);
        }

        return EmployeeResource::collection($employee);
    }



    public function employeeInfo($userId)
    {

        $Employee = Employee::where('userId', $userId)->get();
        //return $Employee;

        return EmployeeResource::collection($Employee);
    }

    public function paywallDetail(Request $request)
    {
        $employee = Employee::where('userId', $request->user()->email)->first();

        if (!$employee) {
            return response()->json([
                "message" => "Employee data not found!"
            ]);
        }

        return response()->json([
            'userId' => $employee->userId,
            'enforceWall' => $employee->enforceWall ?? 0,
            'payWallLesson' => $employee->payWallLesson ?? 0,
            'payWallSummary' => $employee->payWallSummary ?? "",
            'livesLessonWall' => $employee->livesLessonWall ?? "",
            'subscriptionExpires' => $employee->subscriptionExpires,
            'lockedLessons' => $employee->lockedLessons,
            'dailyLivesCount' => $employee->dailyLivesCount,
            'dailyLivesLeft' => $employee->dailyLivesLeft,
            'replenishesCount' => $employee->replenishesCount,
            'replenishesLeft' => $employee->replenishesLeft,
        ]);
    }

    public function customFetch(Request $request)
    {

        $fields = array_keys($request->all());

        try {
            $employee = Employee::select($fields)
                ->where('userId', auth()->user()->email)->first();

            return response()->json($employee);
        } catch (\Exception $e) {
            return response()->json(['message' => 'Bad request!'], 400);
        }
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        date_default_timezone_set("Europe/Madrid");


        $validator = Validator::make($request->all(), [
            "userId" => "required|unique:employee",
            "CompanyCode" => "required"
        ]);


        if ($validator->fails()) {
            $allErrors = $validator->errors()->all();
            return response()->json(["message" => $allErrors[0]]);
        }


        // `id`, `verificationCode`, `subscriptionValidDate`, `CompanyCode`, `userId`, `mobileOS`, `Location`, `lastLoginDate`, `Mobilewcode`, `FirstName`, `CountryCode`, `activationDate`, 
        // `LastName`, `deviceMake`, `fcmToken`, `accountActivated`, `status`, `Mobile`, `company`, `DNI`, `versionNumber`, `disable`, `versionName`, `deviceOsVersion`, `token`, `acceptedGDPR`, 
        // `acceptedGDPRDate`, `weeklyEmail`, `altEmail`, `updatedAt`


        $Employee = $request->isMethod('put') ? Employee::findOrFail($request->id) : new Employee;

        $Employee->i_d = $request->input('id');

        //$post->fill($request->input())->save();

        $Employee->userId = $request->input('userId') ?? "";
        $Employee->verification_code = $request->input('verificationCode') ?? "";
        $Employee->subscriptionValidDate = $request->input('subscriptionValidDate') ?? "";
        $Employee->CompanyCode = $request->input('CompanyCode') ?? "";
        $Employee->mobileOS = $request->input('mobileOS') ?? "";
        $Employee->Location = $request->input('Location') ?? "";

        // accountCreationDate. Set this field when the account is created by the add employee
        //$Employee->accountCreationDate = $request->input('accountCreationDate') ?? date("Y-m-d H:i:s");   //2018-10-03 16:54:43

        $Employee->accountCreationDate = date("Y-m-d H:i:s");    //// save system date

        $Employee->lastLoginDate = $request->input('lastLoginDate') ?? "";
        $Employee->Mobilewcode = $request->input('Mobilewcode') ?? "";
        $Employee->FirstName = $request->input('FirstName') ?? "";
        $Employee->LastName = $request->input('LastName') ?? "";
        $Employee->CountryCode = $request->input('CountryCode') ?? "";
        $Employee->activationDate = $request->input('activationDate') ?? "";
        $Employee->deviceMake = $request->input('deviceMake') ?? "";
        $Employee->fcmToken = $request->input('fcmToken') ?? "";
        $Employee->accountActivated = $request->input('accountActivated') ?? "";
        $Employee->status = $request->input('status') ?? "";
        $Employee->Mobile = $request->input('Mobile') ?? "";
        $Employee->company = $request->input('company') ?? "";
        $Employee->DNI = $request->input('DNI') ?? "";
        $Employee->versionNumber = $request->input('versionNumber') ?? "";
        $Employee->disable = $request->input('disable') ?? "";
        $Employee->versionName = $request->input('versionName') ?? "";
        $Employee->deviceOsVersion = $request->input('deviceOsVersion') ?? "";
        $Employee->token = $request->input('token') ?? "";
        $Employee->acceptedGDPR = $request->input('acceptedGDPR') ?? "";
        $Employee->acceptedGDPRDate = $request->input('acceptedGDPRDate') ?? "";
        $Employee->weeklyEmail = $request->input('weeklyEmail') ?? "";
        $Employee->altEmail = $request->input('altEmail') ?? "";
        $Employee->updatedAt = $request->input('updatedAt') ?? "";

        $Employee->appUserId = $request->input('appUserId') ?? "";
        $Employee->platformPayment = $request->input('platformPayment') ?? "";
        $Employee->productIdentifier = $request->input('productIdentifier') ?? "";
        $Employee->billingStart = $request->input('billingStart') ?? "";
        $Employee->subscriptionExpires = $request->input('subscriptionExpires') ?? "";
        $Employee->isSandbox = $request->input('isSandbox') ?? "";
        $Employee->defaultLanguage = $request->input('defaultLanguage') ?? "";

        $Employee->receiveEmails = $request->input('receiveEmails') ?? "";
        $Employee->receivePush = $request->input('receivePush') ?? "";
        $Employee->receiveRemidersDay = $request->input('receiveRemidersDay') ?? "";
        $Employee->receiveRemindersTime = $request->input('receiveRemindersTime') ?? "";  // HH:mm

        $Employee->languageLocale = $request->input('languageLocale') ?? "";

        $Employee->deleteAccountRequested = $request->input('deleteAccountRequested') ?? "0";


        //print_r($Employee); die;

        //$Employee->fill($Employee); 

        if ($Employee->save()) {
            //return new EmployeeResource($Employee);
            return response()->json(['message' => 'Employee data inserted Successfully.'], 200);
        }
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $employee = Employee::where('userId', $id)->first();

        if (!$employee) {
            return response()->json(["message" => "Not found!"], 404);
        }


        if (in_array(auth()->user()->accesslevel, [0, 3])) {
            if (auth()->user()->email !== $id) {
                return response()->json(["message" => "Forbidden!"], 403);
            }
        }

        $validator = Validator::make($request->all(), [
            "i_d" => "nullable",
            "verification_code" => "nullable",
            "subscriptionValidDate" => "nullable",
            "mobileOS" => "nullable",
            "Location" => "nullable",
            "accountCreationDate" => "nullable",
            "lastLoginDate" => "nullable",
            "Mobilewcode" => "nullable",
            "FirstName" => "nullable",
            "CountryCode" => "nullable",
            "activationDate" => "nullable",
            "LastName" => "nullable",
            "deviceMake" => "nullable",
            "fcmToken" => "nullable",
            "accountActivated" => "nullable",
            "status" => "nullable",
            "Mobile" => "nullable",
            "company" => "nullable",
            "DNI" => "nullable",
            "versionNumber" => "nullable",
            "disable" => "nullable",
            "versionName" => "nullable",
            "deviceOsVersion" => "nullable",
            "token" => "nullable",
            "acceptedGDPR" => "nullable",
            "acceptedGDPRDate" => "nullable",
            "weeklyEmail" => "nullable",
            "altEmail" => "nullable",
            "appUserId" => "nullable",
            "platformPayment" => "nullable",
            "productIdentifier" => "nullable",
            "billingStart" => "nullable",
            "subscriptionExpires" => "nullable",
            "isSandbox" => "nullable",
            "defaultLanguage" => "nullable",
            "receiveEmails" => "nullable",
            "receivePush" => "nullable",
            "receiveRemidersDay" => "nullable",
            "receiveRemindersTime" => "nullable",
            "languageLocale" => "nullable",
            "deleteAccountRequested" => "nullable",
            "currentCourse" => "nullable",
            "currentModule" => "nullable",
            "levelOfLanguage" => "nullable",
            "timezone" => "nullable",
            "gender" => "nullable",
            "dob" => "nullable",
            "age" => "nullable",
            "education" => "nullable",
            "qualification" => "nullable",
            "age_range" => "nullable",
            "reason_to_learn" => "nullable",
            "max_daily_push" => "nullable",
            "daily_goal_total" => "nullable",
            "enforceWall" => "nullable",
            "payWallLesson" => "nullable",
            "payWallSummary" => "nullable",
            "livesLessonWall" => "nullable",
            "dailyLivesCount" => "nullable",
            "dailyLivesLeft" => "nullable",
            "lockedLessons" => "nullable",
            "user_language" => "nullable",
        ]);

        //$validated = array_filter($validator->validated());

        $validated = $validator->validated();

        // check if DNI is already there
        if ($request->has('DNI') && $employee->DNI) {
            // don't save DNI
            unset($validated['DNI']);
        }

        // sanity check employee
        if ($request->has('currentCourse')) {
            if (!DB::table('employeecourse')->where('userId', $id)->where("courseNumber", $request->currentCourse)->exists()) {
                // if the employee has not registered for the course he is trying to use as current, clear the request
                unset($validated['currentCourse']);
            } else {
                // save levelOfLanguage
                if (isset($validated['levelOfLanguage'])) {
                    DB::table('employeecourse')
                        ->where('userId', $id)->where("courseNumber", $request->currentCourse)
                        ->update([
                            'levelOfLanguage' => $validated['levelOfLanguage']
                        ]);
                }

                // update the current moduleNumber
                $mNo = Course::where('courseNumber', $request->currentCourse)->first()->moduleNumber;
                $validated['currentModule'] = $mNo;
            }
        }
        // sanity check request has lastLoginDate
        if ($request->has("lastLoginDate")) {
            $timezone = isset($validated["timezone"]) ? $validated["timezone"] : $employee->timezone;
            $validated['lastLoginDate'] = \Carbon\Carbon::createFromTimeString($validated['lastLoginDate'], $timezone);
        }

        // check if user has last

        $employee->update($validated);

        return response()->json(['message' => 'Employee data updated Successfully.', 'request' => $validated]);
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $id)
    {



        try {

            $Employee = Employee::findOrFail($id);
            return new EmployeeResource($Employee);
        }
        // catch(Exception $e) catch any exception
        catch (ModelNotFoundException $e) {
            return response()->json(['message' => 'Not Found!'], 404);
        }
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {



        try {

            $Employee = Employee::findOrFail($id);

            if ($Employee->delete()) {
                return response()->json(['message' => 'Removed!'], 200);
            }
        }
        // catch(Exception $e) catch any exception
        catch (ModelNotFoundException $e) {
            return response()->json(['message' => 'Not Found!'], 404);
        }

        //print_r($Employee->id); die();





    }



    public function addEmployeeCourse(Request $request)
    {
        if (!$request->has('userId') || !$request->has('courseNumber')) {
            return response()->json(["error" => "Malformed request"], 500);
        }

        $results = DB::table('courses')->select('i_d')->where('courseNumber', $request->input('courseNumber'))->get();

        //print_r($results);

        // Employee doesn't belong to this Company 
        if (sizeof($results) == 0) {
            return response()->json(['message' => "Employee / Course doesn't belong to this Company!"], 200);
        }



        $results = DB::table('employee')->select('i_d')->where('userId', $request->input('userId'))->get();

        //print_r($results);

        // Employee doesn't belong to this Company 
        if (sizeof($results) == 0) {
            return response()->json(['message' => "Employee doesn't belong to this Company!"], 200);
        }


        $results = DB::table('employeecourse')->select('i_d')->where('userId', $request->input('userId'))
            ->where('courseNumber', $request->input('courseNumber'))->get();

        //print_r($results);

        //echo $results[0]->id;

        if (sizeof($results) == 0) {

            $data = array(
                "Id" => time(),
                "userId" => $request->input('userId'),
                "courseNumber" => $request->input('courseNumber'),
                "completedStatus" => "0",
                "couseGroup" => "",
                "dateRegistered" => date("Y-m-d"),
                "evaluationCompleted" => "",
            );

            DB::table('employeecourse')->insert($data);

            // set this course to current course of the employee
            DB::table('employee')->where('userId', $request->input('userId'))->update([
                "currentCourse" => $request->input('courseNumber'),
                "currentModule" => getCourseModule($request->input('courseNumber'))
            ]);
            // set this course to current course of the employee end
            // trigger usercourseaddedevent
            event(new UserCourseAdded(["userId" => $request->input('userId'), "courseNumber" => $request->input('courseNumber')]));

            return response()->json(['message' => 'Employee is successfully registered for this Course', 'courseNumber' => $request->input('courseNumber')], 200);
        } else {
            return response()->json(['message' => 'Employee is already registered for this Course', 'courseNumber' => $request->input('courseNumber')], 200);
        }
    }



    public function removeEmployeeCourse(Request $request)
    {
        if (!$request->has('userId') || !$request->has('courseNumber')) {
            return response()->json(["error" => "Malformed request"], 500);
        }

        $results = DB::table('courses')->select('i_d')->where('courseNumber', $request->input('courseNumber'))->get();

        //print_r($results);

        // Employee doesn't belong to this Company 
        if (sizeof($results) == 0) {
            return response()->json(['message' => "Employee / Course doesn't belong to this Company!"], 200);
        }



        $results = DB::table('employee')->select('i_d')->where('userId', $request->input('userId'))->get();

        //print_r($results);

        // Employee doesn't belong to this Company 
        if (sizeof($results) == 0) {
            return response()->json(['message' => "Employee doesn't belong to this Company!"], 200);
        }


        $results = DB::table('employeecourse')->select('i_d')->where('userId', $request->input('userId'))
            ->where('courseNumber', $request->input('courseNumber'))->get();

        //print_r($results);

        if (sizeof($results) > 0) {

            DB::table('employeecourse')->where('i_d', $results[0]->i_d)->delete();

            return response()->json(['message' => 'Employee is removed from this Course'], 200);
        } else {

            return response()->json(['message' => 'Employee is not registered for this Course'], 200);
        }
    }


    //employeeCourseJsonWithEmail
    public function employeeCourseJsonWithEmail(Request $request)
    {

        //employee_course_json_with_email_new_api.php
        //https://api1.taplingua.com/v1/employee_course_json_with_email_new_api.php?userId=paula.avalos@iberostar.com

        $request->validate([
            "userId" => "required"
        ]);

        $userId = $request->input('userId');

        $employeeCourseJson = array();

        $sql = "SELECT a.*, b.moduleNumber FROM  `employeecourse` a Join courses b on a.courseNumber = b.courseNumber WHERE  a.userId LIKE  '" . $userId . "'";


        $query = DB::select(DB::raw($sql));

        if (sizeof($query) > 0) {

            foreach ($query as $rows) {

                $modName = getModuleNameByCourse($rows->moduleNumber);

                $getModuleNameByCourseInfo = getModuleNameByCourseInfo($rows->moduleNumber);

                //print_r($getModuleNameByCourseInfo);

                //echo $getModuleNameByCourseInfo->long_description." pppppp";

                $modNameLong = $getModuleNameByCourseInfo['long_description'] ?? '';

                $toLanguage = $getModuleNameByCourseInfo['tolanguage'] ?? '';

                $rows->moduleName = $modName;

                $rows->wordcount = cards_words_count($rows->moduleNumber);

                $rows->long_description = $modNameLong;

                $rows->to_language = $toLanguage;

                $rows->loopState = $rows->loopState ?? '';


                $rows->coursePercent = coursePercent($rows->moduleNumber, $userId);


                $rows->module_lesson_count = module_lesson_count($rows->moduleNumber);


                $rows->routeCount = routeCount($rows->moduleNumber);




                $sqlR = "SELECT * FROM `route` where moduleno = '" . $rows->moduleNumber . "'  and status = '1' order by description ";


                $routes = DB::select(DB::raw($sqlR));


                $Routes = array();

                $j = 1;

                $Lessons = array();

                foreach ($routes as $rot) {


                    //// filter based on route Numbers  
                    // filter
                    /*if(!empty($routeNumberArr))
                {
                
                if(!in_array($rot['routeno'], $routeNumberArr)) continue;

                } */

                    //$Routes[] = $rot['description'];

                    $Levels = array();

                    for ($i = 1; $i <= 5; $i++) {



                        $sql1 = "SELECT distinct moduleNo, routeNo, levelNo, lessonNo FROM `useractivitylog_api` where moduleNo = '" . $rows->moduleNumber . "' and routeNo = '" . $rot->routeno . "' and levelNo = '" . $j . "' and userId = '" . $userId . "' order by moduleNo, routeNo, levelNo, lessonNo";




                        $result1 = DB::select(DB::raw($sql1));




                        if (sizeof($result1) > 0) {

                            $Lessons = array();

                            foreach ($result1 as $rws) {

                                $Lessons[] = array("Lesson " . $rws->lessonNo => "33");
                            }
                        } else { }



                        $Levels["Level " . $j] = array("levelPercent" => levelPercent($rows->moduleNumber, $rot->routeno, $j, $userId), "Lessons" => $Lessons);


                        $j++;
                    }


                    $Routes[$rot->description] = array("routePercent" => routePercent($rows->moduleNumber, $rot->routeno, $userId), "Levels" => $Levels);

                    //$Routes[$rot['description']] = "00";

                    //$Routes[$rot['description']]["Levels"][] = $Levels;




                }


                $rows->Routes = $Routes;

                // adding the badges for this course
                $rows->badges = UserBadgeResource::collection(UserBadge::with('badge')->where("userId", $userId)->get()); // TODO - Add user badges here
                // adding the badges for this course end

                $employeeCourseJson[] = $rows;
            }
        }


        return $employeeCourseJson;
    }


    //completionReportAverage
    public function completionReportAverage(Request $request)
    {



        $request->validate([
            "companyCode" => "required",
            "batchNumber" => "required",
            "courseNumber" => "required"
        ]);

        // API V1 = https://api1.taplingua.com/v1/completion-reports-api.php?companyCode=131&courseNumber=20181312&batchNumber=2&routeNumber=1,2,3,4,5,6
        // API V2 = completion-report-average?companyCode=131&courseNumber=20181312&batchNumber=2&routeNumber=1,2,3,4,5,6


        $companyCode = $request->input('companyCode');
        $batchNumber = $request->input('batchNumber');
        $courseNumber = $request->input('courseNumber');
        $routeNumber = $request->input('routeNumber');

        $filter = array();

        if ($companyCode != "") {
            $filter[] = " e.CompanyCode = '" . trim($companyCode) . "'";
        }
        if ($batchNumber != "") {
            $filter[] = " c.courseBatch = '" . trim($batchNumber) . "'";
        }
        if ($courseNumber != "") {
            $filter[] = " ec.courseNumber = '" . trim($courseNumber) . "'";
        }
        if (trim($routeNumber) != "") {
            $filter[] = " r.routeno in( " . $routeNumber . ")";
        }

        $where = "";

        if (count($filter)) {
            $where = " where " . implode(" and ", $filter);
        }

        $sql = "SELECT DISTINCT ec.i_d, ec.`dateRegistered`,ec.`completedStatus`,e.`CompanyCode` ,ec.`userId`,ec.`evaluationCompleted`, ec.`courseNumber`
        , ec.`Id`, ec.`couseGroup`, concat(e.`FirstName`,' ', e.`LastName`) AS Name, e.`mobileOS`, e.`Location`
        , e.`Mobile`, e.`DNI`,c.`moduleNumber`, c.`courseBatch`
        , r.long_description, r.`description`  , r.`routeno`
        FROM employeecourse ec
        JOIN employee e ON e.`userId` = ec.`userId`
        JOIN courses c ON c.`courseNumber` = ec.`courseNumber`
        JOIN route r ON r.`moduleno` = c.`moduleNumber`
        $where";


        $response = array();

        $query = DB::select(DB::raw($sql));

        if (sizeof($query) > 0) {

            foreach ($query as $rows) {
                $key = $rows->userId . $rows->CompanyCode . $rows->courseNumber . $rows->moduleNumber;
                if (isset($response[$key])) {
                    $response[$key]['Routes'][$rows->description] = array("routePercent" => routePercent($rows->moduleNumber, $rows->routeno, $rows->userId), "routeTime" => routeTime($rows->moduleNumber, $rows->routeno, $rows->userId), 'routeno' => $rows->routeno);
                } else {
                    $rData = array();
                    $rData['i_d'] = $rows->i_d;
                    $rData['userId'] = $rows->userId;
                    $rData['Name'] = trim($rows->Name);
                    $rData['Location'] = trim($rows->Location);
                    $rData['Mobile'] = trim($rows->Mobile);
                    $rData['mobileOS'] = trim($rows->mobileOS);
                    $rData['coursePercent'] = coursePercent($rows->moduleNumber, $rows->userId);

                    // // sum(difference of start and end time) group by userId, moduleNo, routeNo from Table: usersessionlog_api
                    $rData["sessionTotalTime"] = sessionTotalTime($rows->userId, $rows->moduleNumber, $rows->routeno);

                    $response[$key] = $rData;
                    $response[$key]['Routes'][$rows->description] = array("routePercent" => routePercent($rows->moduleNumber, $rows->routeno, $rows->userId), "routeTime" => routeTime($rows->moduleNumber, $rows->routeno, $rows->userId), 'routeno' => $rows->routeno);
                }
            }
        }

        $reportsData = array();

        foreach ($response as $key => $value) {
            $reportsData[] = $value;
        }


        return $reportsData;
    }


    //completionReport
    public function completionReport(Request $request)
    {


        $request->validate([
            "companyCode" => "required"
        ]);

        $companyCode = $request->input('companyCode');
        $routeNumber = $request->input('routeNumber');
        $batchNumber = $request->input('batchNumber');
        $courseNumber = $request->input('courseNumber');

        //print_r($routeNumber);

        if ($routeNumber != "")
            $routeNumberArr = $routeNumber;  //explode(",", trim($routeNumber));
        else
            $routeNumberArr = array();

        $comp = array();

        $whr = "";


        if ($batchNumber != "")
            $whr .= " and b.courseBatch = '" . trim($batchNumber) . "'";

        if ($courseNumber != "")
            $whr .= " and b.courseNumber = '" . trim($courseNumber) . "'";


        $sql = "SELECT a.*, b.moduleNumber, b.courseBatch FROM  `employeecourse` a Join courses b on a.courseNumber = b.courseNumber WHERE  b.Company = '" . $companyCode . "' $whr";

        //echo $sql;

        $query = DB::select(DB::raw($sql));

        //echo sizeof($query);

        if (sizeof($query) != 0) {

            foreach ($query as $rows) {

                //print_r($rows);

                $userId = $rows->userId;

                $empInfo = $this->employeeInfo($userId);

                //echo trim($empInfo[0]['CompanyCode'])." - ";

                //Display only company Users 
                if ($companyCode != trim($empInfo[0]['CompanyCode']))  continue;


                $rows->Name = trim($empInfo[0]['FirstName'] . " " . $empInfo[0]['LastName']);
                $rows->Location = trim($empInfo[0]['Location']);
                $rows->Mobile = trim($empInfo[0]['Mobile']);
                $rows->mobileOS = trim($empInfo[0]['mobileOS']);
                $rows->DNI = trim($empInfo[0]['DNI']);



                $modName = getModuleNameByCourse($rows->moduleNumber);

                $modNameLong = getModuleNameByCourseLong($rows->moduleNumber);

                $rows->moduleName = $modName;

                $rows->long_description = $modNameLong;


                $rows->coursePercent = coursePercent($rows->moduleNumber, $userId);

                //print_r($rows);

                $sqlR = "SELECT * FROM `route` where moduleno = '" . $rows->moduleNumber . "'  and status = '1' order by description ";

                $Routes = array();

                $j = 1;

                $queryR = DB::select(DB::raw($sqlR));



                foreach ($queryR as $rot) {


                    //// filter based on route Numbers  
                    if (!empty($routeNumberArr)) {

                        if (!in_array($rot->routeno, $routeNumberArr)) continue;
                    }


                    $Levels = array();
                    $Lessons = array();

                    for ($i = 1; $i <= 5; $i++) {

                        $sql1 = "SELECT distinct moduleNo, routeNo, levelNo, lessonNo FROM `useractivitylog_api` where moduleNo = '" . $rows->moduleNumber . "' and routeNo = '" . $rot->routeno . "' and levelNo = '" . $j . "' and userId = '" . $userId . "' order by moduleNo, routeNo, levelNo, lessonNo";

                        $query2 = DB::select(DB::raw($sql1));

                        //echo sizeof($query2)." svn ";

                        if (sizeof($query2) > 0) {


                            $Lessons = array();

                            //print_r($query2);  

                            foreach ($query2 as $rws) {

                                $Lessons[] = array("Lesson " . $rws->lessonNo => "33");
                            }
                        } else {
                            //                             
                        }


                        $Levels["Level " . $j] = array("levelPercent" => levelPercent($rows->moduleNumber, $rot->routeno, $j, $userId), "Lessons" => $Lessons);

                        $j++;
                    }

                    $Routes[removeNewLine($rot->description)] = array("routePercent" => routePercent($rows->moduleNumber, $rot->routeno, $userId), "Levels" => $Levels);
                }


                $rows->Routes = $Routes;

                $comp[] = $rows;
            }
        }

        return $comp;
    }




    //employeeCourseRegistered 
    public function employeeCourseRegistered(Request $request)
    {

        $userId = $request->input('userId');

        $empInfo = $this->employeeInfo($userId);

        //echo $empInfo[0]->userId; 
        //print_r($empInfo[0]->toArray());


        $employeeCourses = employeeCourses($userId);


        $courseList = array();

        foreach ($employeeCourses as $ckey => $cvalue) {

            $courseList[] = array("courseNumber" => $cvalue->courseNumber, "courseName" => getModuleNameByCourse($cvalue->moduleNumber), "moduleCompletion_percent" => "");
        }

        //return $courseList;  

        $empInfo[0]['courseRegistered'] = $courseList;

        $empInfo[0]['courseCount'] = count($courseList);

        return $empInfo[0];
    }


    //employeeCourseRegistered 
    public function employeeCourseRegisteredAll(Request $request)
    {


        $request->validate([
            "companyCode" => "required",
            "courseNumber" => "required"
        ]);

        //print($request->companyCode);
        ///return "Chat Room";


        try {


            /// Get All Employee of Company

            $emps = array();
            $emps_email = array();

            $sql = "SELECT distinct(userId), FirstName, LastName, Location, Mobile, last_lesson FROM employee WHERE CompanyCode='" . $request->companyCode . "' ";

            $query = DB::select(DB::raw($sql));

            $results = array();

            // get course
            $course = Course::where('courseNumber', $request->courseNumber)->first();

            // get routes id that have status 1
            $routes = Route::where('moduleno', $course->moduleNumber)->where('status', '1')->pluck('routeno');
            // get totalLessons
            $totalLessons = Lesson::where('moduleno', $course->moduleNumber)
                ->whereIn('routeno', $routes)
                ->where('is_challenge', 0)
                ->where('challenge_type', '!=', 'milestone')
                ->whereRaw('MOD(lesson_no,3) != 0')
                ->where('status', '1')->count();


            foreach ($query as $rows) {

                //print_r($rows);
                $emps[] = $rows;

                $emps_email[] = $rows->userId;
            }


            $whr = "";

            if (isset($request->userId) && $request->userId != "")
                $whr .= " and ec.userId='" . $request->userId . "' ";

            if ($request->courseNumber != "")
                $whr .= " and ec.courseNumber='" . $request->courseNumber . "' ";

            //$sql = "SELECT * FROM employeecourse WHERE i_d!='' $whr ";
            $sql = "SELECT distinct(ec.`i_d`), ec.`subscriptionExpiresDate`, ec.`dateRegistered`, ec.`totalScore`, ec.`completedStatus`, ec.`userId`, ec.`last_lesson`, ec.`evaluationCompleted`,ec.`Id`,ec.`couseGroup`, e.`FirstName`, e.`LastName` FROM employeecourse ec JOIN employee e ON e.`userId` = ec.`userId` WHERE ec.`i_d`!='' " . $whr;

            $query = DB::select(DB::raw($sql));

            $results = array();


            $registered = array();

            foreach ($query as $rows) {


                if (in_array($rows->userId, $emps_email)) {

                    $moduleNumber = getCourseModule($request->courseNumber);
                    $dateRegistered = ($rows->dateRegistered != "") ? formatDate($rows->dateRegistered) : "";


                    $value1 = array(
                        "i_d" => $rows->i_d,
                        "FirstName" => $rows->FirstName,
                        "LastName" => $rows->LastName,
                        "dateRegistered" => $dateRegistered,
                        "completedStatus" => $rows->completedStatus,
                        "userId" => $rows->userId,
                        "subscriptionExpiresDate" => $rows->subscriptionExpiresDate,
                        "evaluationCompleted" => trim($rows->evaluationCompleted),
                        "Id" => $rows->Id
                    );


                    $value1['completionPercentage'] = coursePercent($moduleNumber, $rows->userId);
                    $value1['totalTimeSpent'] = "";
                    $value1['lastSession'] = lastSession($rows->userId, $request->courseNumber);
                    $value1['certificate'] = getCertificateIfExists($rows->userId, $request->courseNumber);
                    $value1['totalLessons'] = $totalLessons;
                    $value1['totalScore'] = $rows->totalScore;

                    $userActivities = \App\UserActivityLog::distinct('lessonNo')->where('activityType', 3)->where('moduleNo', $course->moduleNumber)->where('userId', $rows->userId)->orderBy('lessonNo', 'desc')->get();

                    $last_lesson = $userActivities->count() > 0 ? $userActivities[0]->lessonNo : 0;


                    $value1['$last_lesson'] = $last_lesson;
                    $value1['currentMilestone'] = $last_lesson < 15 ? 1 : ($last_lesson < 30 ? 2 : ($last_lesson < 45 ? 3 : 4));


                    // get total lessons and lessonsComplete
                    $value1['lessonsCompleted'] = $userActivities->count();




                    $results[] = $value1;



                    $registered[] = $rows->userId;
                }
            }


            $available = array();

            foreach ($emps as $key => $value) {

                //echo "<pre>"; print_r($value);

                if (!in_array($value, $registered))
                    $available[] = $value;
            }


            //$emp = array("companyCode" => $request->companyCode, "courseNumber" => $request->courseNumber, "courseRoomName" => app('App\Http\Controllers\CourseController')->getCourseName($request->courseNumber), "registered" => $results, "availableToRegister" => $available);

            $emp = array("companyCode" => $request->companyCode, "courseNumber" => $request->courseNumber, "registered" => $results, "availableToRegister" => $available);

            return $emp;
        } catch (ModelNotFoundException $e) {
            return response()->json(['message' => $e], 404);
        }
    }

    /**
     * Show the form to register users
     *
     * @param Request $request
     * @return void
     */
    public function showEmployeeCourseRegistrationForm(Request $request)
    {
        // get course
        $course = Course::where('courseNumber', $request->courseNo)->first();

        if (!$course) {
            abort(404, "Course No Missing");
        }

        return view('app.employee-course-registration-form', [
            'course' => $course
        ]);
    }

    public function showEmployeeCourseRegistrationSuccess(Request $request)
    {
        return view('app.employee-course-registration-success');
    }


    /**
     * Register the users for the course
     *
     * @param Request $request
     * @return void
     */
    public function registerEmployeeToTheCourse(Request $request)
    {
        $this->validate($request, [
            'courseNo' => 'required|exists:courses,courseNumber',
            'email' => 'required|email',
            'FirstName' => 'nullable|string',
            'LastName' => 'nullable|string',
            'mobile' => 'nullable|numeric|digits:10',
            'location' => 'nullable|string',
        ]);

        try {
            // get the course
            $course = \App\Course::where('courseNumber', $request->courseNo)->first();
            // get the module
            $module = Module::where('moduleno', $course->moduleNumber)->first();
            // create an employee with the information
            $employee = \App\Employee::where('userId', $request->email)->first();

            if (!$employee) {
                $employee = \App\Employee::create([
                    'currentCourse' => $request->courseNo,
                    'currentModule' => $course->moduleNumber,
                    'CompanyCode' => $course->Company,
                    'FirstName' => $request->FirstName ?? "",
                    'LastName' => $request->LastName ?? "",
                    'userId' => $request->email,
                    'Mobile' => $request->mobile ?? "",
                    'Location' => $request->location ?? "",
                    'accountCreationDate' => now(),
                ]);
            }
            // check if course already there
            $courseSubscribed = \DB::table('employeecourse')->where('userId', $employee->userId)
                ->where('courseNumber', $request->courseNo)->first();
            if ($courseSubscribed) {
                return redirect()->back()->withInput()->with('error', 'Course already subscribed to!');
            }
            // assign the employee to the said course
            \DB::table('employeecourse')->insert([
                'dateRegistered' => now(),
                'userId' => $employee->userId,
                'courseNumber' => $request->courseNo,
            ]);

            $password = substr(md5(now()), 0, 8);

            // get the user
            $user = User::where('email', $employee->userId)->first();

            if (!$user) {
                // create the user
                $user = User::create([
                    "email" => $employee->userId,
                    "fullname" => $employee->FirstName . " " . $employee->LastName,
                    "password" => bcrypt($password),
                    'token' => md5($employee->userId . time()),
                    'uid' => uniqid(),
                    'accesslevel' => 0
                ]);
                $isNewUser = true;
                // send mail
                Mail::to($employee->userId)
                    ->send(new EnrolledEmployeeWelcomeEmail(
                        $user->fullname,
                        $module->description,
                        $employee->userId,
                        $password
                    ));

                // Send SMS
                sendSMS("+91" . $request->mobile, "Hi " . $request->FirstName . " 
                    \nYour taplingua account has been created.
                    \nPlease download the Taplingua Language app:
                    \nhttps://play.google.com/store/apps/details?id=com.taplingua.languages
                    \nPlease check your email for account login details.
                    \nThanks
                    \nTaplingua Team");
            } else {
                // send mail anyway
                Mail::to($employee->userId)
                    ->send(new EnrolledEmployeeWelcomeEmail(
                        $user->fullname,
                        $module->description,
                        $employee->userId,
                        ""
                    ));

                // Send SMS
                sendSMS("+91" . $request->mobile, "Hi " . $request->FirstName . " 
                    \nYou are registered to a new course.
                    \nPlease download the Taplingua Language app:
                    \nhttps://play.google.com/store/apps/details?id=com.taplingua.languages
                    \nThanks
                    \nTaplingua Team");
            }
            // return success message
            return redirect()->to('/app/employee-course-registration-success')->with('message', 'Thanks for registering for the ' . $course->courseName);
        } catch (\Throwable $th) {
            \Log::error("Could not register user to course!", [$th]);
            return redirect()->back()->withInput()->with('error', 'Registered to course ' . $course->courseName . ' failed!');
        }
    }

    /**
     * Get report of all employee registered in last x days as report
     */
    public function employeeCourseRegisterationReport(Request $request)
    {
        $courseNo = $request->courseNo;
        $lastXDays = (int) $request->lastXDays;

        $response = [];

        // generate the report according to last days
        for ($i = 0; $i < $lastXDays; $i++) {
            $date = today()->subDays($lastXDays - $i);
            $usersRegistered = Employee::select('userId', 'FirstName', 'LastName')
                ->whereDate('accountCreationDate', $date)
                ->where('currentCourse', $courseNo)->get();
            $response[] = [
                "date" => $date,
                "userRegistered" => $usersRegistered
            ];
        }

        return response()->json([
            "lastXDays" => $lastXDays,
            "report" => $response
        ]);
    }

    /**
     * Get report of all employee registered in last x days as report
     */
    public function employeeCompanyRegisterationReport(Request $request)
    {
        $companyCode = $request->companyCode;
        $lastXDays = (int) $request->lastXDays;

        $response = [];

        // generate the report according to last days
        for ($i = 0; $i < $lastXDays; $i++) {
            $date = today()->subDays($lastXDays - $i);
            $usersRegistered = Employee::select('userId', 'FirstName', 'LastName')
                ->whereDate('accountCreationDate', $date)
                ->where('CompanyCode', $companyCode)->get();
            $response[] = [
                "date" => $date,
                "userRegistered" => $usersRegistered
            ];
        }

        return response()->json([
            "lastXDays" => $lastXDays,
            "report" => $response
        ]);
    }

    /**
     * Get report of all employee registered in last x days as report
     */
    public function employeeCompanyActivationReport(Request $request)
    {
        $companyCode = $request->companyCode;
        $lastXDays = (int) $request->lastXDays;

        $response = [];
        // generate the report according to last days
        for ($i = 0; $i < $lastXDays; $i++) {
            $date = today()->subDays($lastXDays - $i);
            $usersRegistered = Employee::select('userId', 'FirstName', 'LastName')
                ->whereDate('accountCreationDate', $date)
                ->where('CompanyCode', $companyCode)
                ->get();
            // get the count of users, that are activated
            $usersActivate = [];
            foreach ($usersRegistered as $emp) {
                if (User::where('email', $emp->userId)->exists()) {
                    $usersActivate[] = $emp;
                }
            }
            $response[] = [
                "date" => $date,
                "usersRegistered" => $usersRegistered,
                "usersActivate" => $usersActivate,
            ];
        }

        return response()->json([
            "lastXDays" => $lastXDays,
            "report" => $response
        ]);
    }

    /**
     * Get report of all employee activated registered in last x days as report
     */
    public function employeeCompanyRegistrationActivationReport(Request $request)
    {
        $companyCode = $request->companyCode;
        $startDate = Carbon::parse($request->startDate);
        $endDate = Carbon::parse($request->endDate);

        $date = Carbon::parse($request->startDate);

        $response = [];

        $usersRegisteredCount = 0;
        $usersActivatedCount = 0;

        // generate the report according to last days
        while ($date->lte($endDate)) {
            $usersRegistered = Employee::select('userId', 'FirstName', 'LastName', 'accountCreationDate', 'activationDate')
                ->whereDate('accountCreationDate', $date)
                ->where('CompanyCode', $companyCode)
                ->get();
            $usersRegisteredCount += $usersRegistered->count();
            // get the count of users, that are activated
            $usersActivate = [];
            foreach ($usersRegistered as $emp) {
                if ($emp->activationDate) {
                    $usersActivate[] = $emp;
                }
            }
            $usersActivatedCount += count($usersActivate);
            $response[] = [
                "date" => Carbon::parse($date),
                "usersRegistered" => $usersRegistered,
                "usersActivate" => $usersActivate,
            ];
            $date = $date->addDay();
        }

        // all registered user data
        $allRegisteredUsers = Employee::select('userId', 'FirstName', 'LastName', "Mobile", "Location", "accountCreationDate", "currentModule", "activationDate", "totalScore", "last_lesson")
            ->whereBetween('accountCreationDate', [$startDate->startOfDay(), $endDate->endOfDay()])
            ->where('CompanyCode', $companyCode)
            ->get();

        // add %completed to the 
        foreach ($allRegisteredUsers as $user) {
            try {
                $user->courseCompleted = coursePercent($user->currentModule, $user->userId);
            } catch (\Throwable $th) {
                $user->courseCompleted = 0;
                //throw $th;
            }
        }

        return response()->json([
            "startDate" => $startDate->format("Y-m-d"),
            "endDate" => $endDate->format("Y-m-d"),
            "usersRegisteredCount" => $usersRegisteredCount,
            "usersActivatedCount" => $usersActivatedCount,
            "report" => $response,
            "allRegisteredUsers" => $allRegisteredUsers,
        ]);
    }



    public function employeeCompanyRegistrationActivationCSV(Request $request)
    {
        // get input
        $companyCode = $request->companyCode;
        $startDate = Carbon::parse($request->startDate);
        $endDate = Carbon::parse($request->endDate);

        // all registered user data
        $users = Employee::select('userId', 'FirstName', 'LastName', "Mobile", "Location", "accountCreationDate", "activationDate", "totalScore")
            ->whereBetween('accountCreationDate', [$startDate, $endDate])
            ->where('CompanyCode', $companyCode)
            ->get();

        // add %completed to the , and format it
        foreach ($users as $user) {
            $newUser = [
                'userId' => $user->userId,
                'Name' => $user->FirstName . " " . $user->LastName,
                "Mobile" => $user->Mobile,
                "Location" => $user->Location,
                "accountCreationDate" => $user->accountCreationDate,
                "activationDate" => $user->activationDate,
                "totalScore" => $user->totalScore
            ];
            try {
                $newUser["courseCompleted"] = coursePercent($user->currentModule, $user->userId);
            } catch (\Throwable $th) {
                $newUser["courseCompleted"]  = 0;
                //throw $th;
            }
            $user = $newUser;
        }

        // prep headers
        $headers = array(
            "Content-type" => "text/csv",
            "Content-Disposition" => "attachment; filename=additiona-lives-claimed-" . now()->toDateString() . ".csv",
            "Pragma" => "no-cache",
            "Cache-Control" => "must-revalidate, post-check=0, pre-check=0",
            "Expires" => "0"
        );

        $columns = array('Email', 'Contact Number', 'Location', 'Registration Date', 'Activation Date', 'Points Scored', '% Completed');

        $callback = function () use ($users, $columns) {
            $file = fopen('php://output', 'w');
            fputcsv($file, $columns);

            foreach ($users as $user) {
                fputcsv($file, $user->toArray());
            }
            fclose($file);
        };

        $response = response()->stream($callback, 200);

        foreach ($headers as $headerKey => $header) {
            $response->headers->set($headerKey, $header);
        }

        return $response;
    }

    /**
     * Says what it does
     *
     * @param Request $request
     * @return void
     */
    public function employeeCourseUpdateSubscriptionExpires(Request $request)
    {
        $userId = $request->userId;
        $courseNo = $request->courseNo;
        $subscriptionExpiresDate = $request->subscriptionExpiresDate;

        try {
            \DB::table('employeecourse')
                ->where('courseNumber', $courseNo)
                ->where('userId', $userId)
                ->update([
                    "subscriptionExpiresDate" => $subscriptionExpiresDate
                ]);

            return response()->json([
                "message" => "Updated subscription expires date!",
                "data" => [
                    'userId' => $userId,
                    'courseNo' => $courseNo,
                    'subscriptionExpiresDate' => $subscriptionExpiresDate,
                ]
            ]);
        } catch (\Throwable $th) {
            \Log::error("could not Update subscription expires date", [$th->getMessage()]);
            //throw $th;
            return response()->json([
                'message' => "Something went wrong!"
            ], 500);
        }
    }
}
