<?php

namespace App\Http\Controllers;

use Illuminate\Database\Eloquent\ModelNotFoundException;
use App\Exercise;
use Illuminate\Http\Request;
use App\Http\Resources\Exercise as ExerciseResource;

use App\ExerciseDescription;
use App\Http\Resources\ExerciseDescription as ExerciseDescriptionResource;

use App\ExerciseMediaAlt3;
use App\Http\Resources\ExerciseMediaAlt3 as ExerciseMediaAlt3Resource;


use App\Http\Resources\CheckUserApiAccess as CheckUserApiAccess;
use DB;
use checkUserPermissionController;
use Session;
use Validator;

class ExerciseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $_callback = $request->input('_callback');

        $id = $request->input('id');

        $module_no = $request->input('module_no');

        $moduleno = $request->input('moduleno');

        $routeno = $request->input('routeno');

        $lessonno = $request->input('lessonno');

        $output = $request->input('output') ? $request->input('output') : 'object';

        if($lessonno!="")
         $id = $lessonno;

        $whr = ""; 

 
        if($module_no!="")
         $whr .= " and moduleno='".$module_no."' ";

        if($moduleno!="")
         $whr .= " and moduleno='".$moduleno."' "; 
         
        if($routeno!="")
         $whr .= " and routeno='".$routeno."' "; 

        
        if($id!="")
         $q = "select * from `exercise` where lesson_no = '".$id."' $whr and status = '1' ";
        else
         $q = "select * from `exercise` where status = '1' $whr  "; 

        //echo $q; 

        $query = DB::select(DB::raw($q));
         
        $exercises = array(); 

        foreach($query as $exercise){


                        
            $qq = "select `title` from `lessons` where id = '".$exercise->lesson_id."' ";
            //$lesson = mysql_fetch_assoc($qq);
            $lesson = DB::select(DB::raw($qq));

            $qq = "select `title`, `status` from `lessons` where moduleno = '".$exercise->moduleno."' and routeno = '".$exercise->routeno."' and lesson_no = '".$exercise->lesson_no."'  ";
            //$lesson_status = mysql_fetch_assoc($qq);
            $lesson_status = DB::select(DB::raw($qq));



            $qq = "select `title` from `exercise_type` where id = '".$exercise->exercise_type_id."' ";
            //$exercise_type = mysql_fetch_assoc($qq);
            $exercise_type = DB::select(DB::raw($qq));

            $descr = explode("\n", trim($exercise->description));

            $descr = str_replace("\r", "", $descr);

            $media = explode("\n", $exercise->media);

            $media = str_replace("\r", "", $media);

            $media_alt1 = explode("\n", $exercise->media_alt1);
            $media_alt2 = explode("\n", $exercise->media_alt2);
            $media_alt3 = explode("\n", $exercise->media_alt3);

            $media_alt1 = str_replace("\r", "", $media_alt1);
            $media_alt2 = str_replace("\r", "", $media_alt2);
            $media_alt3 = str_replace("\r", "", $media_alt3);

            
            $summary_translation = explode("\n", $exercise->summary_translation);
            $summary_translation = str_replace("\r", "", $summary_translation);

            $summary_new_format = $exercise->summary_new_format;

            //print_r($lesson_status); 

            $exercises[] = array('id' => $exercise->id, 
                                 'exercise_no' => $exercise->exercise_no, 
                                 'routeno' => $exercise->routeno, 
                                 'moduleno' => $exercise->moduleno, 
                                 'lesson_no' => $exercise->lesson_no, 
                                 'lesson_id' => $exercise->lesson_id, 
                                 'lesson_name' => $lesson_status[0]->title, 
                                 'lesson_status' => $lesson_status[0]->status, 
                                 'exercise_type_id' => $exercise->exercise_type_id, 
                                 'exercise_type_name' => $exercise_type[0]->title, 
                                 'title' => $exercise->title, 
                                 'total_questions' => count($descr), 
                                 'description' => $descr, 
                                 'media' => $media, 
                                 'media_alt1' => $media_alt1, 
                                 'media_alt2' => $media_alt2, 
                                 'media_alt3' => $media_alt3, 
                                 'summary_translation' => $summary_translation, 
                                 'summary_new_format' => $summary_new_format, 
                                 'image' => "upload/".$exercise->image, 
                                 'status' => $exercise->status 
                                );



        }    

        //return $exercises;

            if($output=="object")
            {
                if(count($exercises) === 0) {
                    return response()->json((object) []);
                }

               if(count($exercises)=="1")
                 return $exercises[0];


                return $exercises;

            }
            else
            {

                // called from lesson pack process for exercise txt file Lesson_4_Exercises.txt
                return $exercises;

            }

        

    }


    public function indexExercisePack(Request $request, $file)
    {

        $return = json_encode($this->index($request), JSON_PRETTY_PRINT);

        file_put_contents($file, $return);

        return $return;

    } 


    public function list(Request $request)
    {
        
        $Exercise = Exercise::query(); 

        $Exercise->orderBy('id','asc');

        if ($request->input('moduleNo') != "") {

            $Exercise->where('moduleno', $request->input('moduleNo'));
        }

        if ($request->input('routeNo') != "") {

            $Exercise->where('routeno', $request->input('routeNo'));
        }

        if ($request->input('lessonNo') != "") {

            $Exercise->where('lesson_no', $request->input('lessonNo'));
        }

        if ($request->input('exerciseNo') != "") {

            $Exercise->where('exercise_no', $request->input('exerciseNo'));
        }

       
        if ($request->input('query') != "") {

            $query = $request->input('query');
            
            //SQL AND + OR + Brackets
            $Exercise->where(function($Exercise) use ($query) {
                $Exercise->where('title', 'LIKE', '%'.$query.'%')
                      ->orWhere('description', 'LIKE', '%'.$query.'%');
            });

        }

             
        $Exercise = $Exercise->paginate(50);

        return ExerciseResource::collection($Exercise);


    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

       
    
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $id)
    {
        
        try{

          $Exercise = Exercise::findOrFail($id);
          return new ExerciseResource($Exercise);
        
        } 
        // catch(Exception $e) catch any exception
        catch(ModelNotFoundException $e)
        {
            return response()->json(['message' => 'Not Found!'], 404);
        } 

    }



    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Exercise  $exercise
     * @return \Illuminate\Http\Response
     */
    public function edit(Exercise $exercise)
    {
        //
    }

    
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $request->validate([
            "title"=>"required",
            "moduleno"=>"required",
            "routeno"=>"required",
            "lesson_no"=>"required",
            "exercise_no"=>"required"
        ]);

        
        $Exercise = Exercise::findOrFail($id);
        
        $Exercise->update($request->all());

        return response()->json(['message' => 'Data Saved!'], 200);


    }



    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            "title"=>"required",
            "moduleno"=>"required",
            "routeno"=>"required",
            "lesson_no"=>"required",
            "exercise_no"=>"required"
        ]);


        $Exercise = $request->isMethod('put') ? Exercise::findOrFail($request->id) : new Exercise;

        $Exercise->id = $request->input('id');

        //$post->fill($request->input())->save();
        
        $Exercise->lesson_id = $request->input('lesson_id') ? $request->input('lesson_id') : ''; 
        $Exercise->moduleno = $request->input('moduleno'); 
        $Exercise->routeno = $request->input('routeno'); 
        $Exercise->lesson_no = $request->input('lesson_no'); 
        $Exercise->exercise_no = $request->input('exercise_no'); 
        $Exercise->exercise_type_id = $request->input('exercise_type_id') ? $request->input('exercise_type_id') : ''; 

        $Exercise->title = $request->input('title'); 
        $Exercise->description = $request->input('description') ? $request->input('description') : ''; 
        $Exercise->media = $request->input('media') ? $request->input('media') : ''; 

        $Exercise->media_alt1 = $request->input('media_alt1') ? $request->input('media_alt1') : '';
        $Exercise->media_alt2 = $request->input('media_alt2') ? $request->input('media_alt2') : '';
        $Exercise->media_alt3 = $request->input('media_alt3') ? $request->input('media_alt3') : '';
        
        $Exercise->summary_translation = $request->input('summary_translation') ? $request->input('summary_translation') : ''; 
        $Exercise->summary_new_format = $request->input('summary_new_format') ? $request->input('summary_new_format') : ''; 
        $Exercise->image = $request->input('image') ? $request->input('image') : ''; 
        $Exercise->status = $request->input('status') ? $request->input('status') : ''; 
        $Exercise->sequence = $request->input('sequence') ? $request->input('sequence') : ''; 
               
        //$Exercise->adddate = date("Y-m-d H:i:s");
         
       
        if($Exercise->save()){
            //return new EmployeeResource($Employee);
            return response()->json(['message' => 'Data Saved!'], 200);
        }


    }

    
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        
        //echo "Test...";

        try{  

          $Exercise = Exercise::findOrFail($id);

          if($Exercise->delete()){
            return response()->json(['message' => 'Removed!'], 200);
          }

        }        
        // catch(Exception $e) catch any exception
        catch(ModelNotFoundException $e)
        {
            return response()->json(['message' => 'Not Found!'], 404);
        }

        
    }




    /* CMS */


    public function listExercises(Request $request)
    {

        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

           $Exercise = Exercise::query(); 

        $Exercise->orderBy('id','asc');

        if ($request->input('moduleNo') != "") {

            $Exercise->where('moduleno', $request->input('moduleNo'));
        }

        if ($request->input('routeNo') != "") {

            $Exercise->where('routeno', $request->input('routeNo'));
        }

        if ($request->input('lessonNo') != "") {

            $Exercise->where('lesson_no', $request->input('lessonNo'));
        }

        if ($request->input('exerciseNo') != "") {

            $Exercise->where('exercise_no', $request->input('exerciseNo'));
        }


        if ($request->input('status') != "") {

            $Exercise->where('status', $request->input('status'));
        }

       
        if ($request->input('query') != "") {

            $query = $request->input('query');
            
            //SQL AND + OR + Brackets
            $Exercise->where(function($Exercise) use ($query) {
                $Exercise->where('title', 'LIKE', '%'.$query.'%')
                      ->orWhere('description', 'LIKE', '%'.$query.'%');
            });

        }


        if ($request->input('pageSize') != "") 
         $pageSize = $request->input('pageSize');
        else
         $pageSize = 50;  

        $Exercise = $Exercise->paginate($pageSize);


        
        
        return view('admin.ListExercises')->with(['exercises'=>$Exercise, "pageSize" => $pageSize]);


    }


    public function editExercise(Request $request)
    {

        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        
        if($request->input('id')=="")
          $Exercise = new Exercise;
        else
          $Exercise = Exercise::findOrFail( $request->input('id') );


        $sql="select * from module where status='1' order by moduleno ";
        $modules = DB::select(DB::raw($sql));

        $sql="select * from exercise_type where status = '1'";
        $exercise_type = DB::select(DB::raw($sql));

        
        return view('admin.EditExercise')->with(["exercise" => $Exercise, "modules" => $modules, "exercise_type" => $exercise_type]);   
      

    }



    public function saveExercise(Request $request)
    {

        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        
        if($request->input('id')!="")
        {
           
           
            $validator = Validator::make($request->all(), [
                "title"=>"required",
                "moduleno"=>"required",
                "routeno"=>"required",
                "lesson_no"=>"required",
                "exercise_no"=>"required"
            ]);
            
    
            if ($validator->fails()) {
                
                $allErrors = $validator->errors()->all();
                return redirect()->back()->with('error', $allErrors[0]);
            }


            $reqNew = array();
            foreach($request->all() as $key=>$value)
            {

                if($value!="")
                  $reqNew[$key] = $value;
                else
                  $reqNew[$key] = ''; 

            }
    
            //print_r($reqNew); die;
            
            $Exercise = Exercise::findOrFail( $request->input('id') );
            
            //$Exercise->update($request->all());

            $Exercise->update($reqNew);

            return redirect()->back()->with('message', 'Exercise saved successfully!');


        }
        else
        {

            $validator = Validator::make($request->all(), [
                "title"=>"required",
                "moduleno"=>"required",
                "routeno"=>"required",
                "lesson_no"=>"required",
                "exercise_no"=>"required"
            ]);
    
            if ($validator->fails()) {
                
                $allErrors = $validator->errors()->all();
                return redirect()->back()->with('error', $allErrors[0]);
            }
    

            $reqNew = array();
            foreach($request->all() as $key=>$value)
            {

                if($value!="")
                  $reqNew[$key] = $value;
                else
                  $reqNew[$key] = ''; 

            }
                    


            //$Exercise = Exercise::create($request->all());  

            $Exercise = Exercise::create($reqNew);  


            return redirect()->back()->with('message', 'Exercise saved successfully!');



        }


    }



    public function deleteExercise(Request $request)
    {
        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        $Exercise = Exercise::findOrFail( $request->input('id'));

          if($Exercise->delete()){
            return redirect()->back()->with('message', 'Exercise removed successfully!');
          }

    }





    public function listExercisesDescription(Request $request)
    {

        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        $ExerciseDescription = ExerciseDescription::query(); 

        $ExerciseDescription->orderBy('id','asc');

        if ($request->input('moduleNo') != "") {

            $ExerciseDescription->where('moduleNo', $request->input('moduleNo'));
        }

        if ($request->input('routeNo') != "") {

            $ExerciseDescription->where('routeNo', $request->input('routeNo'));
        }

        if ($request->input('lessonNo') != "") {

            $ExerciseDescription->where('lessonNo', $request->input('lessonNo'));
        }

        if ($request->input('exerciseNo') != "") {

            $ExerciseDescription->where('exerciseNo', $request->input('exerciseNo'));
        }


         

       
        if ($request->input('query') != "") {

            $query = $request->input('query');
            
            //SQL AND + OR + Brackets
            $ExerciseDescription->where(function($ExerciseDescription) use ($query) {
                $ExerciseDescription->where('exerciseId', 'LIKE', '%'.$query.'%')
                      ->orWhere('description', 'LIKE', '%'.$query.'%');
            });

        }


        if ($request->input('pageSize') != "") 
         $pageSize = $request->input('pageSize');
        else
         $pageSize = 50;  

        $ExerciseDescription = $ExerciseDescription->paginate($pageSize);


        
        
        return view('admin.ListExerciseDescription')->with(['exerciseDescriptions'=>$ExerciseDescription, "pageSize" => $pageSize]);


    }



    public function listExercisesMediaAlt3(Request $request)
    {

        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        $ExerciseMediaAlt3 = ExerciseMediaAlt3::query(); 

        $ExerciseMediaAlt3->orderBy('id','asc');

        if ($request->input('moduleNo') != "") {

            $ExerciseMediaAlt3->where('moduleNo', $request->input('moduleNo'));
        }

        if ($request->input('routeNo') != "") {

            $ExerciseMediaAlt3->where('routeNo', $request->input('routeNo'));
        }

        if ($request->input('lessonNo') != "") {

            $ExerciseMediaAlt3->where('lessonNo', $request->input('lessonNo'));
        }

        if ($request->input('exerciseNo') != "") {

            $ExerciseMediaAlt3->where('exerciseNo', $request->input('exerciseNo'));
        }


         

       
        if ($request->input('query') != "") {

            $query = $request->input('query');
            
            //SQL AND + OR + Brackets
            $ExerciseMediaAlt3->where(function($ExerciseMediaAlt3) use ($query) {
                $ExerciseMediaAlt3->where('exerciseId', 'LIKE', '%'.$query.'%')
                      ->orWhere('media_alt3', 'LIKE', '%'.$query.'%');
            });

        }


        if ($request->input('pageSize') != "") 
         $pageSize = $request->input('pageSize');
        else
         $pageSize = 50;  

        $ExerciseMediaAlt3 = $ExerciseMediaAlt3->paginate($pageSize);


        
        
        return view('admin.ListExerciseMediaAlt3')->with(['exercisesMediaAlt3'=>$ExerciseMediaAlt3, "pageSize" => $pageSize]);


    }




}
