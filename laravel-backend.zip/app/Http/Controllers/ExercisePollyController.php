<?php

namespace App\Http\Controllers;

use Illuminate\Database\Eloquent\ModelNotFoundException;
use App\ExercisePolly;
use Illuminate\Http\Request;
use App\Http\Resources\ExercisePolly as ExercisePollyResource;

use App\Http\Resources\CheckUserApiAccess as CheckUserApiAccess;
use DB;
use checkUserPermissionController;
use Session;
use Validator;

class ExercisePollyController extends Controller
{
    

    public function list(Request $request)
    {
        
        $ExercisePolly = ExercisePolly::query(); 

        $ExercisePolly->orderBy('id','asc');

        if ($request->input('moduleNo') != "") {

            $ExercisePolly->where('moduleno', $request->input('moduleNo'));
        }

        if ($request->input('routeNo') != "") {

            $ExercisePolly->where('routeno', $request->input('routeNo'));
        }

        if ($request->input('lessonNo') != "") {

            $ExercisePolly->where('lesson_no', $request->input('lessonNo'));
        }

        if ($request->input('exerciseNo') != "") {

            $ExercisePolly->where('exercise_no', $request->input('exerciseNo'));
        }

       
        if ($request->input('query') != "") {

            $query = $request->input('query');
            
            //SQL AND + OR + Brackets
            $ExercisePolly->where(function($ExercisePolly) use ($query) {
                $ExercisePolly->where('title', 'LIKE', '%'.$query.'%')
                      ->orWhere('voice_id', 'LIKE', '%'.$query.'%');
            });

        }

             
        $ExercisePolly = $ExercisePolly->paginate(50);

        return ExercisePollyResource::collection($ExercisePolly);


    }

      

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $id)
    {
        
        try{

          $ExercisePolly = ExercisePolly::findOrFail($id);
          return new ExercisePollyResource($ExercisePolly);
        
        } 
        // catch(Exception $e) catch any exception
        catch(ModelNotFoundException $e)
        {
            return response()->json(['message' => 'Not Found!'], 404);
        } 

    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $request->validate([
            "moduleno"=>"required",
            "routeno"=>"required",
            "lesson_no"=>"required",
            "exercise_no"=>"required"
        ]);

        
        $ExercisePolly = ExercisePolly::findOrFail($id);

        /* save encoded for special chars & lang */

        $request->merge(array('voice_id' => json_encode($request->input('voice_id'), JSON_UNESCAPED_UNICODE) ));

        $request->merge(array('voice_ssml' => base64_encode(json_encode($request->input('voice_ssml'), JSON_UNESCAPED_UNICODE)) ));
        
        /* save encoded for special chars & lang */

        //print_r($request->all());
        
        $ExercisePolly->update($request->all());

        $this->pollyGen($request->input('moduleno'), $request->input('routeno'), $request->input('lesson_no'), $request->input('voice_id'), $request->input('voice_ssml'), $request->input('debug'));

        return response()->json(['message' => 'Data Saved!'], 200);


    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            "moduleno"=>"required",
            "routeno"=>"required",
            "lesson_no"=>"required",
            "exercise_no"=>"required"
        ]);


        $ExercisePolly = $request->isMethod('put') ? ExercisePolly::findOrFail($request->id) : new ExercisePolly;

        $ExercisePolly->id = $request->input('id');

        //$post->fill($request->input())->save();
        
        $ExercisePolly->lesson_id = $request->input('lesson_id') ? $request->input('lesson_id') : '';
        $ExercisePolly->moduleno = $request->input('moduleno'); 
        $ExercisePolly->routeno = $request->input('routeno'); 
        $ExercisePolly->lesson_no = $request->input('lesson_no'); 
        $ExercisePolly->exercise_no = $request->input('exercise_no') ? $request->input('exercise_no') : ''; 
        $ExercisePolly->title = $request->input('title') ? $request->input('title') : ''; 
        
        
        
        /* save encoded for special chars & lang */

        $voice_id = $request->input('voice_id') ? json_encode($request->input('voice_id'), JSON_UNESCAPED_UNICODE) : '';  
        $ExercisePolly->voice_id = $voice_id;

        $voice_ssml = $request->input('voice_ssml') ? base64_encode(json_encode($request->input('voice_ssml'), JSON_UNESCAPED_UNICODE)) : '';
        $ExercisePolly->voice_ssml = $voice_ssml;

        /* save encoded for special chars & lang */

        $ExercisePolly->status = $request->input('status') ? $request->input('status') : ''; 
        $ExercisePolly->sequence = $request->input('sequence') ? $request->input('sequence') : ''; 
        
              
         
       
        if($ExercisePolly->save()){
            //return new EmployeeResource($Employee);

            $this->pollyGen($request->input('moduleno'), $request->input('routeno'), $request->input('lesson_no'), $voice_id, $voice_ssml, $request->input('debug'));

            return response()->json(['message' => 'Data Saved!'], 200);
        }


    }


     /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        
        //echo "Test...";

        try{  

          $ExercisePolly = ExercisePolly::findOrFail($id);

          if($ExercisePolly->delete()){
            return response()->json(['message' => 'Removed!'], 200);
          }

        }        
        // catch(Exception $e) catch any exception
        catch(ModelNotFoundException $e)
        {
            return response()->json(['message' => 'Not Found!'], 404);
        }

        
    }



    public function pollyGen($moduleno, $routeno, $lesson_no, $voice_id, $voice_ssml, $debug="")
    {

        $voice_id = json_decode($voice_id, true); 

        $voice_ssml = json_decode(base64_decode($voice_ssml), true);

        //echo $debug."----";

        $voice_c = count($voice_id);

        $packs = $moduleno."_".$routeno."_".$lesson_no;

        for($ivc=0; $ivc < $voice_c; $ivc++)
        { 

            $mp3folder = storage_path()."/Lesson_Module_Packs/Lesson_".$packs."_Pack/exercises/";
            $cmd = "mkdir -p ".$mp3folder;
            exec($cmd, $pp1);

            //if($debug!="") print_r($pp1);

            $mp3file = $mp3folder.$lesson_no.".".($ivc+1).".mp3";

            /* Make MP3 Polly Files */
            $cmd = 'LANG=en_US.UTF-8; AWS_ACCESS_KEY_ID='.env("POLLY_ACCESSKEY").' AWS_SECRET_ACCESS_KEY='.env("POLLY_SECRETKEY").' '.env("AWS_CLI").' polly synthesize-speech --region '.env("POLLY_REGION").' --text-type ssml --text "'.str_replace('"', "'", trim($voice_ssml[$ivc])).'" --output-format mp3 --voice-id '.trim($voice_id[$ivc]).' '.$mp3file.' 2>&1';
            exec($cmd, $pp2); 

            if($debug!="") print_r($pp2);

            /* Copy Polly MP3 files on S3 Media Folder */
            $S3Dir = "s3://".env("S3_MEDIA_BUCKET")."/Lesson_".$packs."_Pack/exercises/";
            exec("LANG=en_US.UTF-8; AWS_ACCESS_KEY_ID=".env("S3_ACCESSKEY")." AWS_SECRET_ACCESS_KEY=".env("S3_SECRETKEY")." ".env("AWS_CLI")." s3 cp '".$mp3file."' ".$S3Dir." --acl public-read 2>&1", $pp3);
            
            if($debug!="") print_r($pp3);

            /* Remove Polly MP3 files from storage_path() */
            @unlink($mp3file);    



        }


    }



    /* CMS */


    public function listExercisesPolly(Request $request)
    {

        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

           $ExercisePolly = ExercisePolly::query(); 

        $ExercisePolly->orderBy('id','asc');

        if ($request->input('moduleNo') != "") {

            $ExercisePolly->where('moduleno', $request->input('moduleNo'));
        }

        if ($request->input('routeNo') != "") {

            $ExercisePolly->where('routeno', $request->input('routeNo'));
        }

        if ($request->input('lessonNo') != "") {

            $ExercisePolly->where('lesson_no', $request->input('lessonNo'));
        }

        if ($request->input('exerciseNo') != "") {

            $ExercisePolly->where('exercise_no', $request->input('exerciseNo'));
        }

        if ($request->input('status') != "") {
   
            $ExercisePolly->where('status', $request->input('status'));
        
        }

       
        if ($request->input('query') != "") {

            $query = $request->input('query');
            
            //SQL AND + OR + Brackets
            $ExercisePolly->where(function($ExercisePolly) use ($query) {
                $ExercisePolly->where('title', 'LIKE', '%'.$query.'%')
                      ->orWhere('voice_id', 'LIKE', '%'.$query.'%');
            });

        }


        if ($request->input('pageSize') != "") 
         $pageSize = $request->input('pageSize');
        else
         $pageSize = 50;  

        $ExercisePolly = $ExercisePolly->paginate($pageSize);


        //$sql="select * from company where Status='1'";
        //$companies = DB::select(DB::raw($sql));
        
        return view('admin.ListExercisePolly')->with(['exercisePolly'=>$ExercisePolly, "pageSize" => $pageSize]);


    }



    public function editExercisePolly(Request $request)
    {

        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        
        if($request->input('id')=="")
          $ExercisePolly = new ExercisePolly;
        else
          $ExercisePolly = ExercisePolly::findOrFail( $request->input('id') );


        $sql="select * from module where status='1' order by moduleno ";
        $modules = DB::select(DB::raw($sql));

        //$sql="select * from route where status='1' order by routeno ";
        //$routes = DB::select(DB::raw($sql));

        //$mp3Polly = env("S3_MEDIA_LINK");

        
        return view('admin.EditExercisePolly')->with(["exercisePolly" => $ExercisePolly, "modules" => $modules]);   
      

    }




    public function saveExercisePolly(Request $request)
    {

        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        
        if($request->input('id')!="")
        {
           
           
            $validator = Validator::make($request->all(), [
                "moduleno"=>"required",
                "routeno"=>"required",
                "lesson_no"=>"required",
                "exercise_no"=>"required"
            ]);
            
    
            if ($validator->fails()) {
                
                $allErrors = $validator->errors()->all();
                return redirect()->back()->with('error', $allErrors[0]);
            }


            /* save encoded for special chars & lang */

            $request->merge(array('voice_id' => json_encode($request->input('voice_id'), JSON_UNESCAPED_UNICODE) ));

            $request->merge(array('voice_ssml' => base64_encode(json_encode($request->input('voice_ssml'), JSON_UNESCAPED_UNICODE)) ));
        
            /* save encoded for special chars & lang */


            $reqNew = array();
            foreach($request->all() as $key=>$value)
            {

                if($value!="")
                  $reqNew[$key] = $value;
                else
                  $reqNew[$key] = ''; 

            }
    
            //print_r($reqNew); die;
            
            $ExercisePolly = ExercisePolly::findOrFail( $request->input('id') );
            
            //$ExercisePolly->update($request->all());

            $ExercisePolly->update($reqNew);

            $this->pollyGen($request->input('moduleno'), $request->input('routeno'), $request->input('lesson_no'), $request->input('voice_id'), $request->input('voice_ssml'), $request->input('debug'));

            return redirect()->back()->with('message', 'ExercisePolly saved successfully!');


        }
        else
        {

            $validator = Validator::make($request->all(), [
                "moduleno"=>"required",
                "routeno"=>"required",
                "lesson_no"=>"required",
                "exercise_no"=>"required"
            ]);
    
            if ($validator->fails()) {
                
                $allErrors = $validator->errors()->all();
                return redirect()->back()->with('error', $allErrors[0]);
            }


            /* save encoded for special chars & lang */

            $request->merge(array('voice_id' => json_encode($request->input('voice_id'), JSON_UNESCAPED_UNICODE) ));

            $request->merge(array('voice_ssml' => base64_encode(json_encode($request->input('voice_ssml'), JSON_UNESCAPED_UNICODE)) ));
        
            /* save encoded for special chars & lang */
    

            $reqNew = array();
            foreach($request->all() as $key=>$value)
            {

                if($value!="")
                  $reqNew[$key] = $value;
                else
                  $reqNew[$key] = ''; 

            }
                    


            //$ExercisePolly = ExercisePolly::create($request->all());  

            $ExercisePolly = ExercisePolly::create($reqNew);  


            $this->pollyGen($request->input('moduleno'), $request->input('routeno'), $request->input('lesson_no'), $request->input('voice_id'), $request->input('voice_ssml'), $request->input('debug'));


            return redirect()->back()->with('message', 'ExercisePolly saved successfully!');



        }


    }




    public function deleteExercisePolly(Request $request)
    {
        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        $ExercisePolly = ExercisePolly::findOrFail( $request->input('id'));

          if($ExercisePolly->delete()){
            return redirect()->back()->with('message', 'ExercisePolly removed successfully!');
          }

    }




}
