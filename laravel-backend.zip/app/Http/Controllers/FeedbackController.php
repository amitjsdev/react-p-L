<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\ModelNotFoundException;

use App\Http\Requests;
use App\Feedback;
use App\Http\Resources\Feedback as FeedbackResource;

use DB;
use Session;
use Illuminate\Support\Facades\Validator;

class FeedbackController extends Controller
{
    


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            "userRating"=>"numeric|required"
        ]);


        $Feedback = $request->isMethod('put') ? Feedback::findOrFail($request->id) : new Feedback;

        $Feedback->id = $request->input('id');

        //$post->fill($request->input())->save();
        
        $Feedback->userId = auth()->user()->email; 
        $Feedback->userRating = $request->input('userRating'); 
        $Feedback->userComments = $request->input('userComments'); 
        $Feedback->moduleNo = $request->input('moduleNo'); 
        $Feedback->routeNo = $request->input('routeNo'); 
        $Feedback->lessonNo = $request->input('lessonNo'); 
        
        //$Feedback->addDate = date("Y-m-d H:i:s");
         
        if($Feedback->save()){
            //return new EmployeeResource($Employee);
            return response()->json(['message' => 'Data Saved!'], 200);
        } else {
            return response()->json(['message' => "Something went wrong!"], 500);
        }


    }



}
