<?php

namespace App\Http\Controllers;

use App\Comment;
use App\Forum;
use App\Employee;
use App\Events\UserCommented;
use App\Http\Resources\ForumCommentResource;
use App\Http\Resources\ForumResource;
use App\Lesson;
use App\Module;
use App\V2Exercise;
use Illuminate\Http\Request;

class ForumController extends Controller
{
    public function ui() {
        return view('ui.forum');
    }


    public function v2exercise(Request $request, $exerciseId)
    {
        $email = auth()->user()->email;

        // fetch exercise
        $exercise = V2Exercise::find($exerciseId);

        if (!$exercise) {
            return response()->json([
                'error' => 'Exercise for this forum not found!'
            ], 404);
        }

        // get forum for this exercise
        $forum = $exercise->forum;

        if (!$forum) {
            // generate default forum;
            $forum = new Forum();
            $forum->title = $exercise->question;
            $forum->for = 'v2exercise';
            $forum->content = $exercise->question;
            $exercise->forum()->save($forum);
        }

        // set all the comments for this forum and their replies to seen
        setForumAsSeenByUser($forum, $email);
        // set all the comments for this forum and their replies to seen end

        return new ForumResource($forum);
    }



    // Add a new comment to exercise
    public function addForumComment(Request $request, $id)
    {
        // fetch exercise
        $forum = Forum::find($id);

        if (!$forum) {
            return response()->json([
                'error' => 'Forum Not Found!'
            ], 404);
        }

        // get comment by user
        $commentMsg = $request->comment;

        if (empty($commentMsg)) {
            return response()->json([
                'error' => 'Comment is required!'
            ], 422);
        }

        $comment = new Comment();
        $comment->userId = auth()->user()->email;
        $comment->comment = $commentMsg;
        $forum->comments()->save($comment);

        event(new UserCommented($comment));

        // follow the forum
        followTheForum(auth()->user()->email, $comment);
        
        return response()->json([
            'success' => 'Comment Added!',
            "comment" => new ForumCommentResource($comment)
        ]);
    }


    // For video and listen
    /**
     * Return forum for video or listen
     *
     * @param Request $request
     * @param string $forumFor, can be video or listen
     * @param integer $moduleNo
     * @param integer $routeNo
     * @param integer $lessonNo
     * @return void
     */
    public function videoOrListen(Request $request, $forumFor, $moduleNo, $routeNo, $lessonNo)
    {
        $email = auth()->user()->email;

        // fetch lesson
        $lesson = Lesson::where('moduleno', $moduleNo)->where('routeno', $routeNo)->where('lesson_no', $lessonNo)->first();

        if (!$lesson) {
            return response()->json([
                'error' => 'Lesson for this forum not found!'
            ], 404);
        }

        // get forum for this lesson (according to type as lesson can have more than one forum)
        if ($forumFor === 'video') {
            $forum = $lesson->videoForum;
        } else if ($forumFor === 'listen') {
            $forum = $lesson->listenForum;
        } else {
            return response()->json([
                "error" => "Invalid Forum Type!"
            ]);
        }

        if (!$forum) {
            // generate default forum;
            $forum = new Forum();
            $forum->title = "Video - " . $lesson->long_description;
            $forum->for = 'video';
            $forum->content = $lesson->description;
            // save forum according to type
            if($forumFor === 'video') {
                $lesson->videoForum()->save($forum);
            } else {
                $lesson->listenForum()->save($forum);
            }
        }

        // set all the comments for this forum and their replies to seen
        setForumAsSeenByUser($forum, $email);
        // set all the comments for this forum and their replies to seen end

        return new ForumResource($forum);
    }

}
