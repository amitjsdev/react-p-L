<?php

namespace App\Http\Controllers;

use App\InterviewReviewParameter;
use Illuminate\Http\Request;

class InterviewReviewParameterController extends Controller
{
    // get the review parameters 
    public function GetReviewParameter(Request $request)
    {
        // 1 for self, 2 for external, 3 for ai
        // get the review parameters from table
        $selfReviewParameters = InterviewReviewParameter::where('reviewType', 1)->get();
        $externalReviewParameters = InterviewReviewParameter::where('reviewType', 2)->get();
        $aiReviewParameters = InterviewReviewParameter::where('reviewType', 3)->get();

        // return the parameters
        return response()->json([
            "parameters" => [
                "self" => $selfReviewParameters,
                "external" => $externalReviewParameters,
                "ai" => $aiReviewParameters,
            ]
        ]);
    }
}
