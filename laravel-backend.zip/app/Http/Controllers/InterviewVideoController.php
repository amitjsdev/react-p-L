<?php

namespace App\Http\Controllers;

use App\Employee;
use App\Course;
use App\Cohort;
use App\CohortPracticeSet;
use App\Http\Resources\InterviewVideoResource;
use App\InterviewAiRating;
use App\InterviewInstructorRating;
use App\InterviewSelfRating;
use App\InterviewVideo;
use App\InterviewVideoReview;
use App\Jobs\GenerateInterviewAiRating;
use App\Lesson;
use App\Mail\InterviewVideoShareMail;
use App\Mail\VpiVideoShareMail;
use App\PracticeQuestion;
use App\StudentPracticeAnswer;
use App\InstructorReview;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use App\Jobs\VPIScore;

class InterviewVideoController extends Controller
{
    function uploadVideo(Request $request)
    {
        $video = $request->file('video');

        if (!$video) {
            return response()->json([
                "message" => "video is required"
            ]);
        }

        // save to a folder on our system
        $filepath = $video->storeAs('interview_video_ai_rating', uniqid() . $video->getClientOriginalName());


        // uploadToS3("newfile", $video->getPathname(), $video->getClientOriginalName());

        return response()->json([
            "done" => "done",
            "filepath" => $filepath
        ]);
    }

    /**
     * Show interface for video
     */
    function interface(Request $request, $moduleNo)
    {
        $module = \App\PracticeSet::where('practiceSetId', $moduleNo)->first();

        if (!$module) {
            return abort(404);
        }

        return view('app/interview/main-interface');
    }

    /**
     * Show interface for my video
     */
    function interfaceMyVideos(Request $request)
    {
        return view('app/interview/interview-videos');
    }

    /**
     * Save an attempt
     */
    function saveAttempt(Request $request)
    {

        $validated = $request->validate([
            "moduleNo" => "required|numeric",
            "routeNo" => "required|numeric",
            "lessonNo" => "required|numeric",
        ]);

        // get the question
        $practiceQuestion = PracticeQuestion::where('practiceSetId', $request->moduleNo)->where('practiceQuestionId', $request->lessonNo)->first();


        if (!$practiceQuestion) {
            return response()->json([
                "message" => "Lesson not found!"
            ]);
        }

        // generate the new attempt number
        $attemptNo = InterviewVideo::where([
            ['moduleNo', $request->moduleNo],
            ['routeNo', $request->routeNo],
            ['lessonNo', $request->lessonNo],
            ['userId', auth()->user()->email],
        ])->count() + 1;

        // save the attempt
        $attempt = InterviewVideo::create([
            'moduleNo' => $request->moduleNo,
            'routeNo' => $request->routeNo,
            'lessonNo' => $request->lessonNo,
            'userId' => auth()->user()->email,
            'uuid' => uniqid(),
            'attemptNo' => $attemptNo
        ]);

        // create ratings
        $aiRating = InterviewAiRating::create([
            'interview_video_id' => $attempt->id,
            'moduleNo' => $request->moduleNo,
            'routeNo' => $request->routeNo,
            'lessonNo' => $request->lessonNo,
            'userId' => auth()->user()->email,
            'attemptNo' => $attemptNo,
            'fluency' => rand(2, 5),
            'wordsPerMinute' => rand(2, 5),
            'unnecessaryPauses' => rand(2, 5),
            'unnecessaryUmsAndAhs' => rand(2, 5)
        ]);

        return $attempt;
    }

    function saveAttemptVideo(Request $request, $attemptNo)
    {
        $validated = $request->validate([
            "moduleNo" => "required|numeric",
            "routeNo" => "required|numeric",
            "lessonNo" => "required|numeric",
        ]);

        $request->validate([
            "video" => "required|file|max:204800"
        ]);

        $userId = auth()->user()->email;

        // get employee
        $employee = Employee::where('userId', $userId)->first();

        // check if attempt exists;
        $attempt = InterviewVideo::where([
            ['moduleNo', $request->moduleNo],
            ['routeNo', $request->routeNo],
            ['lessonNo', $request->lessonNo],
            ['userId', $userId],
        ])->where('attemptNo', $attemptNo)->first();

        if (!$attempt) {
            return response()->json([
                "message" => "not found!"
            ], 404);
        }

        // save video for the attempt
        $video = $request->file('video');

        if (!$video) {
            return response()->json([
                "message" => "video is required"
            ]);
        }

        $mrl = "/" . $request->moduleNo . "_" . $request->routeNo . "_" . $request->lessonNo;

        // generate the dir for s3
        $dir = 'interviewprep/userUploads/' . $employee->i_d . $mrl . '/attempt/' . $attemptNo;

        // upload to s3
        uploadToS3($dir, $video->getPathname(), $video->getClientOriginalName(), false);

        try {
            // $filepath = storage_path("app/interview_video_ai_rating/" . $attempt->uuid . $video->getClientOriginalName());

            $filepath = storage_path("app/" . $video->storeAs('interview_video_ai_rating', $attempt->uuid . uniqid() . $video->getClientOriginalName()));

            // exec("cp ". $video->getPathname() . " " . $filepath);

            $attempt->reviewFileLocation = $filepath;
            $attempt->reviewStatus = 1;
            \Log::info('file copied!', [$filepath, $video->getPathname(), $video->getClientOriginalName()]);
            GenerateInterviewAiRating::dispatch($attempt->id, $filepath);
        } catch (\Throwable $th) {
            $attempt->reviewStatus = 3;
            sendServerErrorMail("File could not be copied from temp to location for processing!", ["error" => $th, "filePath" => $video->getPathname(), "fileName" => $video->getClientOriginalName()]);
            \Log::error('file could not be copied!', [$th, $video->getPathname(), $video->getClientOriginalName()]);
        }

        // save attempt file path
        $attempt->filePath = $dir . "/" . $video->getClientOriginalName();
        $attempt->save();

        return $attempt;
    }


    /**
     * Save an attempt with its video
     */
    function saveAttemptWithVideo(Request $request)
    {

        $validated = $request->validate([
            "moduleNo" => "required|numeric",
            "routeNo" => "required|numeric",
            "lessonNo" => "required|numeric",
            "video" => "required|file|max:204800"
        ]);

        // get the question
        $practiceQuestion = PracticeQuestion::where('practiceSetId', $request->moduleNo)->where('practiceQuestionId', $request->lessonNo)->first();


        if (!$practiceQuestion) {
            return response()->json([
                "message" => "Lesson not found!"
            ]);
        }

        $userId = auth()->user()->email;

        // get video for the attempt
        $video = $request->file('video');

        if (!$video) {
            return response()->json([
                "message" => "video is required"
            ]);
        }

        // generate the new attempt number
        $attemptNo = InterviewVideo::where([
            ['moduleNo', $request->moduleNo],
            ['routeNo', $request->routeNo],
            ['lessonNo', $request->lessonNo],
            ['userId', auth()->user()->email],
        ])->count() + 1;

        // save the attempt
        $attempt = InterviewVideo::create([
            'moduleNo' => $request->moduleNo,
            'routeNo' => $request->routeNo,
            'lessonNo' => $request->lessonNo,
            'userId' => $userId,
            'uuid' => uniqid(),
            'attemptNo' => $attemptNo
        ]);

        // get employee
        $employee = Employee::where('userId', $userId)->first();

        $mrl = "/" . $request->moduleNo . "_" . $request->routeNo . "_" . $request->lessonNo;

        // generate the dir for s3
        $dir = 'interviewprep/userUploads/' . $employee->i_d . $mrl . '/attempt/' . $attemptNo;

        // upload to s3
        uploadToS3($dir, $video->getPathname(), $video->getClientOriginalName(), false);

        try {
            // $filepath = storage_path("app/interview_video_ai_rating/" . $attempt->uuid . $video->getClientOriginalName());

            $filepath = storage_path("app/" . $video->storeAs('interview_video_ai_rating', $attempt->uuid . uniqid() . $video->getClientOriginalName()));

            // exec("cp ". $video->getPathname() . " " . $filepath);

            $attempt->reviewFileLocation = $filepath;
            $attempt->reviewStatus = 1;
            \Log::info('file copied!', [$filepath, $video->getPathname(), $video->getClientOriginalName()]);
            GenerateInterviewAiRating::dispatch($attempt->id, $filepath);
        } catch (\Throwable $th) {
            $attempt->reviewStatus = 3;
            sendServerErrorMail("File could not be copied from temp to location for processing!", ["error" => $th, "filePath" => $video->getPathname(), "fileName" => $video->getClientOriginalName()]);
            \Log::error('file could not be copied!', [$th, $video->getPathname(), $video->getClientOriginalName()]);
        }

        // save attempt file path
        $attempt->filePath = $dir . "/" . $video->getClientOriginalName();
        $attempt->save();

        return $attempt;
    }


    function saveAttemptAndGetSignedURL(Request $request)
    {

        $validated = $request->validate([
            "fileName" => "required|string",
            "moduleNo" => "required|numeric",
            "routeNo" => "required|numeric",
            "lessonNo" => "required|numeric",
        ]);

        // get the question
        $practiceQuestion = PracticeQuestion::where('practiceSetId', $request->moduleNo)->where('practiceQuestionId', $request->lessonNo)->first();


        if (!$practiceQuestion) {
            return response()->json([
                "message" => "Lesson not found!"
            ]);
        }

        // generate the new attempt number
        $attemptNo = InterviewVideo::where([
            ['moduleNo', $request->moduleNo],
            ['routeNo', $request->routeNo],
            ['lessonNo', $request->lessonNo],
            ['userId', auth()->user()->email],
        ])->count() + 1;

        $userId = auth()->user()->email;

        $employee = Employee::where('userId', $userId)->first();

        // save the attempt
        $attempt = InterviewVideo::create([
            'moduleNo' => $request->moduleNo,
            'routeNo' => $request->routeNo,
            'lessonNo' => $request->lessonNo,
            'userId' => $userId,
            'uuid' => uniqid(),
            'attemptNo' => $attemptNo
        ]);

        // create the signed URL
        $signedUrlResponse = Http::get('https://vetg6p7gp9.execute-api.us-east-1.amazonaws.com/uploads?' . http_build_query([
            'employeeId' => $employee->i_d,
            'fileName' => $request->fileName,
            'moduleNo' => $request->moduleNo,
            'routeNo' => $request->routeNo,
            'lessonNo' => $request->lessonNo,
            'userId' => auth()->user()->email,
            'uuid' => uniqid(),
            'attemptNo' => $attemptNo
        ]));

        $signedUrlResponseJSON = $signedUrlResponse->json();

        if (is_array($signedUrlResponseJSON) && isset($signedUrlResponseJSON['Key'])) {

            // add signed url to attempt
            $attempt->uploadURL = $signedUrlResponseJSON["uploadURL"];
            $attempt->Key = $signedUrlResponseJSON["Key"];

            // return attempt
            return $attempt;
        } else {
            return response()->json([
                'message' => "Could not generated signed URL!",
                'response' => $signedUrlResponseJSON
            ], 400);
        }
    }


    function markAttemptVideoUploaded(Request $request, $attemptNo)
    {
        $validated = $request->validate([
            "reviewFileLocation" => "required|string",
            "moduleNo" => "required|numeric",
            "routeNo" => "required|numeric",
            "lessonNo" => "required|numeric",
        ]);

        $userId = auth()->user()->email;
        $isVPI =false;
        if($request->post('cohortId')){
            $isVPI = Cohort::where('id',$request->post('cohortId'))->where('vpi_value',1)->get()->count();
            $isVPI  = $isVPI >0 ? true: false;
        }
       

        // get employee
        $employee = Employee::where('userId', $userId)->first();

        // check if attempt exists;
        $attempt = InterviewVideo::where([
            ['moduleNo', $request->moduleNo],
            ['routeNo', $request->routeNo],
            ['lessonNo', $request->lessonNo],
            ['userId', $userId],
        ])->where('attemptNo', $attemptNo)->first();

        if (!$attempt) {
            return response()->json([
                "message" => "not found!"
            ], 404);
        }

        $reviewFileLocation = $request->reviewFileLocation;
       $distinctAttempts = [];
        try {
            // exec("cp ". $video->getPathname() . " " . $filepath);

            $attempt->reviewFileLocation = 'https://langappnew.s3.amazonaws.com/' . $reviewFileLocation;
            $attempt->reviewStatus = 1;
            \Log::info('file location saved!', [$reviewFileLocation]);
            GenerateInterviewAiRating::dispatch($attempt->id, $attempt->reviewFileLocation, true);
        } catch (\Throwable $th) {
            $attempt->reviewStatus = 3;
            sendServerErrorMail("File location could not be saved!", ["error" => $th, "filePath" => $reviewFileLocation]);
            \Log::error('file could not be copied!', [$th, $reviewFileLocation]);
        }

        //get Lesson which completed start
        $practice_set = \App\PracticeSet::where('practiceSetId', $request->moduleNo)->first();

        if (!$practice_set) {
            return response()->json([
                "message" => "Practice set not found!"
            ]);
        }

        $userId = auth()->user()->email;

        $practice_set_questions = $practice_set->questions()->orderBy('practiceQuestionId')->get()->map(function ($question) use ($userId) {
            $question->long_description = $question->practiceSetQuestion;
            $question->routeno = 0;
            $question->lesson_no = $question->practiceQuestionId;

            $question->completed = \App\InterviewVideo::where([
                ['moduleNo', $question->practiceSetId],
                ['routeNo', 0],
                ['lessonNo', $question->practiceQuestionId],
                ['userId', $userId],
            ])->exists();

            $question->tldrs = \App\PracticeQuestionTldr::select(['title', 'description'])
                ->where([
                    ['practiceSetId', $question->practiceSetId],
                    ['practiceQuestionId', $question->practiceQuestionId],
                ])->get();
            return $question;
        });
        //get Lesson which completed end

                //total attempts
        $distinctAttempts = InterviewVideo::distinct('routeNo', 'lessonNo')
                ->where([
                ['userId', $userId],
                ])
                ->where([
                ['moduleNo', $request->moduleNo],
                ])
                ->groupBy('moduleNo','routeNo','lessonNo')->get();

                // $attempt['distinctAttempts'] = $distinctAttempts;
        // save attempt file path
        $attempt->filePath = str_replace('uploads/', '', $reviewFileLocation);
        $attempt->save();


        // $cohortSet = CohortPracticeSet::where('practiceSetId', $request->moduleNo)->first();

        $cohort = Cohort::where('id', $request->cohortId)->first();
        if($isVPI && $attempt->id){
            \Log::error('generateVPIScore', [$attempt->id]);
            VPIScore::dispatch($attempt->id);
        }
       if($cohort && ($cohort->vpi_value != null and $cohort->vpi_value == 1)){
           
            if($cohort->type_id == 3 && count($practice_set_questions) == count($distinctAttempts)){
                //review mail start
                // get the employee
                $employee = Employee::where('userId', $userId)->first();

                // send the mail here
                $mail = new VpiVideoShareMail($employee->FirstName,$cohort->name);
                // Mail::to('test.official92@gmail.com')->send($mail);
                Mail::to($userId)->send($mail);
            //review mail end
            }


            return response()->json([
                "attempts" => $attempt,
                "VPIScore" => null,
                "message" => "Mail sent to users!",
                "uuids" => $attempt->uuid,
                "cohort" => $cohort,
                "distinctAttempts"=>$distinctAttempts,
                "lessons" => $practice_set_questions

            ]);
        } else{

            return response()->json([
                "attempts" => $attempt,
                "cohort" => $cohort,
                "distinctAttempts"=>$distinctAttempts,
                "lessons" => $practice_set_questions

            ]);
        }


    }

    function getPreviousAttempts(Request $request)
    {
        $validated = $request->validate([
            "moduleNo" => "required|numeric",
            "routeNo" => "required|numeric",
            "lessonNo" => "required|numeric",
        ]);

        // get previous attempts
        $prevAttempts = InterviewVideo::where([
            ['moduleNo', $request->moduleNo],
            ['routeNo', $request->routeNo],
            ['lessonNo', $request->lessonNo],
            ['userId', auth()->user()->email],
        ])->latest()->get();

        // $prevAttempts = InterviewVideo::where([
        //     ['moduleNo', 301],
        //     ['routeNo', 0],
        //     ['lessonNo', 1],
        //     ['userId', '10x@taplingua.com'],
        // ])->latest()->get();


        return response()->json([
            "attempts" => $prevAttempts
        ]);
    }

    function getPreviousAttemptsAll(Request $request)
    {
        // get previous attempts
        $prevAttempts = InterviewVideo::where([
            ['userId', auth()->user()->email],
        ])
            ->latest()->get()->map(function ($v) {
                // TODO: get ratings mean
                $v->lessonName = $v->lesson ? $v->lesson->practiceSetQuestion : "";
                $v->self_rating =  InterviewVideoReview::where([
                    ['interviewVideoId', $v->id],
                    ['reviewType', 1]
                ])->latest()->first();
                $v->external_rating =  InterviewVideoReview::where([
                    ['interviewVideoId', $v->id],
                    ['reviewType', 2]
                ])->get();
                $v->ai_rating =  InterviewVideoReview::where([
                    ['interviewVideoId', $v->id],
                    ['reviewType', 3]
                ])->latest()->first();
                return $v;
            });
        $arr =[];
        foreach ($prevAttempts as  $att) {
            if ($att->lesson) {
                $arr[]=($att);
            }
        }
        return response()->json([
            "attempts" => InterviewVideoResource::collection($arr)
        ]);
    }
    function getPreviousAttemptsAllByEmail(Request $request, $email)
    {
        // get previous attempts
        $prevAttempts = InterviewVideo::where([
            ['userId', $email],
        ])->with('External')
            ->latest()->get()->map(function ($v) {
                // TODO: get ratings mean
                $v->lessonName = $v->lesson ? $v->lesson->practiceSetQuestion : "";

                $v->external_rating =  $v->external;

                return $v;
            });

        foreach ($prevAttempts as $key => $att) {
            if (!$att->external_rating) {
                unset($prevAttempts[$key]);
            }
        }
        $arr =[];
        foreach ($prevAttempts as  $att) {
            if ($att->lesson) {
                $arr[]=($att);
            }
        }
        return response()->json([
            "attempts" => InterviewVideoResource::collection($arr)
        ]);
    }


    function getPreviousAttemptByUUID(Request $request, $uuid)
    {
        // get previous attempt by uuid
        $v = InterviewVideo::where([
            ['userId', auth()->user()->email],
            ['uuid', $uuid]
        ])
            ->first();


        // TODO: get ratings mean
        $v->lessonName = $v->lesson ? $v->lesson->practiceSetQuestion : "";
        $v->self_rating =  InterviewVideoReview::where([
            ['interviewVideoId', $v->id],
            ['reviewType', 1]
        ])->first();
        $v->external_rating =  InterviewVideoReview::where([
            ['interviewVideoId', $v->id],
            ['reviewType', 2]
        ])->get();
        $v->ai_rating =  InterviewVideoReview::where([
            ['interviewVideoId', $v->id],
            ['reviewType', 3]
        ])->first();


        return response()->json([
            "attempt" => new InterviewVideoResource($v)
        ]);
    }
    function getVPIScore(Request $request, $id)
    {
        // get previous attempt by uuid
        $v = InterviewVideo::find($id);
        $ck = new VPIScore($id);
        $d =$ck->handle();
        // VPIScore::dispatch($id);
        return response()->json($d);
    }


    function getUserPreviousAttemptsAll(Request $request)
    {
        $employee = Employee::where('userId', $request->email)->first();
        // get previous attempts
        // $data = StudentPracticeAnswer::where('userId', $userId)
        // ->where('questionId',$questionId )
        // ->where('practiceSetId',$practiceSetId )
        // ->first();
        $courseNumber = Course::select('employeecourse.courseNumber','manual_rating')
                 ->join('employeecourse', 'courses.courseNumber', "=", "employeecourse.courseNumber")
                 ->where('userId',$request->email)
                 ->where('cohort_id', $request->cohort_id)
                 ->get();
        $prevAttempts = InterviewVideo::where([
            ['userId', $request->email],
        ])
            ->latest()->get()->map(function ($v) {
                // TODO: get ratings mean
                $v->lessonName = $v->lesson ? $v->lesson->practiceSetQuestion : "";
                // $v->lesson = $v->lesson ;
                $v->student_practice_answers =StudentPracticeAnswer::where([
                            ['practiceSetId', $v->lesson->practiceSetId],
                            ['questionId',  $v->lesson->practiceQuestionId],
                            ['userId',  $v->userId]
                        ])->first();
                // $v->self_rating =  InterviewVideoReview::where([
                //     ['interviewVideoId', $v->id],
                //     ['reviewType', 1]
                // ])->first();
                $v->external_rating =  InterviewVideoReview::where([
                    ['interviewVideoId', $v->id],
                    ['reviewType', 2]
                ])->get();
                $v->ai_rating =  InterviewVideoReview::where([
                    ['interviewVideoId', $v->id],
                    ['reviewType', 3]
                ])->first();
                return $v;
            });

        return response()->json([
            "user" => [
                "userId" => $request->email,
                "FirstName" => $employee->FirstName,
                "LastName" => $employee->LastName,
                "manual_rating"=>$courseNumber
            ],
            "attempts" => InterviewVideoResource::collection($prevAttempts)
        ]);
    }


    /**
     * get attempts by uuid
     */
    function getAttemptsByUUID(Request $request, $videos)
    {

        // get previous attempts
        $prevAttempts = InterviewVideo::whereIn('uuid', array_filter(explode("-", $videos), function ($v) {
            return $v;
        }))
            ->latest()->get()->map(function ($v) {
                $v->lessonName = $v->lesson ? $v->lesson->practiceSetQuestion : "";
                $v->sagFlag = $v->lesson ? $v->lesson->sagFlag : false;

                $v->self_rating =  InterviewVideoReview::where([
                    ['interviewVideoId', $v->id],
                    ['reviewType', 1]
                ])->first();
                $v->external_rating =  InterviewVideoReview::where([
                    ['interviewVideoId', $v->id],
                    ['reviewType', 2]
                ])->get();
                $v->ai_rating =  InterviewVideoReview::where([
                    ['interviewVideoId', $v->id],
                    ['reviewType', 3]
                ])->first();
                return $v;
            });

        return response()->json([
            "attempts" => InterviewVideoResource::collection($prevAttempts)
        ]);
    }

    /**
     * get attempts by uuid
     */
    function getAttemptsByUUIDForInstructor(Request $request, $videos)
    {
        $userId = auth()->user()->email;

        // requested UUIDs =
        $instructorReviews = InstructorReview::whereIn('videoId', array_filter(explode("-", $videos), function ($v) {
            return $v;
        }))->where('instructorEmail', $userId)->get();

        // get the video ids out
        $videoIds = $instructorReviews->map(function ($i) {
            return $i->videoId;
        });



        // get previous attempts
        $prevAttempts = InterviewVideo::whereIn('uuid', $videoIds)
            ->latest()->get()->map(function ($v) use ($userId) {
                $v->lessonName = $v->lesson ? $v->lesson->practiceSetQuestion : "";

                $v->self_rating =  InterviewVideoReview::where([
                    ['interviewVideoId', $v->id],
                    ['reviewType', 1]
                ])->first();
                $v->external_rating =  InterviewVideoReview::where([
                    ['interviewVideoId', $v->id],
                    ['reviewType', 2]
                ])->get();
                $v->my_rating = InterviewVideoReview::where([
                    ['interviewVideoId', $v->id],
                    ['reviewerEmail', $userId],
                    ['reviewType', 2]
                ])->first();
                $v->ai_rating =  InterviewVideoReview::where([
                    ['interviewVideoId', $v->id],
                    ['reviewType', 3]
                ])->first();
                $v->isReviewedByInstructor = InstructorReview::where('videoId', $v->uuid)->where('instructorEmail')->where('instructorEmail', $userId)
                    ->where('reviewCompleted', true)->exists() ? true : false;
                return $v;
            });

        return response()->json([
            "attempts" => InterviewVideoResource::collection($prevAttempts)
        ]);
    }

    /**
     * get attempts by uuid
     */
    function deleteVideoByUUID(Request $request, $video)
    {
        // get previous attempt
        $prevAttempt = InterviewVideo::where('uuid', $video)
            ->where('userId', auth()->user()->email)
            ->first();

        if ($prevAttempt) {
            // delete all reviews too
            InterviewVideoReview::where([
                ['interviewVideoId', $prevAttempt->id],
            ])->delete();
            $prevAttempt->delete();
        } else {
            return response()->json([
                "message" => "Video with uuid not found",
                "uuid" => $video,
                'status' => 0,
            ]);
        }

        return response()->json([
            'status' => 1,
            "message" => "deleted video",
            "attempt" => new InterviewVideoResource($prevAttempt),
            "uuid" => $video
        ]);
    }


    /**
     * get attempts by uuid
     */
    function shareAttemptByUUIDThroughEmail(Request $request)
    {

        // make validator
        $validator = Validator::make($request->all(), [
            "message" => "string|nullable|max:190",
            "emails" => "array|required|min:1",
            "emails.*" => "required|email",
            "uuids" => "array|required|min:1",
            "uuids.*" => "required|string|exists:interview_videos,uuid"
        ]);

        if ($validator->fails()) {
            return response()->json([
                "message" => "Validation error!",
                "errors" => $validator->errors()
            ]);
        }

        $validated = $validator->validated();

        // get the uuids
        $uuids = $validated['uuids'];


        // get the userId
        $userId = InterviewVideo::where('uuid', $uuids[0])->first()->userId;
        // get the employee
        $employee = Employee::where('userId', $userId)->first();

        if (!$employee) {
            return response()->json([
                "message" => "User not found!"
            ]);
        }
        foreach ($uuids as $videoId_uni) {
            foreach ($validated['emails'] as $email) {
                $instructor_review = new InstructorReview;
                $instructor_review->videoId = $videoId_uni;
                $instructor_review->instructorEmail = $email;
                $instructor_review->videoEmailOpened = false;
                $instructor_review->reviewCompleted = false;
                $instructor_review->userId = $request->user()->email;
                $instructor_review->save();
            }
        }




        // generate link
        $link = 'https://app.taplingua.com/interview/external-review/' . implode('-', $uuids);

        // send the mail here
        $mail = new InterviewVideoShareMail($link, $employee->FirstName);

        Mail::to($validated['emails'])->send($mail);

        return response()->json([
            "message" => "Mail sent to users!",
            "uuids" => $uuids
        ]);
    }
}
