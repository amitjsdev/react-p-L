<?php

namespace App\Http\Controllers;

use App\Employee;
use App\Http\Resources\InterviewVideoReviewResource;
use App\Http\Resources\InterviewVideoResource;
use App\InterviewReviewParameter;
use App\InterviewVideo;
use App\InstructorReview;
use App\InterviewVideoReview;
use App\Mail\InterviewVideoReviewReceivedMail;
use App\Mail\InterviewVideoReviewUpdatedMail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;

class InterviewVideoReviewController extends Controller
{
    /**
     * Get selft saved review
     */
    public function getSelfReview(Request $request, $interviewVideoId)
    {
        $userId = auth()->user()->email;
        // check if video id is valid
        if (!InterviewVideo::find($interviewVideoId)) {
            return response()->json([
                "message" => "Attempt not found!",
            ], 404);
        }
        // check if review already done
        $review = InterviewVideoReview::where('userId', $userId)->where('reviewType', 1)
            ->where('interviewVideoId', $interviewVideoId)
            ->first();

        // check if review available
        if (!$review) {
            return response()->json([
                "message" => "Review not found!",
            ], 404);
        }

        // return review
        return response()->json([
            "message" => "Review fetched!",
            "review" => new InterviewVideoReviewResource($review)
        ]);
    }

    /**
     * Save self review
     */
    public function saveSelfReview(Request $request, $interviewVideoId)
    {
        $userId = auth()->user()->email;
        // check if video id is valid
        if (!InterviewVideo::find($interviewVideoId)) {
            return response()->json([
                "message" => "Attempt not found!",
            ], 404);
        }
        // check if review already done
        $review = InterviewVideoReview::where('userId', $userId)->where('reviewType', 1)
            ->where('interviewVideoId', $interviewVideoId)
            ->first();
        // get the actual parameters available
        $selfReviewParameters = InterviewReviewParameter::where('reviewType', 1)->get()->pluck('reviewParameter');
        $parameterRules = array_reduce($selfReviewParameters->toArray(), function ($acc, $value) {
            $acc["review." . $value] = "required|numeric|max:5|min:1";
            return $acc;
        }, []);
        // validate the review data
        $validator = Validator::make($request->all(), array_merge([
            "comment" => "nullable|string",
            "review" => "required",
        ], $parameterRules));
        if ($validator->fails()) {
            return response()->json([
                "message" => "Validation Error",
                "errors" => $validator->errors()
            ], 422);
        }
        $validated = $validator->validated();
        // save the review
        if ($review) {
            $review->update([
                'comment' => isset($validated["comment"]) ? $validated["comment"] : null,
                'reviewJSON' => json_encode($validated["review"])
            ]);
        } else {
            $review = InterviewVideoReview::create([
                'userId' => $userId,
                'reviewType' => 1,
                'interviewVideoId' => $interviewVideoId,
                'comment' => isset($validated["comment"]) ? $validated["comment"] : null,
                'reviewJSON' => json_encode($validated["review"])
            ]);
        }

        // return review
        return response()->json([
            "message" => "Review saved!",
            "review" => new InterviewVideoReviewResource($review)
        ]);
    }

    /**
     * Save external review
     */
    public function saveExternalReview(Request $request, $interviewVideoId)
    {
        // check if video id is valid
        $interviewVideo = InterviewVideo::find($interviewVideoId);
        if (!$interviewVideo) {
            return response()->json([
                "message" => "Attempt not found!",
            ], 404);
        }
        // get the actual parameters available
        $externalReviewParameters = InterviewReviewParameter::where('reviewType', 2)->get()->pluck('reviewParameter');
        $parameterRules = array_reduce($externalReviewParameters->toArray(), function ($acc, $value) {
            $acc["review." . $value] = "required|numeric|max:5|min:0";
            return $acc;
        }, []);

        // validate the review data
        $postData = json_decode($request->post('payload'), 1);
        $validator = Validator::make($postData, array_merge([
            "userId" => "required|exists:employee|email|max:100",
            "reviewerName" => "required|string|max:100",
            "reviewerEmail" => "required|email|max:100",
            "comment" => "nullable|string",
            "review" => "required",
        ], $parameterRules));
        if ($validator->fails()) {
            return response()->json([
                "message" => "Validation Error",
                "errors" => $validator->errors()
            ], 422);
        }
        $validated = $validator->validated();
        // return response()->json([
        //     "message" => $validated['review'],
        // ], 404);
        // check if review already done
        $review = InterviewVideoReview::where('userId', $validated['userId'])->where('reviewType', 2)
            ->where('interviewVideoId', $interviewVideoId)
            ->where('reviewerEmail', $validated['reviewerEmail'])
            ->first();
        // save the review
        if ($review) {
            $review->update([
                "comment" => isset($validated["comment"]) ? $validated["comment"] : '',
                'reviewJSON' => json_encode($validated['review'])
            ]);
        } else {
            $review = InterviewVideoReview::create([
                'userId' => $interviewVideo->userId,
                'reviewType' => 2,
                'interviewVideoId' => $interviewVideoId,
                "reviewerName" => $validated['reviewerName'],
                "reviewerEmail" => $validated['reviewerEmail'],
                "comment" => isset($validated["comment"]) ? $validated["comment"] : '',
                'reviewJSON' => json_encode($validated['review'])
            ]);
        }
        if ($audio = $request->file('audio')) {
            $mrl = $review->id . '_' . time();
            $dir = 'reviews';
            uploadToS3Exact($dir, $audio->getPathname(), $mrl . ".mp3"); // mrl creates the file name
            $review->update(["audio" => $mrl . '.mp3']);
        }
        if ($video = $request->file('video')) {
            $mrl = $review->id . '_' . time();
            $dir = 'reviews/video/' . $review->id;
            uploadToS3Exact($dir, $video->getPathname(), $mrl . ".webm"); // mrl creates the file name
            $review->update(["video" => $mrl . '.webm']);
        }

        // send interviewvideoreviewreceivedemails
        $employee = Employee::where('userId', $interviewVideo->userId)->first();
        $email = new InterviewVideoReviewReceivedMail($employee->FirstName, $interviewVideoId);
        InstructorReview::where('instructorEmail', $validated['reviewerEmail'])
            ->where('videoId', $interviewVideo->uuid)
            ->update(['reviewCompleted' => 1]);
        Mail::to($interviewVideo->userId)->send($email);

        // return review
        return response()->json([
            "message" => "Review saved!",
            "review" => new InterviewVideoReviewResource($review)

        ]);
    }

    /**
     * Save external review
     */
    public function saveMentorReview(Request $request, $interviewVideoId)
    {
        // check if video id is valid
        $interviewVideo = InterviewVideo::find($interviewVideoId);
        if (!$interviewVideo) {
            return response()->json([
                "message" => "Attempt not found!",
            ], 404);
        }
        // get the actual parameters available
        $externalReviewParameters = InterviewReviewParameter::where('reviewType', 2)->get()->pluck('reviewParameter');
        $parameterRules = array_reduce($externalReviewParameters->toArray(), function ($acc, $value) {
            $acc["review." . $value] = "nullable";
            return $acc;
        }, []);
        // validate the review data
        $postData =json_decode($request->post('payload'),1);
       
         if($postData['review']['Convincing answer'] > 0 ||  
         $postData['review']['Conveys relevant abilities and qualifications'] > 0 || 
         $postData['review']['Apppropriate attire'] > 0 || 
         $postData['review']['Shows enthusiasm'] > 0 || 
         $postData['review']['Keeps answer concise'] > 0 || 
         $postData['review']['No ums and ahs'] > 0 || 
         $postData['review']['Speaks clearly'] > 0 || 
         $postData['review']['Maintains eye contact'] > 0 || 
         $postData['review']['Good body language'] > 0 || 
         $postData['review']["Doesn't appear nervous"] > 0){
            $validator = Validator::make($postData, array_merge([
                "userId" => "required|exists:employee|email|max:100",
                "reviewerName" => "required|string|max:100",
                "reviewerEmail" => "required|email|max:100",
                "comment" => "nullable|string",
                "review" => "required|min:1",
            ], $parameterRules));
         } else{

            $validator = Validator::make($postData, array_merge([
                "userId" => "required|exists:employee|email|max:100",
                "reviewerName" => "required|string|max:100",
                "reviewerEmail" => "required|email|max:100",
                "comment" => "nullable|string",
                "review" => "nullable",
            ], $parameterRules));            
         }

        // $validator = Validator::make($postData, array_merge([
        //     "userId" => "required|exists:employee|email|max:100",
        //     "reviewerName" => "required|string|max:100",
        //     "reviewerEmail" => "required|email|max:100",
        //     "comment" => "nullable|string",
        //     "review" => "nullable",
        // ], $parameterRules));
        if ($validator->fails()) {
            return response()->json([
                "message" => "Validation Error",
                "errors" => $validator->errors()
            ], 422);
        }
        $validated = $validator->validated();
        // check if review already done
        $review = InterviewVideoReview::where('userId', $validated['userId'])->where('reviewType', 2)
            ->where('interviewVideoId', $interviewVideoId)
            ->where('reviewerEmail', $validated['reviewerEmail'])
            ->first();
        // save the review
        if ($review) {
            $review->update([
                "comment" => isset($validated["comment"]) ? $validated["comment"] : null,
                'reviewJSON' => json_encode($validated['review'])
            ]);
        } else {
            $review = InterviewVideoReview::create([
                'userId' => $interviewVideo->userId,
                'reviewType' => 2,
                'interviewVideoId' => $interviewVideoId,
                "reviewerName" => $validated['reviewerName'],
                "reviewerEmail" => $validated['reviewerEmail'],
                "comment" => isset($validated["comment"]) ? $validated["comment"] : null,
                'reviewJSON' => json_encode($validated['review'])
            ]);
        }
        if ($audio = $request->file('audio')) {
            $mrl = $review->id . '_' . time();
            $dir = 'reviews';
            uploadToS3Exact($dir, $audio->getPathname(), $mrl . ".mp3"); // mrl creates the file name
            $review->update(["audio" => $mrl . '.mp3']);
        }
        if ($video = $request->file('video')) {
            $mrl = $review->id . '_' . time();
            $dir = 'reviews/video/' . $review->id;
            uploadToS3Exact($dir, $video->getPathname(), $mrl . ".webm"); // mrl creates the file name
            $review->update(["video" => $mrl . '.webm']);
        }


        // send interviewvideoreviewreceivedemails
        $employee = Employee::where('userId', $interviewVideo->userId)->first();
        $email = new InterviewVideoReviewReceivedMail($employee->FirstName, $interviewVideoId);

        InstructorReview::where('instructorEmail', $validated['reviewerEmail'])
            ->where('videoId', $interviewVideo->uuid)
            ->update(['reviewCompleted' => 1]);
        Mail::to($interviewVideo->userId)->send($email);

        // return review
        return response()->json([
            "message" => "Review saved!",
            "review" => new InterviewVideoReviewResource($review)

        ]);
    }


    public function updateMentorReview(Request $request, $id)
    {

        $payload = json_decode($request->post('payload'), 1);
        $validator = Validator::make($payload, [
            "userId" => "required|exists:employee|email|max:100",
            "reviewerName" => "required|string|max:100",
            "reviewerEmail" => "required|email|max:100",
            "comment" => "nullable|string",
            "review" => "required",
        ]);
        if ($validator->fails()) {
            return response()->json([
                "message" => "Validation Error",
                "errors" => $validator->errors()
            ], 422);
        }
        $validated = $validator->validated();

        // $attempt->proctoredVideo = $dir . "/" . $mrl . ".mp3";
        // $audio =$audio->getPathname();
        // check if review already done
        $iserId = (\Auth::user())->email;
        $review = InterviewVideoReview::where('reviewType', 2)
            ->where('id', $id)
            // ->where('reviewerEmail', $validated['reviewerEmail'])
            ->where('reviewerEmail', $iserId)
            ->first();
        // save the review
        if ($review) {
            $review->update([
                "comment" => isset($validated["comment"]) ? $validated["comment"] : null,
                'reviewJSON' => json_encode($validated['review'])
            ]);
        } else {
            return response()->json([
                "message" => "Attempt not found!",
                "iserId" => $iserId,
            ], 404);
        }

        // // send interviewvideoreviewreceivedemails
        $employee = Employee::where('userId', $review->userId)->first();
        $email = new InterviewVideoReviewUpdatedMail($employee->FirstName);
        if ($audio = $request->file('audio')) {
            $mrl = $review->id . '_' . time();
            // generate the dir for s3
            $dir = 'reviews';
            $review->update([
                "audio" => $mrl . '.mp3'
            ]);
            // upload to s3
            uploadToS3Exact($dir, $audio->getPathname(), $mrl . ".mp3"); // mrl creates the file name
        }
        if ($video = $request->file('video')) {
            $mrl = $review->id . '_' . time();
            $dir = 'reviews/video/' . $review->id;
            uploadToS3Exact($dir, $video->getPathname(), $mrl . ".webm"); // mrl creates the file name
            $review->update(["video" => $mrl . '.webm']);
        }
        InstructorReview::where('instructorEmail', $validated['reviewerEmail'])
            ->where('videoId', $review->interviewVideoId)
            ->update(['reviewCompleted' => 1]);
        Mail::to($review->userId)->send($email);

        // return review
        return response()->json([
            "message" => "Review updated!",
            "mrl" => $review,
            "review" => new InterviewVideoReviewResource($review)
        ]);
    }

    public function getExternalReviews(Request $request, $interviewVideoId)
    {
        $userId = auth()->user()->email;
        // check if video id is valid
        if (!InterviewVideo::find($interviewVideoId)) {
            return response()->json([
                "message" => "Attempt not found!",
            ], 404);
        }
        // check if review already done
        $reviews = InterviewVideoReview::where('userId', $userId)
            ->where('reviewType', 2)
            ->where('interviewVideoId', $interviewVideoId)
            ->get();

        // return review
        return response()->json([
            "message" => "External Reviews fetched!",
            "review" => InterviewVideoReviewResource::collection($reviews)
        ]);
    }
}
