<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Google\Cloud\Translate\V3\TranslationServiceClient;

class LanguagesController extends Controller
{
    function detect(Request $request)
    {
        try {
            $text = $request->post('text');
            if (!$text) {
                return response()->json(['data' => null]);
            }
            // https://console.developers.google.com/iam-admin/serviceaccounts/details/104672777681454851826?project=taplinguav20
            $translationClient = new TranslationServiceClient([
                // 'credentials' => storage_path('app/gcloud.json')
                'credentials' => env("GOOGLE_APPLICATION_CREDENTIALS_LKM", "/home/ubuntu/laravel-languagedetect/gcloud.json")
            ]);
            $result = null;
            try {
                $formattedParent = $translationClient->locationName('taplinguav20', 'global');
                // var_dump($formattedParent);
                $response = $translationClient->detectLanguage($formattedParent, ['content' => $text]);
                $languages = $response->getLanguages();

                foreach ($languages as $language) {
                    $result = $language->getLanguageCode();
                    break;
                }
            } finally {
                $translationClient->close();
            }

            return response()->json(['data' => $result]);
        } catch (Exception $e) {
            return response()->json(['data' => null]);
        }
    }
}
