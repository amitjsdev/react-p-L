<?php

namespace App\Http\Controllers;

use App\Employee;
use App\Http\Resources\LeaderboardResource;
use App\Http\Resources\LeaderboardWeeklyResource;
use App\LingoCoinLog;
use App\UserDailyGoalLog;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class LeaderBoardController extends Controller
{
    const emailExceptions = [
        "exercises@taplingua.com",
        "french01@taplingua.com",
        "satishreddyb@datavolt.com",
        "oct07@taplingua.com",
        "ashutosh@taplingua.com",
        "italian01@taplingua.com",
        "oct1403@taplingua.com",
        'santanu@taplingua.com'
    ];

    public function weekly(Request $request)
    {
        $startOfWeek = null; // last saturday
        // $endOfWeek = today()->endOfDay(); // today
        // check if saturday for current week has passed
        if (now()->dayOfWeek >= 6) {
            // today is saturday or more
            $startOfWeek = today()->addDays(6 - now()->dayOfWeek)->startOfDay();
            $endOfWeek = today()->addWeek()->addDays(5 - now()->dayOfWeek)->endOfDay();
        } else {
            // saturday yet to come
            $startOfWeek = today()->subWeek()->addDays(6 - now()->dayOfWeek)->startOfDay();
            $endOfWeek = today()->addDays(5 - now()->dayOfWeek)->endOfDay();
        }

        $leaderboard = $this->getLeaderboardByDateRange($startOfWeek, $endOfWeek, $request->user()->email, $request->has('withNewUsers'), 'weekly');

        return response()->json($leaderboard);
    }

    public function lastWeek(Request $request)
    {
        $startOfWeek = null; // last saturday
        // $endOfWeek = today()->endOfDay(); // today
        // check if saturday for current week has passed
        if (now()->dayOfWeek >= 6) {
            // today is saturday or more
            $startOfWeek = today()->subWeek()->addDays(6 - now()->dayOfWeek)->startOfDay();
            $endOfWeek = today()->subWeek()->addWeek()->addDays(5 - now()->dayOfWeek)->endOfDay();
        } else {
            // saturday yet to come
            $startOfWeek = today()->subWeek()->subWeek()->addDays(6 - now()->dayOfWeek)->startOfDay();
            $endOfWeek = today()->subWeek()->addDays(5 - now()->dayOfWeek)->endOfDay();
        }

        $leaderboard = $this->getLeaderboardByDateRange($startOfWeek, $endOfWeek, $request->user()->email, $request->has('withNewUsers'), 'weekly');

        return response()->json($leaderboard);
    }

    public function today(Request $request)
    {
        $leaderboard = $this->getLeaderboardByDateRange(today()->startOfDay(), today()->endOfDay(), $request->user()->email, $request->has('withNewUsers'), 'daily');
        return response()->json($leaderboard);
    }

    public function yesterday(Request $request)
    {
        $leaderboard = $this->getLeaderboardByDateRange(today()->subDay()->startOfDay(), today()->subDay()->endOfDay(), $request->user()->email, $request->has('withNewUsers'), 'daily');
        return response()->json($leaderboard);
    }

    public function myRank(Request $request)
    {
        $userId = $request->user()->email;

        $dailyGoalLog = UserDailyGoalLog::where('userId', $userId)->first();

        return response()->json([
            "rank" => $dailyGoalLog->daily_rank->rank ?? 0
        ]);
    }

    public function dailyHighScore(Request $request)
    {
        $highScore = UserDailyGoalLog::select(DB::raw('sum(points) as total'), 'userId', 'dated')
            ->where('userId', $request->user()->email)
            ->groupBy('dated')
            ->orderBy('total', 'desc')
            ->first();

        return response()->json($highScore);
    }

    public function weeklyHighscore(Request $request)
    { }

    public function last7DaysScore(Request $request)
    {
        $highScore = UserDailyGoalLog::select(DB::raw('sum(points) as total'), 'userId', 'dated')
            ->where('userId', $request->user()->email)
            ->whereDate('dated', '>', today()->subWeek())
            ->groupBy('dated')
            ->orderBy('dated', 'desc')
            ->get();

        return response()->json($highScore);
    }

    public function lingoLeaderboard()
    {
        $leaders = LingoCoinLog::select('userId', DB::raw('sum(coins) as totalCoins'))
            ->groupBy('userId')
            ->orderBy('totalCoins', 'desc')
            ->limit(10)
            ->get();

        return response()->json($leaders);
    }

    public function lingoLeaderboardThisMonth()
    {
        $leaders = LingoCoinLog::select('userId', 'created_at', DB::raw('sum(coins) as totalCoins'))
            ->whereDate('created_at', '>', now()->startOfMonth())
            ->groupBy('userId')
            ->orderBy('totalCoins', 'desc')
            ->limit(10)
            ->get();

        return response()->json($leaders);
    }

    private function getLeaderboardByDateRange($startDate, $endDate, $userId, $withNewUsers = false, $type)
    {
        $you = Employee::where('userId', $userId)->first();

        // get all users for that company
        $userIds = Employee::where('CompanyCode', $you->CompanyCode)->whereNotIn('userId', LeaderBoardController::emailExceptions)->pluck('userId')->toArray();

        $yourTotal = $you->totalScore ?? 0;
        $current = UserDailyGoalLog::where('userId', $userId)
            ->whereBetween('dated', [$startDate, $endDate])
            ->sum('points');
        $leaderboard = UserDailyGoalLog::select('userId', DB::raw('sum(points) as current'))
            ->whereIn('userId', $userIds)
            ->whereBetween('dated', [$startDate, $endDate]);

        // if new users are not needed, apply the filter
        if (!$withNewUsers) {
            // get users with total score more than 500 (optimize it later)
            $userIds = UserDailyGoalLog::select('userId', DB::raw('sum(points) as total'))->groupBy('userId')->having('total', '>=', 250)->pluck('userId');
            $leaderboard = $leaderboard->whereIn('userId', $userIds->toArray());
        }

        // get top 50 records
        $leaderboard = $leaderboard
            ->groupBy('userId')
            ->orderBy('current', 'desc')
            ->take(15)
            ->get();

        return [
            'you' => [
                'userId' => $userId,
                'current' => $current,
                "dailyThumbsUp" => $you->daily_thumbs_up ?? 0,
                "weeklyThumbsUp" => $you->weekly_thumbs_up ?? 0,
                'total' => $yourTotal
            ],
            'secondsLeft' => now()->diffInSeconds($endDate),
            'leaderboard' => $type === 'daily'
                ? LeaderboardResource::collection($leaderboard)
                : LeaderboardWeeklyResource::collection($leaderboard)
        ];
    }
}
