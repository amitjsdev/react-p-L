<?php

namespace App\Http\Controllers;

use App\Employee;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use App\Lesson;
use Illuminate\Http\Request;
use App\Http\Resources\Lesson as LessonResource;

use App\LessonsDialogTranslation;
use App\Http\Resources\LessonsDialogTranslation as LessonsDialogTranslationResource;

use App\Http\Resources\CheckUserApiAccess as CheckUserApiAccess;
use App\Module;
use App\RoundLog;
use DB;
use checkUserPermissionController;
use Illuminate\Support\Facades\Log;
use Session;
use Validator;

class LessonController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

        $_callback = $request->input('_callback');

        $id = $request->input('id');

        $module_no = $request->input('module_no');

        $moduleno = $request->input('moduleno');

        $routeno = $request->input('routeno');

        $lessonno = $request->input('lessonno');

        $output = $request->input('output') ? $request->input('output') : 'object';

        if($lessonno!="")
         $id = $lessonno;


        //print_r($_REQUEST);

        $whr = "";

        if($module_no!="")
        $whr .= " and moduleno='".$module_no."' ";

        if($moduleno!="")
        $whr .= " and moduleno='".$moduleno."' ";
        
        if($routeno!="")
        $whr .= " and routeno='".$routeno."' ";
        

        if($id!="")
        {
         $q = "select * from `lessons` where lesson_no = '".$id."' $whr and status = '1' ";
        }
        else
        {
         $q = "select * from `lessons` where status = '1' $whr order by lesson_no ";
        } 

        $query = DB::select(DB::raw($q));

        // get module
        $presentationModule = false;
        if($moduleno != "") {
            $module = Module::where('moduleno', $moduleno)->first();
            if($module) {
                $presentationModule = $module->presentationModule;
            }
        }
        
        $lessons = array(); 

            try {
                $user_language = Employee::where('userId', auth()->user()->email)->first()->user_language;
            } catch (\Throwable $th) {
                $user_language = null;
            }

            foreach($query as $lesson){
            
            $video = explode("\n", $lesson->video);
            $image = explode("\n", $lesson->image);

            $video = str_replace("\r", "", $video);
            $image = str_replace("\r", "", $image);

            $speakers=explode("\n", $lesson->speakers);
            $video_english=explode("\n", $lesson->video_english);
            $video_spanish=explode("\n", $lesson->video_spanish);
            $video_english_subtitles=explode("\n", $lesson->video_english_subtitles);
            $video_spanish_subtitles=explode("\n", $lesson->video_spanish_subtitles);


            $speakers = str_replace("\r", "", $speakers);
            $video_english = str_replace("\r", "", $video_english);
            $video_spanish = str_replace("\r", "", $video_spanish);
            // $video_english_subtitles = str_replace("\r", "", $video_english_subtitles);
            // $video_spanish_subtitles = str_replace("\r", "", $video_spanish_subtitles);
            $video_english_subtitles = explode("\n", getTranslations($lesson->moduleno, $lesson->routeno, $lesson->lesson_no, "or"));
            $video_spanish_subtitles = explode("\n", getTranslations($lesson->moduleno, $lesson->routeno, $lesson->lesson_no, "te"));
            


            $dialog = explode("\n", getTranslations($lesson->moduleno, $lesson->routeno, $lesson->lesson_no, "hi"));
            $dialog_translation = explode("\n", $lesson->dialog_translation);
            $dialog_extra_info = explode("\n", $lesson->dialog_extra_info);
            $audio = explode("\n", $lesson->audio);

            $dialog = str_replace("\r", "", $dialog);
            $dialog_translation = str_replace("\r", "", $dialog_translation);
            $dialog_extra_info = str_replace("\r", "", $dialog_extra_info);
            $audio = str_replace("\r", "", $audio);


            $dialog_translation = str_replace("’", "'", $dialog_translation);
            $dialog_extra_info = str_replace("’", "'", $dialog_extra_info);

            try {
                $livesLeft = getLivesLeftForLesson($lesson->moduleno, $lesson->routeno, $lesson->lesson_no, auth()->user()->email);
            } catch(\Exception $e) {
                Log::error("some error occurred in calculating livesLeft in lesson api", [$e]);
                $livesLeft = 0 ;
            }

            if (
                (int) $lesson->is_challenge === 0 ||
                ((int) $lesson->is_challenge === 1 && $lesson->challenge_type !== "milestone") ||
                ($lesson->challenge_type == "milestone" && (in_array(auth()->user()->email ?? "", __temp_get_milestone_exception_user_list()) || __check_for_milestone_version_app(auth()->user()->email ?? "") 
                )
            ))
            
            $lessons[] = array('id' => $lesson->id, 
                               'moduleno' => $lesson->moduleno, 
                               'routeno' => $lesson->routeno, 
                               'lesson_type' => $lesson->lesson_type, 
                               'lesson_no' => $lesson->lesson_no, 
                               'level_no' => $lesson->level_no, 
                               'title' => $lesson->title, 
                               'description' => $lesson->description, 
                               'long_description' => $lesson->long_description, 
                               'lesson_image' => $lesson->lesson_image, 
                               'pre_lesson' => $lesson->pre_lesson, 
                               'pre_exercise' => $lesson->pre_exercise, 
                               'pre_dialog_msg' => $lesson->pre_dialog_msg, 
                               'pre_video_msg' => $lesson->pre_video_msg, 
                               'video' => $video,   
                               'speakers'=> $speakers, 
                               'speaker_gender'=> $lesson->speaker_gender, 
                               'video_english'=>$video_english, 
                               'video_spanish'=>$video_spanish, 
                               'video_english_subtitles'=>$video_english_subtitles, 
                               'video_spanish_subtitles'=>$video_spanish_subtitles,
                               'interactiveListen' => $image, // changed due to santanu's request; image -> interactiveListen
                               'dialog' => $dialog, 
                               'dialog_translation' => $dialog_translation,
                'dialog_extra_info' => $dialog_extra_info, 
                               'audio' => $audio, 
                               'virtualModule' => $lesson->virtualModule,
                               'virtualRoute' => $lesson->virtualRoute, 
                               'virtualLesson' => $lesson->virtualLesson, 
                               'virtualLessonFlag' => $lesson->virtualLessonFlag, 
                               'examLevel' => $lesson->examLevel, 
                               'holidayWeek' => $lesson->holidayWeek, 
                               'reviewLesson' => $lesson->reviewLesson, 
                               'zipsize' => $lesson->zipsize, 
                               'updatedate' => $lesson->updatedate, 
                               'status' => $lesson->status, 
                               'production' => $lesson->production,
                               'is_challenge' => $lesson->is_challenge,
                               'challenge_type' => $lesson->challenge_type,
                               'livesLeft' => $livesLeft,
                            //    'failCount' => getUserMistakesCountForLesson($lesson->moduleno, $lesson->routeno, $lesson->lesson_no, auth()->user()->email ?? ""),
                               'failCount' => 0,
                               'presentationModule' => $presentationModule ? true : false,
                               'has_dialogs' => $lesson->has_dialogs ? true : false,
                            ); 


            }

             
            //return $lessons;
            //return response()->json($lessons, 200);
            //return LessonResource::collection($lessons);

            //return json_encode($lessons);

            if($output=="object")
            {

                if(count($lessons)=="1")
                 return $lessons[0];
                
                return $lessons;

            }
            else
            {
                // called from lesson pack process for lesson txt file  Lesson_4.txt
                return $lessons;

            }


    }


    public function list(Request $request)
    {
        
        $lesson = Lesson::query(); 

        $lesson->orderBy('id','asc');

        if ($request->input('moduleNo') != "") {

            $lesson->where('moduleno', $request->input('moduleNo'));
        }

        if ($request->input('routeNo') != "") {

            $lesson->where('routeno', $request->input('routeNo'));
        }

        if ($request->input('lessonNo') != "") {

            $lesson->where('lesson_no', $request->input('lessonNo'));
        }

        if ($request->input('query') != "") {

            $query = $request->input('query');
            
            //SQL AND + OR + Brackets
            $lesson->where(function($lesson) use ($query) {
                $lesson->where('title', 'LIKE', '%'.$query.'%')
                      ->orWhere('description', 'LIKE', '%'.$query.'%');
            });

        }

             
        $lesson = $lesson->paginate(50);

        return LessonResource::collection($lesson);


    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $id)
    {
        
        try{

          $Lesson = Lesson::findOrFail($id);
          return new LessonResource($Lesson);
        
        } 
        // catch(Exception $e) catch any exception
        catch(ModelNotFoundException $e)
        {
            return response()->json(['message' => 'Not Found!'], 404);
        } 

    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $request->validate([
            "title"=>"required",
            "moduleno"=>"required",
            "routeno"=>"required",
            "lesson_no"=>"required"
        ]);

        
        $Lesson = Lesson::findOrFail($id);
        
        $Lesson->update($request->all());

        return response()->json(['message' => 'Data Saved!'], 200);


    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            "title"=>"required",
            "moduleno"=>"required",
            "routeno"=>"required",
            "lesson_no"=>"required"
        ]);


        $Lesson = $request->isMethod('put') ? Lesson::findOrFail($request->id) : new Lesson;

        $Lesson->id = $request->input('id');

        //$post->fill($request->input())->save();
        
        $Lesson->moduleno = $request->input('moduleno'); 
        $Lesson->routeno = $request->input('routeno'); 
        $Lesson->lesson_type = $request->input('lesson_type') ? $request->input('lesson_type') : ''; 
        $Lesson->lesson_no = $request->input('lesson_no'); 
        $Lesson->level_no = $request->input('level_no') ? $request->input('level_no') : ''; 

        $Lesson->title = $request->input('title'); 
        $Lesson->description = $request->input('description') ? $request->input('description') : ''; 
        $Lesson->long_description = $request->input('long_description') ? $request->input('long_description') : ''; 
        $Lesson->lesson_image = $request->input('lesson_image') ? $request->input('lesson_image') : ''; 
        $Lesson->pre_lesson = $request->input('pre_lesson') ? $request->input('pre_lesson') : ''; 

        $Lesson->pre_exercise = $request->input('pre_exercise') ? $request->input('pre_exercise') : ''; 
        $Lesson->pre_dialog_msg = $request->input('pre_dialog_msg') ? $request->input('pre_dialog_msg') : ''; 
        $Lesson->pre_video_msg = $request->input('pre_video_msg') ? $request->input('pre_video_msg') : ''; 
        $Lesson->video = $request->input('video') ? $request->input('video') : ''; 
        $Lesson->speakers = $request->input('speakers') ? $request->input('speakers') : ''; 

        $Lesson->speaker_gender = $request->input('speaker_gender') ? $request->input('speaker_gender') : ''; 
        
        $Lesson->video_english = $request->input('video_english') ? $request->input('video_english') : ''; 
        $Lesson->video_spanish = $request->input('video_spanish') ? $request->input('video_spanish') : ''; 
        $Lesson->video_english_subtitles = $request->input('video_english_subtitles') ? $request->input('video_english_subtitles') : ''; 
        $Lesson->video_spanish_subtitles = $request->input('video_spanish_subtitles') ? $request->input('video_spanish_subtitles') : ''; 
        $Lesson->image = $request->input('image') ? $request->input('image') : ''; 

        $Lesson->dialog = $request->input('dialog') ? $request->input('dialog') : ''; 
        $Lesson->dialog_translation = $request->input('dialog_translation') ? $request->input('dialog_translation') : ''; 
        $Lesson->dialog_extra_info = $request->input('dialog_extra_info') ? $request->input('dialog_extra_info') : ''; 
        $Lesson->reviewLesson = $request->input('reviewLesson') ? $request->input('reviewLesson') : ''; 
        $Lesson->audio = $request->input('audio') ? $request->input('audio') : ''; 
        $Lesson->virtualModule = $request->input('virtualModule') ? $request->input('virtualModule') : ''; 

        $Lesson->virtualRoute = $request->input('virtualRoute') ? $request->input('virtualRoute') : ''; 
        $Lesson->virtualLesson = $request->input('virtualLesson') ? $request->input('virtualLesson') : ''; 
        $Lesson->virtualLessonFlag = $request->input('virtualLessonFlag') ? $request->input('virtualLessonFlag') : ''; 
        $Lesson->examLevel = $request->input('examLevel') ? $request->input('examLevel') : ''; 
        $Lesson->holidayWeek = $request->input('holidayWeek') ? $request->input('holidayWeek') : ''; 

        $Lesson->status = $request->input('status') ? $request->input('status') : ''; 
        $Lesson->zipsize = $request->input('zipsize') ? $request->input('zipsize') : ''; 
        $Lesson->production = $request->input('production') ? $request->input('production') : ''; 

        $Lesson->updatedate = date("Y-m-d H:i:s");
         
       
        if($Lesson->save()){
            //return new EmployeeResource($Employee);
            return response()->json(['message' => 'Data Saved!'], 200);
        }


    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        
        //echo "Test...";

        try{  

          $Lesson = Lesson::findOrFail($id);

          if($Lesson->delete()){
            return response()->json(['message' => 'Removed!'], 200);
          }

        }        
        // catch(Exception $e) catch any exception
        catch(ModelNotFoundException $e)
        {
            return response()->json(['message' => 'Not Found!'], 404);
        }

        
    }


    // lessonSummary
    public function lessonSummary(Request $request)
    {

        $id = $request->input('id');
        $module_no = $request->input('moduleno');
        $routeno = $request->input('routeno');
        $lessonno = $request->input('lessonno');
        
        if($lessonno!="")
          $id = $lessonno;

        
        $whr = "";

        if($module_no!="")
            $whr .= " and moduleno='".$module_no."' ";
          
        if($routeno!="")
            $whr .= " and routeno='".$routeno."' ";
          
           
        if($id!="") 
           $q = "select moduleno, routeno, lesson_no, media_alt2, summary_translation, summary_new_format from `exercise` where lesson_no = '".$id."' $whr order by id ";
        else
           $q = "select moduleno, routeno, lesson_no, media_alt2, summary_translation, summary_new_format from `exercise` where id!='' $whr order by id ";  

        
        $assessment = array(); 
           
        $query = DB::select(DB::raw($q)); 
        
        
        foreach($query as $row){

            $summary_translation = explode("\n", $row->summary_translation);
            $summary_translation = str_replace("\r", "", $summary_translation);


            $assessment[] = array("module_no" => $row->moduleno, 
                                  "route_no" => $row->routeno, 
                                  "lesson_no" => $row->lesson_no, 
                                  "level_no" => (string)ceil($row->lesson_no/3), 
                                  "lesson_summary" => $row->media_alt2, 
                                  "summary_translation" => $summary_translation, 
                                  "summary_new_format" => $row->summary_new_format
                                 );


        }    
        

        return $assessment;

    }




    public function lessonPack(Request $request)
    {

        $id = $request->input('id');

        $moduleno = $request->input('moduleno');

        $routeno = $request->input('routeno');

        $lessonno = $request->input('lessonno');


        if($lessonno!="")  /// for new QS lessonno
          $id = $lessonno;

        $packs = $moduleno."_".$routeno."_".$lessonno;


        exec("mkdir ".storage_path()."/Lesson_Module_Packs/Lesson_".$packs."_Pack 2>&1", $ss);
        exec("sudo chmod -R 0777 ".storage_path()."/Lesson_Module_Packs/Lesson_".$packs."_Pack 2>&1", $ss);


        // https://devapi.taplingua.com/api/lesson?moduleno=89&routeno=1&lessonno=1
        // Lesson_".$lessonno.".txt

        $newRequest = new \Illuminate\Http\Request([
            'moduleno' => $moduleno,
            'routeno' => $routeno,
            'lessonno' => $lessonno,
            'output' => 'array'
        ]);

        $lesson_file = storage_path()."/Lesson_Module_Packs/Lesson_".$packs."_Pack/Lesson_".$lessonno.".txt";

        $lesson = app(\App\Http\Controllers\LessonController::class)->indexLessonPack($newRequest, $lesson_file);

        /* Copy TXT files on S3 Media Folder */
        $S3Dir = "s3://".env("S3_MEDIA_BUCKET")."/Lesson_".$packs."_Pack/";
        exec("LANG=en_US.UTF-8; AWS_ACCESS_KEY_ID=".env("S3_ACCESSKEY")." AWS_SECRET_ACCESS_KEY=".env("S3_SECRETKEY")." ".env("AWS_CLI")." s3 cp '".$lesson_file."' ".$S3Dir." --acl public-read 2>&1", $pp3);
        


        // https://devapi.taplingua.com/api/exercise?moduleno=89&routeno=1&lessonno=1
        // Lesson_".$lessonno."_Exercises.txt

        $newRequest = new \Illuminate\Http\Request([
            'moduleno' => $moduleno,
            'routeno' => $routeno,
            'lessonno' => $lessonno,
            'output' => 'array'
        ]);

        $exercise_file = storage_path()."/Lesson_Module_Packs/Lesson_".$packs."_Pack/Lesson_".$lessonno."_Exercises.txt";

        $exercise = app(\App\Http\Controllers\ExerciseController::class)->indexExercisePack($newRequest, $exercise_file);

        /* Copy TXT files on S3 Media Folder */
        $S3Dir = "s3://".env("S3_MEDIA_BUCKET")."/Lesson_".$packs."_Pack/";
        exec("LANG=en_US.UTF-8; AWS_ACCESS_KEY_ID=".env("S3_ACCESSKEY")." AWS_SECRET_ACCESS_KEY=".env("S3_SECRETKEY")." ".env("AWS_CLI")." s3 cp '".$exercise_file."' ".$S3Dir." --acl public-read 2>&1", $pp3);
       

        ////aws s3 sync s3://bucket-name .
               
        /* Copy All dialogs MP3 from AWS S3 to FTP for zip  */
        $S3Dir = "s3://".env("S3_MEDIA_BUCKET")."/Lesson_".$packs."_Pack/dialogs/";
        $dialog_file = storage_path()."/Lesson_Module_Packs/Lesson_".$packs."_Pack/dialogs/";
        exec("LANG=en_US.UTF-8; AWS_ACCESS_KEY_ID=".env("S3_ACCESSKEY")." AWS_SECRET_ACCESS_KEY=".env("S3_SECRETKEY")." ".env("AWS_CLI")." s3 sync ".$S3Dir." '".$dialog_file."' --acl public-read 2>&1", $pp3);


        /* Copy All exercises MP3 from AWS S3 to FTP for zip  */
        $S3Dir = "s3://".env("S3_MEDIA_BUCKET")."/Lesson_".$packs."_Pack/exercises/";
        $exercise_file = storage_path()."/Lesson_Module_Packs/Lesson_".$packs."_Pack/exercises/";
        exec("LANG=en_US.UTF-8; AWS_ACCESS_KEY_ID=".env("S3_ACCESSKEY")." AWS_SECRET_ACCESS_KEY=".env("S3_SECRETKEY")." ".env("AWS_CLI")." s3 sync ".$S3Dir." '".$exercise_file."' --acl public-read 2>&1", $pp3);


        /* Copy SRT files from videos folder AWS S3 to FTP for zip  */
        $S3Dir = "s3://".env("S3_MEDIA_BUCKET")."/Lesson_".$packs."_Pack/videos/";
        $video_file = storage_path()."/Lesson_Module_Packs/Lesson_".$packs."_Pack/videos/";
        exec("LANG=en_US.UTF-8; AWS_ACCESS_KEY_ID=".env("S3_ACCESSKEY")." AWS_SECRET_ACCESS_KEY=".env("S3_SECRETKEY")." ".env("AWS_CLI")." s3 sync ".$S3Dir." '".$video_file."' --acl public-read 2>&1", $pp3);


        // /* Make Zip File  Include .srt  Exclude .mp4 and .sbv  */
        // exec("cd ".storage_path()."/Lesson_Module_Packs/Lesson_".$packs."_Pack/; zip -r -9 Lesson_".$packs."_Pack_Lite.zip . -x videos/*.mp4 -x videos/*.sbv 2>&1", $PP);


        // /* Copy Zip file to AWS S3 */
        // //$S3Dir = "s3://".env("S3_MEDIA_BUCKET")."/Lesson_".$packs."_Pack/";
        // $S3Dir = "s3://".env("S3_MEDIA_BUCKET")."/";
        // $filename = storage_path()."/Lesson_Module_Packs/Lesson_".$packs."_Pack/Lesson_".$packs."_Pack_Lite.zip";
        // exec("LANG=en_US.UTF-8; AWS_ACCESS_KEY_ID=".env("S3_ACCESSKEY")." AWS_SECRET_ACCESS_KEY=".env("S3_SECRETKEY")." ".env("AWS_CLI")." s3 cp '".$filename."' ".$S3Dir." --acl public-read 2>&1", $pp3);


        // /* Remove all TEMP files / folders */
        // $folderName = storage_path()."/Lesson_Module_Packs/Lesson_".$packs."_Pack/";
        // exec("rm -rf ".$folderName." 2>&1", $rr);

        //print_r($rr);
        


        return response()->json(['message' => 'PACK Process Done!'], 200);


    }    



    public function indexLessonPack(Request $request, $file)
    {

        
        $return = json_encode($this->index($request), JSON_PRETTY_PRINT);

        file_put_contents($file, $return);

        return $return;

    } 


    public function packLessons(Request $request)
    {

        $moduleno = $request->input('moduleno');

        $routeno = $request->input('routeno');

        $lessonno = $request->input('lessonno');

        
        $newRequest = new \Illuminate\Http\Request([
            'moduleno' => $moduleno,
            'routeno' => $routeno,
            'lessonno' => $lessonno
        ]);

        
        $lesson = app(\App\Http\Controllers\LessonController::class)->lessonPack($newRequest);

        //echo $lesson;


        return redirect()->back()->with('message', 'Lesson PACK Process Done successfully!');




    }


    public function packLessonsAll(Request $request)
    {

        $moduleno = $request->input('moduleno');

        
        if($moduleno=="")  die("ModuleNo Missing....");      


        $sql="select * from lessons where status='1' and moduleno='".$moduleno."' order by id";
        $packs = DB::select(DB::raw($sql));

        ///echo "<pre>"; print_r($packs);

        echo "<h3>Making PACK for moduleno = ".$moduleno."</h3><br><br>";  
   
        foreach($packs as $pack)
        {    

        $routeno = $pack->routeno;

        $lessonno = $pack->lesson_no;

        
        $newRequest = new \Illuminate\Http\Request([
            'moduleno' => $moduleno,
            'routeno' => $routeno,
            'lessonno' => $lessonno
        ]);


        echo "Making PACK for moduleno = ".$moduleno." and routeno = ".$routeno." and lessonno = ".$lessonno."<br><br>";  

        
        $lesson = app(\App\Http\Controllers\LessonController::class)->lessonPack($newRequest);
      
        echo $lesson;

        echo "<br><br>.........................................................................................<br><br>";


        }


        //return redirect()->back()->with('message', 'Lesson PACK Process Done successfully!');

        echo "<b>Done!!!!</b>";




    }


    
    

    /* CMS */


    public function listLessons(Request $request)
    {

        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        $lesson = Lesson::query(); 

        $lesson->orderBy('id','asc');
   
           if ($request->input('moduleNo') != "") {
   
               $lesson->where('moduleno', $request->input('moduleNo'));
           }
   
           if ($request->input('routeNo') != "") {
   
               $lesson->where('routeno', $request->input('routeNo'));
           }
   
           if ($request->input('lessonNo') != "") {
   
               $lesson->where('lesson_no', $request->input('lessonNo'));
           }

           if ($request->input('status') != "") {
   
            $lesson->where('status', $request->input('status'));
           }

           if ($request->input('production') != "") {
   
            $lesson->where('production', $request->input('production'));
           }
   
           if ($request->input('query') != "") {
   
               $query = $request->input('query');
               
               //SQL AND + OR + Brackets
               $lesson->where(function($lesson) use ($query) {
                   $lesson->where('title', 'LIKE', '%'.$query.'%')
                         ->orWhere('description', 'LIKE', '%'.$query.'%');
               });
   
           }


        if ($request->input('pageSize') != "") 
         $pageSize = $request->input('pageSize');
        else
         $pageSize = 50;  

        $lesson = $lesson->paginate($pageSize);


        $sql="select * from company where Status='1'";
        $companies = DB::select(DB::raw($sql));
        
        return view('admin.ListLessons')->with(['lessons'=>$lesson, "companies" => $companies, "pageSize" => $pageSize]);


    }



    public function editLesson(Request $request)
    {

        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        
        if($request->input('id')=="")
          $lesson = new Lesson;
        else
          $lesson = Lesson::findOrFail( $request->input('id') );


        $sql="select * from module where status='1' order by moduleno ";
        $modules = DB::select(DB::raw($sql));

        //$sql="select * from route where status='1' order by routeno ";
        //$routes = DB::select(DB::raw($sql));

        
        return view('admin.EditLesson')->with(["lesson" => $lesson, "modules" => $modules]);   
      

    }



    public function saveLesson(Request $request)
    {

        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        
        if($request->input('id')!="")
        {
           
           
            $validator = Validator::make($request->all(), [
                "title"=>"required",
                "moduleno"=>"required",
                "routeno"=>"required",
                "lesson_no"=>"required"
            ]);
            
    
            if ($validator->fails()) {
                
                $allErrors = $validator->errors()->all();
                return redirect()->back()->with('error', $allErrors[0]);
            }


            $reqNew = array();
            foreach($request->all() as $key=>$value)
            {

                if($value!="")
                  $reqNew[$key] = $value;
                else
                  $reqNew[$key] = ''; 

            }
    
            //print_r($reqNew); die;
            
            $Lesson = Lesson::findOrFail( $request->input('id') );
            
            //$Lesson->update($request->all());

            $Lesson->update($reqNew);

            return redirect()->back()->with('message', 'Lesson saved successfully!');


        }
        else
        {

            $validator = Validator::make($request->all(), [
                "title"=>"required",
                "moduleno"=>"required",
                "routeno"=>"required",
                "lesson_no"=>"required"
            ]);
    
            if ($validator->fails()) {
                
                $allErrors = $validator->errors()->all();
                return redirect()->back()->with('error', $allErrors[0]);
            }
    

            $reqNew = array();
            foreach($request->all() as $key=>$value)
            {

                if($value!="")
                  $reqNew[$key] = $value;
                else
                  $reqNew[$key] = ''; 

            }
                    


            //$Lesson = Lesson::create($request->all());  

            $Lesson = Lesson::create($reqNew);  


            return redirect()->back()->with('message', 'Lesson saved successfully!');



        }


    }





    public function deleteLesson(Request $request)
    {
        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        $Lesson = Lesson::findOrFail( $request->input('id'));

          if($Lesson->delete()){
            return redirect()->back()->with('message', 'Lesson removed successfully!');
          }

    }



    public function moduleRouteLesson(Request $request)
    {

        $whr = " where Status='1' ";       

        if ($request->input('moduleNo') != "") {

            $whr .= ' and moduleno='.$request->input('moduleNo');
        }

        if ($request->input('routeNo') != "") {

            $whr .= ' and routeno='.$request->input('routeNo');
        }


        $sql="select * from lessons $whr";
        $lesson = DB::select(DB::raw($sql));

        return view('admin.ModuleRouteLessons')->with(["results" => $lesson]);  

    }
    
    

    //listLessonsDialogTranslation

    public function listLessonsDialogTranslation(Request $request)
    {

        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        $LessonsDialogTranslation = LessonsDialogTranslation::query(); 

        $LessonsDialogTranslation->orderBy('id','asc');
   
           if ($request->input('moduleNo') != "") {
   
               $LessonsDialogTranslation->where('moduleNo', $request->input('moduleNo'));
           }
   
           if ($request->input('routeNo') != "") {
   
               $LessonsDialogTranslation->where('routeNo', $request->input('routeNo'));
           }
   
           if ($request->input('lessonNo') != "") {
   
               $LessonsDialogTranslation->where('lessonNo', $request->input('lessonNo'));
           }

           if ($request->input('lessonId') != "") {
   
            $LessonsDialogTranslation->where('lessonId', $request->input('status'));
           }

            
   
           if ($request->input('query') != "") {
   
               $query = $request->input('query');
               
               //SQL AND + OR + Brackets
               $LessonsDialogTranslation->where(function($LessonsDialogTranslation) use ($query) {
                   $LessonsDialogTranslation->where('dialog_translation', 'LIKE', '%'.$query.'%')
                         ->orWhere('lesssonId', 'LIKE', '%'.$query.'%');
               });
   
           }


        if ($request->input('pageSize') != "") 
         $pageSize = $request->input('pageSize');
        else
         $pageSize = 50;  

        $LessonsDialogTranslation = $LessonsDialogTranslation->paginate($pageSize);


        //$sql="select * from company where Status='1'";
        //$companies = DB::select(DB::raw($sql));
        
        return view('admin.ListLessonsDialogTranslation')->with(['lessonsDialogTranslations'=>$LessonsDialogTranslation, "pageSize" => $pageSize]);


    }
    

}
