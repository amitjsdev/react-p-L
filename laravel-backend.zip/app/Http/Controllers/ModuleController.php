<?php

namespace App\Http\Controllers;

use Illuminate\Database\Eloquent\ModelNotFoundException;
use App\Module;
use App\Company;
use App\Course;
use Illuminate\Http\Request;
use App\Http\Resources\Module as ModuleResource;

use App\Http\Resources\CheckUserApiAccess as CheckUserApiAccess;
use App\Lesson;
use App\PlacementLog;
use App\PlacementTestResult;
use App\RoundLog;
use DB;
use checkUserPermissionController;
use Illuminate\Support\Facades\Log;
use Session;
use Validator;


class ModuleController extends Controller
{
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        try {
            $userId = auth()->user()->email;
        } catch(\Exception $e) {
            $userId = null;
        }
        // have to add all other filters

        //$module = DB::table('module');
        //$module = $module->get();
        //return ModuleResource::collection($module);

        $all = $request->input('all');

        $fetchLevel = $request->input('fetchLevel');

        $_callback = $request->input('_callback');

        $id = $request->input('id');

        $lang = $request->input('lang');

        $tolanguage = $request->input('tolanguage');

        $fromlanguage = $request->input('fromlanguage');

        $module_no = $request->input('module_no');

        $moduleNo = $request->input('moduleNo');

        $module_type  = $request->input('module_type');

        $availableForConsumer = $request->input('availableForConsumer');

        $companyCode = $request->input('companyCode');


        if($companyCode!="")
        {

        $sql="select Modules from company where Status='1' and Id='".$companyCode."' ";
        $comp = DB::select(DB::raw($sql));

        $Modules = explode(",", trim($comp[0]->Modules));

        }

        if($module_no!="")
        $id = $module_no;

        if($moduleNo!="")
        $id = $moduleNo;
        
        
        $whr = "";
        
        if($lang!="")
        $whr .= " and language='".$lang."' ";
        
        if($tolanguage!="")
        $whr .= " and tolanguage='".$tolanguage."' ";
        
        if($fromlanguage!="")
        $whr .= " and language='".$fromlanguage."' ";
        
        
        if($module_type!="")
        $whr .= " and module_type='".$module_type."' ";
        
        
        if($availableForConsumer!="")
        $whr .= " and availableForConsumer='".$availableForConsumer."' ";
        
        
        if($id!==""){ 
          $q = "select * from `module` where moduleno in (".$id.") and status = '1' order by categoryRanking DESC ";	
        }else{	
          $q = "select * from `module` where status = '1' $whr order by categoryRanking DESC ";
        }
        
        
        if($companyCode!=""){

        $moduleFixed = str_replace(" ,", "", trim($comp[0]->Modules));    
                
        $q = "select * from `module` where moduleno in (".$moduleFixed.") and status = '1' order by categoryRanking DESC ";
        
        }  
    
         
        $query = DB::select(DB::raw($q));

        $module = array(); 

        foreach($query as $row){ // iterate all the modules

            $query1 = "select * from route where status='1' and moduleno='".$row->moduleno."' order by routeno";

            $result1 = DB::select(DB::raw($query1));

            $routes = array();

            $ii = 1;

            foreach($result1 as $route)
            {

                if($fetchLevel!="")
                {  
              
                $lessons = array();
              
              
                $lessq = "select * from `lessons` where status = '1' and moduleno='".$row->moduleno."' and routeno='".$route->routeno."' order by lesson_no ";
              
                $result2 = DB::select(DB::raw($lessq));

              
                
                foreach($result2 as $lesson)
                {
                  
              
                 $jj = ($ii/3); // its the lessonNo being calculated
                 $kk = ($ii%3); // its the what is the rank of lesson in that level, not touching it as it works
              
                 if($kk==0)  $kk=3; 
                 
                //  if all lessons of a level are needed, we will make the structure
                 if($request->allLessons) {
                    //  if lesson index does not exist, make one
                     if(!isset($lessons[ceil($jj)])) {
                         $lessons[ceil($jj)] = [];
                     }



                            // get the lives left for the lesson
                            $livesLeft = 0;
                            $additionalLivesClaimed = 0;
                            $lastRoundData = RoundLog::where('moduleNo', $lesson->moduleno)
                                ->where('routeNo', $lesson->routeno)
                                ->where('lessonNo', $lesson->lesson_no)
                                ->orderBy('roundNo', 'desc')->first();

                            if ($lastRoundData) {
                                $livesLeft = $lastRoundData->livesLeft;
                                $additionalLivesClaimed = $lastRoundData->additionalLivesClaimed;
                            }
                     
                    //  push lesson to index
                    $lessons[ceil($jj)][] = array("levelno" => ceil($jj) . "." . $kk, "lessonno" => $lesson->lesson_no, 'description' => $lesson->description, 'long_description' => $lesson->long_description, 'isChallenge'=> $lesson->is_challenge, 'challengeType' => $lesson->challenge_type, 'livesLeft' => $livesLeft, 'additionalLivesClaimed' => $additionalLivesClaimed, 'speaker_gender' => $lesson->speaker_gender, 'progress' => getMRLProgressOnRoundLog($userId, $row->moduleno, $route->routeno, $lesson->lesson_no), "has_dialogs" => $lesson->has_dialogs ? true: false);
                 } else {
                    //  old boring stuff
                    if ($all != "") {
                        $lessons[] = array("levelno" => ceil($jj) . "." . $kk, "lessonno" => $lesson->lesson_no, 'description' => $lesson->description, 'long_description' => $lesson->long_description, 'isChallenge'=> $lesson->is_challenge, 'challengeType' => $lesson->challenge_type, 'speaker_gender' => $lesson->speaker_gender, 'progress' => getMRLProgressOnRoundLog($userId, $row->moduleno, $route->routeno, $lesson->lesson_no), "has_dialogs" => $lesson->has_dialogs ? true: false);
                    } else {

                        if ($kk == 1)
                            $lessons[] = array("levelno" => ceil($jj), "lessonno" => $lesson->lesson_no, 'description' => $lesson->description, 'long_description' => $lesson->long_description, 'isChallenge'=> $lesson->is_challenge, 'challengeType' => $lesson->challenge_type, 'speaker_gender' => $lesson->speaker_gender, 'progress' => getMRLProgressOnRoundLog($userId, $row->moduleno, $route->routeno, $lesson->lesson_no), "has_dialogs" => $lesson->has_dialogs ? true: false);
                    } 
                 }
              
              
                 $ii++; 
                 
              
                } /// lesson loop 

                // check if allLessons is true, if so, restructure the lesson to their level
                if($request->allLessons) {
                    $newLessons = [];
                    foreach($lessons as $levelNo => $lessons) {
                        $newLessons[] = [
                            "levelno" => $levelNo,
                            "lessons" => array_map(function($lesson) use($route, $id) {
                                // filter out the milestone for normal users
                                $userId = auth()->user()->email ?? "";
                                if(((int) $lesson['isChallenge'] === 0 || ((int) $lesson['isChallenge'] === 1 && $lesson["challengeType"] !== "milestone") || ($lesson["challengeType"] == "milestone" && (in_array(auth()->user()->email ?? "",  __temp_get_milestone_exception_user_list())
                                || __check_for_milestone_version_app(auth()->user()->email ?? "")
                                )))) {
                                    } else {
                                        $lesson["isChallenge"] = 0;
                                    }
                                    // $lesson["failCount"] = getUserMistakesCountForLesson($id, $route->routeno, $lesson['lessonno'], auth()->user()->email ?? "");
                                    $lesson["failCount"] = 0;
                                    return $lesson;
                            }, $lessons)
                        ];
                    }
                    $lessons = $newLessons;
                }

                if($route->routeno < 9) {
                        // if route is smaller than 7, add it
                        $routes[] = array("routeno" => $route->routeno, "route_lesson_count" => route_lesson_count($row->moduleno, $route->routeno), "description" => $route->description, "long_description" => $route->long_description, "levels" => $lessons);  
                } else if(in_array($userId, [
                        'sanjoy.sanyal@taplingua.com',
                        'exercises@taplingua.com',
                        'ramarajuk@datavolt.com',
                        'french01@taplingua.com'
                ])) {
                        $routes[] = array("routeno" => $route->routeno, "route_lesson_count" => route_lesson_count($row->moduleno, $route->routeno), "description" => $route->description, "long_description" => $route->long_description, "levels" => $lessons);
                }
              
                }
                else {

                    if ($route->routeno < 9) {
                        // if route is smaller than 7, add it
                        $routes[] = array("routeno" => $route->routeno, "route_lesson_count" => route_lesson_count($row->moduleno, $route->routeno), "description" => $route->description, "long_description" => $route->long_description); 
                    } else if (in_array($userId, [
                        'sanjoy.sanyal@taplingua.com',
                        'exercises@taplingua.com',
                        'ramarajuk@datavolt.com',
                        'french01@taplingua.com'
                    ])) {
                        $routes[] = array("routeno" => $route->routeno, "route_lesson_count" => route_lesson_count($row->moduleno, $route->routeno), "description" => $route->description, "long_description" => $route->long_description); 
                    }
               
              
                }



            }


            // get score for current module
            // get employee course and then use score from it
            $score = 0;
            $totalScore = 0;
            $courseNumber = 0;
            $subscriptionExpiresDate = null;
            try {
                $userId = auth()->user()->email;
                $courseNumber = getCourseNoFromModuleNo($row->moduleno, $userId);
                if(isset($courseNumber)) {
                    $employeeCourse = \DB::table('employeecourse')->where('userId', $userId)->where('courseNumber', $courseNumber)->first();
                    if($employeeCourse) {
                        $score = $employeeCourse->score;
                        $totalScore = $employeeCourse->totalScore;
                        $subscriptionExpiresDate = $employeeCourse->subscriptionExpiresDate;
                    }
                }
            } catch (\Exception $e) {
                Log::error("exception occurred at adding score to module api", [$e]);
            }

            $placementScore = null;
            $placementCompleted = false;

            // check placement score
            try {
                $userId = auth()->user()->email;
                $placementTestResult = PlacementTestResult::where('userId', $userId)
                ->where('moduleNo', $row->moduleno)
                ->latest()
                ->first();

                if($placementTestResult) {

                    $placementScore = $placementTestResult->placementScore;
                }

                // check if placement test completed
                try {
                    $placementCompleted = PlacementLog::where('userId', $userId)
                        ->where('moduleNo', $row->moduleno)
                        ->where('status', 1)
                        ->exists();
                } catch (\Throwable $th) {
                    //throw $th;
                }

            } catch (\Throwable $th) {
            }
           
            $module[] = array(
                              "id" => $row->id, 
                              "moduleno" => $row->moduleno, 
                              "moduleno" => $row->moduleno,
                              "courseNumber" => $courseNumber,
                              "placementScore" => $placementScore,
                              "placementCompleted" => $placementCompleted,
                              "subscriptionExpiresDate" => $subscriptionExpiresDate, 
                              "description" => $row->description, 
                              "long_description" => $row->long_description, 
                            //   "courseFlag" => $row->courseFlag,  // removed
                              "module_level" => $row->module_level, 
                              "module_type" => $row->module_type, 
                              "module_tags" => $row->module_tags, 
                              "single_speaker" => $row->single_speaker, 
                            //   "module_color_A" => $row->module_color_A,  // removed
                            //   "module_color_B" => $row->module_color_B,  // removed
                            //   "module_color_C" => $row->module_color_C,  // removed
                              "adddate" => $row->adddate, 
                              "status" => $row->status, 
                              "lite_zip_flag" => $row->lite_zip_flag, 
                            //   "demo_only_status" => $row->demo_only_status,  // removed
                              "from_language" => $row->language, 
                              "to_language" => $row->tolanguage, 
                            //   "availableForConsumer" => $row->availableForConsumer,  // removed
                            //   "userFriendlyName" => $row->userFriendlyName,  // removed
                              "moduleDetailInformation" => $row->moduleDetailInformation, 
                              "categoryRanking" => $row->categoryRanking,
                              "routeCount" => (string)count($routes), 
                              "module_lesson_count" => module_lesson_count($row->moduleno), 
                              "routes" => $routes,
                              "score" => $score,
                              "totalScore" => $totalScore,
                              "latestMilestone" => getMilestonesCompleted(auth()->user()->email, $row->moduleno)
                            );

        }
    

        return $module;

    }

    public function indexV2(Request $request)
    {
        // Warning: this is mostly the legacy code by sandeep, documenting it wherever possible

        // have to add all other filters

        //$module = DB::table('module');
        //$module = $module->get();
        //return ModuleResource::collection($module);

        $all = $request->input('all');

        $fetchLevel = $request->input('fetchLevel');

        $_callback = $request->input('_callback');

        $id = $request->input('id');

        $lang = $request->input('lang');

        $tolanguage = $request->input('tolanguage');

        $fromlanguage = $request->input('fromlanguage');

        $module_no = $request->input('module_no');

        $moduleNo = $request->input('moduleNo');

        $module_type  = $request->input('module_type');

        $availableForConsumer = $request->input('availableForConsumer');

        $companyCode = $request->input('companyCode');


        if ($companyCode != "") {

            $sql = "select Modules from company where Status='1' and Id='" . $companyCode . "' ";
            $comp = DB::select(DB::raw($sql));

            $Modules = explode(",", trim($comp[0]->Modules));
        }

        if ($module_no != "")
            $id = $module_no;

        if ($moduleNo != "")
            $id = $moduleNo;


        $whr = "";

        if ($lang != "")
            $whr .= " and language='" . $lang . "' ";

        if ($tolanguage != "")
            $whr .= " and tolanguage='" . $tolanguage . "' ";

        if ($fromlanguage != "")
            $whr .= " and language='" . $fromlanguage . "' ";


        if ($module_type != "")
            $whr .= " and module_type='" . $module_type . "' ";


        if ($availableForConsumer != "")
            $whr .= " and availableForConsumer='" . $availableForConsumer . "' ";


        if ($id !== "") {
            $q = "select * from `module` where moduleno in (" . $id . ") and status = '1' order by categoryRanking DESC ";
        } else {
            $q = "select * from `module` where status = '1' $whr order by categoryRanking DESC ";
        }


        if ($companyCode != "") {

            $moduleFixed = str_replace(" ,", "", trim($comp[0]->Modules));

            $q = "select * from `module` where moduleno in (" . $moduleFixed . ") and status = '1' order by categoryRanking DESC ";
        }


        $query = DB::select(DB::raw($q));

        $module = array();

        foreach ($query as $row) {

            $query1 = "select * from route where status='1' and moduleno='" . $row->moduleno . "' order by routeno";

            $result1 = DB::select(DB::raw($query1));

            $routes = array();

            $ii = 1;

            foreach ($result1 as $route) {

                if ($fetchLevel != "") {
                    // this means that level have to be fetched too
                    $lessons = array();

                    // v2 data
                    $levels = [];
                    $lessons = Lesson::select(
                            DB::raw('level_no as levelno'),
                            DB::raw('lesson_no as lessonno'),
                            'is_challenge',
                            'challenge_type',
                            'moduleno',
                            'routeno',
                            'description',
                            'long_description'
                        )
                        ->where('moduleno', $row->moduleno)->where('routeno', $route->routeno)->orderBy('lessonno')->get();

                    foreach($lessons as $item) {
                        // if level is not there, make it
                        if(!isset($levels[$item->levelno])) {
                            $ret = new \stdClass();
                            $ret->levelno = $item->levelno;
                            $ret->lessons = [];
                            $levels[$item->levelno] = $ret;
                        }

                        // get the lives left for the lesson
                       /*  $item->livesLeft = 0;
                        $item->additionalLivesClaimed = 0;
                        $lastRoundData = RoundLog::where('moduleNo', $item->moduleno)
                            ->where('routeNo', $item->routeno)
                            ->where('lessonNo', $item->lessonno)
                            ->orderBy('roundNo', 'desc')->first();

                        if ($lastRoundData) {
                            $item->livesLeft = $lastRoundData->livesLeft;
                            $item->additionalLivesClaimed = $lastRoundData->additionalLivesClaimed;
                        } */
                        // unset extra values
                        unset($item->moduleno);
                        unset($item->routeno);

                        $item->is_challenge = $item->is_challenge ? true : false;
                        $item->challenge_type = $item->challenge_type;
                        // add item to level
                        $levels[$item->levelno]->lessons[] = $item;
                    }
                    // v2-data end

                    $routes[] = [
                        "routeno" => $route->routeno,
                        "route_lesson_count" => route_lesson_count($row->moduleno, $route->routeno),
                        "description" => $route->description,
                        "long_description" => $route->long_description,
                        "levels" => array_values($levels)
                    ];
                } else {
                    $routes[] = [
                        "routeno" => $route->routeno,
                        "route_lesson_count" => route_lesson_count($row->moduleno, $route->routeno),
                        "description" => $route->description,
                        "long_description" => $route->long_description
                    ];
                }
            }


            $module[] = array(
                "id" => $row->id,
                "moduleno" => $row->moduleno,
                "companyno" => $row->companyno,
                "description" => $row->description,
                "long_description" => $row->long_description,
                //   "courseFlag" => $row->courseFlag,  // removed
                "module_level" => $row->module_level,
                "module_type" => $row->module_type,
                "module_tags" => $row->module_tags,
                "single_speaker" => $row->single_speaker,
                //   "module_color_A" => $row->module_color_A,  // removed
                //   "module_color_B" => $row->module_color_B,  // removed
                //   "module_color_C" => $row->module_color_C,  // removed
                "adddate" => $row->adddate,
                "status" => $row->status,
                "lite_zip_flag" => $row->lite_zip_flag,
                //   "demo_only_status" => $row->demo_only_status,  // removed
                "from_language" => $row->language,
                "to_language" => $row->tolanguage,
                //   "availableForConsumer" => $row->availableForConsumer,  // removed
                //   "userFriendlyName" => $row->userFriendlyName,  // removed
                "moduleDetailInformation" => $row->moduleDetailInformation,
                "categoryRanking" => $row->categoryRanking,
                "routeCount" => (string) count($routes),
                "module_lesson_count" => module_lesson_count($row->moduleno),
                "routes" => $routes
            );
        }


        return $module;
    }

    public function getFailCountSame(Request $request)

    {
        try {
            $userId = auth()->user()->email;
        } catch (\Exception $e) {
            $userId = null;
        }
        // have to add all other filters

        //$module = DB::table('module');
        //$module = $module->get();
        //return ModuleResource::collection($module);

        $all = $request->input('all');

        $fetchLevel = $request->input('fetchLevel');

        $_callback = $request->input('_callback');

        $id = $request->input('moduleNo');



        $whr = "";

        if ($id !== "") {
            $q = "select * from `module` where moduleno in (" . $id . ") and status = '1' order by categoryRanking DESC ";
        } else {
            $q = "select * from `module` where status = '1' $whr order by categoryRanking DESC ";
        }

        $query = DB::select(DB::raw($q));

        $module = array();

        foreach ($query as $row) {

            $query1 = "select * from route where status='1' and moduleno='" . $row->moduleno . "' order by routeno";

            $result1 = DB::select(DB::raw($query1));

            $routes = array();

            $ii = 1;

            foreach ($result1 as $route) { {

                    $lessons = array();


                    $lessq = "select * from `lessons` where status = '1' and moduleno='" . $row->moduleno . "' and routeno='" . $route->routeno . "' order by lesson_no ";

                    $result2 = DB::select(DB::raw($lessq));



                    foreach ($result2 as $lesson) {


                        $jj = ($ii / 3); // its the lessonNo being calculated
                        $kk = ($ii % 3); // its the what is the rank of lesson in that level, not touching it as it works

                        if ($kk == 0)  $kk = 3;

                        //  if all lessons of a level are needed, we will make the structure

                        //  if lesson index does not exist, make one
                        if (!isset($lessons[ceil($jj)])) {
                            $lessons[ceil($jj)] = [];
                        }

                        //  push lesson to index
                        $lessons[ceil($jj)][] = array("levelno" => ceil($jj) . "." . $kk, "lessonno" => $lesson->lesson_no, 'failCount' => getUserMistakesCountForLesson($row->moduleno, $route->routeno, $lesson->lesson_no, $userId ?? ""));


                        $ii++;
                    } /// lesson loop 

                    // check if allLessons is true, if so, restructure the lesson to their level
                    if ($request->allLessons) {
                        $newLessons = [];
                        foreach ($lessons as $levelNo => $lessons) {
                            $newLessons[] = [
                                "levelno" => $levelNo,
                                "lessons" => $lessons
                            ];
                        }
                        $lessons = $newLessons;
                    }

                    if ($route->routeno < 9) {
                        // if route is smaller than 7, add it
                        $routes[] = array("routeno" => $route->routeno, "levels" => $lessons);
                    } else if (in_array($userId, [
                        'sanjoy.sanyal@taplingua.com',
                        'exercises@taplingua.com',
                        'ramarajuk@datavolt.com',
                        'french01@taplingua.com'
                    ])) {
                        $routes[] = array("routeno" => $route->routeno,"long_description" => $route->long_description, "levels" => $lessons);
                    }
                }
            }

            $module[] = array(
                "id" => $row->id,
                "moduleno" => $row->moduleno,
                "routes" => $routes,
            );
        }


        return $module;
    }

    /**
     * Deprecated
     */
    public function getFailCount(Request $request)
    {
        $userId =  auth()->user()->email ?? null;

        $request->validate([
            'moduleNo' => 'required|numeric',
        ]);

        // get the module
        $module = Module::where('module.moduleno', $request->moduleNo)
        ->get();

        // add the fail count
        $module = $module->map(function($m) use($userId) {
            // map the module
            return [
                'moduleno' => $m->moduleno,
                'description' => $m->long_description,
                'routes' => \App\Route::where('moduleno', $m->moduleno)
                    ->get()->map(function($r) use($m, $userId) {
                    $lessons = \App\Lesson::select(['lesson_no', 'fail_count'])
                        ->join('lesson_fail_counts', function ($join) use ($m, $r) {
                            $join->on('lesson_fail_counts.lessonNo', 'lessons.lesson_no');
                            $join->where('lesson_fail_counts.moduleNo', $m->moduleno);
                            $join->where('lesson_fail_counts.routeNo', $r->routeno);
                        })
                        ->where('lessons.moduleno', $m->moduleno)
                        ->where('lessons.routeno', $r->routeno)
                        ->get();
                    
                    // if lesson is empty
                    if(count($lessons) < 1) {
                        // generate failCount
                        $lessons = \App\Lesson::where('moduleno', $m->moduleno)
                        ->where('routeno', $r->routeno)
                        ->get()->map(function($l) use($userId) {
                            return [
                                'lesson_no' => $l->lesson_no,
                                'fail_count' => getUserMistakesCountForLesson($l->moduleno, $l->routeno, $l->lesson_no, $userId)
                            ];
                        });
                    }
                    // map the route
                    return [
                        'routeno' => $r->routeno,
                        'description' => $r->description,
                        'lessons' => $lessons
                    ];
                })
            ];
        });

        return response()->json($module);
    }
    
    

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function list(Request $request)
    {
        
       
        $request->validate([
            "companyCode" => "required"
        ]);

         
        $company = Company::where('Id', $request->input('companyCode'))->get();

        //print_r($company[0]->Modules);

        $mods = explode(",", trim($company[0]->Modules));

        $Modules = array();

        foreach($mods as $k => $m)
        {
          $Modules[] = array( "moduleNo" => $m, "moduleName" => getModuleNameByCourse($m) );
        }


        $moduleList[] = array("companyCode" => $request->input('companyCode'), "Modules" => $Modules );

        return $moduleList;
    }


    /**
     * Display a list of modules for guest users.
     *
     * @return \Illuminate\Http\Response
     */
    public function moduleListGuest(Request $request)
    {
        $request->validate([
            "companyCode" => "required"
        ]);


        // get the company
        $company = Company::where('Id', $request->companyCode)->get();

        // get the module Numbers
        $mods = explode(",", trim($company[0]->Modules));

        // modules
        $modules = Module::whereIn("moduleno", $mods)
            ->select('moduleno', 'description', 'long_description', 'module_type')
            ->orderBy('moduleno', 'desc')
            ->get();

        // 
        $modules = $modules->map(function ($module)  {
            $module->courseno = null;
            $module->totalLessons = getLessonCountForModule($module->moduleno);
            return $module;
        });

        return response()->json([
            'companyCode' => $request->companyCode,
            'modules' => $modules
        ]);
    }


    /**
     * Display a list of modules for registered users.
     *
     * @return \Illuminate\Http\Response
     */
    public function moduleListUser(Request $request)
    {
        $request->validate([
            "companyCode" => "required"
        ]);

        $user = $request->user();


        // get the company
        $company = Company::where('Id', $request->companyCode)->get();

        // get the module Numbers
        $mods = explode(",", trim($company[0]->Modules));

        // modules
        $modules = Module::whereIn("moduleno", $mods)
            ->select('moduleno', 'description', 'long_description')
            ->get();

        // 
        $modules = $modules->map(function($module) use($user) {
            $module->courseno = getCourseNoFromModuleNo($module->moduleno, $user->email);
            $module->totalLessons = getLessonCountForModule($module->moduleno);
            return $module;
        });

        return response()->json([
            'companyCode' => $request->companyCode,
            'userId' => $user->email,
            'modules' => $modules,
        ]);
    }



    public function listing(Request $request)
    {
        
        $Module = Module::query(); 

        $Module->orderBy('id','asc');

        if ($request->input('moduleNo') != "") {

            $Module->where('moduleno', $request->input('moduleNo'));
        }

        if ($request->input('companyNo') != "") {

            $Module->where('companyno', $request->input('companyNo'));
        }

        

        if ($request->input('query') != "") {

            $query = $request->input('query');
            
            //SQL AND + OR + Brackets
            $Module->where(function($Module) use ($query) {
                $Module->where('description', 'LIKE', '%'.$query.'%')
                      ->orWhere('long_description', 'LIKE', '%'.$query.'%');
            });

        }

             
        $Module = $Module->paginate(50);

        return ModuleResource::collection($Module);


    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $id)
    {
        
        try{

          $Module = Module::findOrFail($id);
          return new ModuleResource($Module);
        
        } 
        // catch(Exception $e) catch any exception
        catch(ModelNotFoundException $e)
        {
            return response()->json(['message' => 'Not Found!'], 404);
        } 

    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $request->validate([
            "moduleno"=>"required",
            "companyno"=>"required",
            "description"=>"required"
        ]);

        
        $Module = Module::findOrFail($id);
        
        $Module->update($request->all());

        return response()->json(['message' => 'Data Saved!'], 200);


    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            "moduleno"=>"required",
            "companyno"=>"required",
            "description"=>"required"
        ]);


        $Module = $request->isMethod('put') ? Module::findOrFail($request->id) : new Module;

        $Module->id = $request->input('id');

        //$post->fill($request->input())->save();
        
        $Module->moduleno = $request->input('moduleno'); 
        $Module->companyno = $request->input('companyno'); 
        $Module->description = $request->input('description'); 
        $Module->long_description = $request->input('long_description') ? $request->input('long_description') : ''; 
        $Module->startDate = $request->input('startDate') ? $request->input('startDate') : '';
        
        $Module->numberOfWeeks = $request->input('numberOfWeeks') ? $request->input('numberOfWeeks') : ''; 
        $Module->numberOfHours = $request->input('numberOfHours') ? $request->input('numberOfHours') : ''; 
        $Module->numberOfStudentsRegistered = $request->input('numberOfStudentsRegistered') ? $request->input('numberOfStudentsRegistered') : ''; 
        $Module->courseFlag = $request->input('courseFlag') ? $request->input('courseFlag') : ''; 
        $Module->tutor1 = $request->input('tutor1') ? $request->input('tutor1') : '';

        $Module->tutor2 = $request->input('tutor2') ? $request->input('tutor2') : ''; 
        $Module->module_level = $request->input('module_level') ? $request->input('module_level') : ''; 
        $Module->module_type = $request->input('module_type') ? $request->input('module_type') : ''; 
        $Module->module_tags = $request->input('module_tags') ? $request->input('module_tags') : ''; 
        $Module->module_image = $request->input('module_image') ? $request->input('module_image') : '';

        $Module->module_color_A = $request->input('module_color_A') ? $request->input('module_color_A') : ''; 
        $Module->module_color_B = $request->input('module_color_B') ? $request->input('module_color_B') : ''; 
        $Module->module_color_C = $request->input('module_color_C') ? $request->input('module_color_C') : ''; 
        $Module->status = $request->input('status') ? $request->input('status') : ''; 
        $Module->lite_zip_flag = $request->input('lite_zip_flag') ? $request->input('lite_zip_flag') : '';

        $Module->demo_only_status = $request->input('demo_only_status') ? $request->input('demo_only_status') : ''; 
        $Module->language = $request->input('language') ? $request->input('language') : ''; 
        $Module->tolanguage = $request->input('tolanguage') ? $request->input('tolanguage') : ''; 
        $Module->availableForConsumer = $request->input('availableForConsumer') ? $request->input('availableForConsumer') : ''; 
        $Module->userFriendlyName = $request->input('userFriendlyName') ? $request->input('userFriendlyName') : '';
        $Module->moduleDetailInformation = $request->input('moduleDetailInformation') ? $request->input('moduleDetailInformation') : '';

        $Module->categoryRanking = $request->input('categoryRanking') ? $request->input('categoryRanking') : 0;


        $Module->adddate = date("Y-m-d H:i:s");
         
       
        if($Module->save()){
            //return new EmployeeResource($Employee);
            return response()->json(['message' => 'Data Saved!'], 200);
        }


    }



    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        
        //echo "Test...";

        try{  

          $Module = Module::findOrFail($id);

          if($Module->delete()){
            return response()->json(['message' => 'Removed!'], 200);
          }

        }        
        // catch(Exception $e) catch any exception
        catch(ModelNotFoundException $e)
        {
            return response()->json(['message' => 'Not Found!'], 404);
        }

        
    }
    
    
    public function moduleListBatch(Request $request)
    {

        

        $request->validate([
            "companyCode" => "required"
        ]);


        $module = DB::table('company')
         ->leftJoin('courses', 'company.Id', '=', 'courses.Company');

        if ($request->input('companyCode') != "") {
            $module->where('company.Id', $request->input('companyCode'));
        }

        if ($request->input('batchNumber') != "") {

            $module->where('courses.courseBatch', $request->input('batchNumber'));
        } 

        
        $module = $module->get();
        
        $Modules = array();


        foreach($module as $rows) {

            $mods = explode(",", trim($rows->Modules));
      
      
            if(in_array($rows->moduleNumber, $mods))
            {
             $Modules[] = array( "moduleNo" => $rows->moduleNumber, "batchNumber" => $rows->courseBatch, "courseNumber" => $rows->courseNumber, "moduleName" => getModuleNameByCourse($rows->moduleNumber) );
            }
      
          }


          return $Modules;
      

    }



    /* CMS */


    public function listModules(Request $request)
    {

        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

           $Module = Module::query(); 

           $Module->orderBy('id','asc');
   
           if ($request->input('moduleNo') != "") {
   
               $Module->where('moduleno', $request->input('moduleNo'));
           }
   
           if ($request->input('companyNo') != "") {
   
               $Module->where('companyno', $request->input('companyNo'));
           }

           if ($request->input('language') != "") {
   
            $Module->where('language', $request->input('language'));

           }


           if ($request->input('status') != "") {

            $Module->where('status', $request->input('status'));
          
           }
         
         
   
           if ($request->input('query') != "") {
   
               $query = $request->input('query');
               
               //SQL AND + OR + Brackets
               $Module->where(function($Module) use ($query) {
                   $Module->where('description', 'LIKE', '%'.$query.'%')
                         ->orWhere('long_description', 'LIKE', '%'.$query.'%');
               });
   
           }


        if ($request->input('pageSize') != "") 
         $pageSize = $request->input('pageSize');
        else
         $pageSize = 50;  

        $Module = $Module->paginate($pageSize);


        
        
        return view('admin.ListModules')->with(['modules'=>$Module, "pageSize" => $pageSize]);


    }


    public function editModule(Request $request)
    {

        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        
        if($request->input('id')=="")
          $Module = new Module;
        else
          $Module = Module::findOrFail( $request->input('id') );


        //$sql="select * from module where status='1' order by moduleno ";
        //$modules = DB::select(DB::raw($sql));

        //$sql="select * from route where status='1' order by routeno ";
        //$routes = DB::select(DB::raw($sql));

        
        return view('admin.EditModule')->with(["module" => $Module]);   
      

    }




    public function saveModule(Request $request)
    {

        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        
        if($request->input('id')!="")
        {
           
           
            $validator = Validator::make($request->all(), [
                "moduleno"=>"required",
                "description"=>"required"
            ]);
            
    
            if ($validator->fails()) {
                
                $allErrors = $validator->errors()->all();
                return redirect()->back()->with('error', $allErrors[0]);
            }


            $reqNew = array();
            foreach($request->all() as $key=>$value)
            {

                if($value!="")
                  $reqNew[$key] = $value;
                else
                  $reqNew[$key] = ''; 

            }
    
            //print_r($reqNew); die;
            
            $Module = Module::findOrFail( $request->input('id') );
            
            //$Module->update($request->all());

            $Module->update($reqNew);

            return redirect()->back()->with('message', 'Module saved successfully!');


        }
        else
        {

            $validator = Validator::make($request->all(), [
                "moduleno"=>"required",
                "description"=>"required"
            ]);
    
            if ($validator->fails()) {
                
                $allErrors = $validator->errors()->all();
                return redirect()->back()->with('error', $allErrors[0]);
            }
    

            $reqNew = array();
            foreach($request->all() as $key=>$value)
            {

                if($value!="")
                  $reqNew[$key] = $value;
                else
                  $reqNew[$key] = ''; 

            }
                    


            //$Module = Module::create($request->all());  

            $Module = Module::create($reqNew);  


            return redirect()->back()->with('message', 'Module saved successfully!');



        }


    }







    public function deleteModule(Request $request)
    {
        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        $Module = Module::findOrFail( $request->input('id'));

          if($Module->delete()){
            return redirect()->back()->with('message', 'Module removed successfully!');
          }

    }





    public function moduleRoute(Request $request)
    {

        if($request->input('moduleNo')!="")
        {

            $results = DB::table('route')->select()->where('moduleno', $request->input('moduleNo'))->orderBy('routeno', 'asc')->get();

        }
        else
        {
            $results = array();
        }


        return view('admin.ModuleRoutes')->with(["results" => $results]);  


    }





}
