<?php

namespace App\Http\Controllers;

use App\PushLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;

class NotificationController extends Controller
{
    public function welcome(Request $request)
    {
        $from = "cristina.guijarro@taplingua.com";
        $validator = Validator::make($request->all(), [
            'params.to' => 'required|array|min:1',
            'params.to.*' => 'email',
            'params.companyCode' => 'numeric|required',
            'params.courseNumber' => 'numeric|required',
            'params.batchNumber' => 'numeric|required',
            'params.lang' => 'string',
            'params.mailMode' => 'string',
        ]);
        if ($validator->fails()) {
            return response()->json(["message" => "companyCode/batchNumber/courseNumber is missing"]);
        }

        $validated = $validator->validated()['params'];

        $data = DB::table('employeecourse', 'ec')
            ->selectRaw("ec.i_d, ec.dateRegistered, e.CompanyCode, ec.userId, ec.courseNumber, ec.Id, CONCAT(e.FirstName,' ', e.LastName) AS Name, r.long_description, r.description, c.courseName, DATE_FORMAT(c.courseStartDate, '%d-%m-%Y') AS courseStartDate,DATE_FORMAT(c.courseEndDate, \"%d-%m-%Y\") as courseEndDate, concat(m.description,'  (Taplingua)') AS moduleName, co.Name AS companyName")
            ->join('employee AS e', 'e.userId', '=', 'ec.userId')
            ->join('courses AS c', 'c.courseNumber', '=', 'ec.courseNumber')
            ->join('module AS m', 'm.moduleno', '=', 'c.moduleNumber')
            ->join('route AS r', 'r.moduleno', '=', 'c.moduleNumber')
            ->leftJoin('company AS co', 'co.Id', '=', 'e.CompanyCode');

        $data->whereIn('ec.userId', $validated['to'])
            ->where('e.CompanyCode', $validated['companyCode'])
            ->where('c.coursebatch', $validated['batchNumber'])
            ->where('ec.courseNumber', $validated['courseNumber'])
            ->distinct();

        $data = $data->get();
        $response = [];
        foreach ($data as $i => $record) {
            $rows = (array) $record;
            $key = $record->userId;
            if (isset($response[$key])) {
                //$response[$key]['Routes'][]= $rows['description'];

                $response[$key]['certificateImg'] = getCertificate($record->userId, $record->courseNumber)->rawUrl();
                $response[$key]['courseDuration'] = \Carbon\Carbon::createFromFormat('d-m-Y', trim($record->courseStartDate))->diffInWeeks(\Carbon\Carbon::createFromFormat('d-m-Y', trim($record->courseEndDate))) . " weeks";
                $response[$key]['Routes'][$i]['description'] = $rows['description'];
                $response[$key]['Routes'][$i]['long_description'] = $rows['long_description'];
            } else {
                $response[$key] = $rows;
                //$response[$key]['Routes'][]= $rows['description'];
                $response[$key]['certificateImg'] = getCertificate($record->userId, $record->courseNumber)->rawUrl();
                $response[$key]['courseDuration'] = \Carbon\Carbon::createFromFormat('d-m-Y', trim($record->courseStartDate))->diffInWeeks(\Carbon\Carbon::createFromFormat('d-m-Y', trim($record->courseEndDate))) . " weeks";
                $response[$key]['Routes'][$i]['description'] = $rows['description'];
                $response[$key]['Routes'][$i]['long_description'] = $rows['long_description'];
            }
        }
        // return response()->json($data);
        try {
            // TODO: Send Email

            foreach ($response as $email) {
                if (strtolower($request->params["mailMode"]) === 'real') {
                    \Mail::to($email['userId'])
                        ->send(new \App\Mail\Welcome($email, $request->params["companyCode"], $request->params["lang"]));
                } else { // in test mode
                    \Mail::to(['santanu.dasgupta@taplingua.com', 'shubham@truetechpro.com'])
                        ->send(new \App\Mail\Welcome($email, $request->params["companyCode"], $request->params["lang"]));
                }
            }
            // $result = sendWelcomeEmail($response, $validated['companyCode'], $validated['lang'], $validated['mailMode'], $from);
            return response()->json(["message" => "Email Sent Successfully."]);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function weekly(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'params.to' => 'required|array|min:1',
            'params.to.*' => 'email',
            'params.routeNumber' => 'numeric',
            'params.companyCode' => 'numeric|required',
            'params.courseNumber' => 'numeric|required',
            'params.batchNumber' => 'numeric|required',
            'params.routeNumber' => 'nullable|array',
            'params.routeNumber.*' => 'numeric|required',
            'params.lang' => 'string',
            'params.type' => 'string',
            'params.mailMode' => 'string',
        ]);

        //print_r($request->all());

        //print_r($request->params['to']);

        if ($validator->fails()) {
            //return response()->json(["message" => "companyCode/batchNumber/courseNumber/email is missing"]);
        }

        $type = isset($request->params['type']) ? $request->params['type'] : 'weekly_email';
        $from = "cristina.guijarro@taplingua.com";
        // $from = "Cristina Guijarro (Taplingua) <cristina.guijarro@taplingua.com>";

        $data = DB::table('employeecourse AS ec')
            ->selectRaw('ec.userId, e.CompanyCode, comp.Name as companyName, ec.courseNumber, c.moduleNumber, concat(e.firstName, " ", e.lastName) as Name, e.fcmToken, r.routeno, concat(m.description, " Taplingua") AS moduleName, r.description, DATE_FORMAT(c.courseStartDate, "%d-%m-%Y") as courseStartDate, DATE_FORMAT(c.courseEndDate, "%d-%m-%Y") as courseEndDate, co.Name AS companyName')
            ->join('employee AS e', 'e.userId', '=', 'ec.userId')
            ->join('company AS comp', 'comp.Id', '=', 'e.companyCode')
            ->join('courses AS c', 'c.courseNumber', '=', 'ec.courseNumber')
            ->join('module AS m', 'm.moduleno', '=', 'c.moduleNumber')
            ->join('route AS r', 'r.moduleno', '=', 'c.moduleNumber')
            ->leftJoin('company AS co', 'co.Id', '=', 'e.CompanyCode');

        if ($request->has('params.to')) {
            $data->whereIn('ec.userId', $request->params['to']);
        }

        if ($request->has('params.companyCode')) {
            $data->where('e.CompanyCode', $request->params['companyCode']);
        }

        if ($request->has('params.courseBatch')) {
            $data->where('c.courseBatch', $request->params['batchNumber']);
        }

        if ($request->has('params.courseNumber')) {
            $data->where('ec.courseNumber', $request->params['courseNumber']);
        }

        if ($request->has('params.routeNumber')) {
            $data->where('r.id', $request->params['routeNumber']);
        }

        $data = $data->groupBy('ec.userId')->get();
        $response = [];

        //echo "Count => ". count($data);

        //print_r($data);

        foreach ($data as $row) {
            $key = $row->userId;
            // add weeks according to routes available
            $row->weeks = DB::table('route')->where('moduleno', $row->moduleNumber)->count();
            $row->courseDuration = $row->weeks . " weeks";
            // add courseEndDate according to routes available
            $row->courseEndDate = \Carbon\Carbon::createFromFormat('d-m-Y', trim($row->courseStartDate))->addWeeks($row->weeks)->format('d-m-Y');
            $response[$key][0] = $row;
            $routeNo = $row->routeno;
            // TODO: Should be optimized, is quick migration of core php code!!!
            $newRequest = new \Illuminate\Http\Request([
                'modules' => 1,
                'fetchLevel' => 1,
                'id' => $row->moduleNumber
            ]);

            $levelData = (array) app(\App\Http\Controllers\ModuleController::class)->index($newRequest);
            foreach ($levelData[0]['routes'] as $routeArr) {
                if ($routeArr['routeno'] == $routeNo) {
                    $response[$key][0]->routeLevels = $routeArr["levels"];
                }
            }
        }

        try {
            if ($type == 'weekly_email') {
                foreach ($response as $key => $email) {
                    // check if user is ahead of time
                    $user = (array) $email[0];
                    // send email to first of array for each user
                    if (!userIsLost($user['userId'], $user['moduleNumber'])) { // check if user is lost or not
                        if (!userIsAheadOfTimeInModule($user['userId'], $user['moduleNumber'], $user['moduleNumber'])) { // if user is not ahead of time, then only send email
                            // get payload for branch.io link
                            $payload = getWeeklyPushNotificationPayload($response, $request->params['lang'], $key);
                            if (strtolower($request->params["mailMode"]) === 'real') {
                                \Mail::to($user['userId'])
                                    ->send(new \App\Mail\Weekly($user, $request->params['lang'], $payload));
                            } else { // in test mode
                                \Mail::to(['santanu.dasgupta@taplingua.com', 'shubham@truetechpro.com'])
                                    ->send(new \App\Mail\Weekly($user, $request->params['lang'], $payload));
                            }
                        }
                    }
                }
            }
            if ($type == 'weekly_push') {
                // foreach response a push will be sent
                $results = sendWeeklyPushNotification($response, $request->params['lang'], $request->params['mailMode']);
            }
            return response()->json(["message" => $type . " Sent Successfully."]);
        } catch (\Exception $e) {
            return response()->json(["error" => $e->getMessage()]);
        }
    }

    public function pushNotification(Request $request, $generatePayloadOnly = false, $payLoadIndex = "") // generate payload only is used in sendEmail to generate payload for branch.io
    {
        $validator = Validator::make($request->all(), [
            'params.to' => 'required|array|min:1',
            'params.to.*' => 'email',
            'params.routeNumber' => 'numeric',
            'params.companyCode' => 'numeric|required',
            'params.courseNumber' => 'numeric|required',
            'params.batchNumber' => 'numeric|required',
            'params.routeNumber' => 'nullable|array',
            'params.routeNumber.*' => 'numeric|required',
            'params.lang' => 'string',
            'params.type' => 'string',
            'params.mailMode' => 'string',
        ]);

        if ($validator->fails()) {
            return response()->json(["message" => "companyCode/batchNumber/courseNumber/email is missing"]);
        }
        // Its couseGroup in db as well;
        $data = DB::table('employeecourse AS ec')
            ->selectRaw('ec.i_d, ec.dateRegistered, ec.completedStatus, e.CompanyCode, ec.userId, ec.evaluationCompleted, ec.courseNumber, ec.Id, ec.couseGroup, e.FirstName, concat(e.FirstName, " ", e.LastName) AS Name, e.fcmToken, e.Location, e.Mobile, e.DNI, c.moduleNumber, c.courseBatch, DATE_FORMAT(c.courseEndDate, "%d-%m-%Y") as courseEndDate, r.long_description, r.description, r.routeno, DATE_FORMAT(c.courseStartDate, "%d-%m-%Y") as courseStartDate, concat(m.description, " (Taplingua)") as moduleName')
            ->join('employee AS e', 'e.userId', '=', 'ec.userId')
            ->join('courses AS c', 'c.courseNumber', '=', 'ec.courseNumber')
            ->join('module AS m', 'm.moduleno', '=', 'c.moduleNumber')
            ->join('route AS r', 'r.moduleno', '=', 'c.moduleNumber');

        if ($request->has('params.to')) {
            $data->whereIn('ec.userId', $request->params['to']);
        }

        if ($request->has('params.companyCode')) {
            $data->where('e.CompanyCode', $request->params['companyCode']);
        }

        if ($request->has('params.courseBatch')) {
            $data->where('c.courseBatch', $request->params['batchNumber']);
        }

        if ($request->has('params.courseNumber')) {
            $data->where('ec.courseNumber', $request->params['courseNumber']);
        }

        if ($request->has('params.routeNumber') && $request->get('params.routeNumber') !== null) {
            $data->whereIn('r.id', $request->params['routeNumber']);
        }

        $data = $data->get();

        $response = [];

        foreach ($data as $row) {
            $key = $row->userId . $row->CompanyCode . $row->courseNumber . $row->moduleNumber;
            if (!isset($response[$key])) {
                $userData = array();
                $userData['i_d'] = $row->i_d;
                $userData['userId'] = $row->userId;
                $userData['fcmToken'] = $row->fcmToken;
                $userData['Name'] = trim($row->Name);
                $userData['FirstName'] = trim($row->FirstName);
                $userData['moduleName'] = trim($row->moduleName);
                $userData['moduleNumber'] = (int) trim($row->moduleNumber);
                $userData['courseNumber'] = (int) trim($row->courseNumber);
                $userData['courseStartDate'] = trim($row->courseStartDate);
                $userData['coursePercent'] = coursePercent($row->moduleNumber, $row->userId);
                $userData['courseEndDate'] = $row->courseEndDate;
                $response[$key] = $userData;
            }
            $response[$key]['Routes'][$row->description] = [
                'routePercent' => routePercent($row->moduleNumber, $row->routeno, $row->userId),
                'routeno' => $row->routeno,
                'description' => $row->description,
                'longDescription' => $row->long_description
            ];
        }
        try {
            if (!$generatePayloadOnly) { // if payload in not asked
                sendPushNotification($response, $request->params['companyCode'], $request->params['lang']);
                // return response
                return response()->json(["message" => "Push Notification sent Successfully."]);
            } else {
                // send the payload for asked index
                return getPushNotificationPayload($response, $request->params['companyCode'], $request->params['lang'], $payLoadIndex);
            }
        } catch (\Exception $e) {
            return response()->json(["error" => $e->getMessage()]);
        }
    }

    public function sendEmail(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'params.to' => 'required|array|min:1',
            'params.to.*' => 'email',
            'params.routeNumber' => 'numeric',
            'params.companyCode' => 'numeric|required',
            'params.courseNumber' => 'numeric|required',
            'params.batchNumber' => 'numeric|required',
            'params.routeNumber' => 'nullable|array',
            'params.routeNumber.*' => 'numeric|required',
            'params.lang' => 'string',
            'params.type' => 'string',
            'params.mailMode' => 'string',
        ]);

        if ($validator->fails()) {
            return response()->json(["message" => "companyCode/batchNumber/courseNumber/email is missing"]);
        }
        $from = "cristina.guijarro@taplingua.com";
        // Its couseGroup in db as well;
        $data = DB::table('employeecourse AS ec')
            ->selectRaw('ec.i_d, ec.dateRegistered, ec.completedStatus, e.CompanyCode, ec.userId, ec.evaluationCompleted, ec.courseNumber, ec.Id, ec.couseGroup, e.FirstName, concat(e.FirstName, " ", e.LastName) AS Name, e.mobileOS, e.Location, e.Mobile, e.DNI, c.moduleNumber, c.courseBatch, r.long_description, r.description, r.routeno, DATE_FORMAT(c.courseStartDate, "%d-%m-%Y") as courseStartDate,DATE_FORMAT(c.courseEndDate, "%d-%m-%Y") as courseEndDate, concat(m.description, " (Taplingua)") as moduleName, co.Name AS companyName')
            ->join('employee AS e', 'e.userId', '=', 'ec.userId')
            ->join('courses AS c', 'c.courseNumber', '=', 'ec.courseNumber')
            ->join('module AS m', 'm.moduleno', '=', 'c.moduleNumber')
            ->join('route AS r', 'r.moduleno', '=', 'c.moduleNumber')
            ->leftJoin('company AS co', 'co.Id', '=', 'e.CompanyCode');

        if ($request->has('params.to')) {
            $data->whereIn('ec.userId', $request->params['to']);
        }

        if ($request->has('params.companyCode')) {
            $data->where('e.CompanyCode', $request->params['companyCode']);
        }

        if ($request->has('params.courseBatch')) {
            $data->where('c.courseBatch', $request->params['batchNumber']);
        }

        if ($request->has('params.courseNumber')) {
            $data->where('ec.courseNumber', $request->params['courseNumber']);
        }

        if ($request->has('params.routeNumber') && $request->get('params.routeNumber') !== null) {
            $data->whereIn('r.id', $request->params['routeNumber']);
        }

        $data = $data->get();

        $response = [];

        foreach ($data as $row) {
            $key = $row->userId . $row->CompanyCode . $row->courseNumber . $row->moduleNumber;
            if (!isset($response[$key])) {
                $userData = array();
                $userData['i_d'] = $row->i_d;
                $userData['userId'] = $row->userId;
                $userData['Name'] = trim($row->Name);
                $userData['companyName'] = trim($row->companyName);
                $userData['moduleName'] = trim($row->moduleName);
                $userData['courseStartDate'] = trim($row->courseStartDate);
                $userData['courseEndDate'] = trim($row->courseEndDate);
                $userData['courseDuration'] = \Carbon\Carbon::createFromFormat('d-m-Y', trim($row->courseStartDate))->diffInWeeks(\Carbon\Carbon::createFromFormat('d-m-Y', trim($row->courseEndDate))) . " weeks";
                $userData['coursePercent'] = coursePercent($row->moduleNumber, $row->userId);
                $userData['certificateImg'] = getCertificate($row->userId, $row->courseNumber)->rawUrl();
                $response[$key] = $userData;
            }
            $response[$key]['Routes'][$row->description] = ['routePercent' => routePercent($row->moduleNumber, $row->routeno, $row->userId), 'routeno' => $row->routeno];
        }

        try {
            foreach ($response as $key => $email) {
                if (strtolower($request->params["mailMode"]) === 'real') {
                    \Mail::to($email['userId'])
                        ->send(
                            new \App\Mail\WeeklyCompletionReport(
                                $email,
                                $request->params["companyCode"],
                                $request->params["lang"],
                                $this->pushNotification($request, true, $key)
                            )
                        );
                } else { // in test mode
                    \Mail::to(['santanu.dasgupta@taplingua.com', 'shubham@truetechpro.com'])
                        ->send(new \App\Mail\WeeklyCompletionReport(
                            $email,
                            $request->params["companyCode"],
                            $request->params["lang"],
                            $this->pushNotification($request, true, $key)
                        ));
                }
            }
            return response()->json(["message" => "Email Sent Successfully."]);
        } catch (\Exception $e) {
            return response()->json(["error" => $e->getMessage()]);
        }
    }



    public function unsubscribe(Request $request)
    {

        $email = $request->email;

        $messages = array();

        return view('Unsubscribe')->with(["email" => $email, "messages" => $messages]);
    }

    public function unsubscribeSubmit(Request $request)
    {

        $validator = Validator::make($request->all(), [
            "email" => "required"
        ]);


        if ($validator->fails()) {

            $allErrors = $validator->errors()->all();
            return redirect()->back()->with('error', $allErrors[0]);
        }

        $email = $request->input('email');

        $emailType = "u"; // u=unsubscribe


        
        /* Check if email already sent or not */
        $logs = "SELECT id from `ses_sns_email_list` where userId='" . trim($email) . "'";
        
        $sent = DB::select(DB::raw($logs));
        
        
        if (sizeof($sent) <= 0) {
            
            
            $logs = "INSERT INTO `ses_sns_email_list` (`id`, `userId`, `emailType`, `emailDate`) VALUES (NULL, '" . trim($email) . "', '" . $emailType . "', now())";
            
            DB::select(DB::raw($logs));
        }

        Mail::to($email)->send(new \App\Mail\UnsubscribeConfirmationMail($email));
        
        return redirect()->back()->with('success', 'You have unsubscribed successfully!');
    }
}
