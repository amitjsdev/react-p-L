<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use Illuminate\Support\Facades\Validator;
use App\OverallFeedback;

class OverallFeedbackController extends Controller
{
    
    function saveOverallFeedback(Request $request)
    {


        $overall_feedback =$request->post('overall_feedback');
        $practiceSetId =$request->post('practiceSetId');
        $email =$request->post('email');
        $data = DB::table('overall_feedback')->where('email', $email)
        ->where('practiceSetId',$practiceSetId)
        ->first();
        if(!$data){

            OverallFeedback::create($request->all());
        }
        // $data->update($request->all());

     $updated = DB::table('overall_feedback')
        ->where('email', $email)
        ->where('practiceSetId', $practiceSetId)
        ->update(['feedback' => $overall_feedback]);

        return response()->json($data);

        // $practiceSetId =$request->post('practiceSetId');
        // $overall_feedback =$request->post('overall_feedback');
        //     if(empty($overall_feedback)){
        //         return response()->json([
        //             "message" => "Overall feedback required!",
        //             "errors" => [
        //                 "overall_feedback" => [
        //                     "Overall feedback required!"
        //                 ]
        //             ]
        //         ], 422);
        //     }
        // $updated = DB::table('practice_sets')
        // ->where('practiceSetId', $practiceSetId)
        // ->update(['overall_feedback' => $overall_feedback]);

        // return response()->json([
        //     "message" => $updated
        // ]);
    }
}
