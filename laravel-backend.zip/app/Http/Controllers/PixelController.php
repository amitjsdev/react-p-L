<?php

namespace App\Http\Controllers;

use App\EmailLog;
use Illuminate\Http\Request;

class PixelController extends Controller
{
    public function fire(Request $request, String $uuid) {
        // get email log
        $emailLog = EmailLog::where('log_uuid', $uuid)->first();
        
        if($emailLog) {
            // log the pixel as opened
            $emailLog->emailOpened = true;
            $emailLog->save();
        }

        // return pixel
        return response()->download(storage_path('pixel.png'));
    }


    /**
     * to track ctaCLiked in email_logs
     *
     * @param Request $request
     * @param String $uuid
     * @return void
     */
    public function cta(Request $request, String $uuid)
    {
        // check if there is branchUrl?
        if(!$request->has('to') || empty($request->to)) {
            return response('Invalid Branch Link');
        }
        // get email log
        $emailLog = EmailLog::where('log_uuid', $uuid)->first();

        if ($emailLog) {
            // log the pixel as opened
            $emailLog->ctaClicked = true;
            $emailLog->save();
        }

        // redirect to branch url
        return response()->redirectTo($request->to);
    }
}
