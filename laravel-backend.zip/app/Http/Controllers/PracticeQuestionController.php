<?php

namespace App\Http\Controllers;

use App\PracticeQuestion;
use App\PracticeSet;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class PracticeQuestionController extends Controller
{
    /**
     * get all practice questions from a set
     *
     * @param Request $request
     * @return void
     */
    public function index(Request $request, $id)
    {
        if (!Session::has('admin') && !Session::has('marketing')) {
            return redirect('/admin-login');
        }

        $set = PracticeSet::where('practiceSetId', $id)->first();

        // get all cohorts
        $data = PracticeQuestion::where('practiceSetId', $id)->orderBy('practiceQuestionId')->get();

        // return view
        return view('admin.practice-question.practice-question-index', compact('set', 'data'));
    }
    /**
     * show create practice set view
     *
     * @param Request $request
     * @return void
     */
    public function createView(Request $request, $setId, $id = null)
    {
        if (!Session::has('admin') && !Session::has('marketing')) {
            return redirect('/admin-login');
        }

        $set = PracticeSet::where('practiceSetId', $setId)->first();

        $data = PracticeQuestion::where('practiceSetId', $setId)->where('practiceQuestionId', $id)->first();

        if (!$data) {
            $data = new PracticeQuestion();
        }

        // return view
        return view('admin.practice-question.practice-question-create', compact('set', 'data'));
    }
    /**
     * save question to practice set
     *
     * @param Request $request
     * @return void
     */
    public function saveQuestion(Request $request, $setId)
    {
        if (!Session::has('admin') && !Session::has('marketing')) {
            return redirect('/admin-login');
        }
        // validate the request
        $request->validate([
            "practiceQuestionId" => "nullable|numeric",
            "practiceSetId" => "nullable|exists:practice_sets,practiceSetId",
            "practiceSetQuestion" => "required|string",
            "practiceSetTip" => "nullable|string",
            "practiceQuestionText" => "nullable|string",
            "practiceSetDfficultyLevel" => "nullable|string",
        ]);

        $practice_question = PracticeQuestion::where('practiceSetId', $setId)->where('practiceQuestionId', $request->practiceQuestionId)->first();

        $isBeingCreated = false;

        // create the cohort if the id is empty
        if (!$practice_question) {
            $isBeingCreated = true;
            $practice_question = PracticeQuestion::create($request->all());
        } else {
            // update cohort elsewise
            $practice_question->update($request->all());
        }

        if ($isBeingCreated) {
            return redirect('/practice-sets/' . $setId . '/questions')->with('message', 'Practice set created successfully!');
        } else {
            return redirect('/practice-sets/' . $setId . '/questions')->with('message', 'Practice set updated successfully!');
        }
    }
}
