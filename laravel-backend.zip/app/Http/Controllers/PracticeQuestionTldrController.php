<?php

namespace App\Http\Controllers;

use App\PracticeQuestionTldr;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class PracticeQuestionTldrController extends Controller
{

    public function new(Request $request, $id, $questionId, $tldrId = null)
    {

        $videoTLDR = PracticeQuestionTldr::find($tldrId);

        if (!$videoTLDR) {
            $videoTLDR = new PracticeQuestionTldr();
            $videoTLDR->practiceSetId = $id;
            $videoTLDR->practiceQuestionId = $questionId;
        }

        return view('admin.practice-question.tldr-create', compact('videoTLDR'));
    }

    public function save(Request $request, $id, $questionId, $tldrId = null)
    {
        $tldr = PracticeQuestionTldr::find($tldrId);

        $validator = Validator::make($request->all(), [
            'practiceQuestionId' => 'required|exists:practice_questions',
            'practiceSetId' => 'required|exists:practice_questions',
            'title' => 'nullable|string',
            'description' => 'nullable|string',
        ]);


        if ($validator->fails()) {
            return redirect()->back()->with('error', $validator->errors()->all()[0]);
        }

        if ($tldr) {
            $tldr->update($validator->validated());
            return redirect()->back()->with('message', "TLDR updated with id " . $tldrId);
        } else {
            $tldr = PracticeQuestionTldr::create($validator->validated());
            return redirect()->back()->with('message', "TLDR Created with id " . $tldrId);
        }
    }
}
