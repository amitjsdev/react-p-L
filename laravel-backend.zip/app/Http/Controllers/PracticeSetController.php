<?php

namespace App\Http\Controllers;

use App\Cohort;
use App\Company;
use App\Employee;
use App\InterviewVideo;
use App\PracticeSet;
use App\CohortPracticeSet;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;

class PracticeSetController extends Controller
{
    /**
     * get all practice sets
     *
     * @param Request $request
     * @return void
     */
    public function index(Request $request)
    {
        if (!Session::has('admin') && !Session::has('marketing')) {
            return redirect('/admin-login');
        }
        // get all cohorts
       // $data = PracticeSet::whereNull('companyCode')->get();

        // return view
       // return view('admin.practice-set.practice-set-index', compact('data'));
    }
    /**
     * show create practice set view
     *
     * @param Request $request
     * @return void
     */
    public function createView(Request $request, $id = null)
    {
        if (!Session::has('admin') && !Session::has('marketing')) {
            return redirect('/admin-login');
        }

        $data = PracticeSet::find($id);

        if (!$data) {
            $data = new PracticeSet();
        }

        // return view
        return view('admin.practice-set.practice-set-create', compact('data'));
    }
    /**
     * save practice set
     *
     * @param Request $request
     * @return void
     */
    public function savePracticeSet(Request $request)
    {
        if (!Session::has('admin') && !Session::has('marketing')) {
            return redirect('/admin-login');
        }
        // validate the request
        $request->validate([
            "practiceSetId" => "required|numeric",
            "practiceSetName" => "required|string",
        ]);

        $practice_set = PracticeSet::find($request->practiceSetId);

        $isBeingCreated = false;

        // create the cohort if the id is empty
        if (!$practice_set) {
            $isBeingCreated = true;
            $practice_set = PracticeSet::create($request->all());
        } else {
            // update cohort elsewise
            $practice_set->update($request->all());
        }

        if ($isBeingCreated) {
            return redirect('/practice-sets')->with('message', 'Practice set created successfully!');
        } else {
            return redirect('/practice-sets')->with('message', 'Practice set updated successfully!');
        }
    }

    /**
     * Api to get all Available Practice Sets, to company user
     */
    public function getAllAvailablePracticeSets(Request $request)
    {
        // get userId
        $userId = auth()->user()->email;
        $employee = Employee::where('userId', $userId)->first();

        // get employee company 
        $company = Company::where('Id', $employee->CompanyCode)->first();

        // // get overall feedback 
        // $overall_feedback = DB::table('overall_feedback')->where('email', $userId)
        // ->first();

        // get practice sets for company code
        $practiceSetIds = array_filter(explode(',', $company->PracticeSets), function ($a) {
            return $a;
        });
        $CohortsIds =getUserCohortIds($userId);
        $activeCohortIds =Cohort::whereIn('id',$CohortsIds)->where('archived',false)->pluck('id');
        // get all practice sets with the user cohorts
        foreach (\App\CohortPracticeSet::whereIn("cohortId", $activeCohortIds)->get()->pluck("practiceSetId") as $practiceSetId) {
            array_push($practiceSetIds, $practiceSetId);
        }

        // get all cohorts
        $data = is_array($practiceSetIds) && count($practiceSetIds) > 0 ? PracticeSet::whereIn('practiceSetId', $practiceSetIds)
            ->get()->map(function ($value) use ($userId) {
                // get total lesson count
                $value->totalLessons = $value->questions()->count();
                // get attempted lesson count
                $value->completedLessons = InterviewVideo::where([
                    ['moduleNo', $value->practiceSetId],
                    ['userId', $userId],
                ])->distinct('lessonNo')->count();

                $value->cohortId = CohortPracticeSet::where([
                    ['practiceSetId', $value->practiceSetId],
                    ["cohortId", getUserCohortIds($userId)],
                ])->get()->pluck("cohortId");

                if ($value->completedLessons > 0) {
                    $value->firstVideo = InterviewVideo::where([
                        ['moduleNo', $value->practiceSetId],
                        ['userId', $userId],
                    ])->oldest()->first()->created_at;
                }
                
            // get overall feedback 
            $value->overall_feedback = DB::table('overall_feedback')->where('email', $userId)
            ->where('practiceSetId',$value->practiceSetId)->first();
                return $value;
            }) : [];

        return response()->json([
            "companyCode" => $employee->CompanyCode,
            "companyName" => $employee->companyRecord->Name,
            "practiceSets" => $data,
            "CohortsIds" => $CohortsIds,
            // "overall_feedback" => $overall_feedback
        ]);
    }



    /**
     * Get a compact list of all the lesson in a module
     */
    public function questionBySetCompact(Request $request, $id)
    {
        $practice_set = PracticeSet::where('practiceSetId', $id)->first();

        if (!$practice_set) {
            return response()->json([
                "message" => "Practice set not found!"
            ]);
        }
        $cohort =null;
        $userId = auth()->user()->email;
        try {
            $cohort = CohortPracticeSet::where([
                ['practiceSetId', $id],
                ["cohortId", getUserCohortIds($userId)],
            ])->with('cohort')->first();

        } catch (\Throwable $th){
            \Log::error("unable to get CohortPracticeSet", $th->getMessage());
        }
       

        

        $practice_set_questions = $practice_set->questions()->orderBy('practiceQuestionId')->get()->map(function ($question) use ($userId) {
            $question->long_description = $question->practiceSetQuestion;
            $question->routeno = 0;
            $question->lesson_no = $question->practiceQuestionId;

            $question->completed = \App\InterviewVideo::where([
                ['moduleNo', $question->practiceSetId],
                ['routeNo', 0],
                ['lessonNo', $question->practiceQuestionId],
                ['userId', $userId],
            ])->exists();

            $question->tldrs = \App\PracticeQuestionTldr::select(['title', 'description'])
                ->where([
                    ['practiceSetId', $question->practiceSetId],
                    ['practiceQuestionId', $question->practiceQuestionId],
                ])->get();
            return $question;
        });

        return response()->json([
            "moduleNo" => $id,
            "cohort"=>$cohort,
            "module" => $practice_set->practiceSetName,
            "lessons" => $practice_set_questions
        ]);
    }
}
