<?php

namespace App\Http\Controllers;

use App\Module;
use App\Program;
use App\ProgramModule;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class ProgramController extends Controller
{

    public function index(Request $request)
    {
        if (!Session::has('admin') && !Session::has('marketing')) {
            return redirect('/admin-login');
        }
        // get all programs
        $programs = Program::all();

        // return view
        return view('admin.programs.program-index', compact('programs'));
    }


    /**
     * show create view
     *
     * @param Request $request
     * @return void
     */
    public function createView(Request $request, $id = null)
    {
        if (!Session::has('admin') && !Session::has('marketing')) {
            return redirect('/admin-login');
        }
        // get all modules
        $modules = Module::all();

        $program = Program::find($id);

        $programModules = [];

        if (!$program) {
            $program = new Program();
        } else {
            $programModules = $program->modules()->orderBy('level_number')->orderBy('sort_order')->get();
        }

        // return view
        return view('admin.programs.program-create', compact(
            'modules',
            'programModules',
            'program'
        ));
    }

    /**
     * save program
     *
     * @param Request $request
     * @return void
     */
    public function saveProgram(Request $request)
    {
        if (!Session::has('admin') && !Session::has('marketing')) {
            return redirect('/admin-login');
        }
        // validate the request
        $request->validate([
            "id" => "nullable|exists:programs,id",
            "name" => "required|string"
        ]);

        $program = Program::find($request->id);

        // create the cohort if the id is empty
        if (!$program) {
            $program = Program::create([
                "name" => $request->name
            ]);
        } else {
            // or update if need be
            $program->update([
                "name" => $request->name
            ]);
        }

        // delete all modules that are not in new list
        ProgramModule::where("program_id", $program->id)
            ->whereNotIn('module_number', $request->module_number)->delete();

        // add the program modules or update existing
        foreach ($request->level_number as $index => $level_number) {
            ProgramModule::updateOrCreate([
                "program_id" => $program->id,
                "module_number" => $request->module_number[$index],
            ], [
                "level_number" => $level_number,
                "sort_order" => $request->sort_order[$index],
            ]);
        }

        if (isset($request->id)) {
            return redirect('/programs')->with('message', 'Program updated successfully!');
        } else {
            return redirect('/programs')->with('message', 'Program created successfully!');
        }
    }

    /**
     * Delete the program
     *
     * @param Request $request
     * @param [type] $id
     * @return void
     */
    public function deleteProgram(Request $request, $id)
    {
        if (!Session::has('admin') && !Session::has('marketing')) {
            return redirect('/admin-login');
        }

        $program = Program::find($id);

        if (!$program) {
            return redirect()->back()->with('error', 'Program not found!!');
        }

        $program->delete();

        // delete program modules
        ProgramModule::where('program_id', $program->id)->delete();

        return redirect()->back()->with('message', 'Program deleted!');
    }

    /**
     * Get all users for program
     *
     * @param Request $request
     * @param integer $company_code
     * @param integer $program_id
     * @return void
     */
    function getUserForProgram(Request $request, $company_code = 0, $program_id = 1)
    {

        // get program
        $program = Program::with('modules')->find($program_id);

        if (!$program) {
            return response()->json([
                "message" => "Program not found!"
            ], 400);
        }

        // get all users for this program
        $employees = $program->employees()->where('CompanyCode', $company_code)->get();

        // for all employees get their level
        foreach ($employees as $employee) {
            //
            $employee->level = getEmployeeLevelForProgram($employee->userId, $program_id);
        }

        return response()->json([
            'program' => $program->withStructure,
            'employees' => $employees->map(function ($employee) {
                return [
                    'FirstName' => $employee->FirstName,
                    'LastName' => $employee->LastName,
                    'CompanyCode' => $employee->CompanyCode,
                    'userId' => $employee->userId,
                    'level' => $employee->level
                ];
            })
        ]);
    }

    /**
     * Get program for user by userId
     *
     * @param Request $request
     * @param [type] $program_id
     * @param [type] $userId
     * @return void
     */
    function getProgramForUserById(Request $request, $program_id, $userId)
    {
        $program = \App\Program::find($program_id);

        $levels = [];
        // get all modules and make levels
        foreach ($program->modules as $module) {
            // check if level array there, create if not
            if (!isset($levels[$module->level_number])) {
                $levels[$module->level_number] = [];
            }
            // check if certification available
            $courseNo = getCourseNoFromModuleNo($module->module_number, $userId);
            $module->course_number = $courseNo;
            $module->moduleName = $module->module ? $module->module->description : null;
            $module->completed = getCertificateIfExists($userId, $courseNo) ? true : false;
            unset($module->module);
            // add to level
            $levels[$module->level_number][] = $module;
        }
        $program->levels = $levels;
        unset($program->modules);
        return $program;

        return response()->json([
            "message" => "Program detail for user",
            "program" => $program
        ]);
    }

    /**
     * Get programs for auth user
     *
     * @param Request $request
     * @return void
     */
    function getProgramsForUser(Request $request)
    {
        $user = User::with('programs.modules')
            ->where('email', $request->user()->email)
            ->first();
        $programs = $user->programs;

        $userId = $user->email;

        $programs = $programs->map(function ($program) use ($userId) {
            $levels = [];
            // get all modules and make levels
            foreach ($program->modules as $module) {
                // check if level array there, create if not
                if (!isset($levels[$module->level_number])) {
                    $levels[$module->level_number] = [];
                }
                // check if certification available
                $courseNo = getCourseNoFromModuleNo($module->module_number, $userId);
                $module->course_number = $courseNo;
                $module->description = $module->module ? $module->module->description : null;
                $module->long_description = $module->module ? $module->module->long_description : null;
                $module->totalLessons = getLessonCountForModule($module->module_number);
                $module->completed = getCertificateIfExists($userId, $courseNo) ? true : false;
                unset($module->module);
                // add to level
                $levels[$module->level_number][] = $module;
            }

            // restructure the level
            $levels = array_values(array_map(function ($modules) {
                return [
                    "level_number" => $modules[0]->level_number,
                    "modules" => $modules
                ];
            }, $levels));


            $program->levels = $levels;
            unset($program->modules);
            return $program;
        });

        return response()->json([
            "message" => "Programs",
            "programs" => $programs
        ]);
    }

    /**
     * get groups programs
     *
     * @return void
     */
    function getGroupsPrograms()
    {
        // get all programs
        $programs = Program::all();
        $types = \App\CohortType::all();
        // return response
        return response()->json([
            "programs" => $programs,
            "types" => $types
        ]);
    }
}
