<?php

namespace App\Http\Controllers;

use App\Employee;
use App\Http\Resources\V2ExerciseResource;
use App\Program;
use App\ProgramPlacementExerciseLog;
use App\ProgramPlacementLog;
use App\ProgramPlacementTestResult;
use App\RoundExerciseLog;
use App\V2Exercise;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator as IlluminateValidator;
use Illuminate\Validation\Validator;

class ProgramPlacementController extends Controller
{


    /**
     * For fetching the exercises using programId in request
     *
     * @param Request $request
     * @return void
     */
    public function fetch(Request $request)
    {
        $validator = IlluminateValidator::make($request->all(), [
            "programId" => "required|numeric|exists:programs,id",
        ]);

        // typecast lesson no so that wrong comparision does not happen
        $request->programId = (int) $request->programId;

        if ($validator->fails()) {
            return response()->json(["message" => "Bad request!", "errors" => $validator->errors()], 400);
        }

        // get program
        $program = Program::find($request->programId);

        // get program modules
        $modules = $program->modules->map(function($pm) {
            return $pm->module->moduleno;
        });

        $moduleCount = $modules->count();

        if(!$moduleCount) {
            return response()->json(["message" => "Bad request!", "errors" => [
                "programId" => "Program doesnt have any modules!"
            ]], 400);
        }

        $exerciseCountPerModule = (int) round(40 / $moduleCount);

        // check roundNo for this programId and userId combo
        $userId = auth()->user()->email;
        $exercises = collect([]);
        $challengeExceptions = [
            'informational',
            'mini_lesson_1',
            'mini_lesson_2',
            'mini_lesson_3',
            'voice_recognition',
            'select_correct_translation',
            'tap_the_pair',
            'tap_the_pair_sentences'
        ];


        // foreach module get exerciseCountPerModule exercises
        foreach($modules as $moduleNo) {
            $exs = V2Exercise::whereNotIn('exerciseType', $challengeExceptions)->where("moduleNo", $moduleNo)->where('status', 1)->inRandomOrder()->limit($exerciseCountPerModule)->get();
            foreach($exs as $ex) {
                $exercises->push($ex);
            }
        }

        $roundNo = ProgramPlacementLog::where('userId', $userId)
            ->where("programId", $request->programId)
            ->count(); // add one to the last count
        // create roundLog for new record
        $roundLog = ProgramPlacementLog::create([
            "userId" => $userId,
            "roundNo" => $roundNo,
            "programId" => $request->programId,
            "status" => -1,
        ]);
        // get employee
        $employee = Employee::where('userId', $userId)->first();
        // create log for each exercise
        foreach ($exercises as $exercise) {
            ProgramPlacementExerciseLog::create([
                "userId" => $userId,
                "programId" => $request->programId,
                "mobileOS" => $employee->mobileOS,
                "roundLogId" => $roundLog->id,
                "questionId" => $exercise->id,
                "status" => -1,
                "type" => $exercise->exerciseType,
                "additionalInfo" => null,
            ]);
        }

        return response()->json(V2ExerciseResource::collection($exercises));
    }

    /**
     * Save placement test result
     *
     * @param Request $request
     * @return void
     */
    public function savePlacementTestResult(Request $request)
    {
        $userId = auth()->user()->email;

        // check the database to see if the combo exists (no need to see last combo for sake of simplicity)
        $placementLog = ProgramPlacementLog::where('userId', $userId)
            ->where("programId", $request->programId)
            ->orderBy('roundNo', "desc")
            ->first();
        if (!$placementLog) {
            return response()->json([
                "message" => "Invalid Request",
                "type" => "placement-log:log-not-found",
                "request" => $request->all()
            ], 400);
        }
        if ((int) $placementLog->status === -1) {
            // get v2 exercise for this MRL, and save roundLog
            $placementLog->status = $request->status;
            $placementLog->mistakesMade = $request->mistakesMade;
            $placementLog->additionalLivesClaimed = $request->additionalLivesClaimed;
            $placementLog->save();
            $placementLogExercise = [];
            // save every exrcise too
            foreach ($request->questions as $question) {
                $failCount = isset($question["failCount"]) ? $question["failCount"] : 0;
                // not verifying the existance of record with that question id for sake of simplicity
                if (isset($question["questionId"])) {
                    $placementLogExercise[$question["questionId"]] = ProgramPlacementExerciseLog::where('roundLogId', $placementLog->id)
                        ->where('questionId', $question["questionId"])
                        ->update([
                            "status" => isset($question["status"]) ? $question["status"] : -1,
                            "additionalInfo" => isset($question["additionalInfo"]) ? $question["additionalInfo"] : "",
                            "failCount" => $failCount
                        ]);
                } else {
                    $placementLogExercise[$question["questionId"]] = -1;
                }
            }

            // paused
            // GeneratePlacementTestReportForUser::dispatch($placementLog->id);

            // create result
            ProgramPlacementTestResult::create([
                'userId' => $userId,
                'programId' => $request->programId,
                'placementScore' => $request->placementScore
            ]);

            return response()->json([
                "message" => "Test Result Saved!",
                "request" => $request->all(),
                "placementLog" => $placementLog,
                "placementLogExercise" => $placementLogExercise
            ]);
        } else {
            return response()->json([
                "message" => "Invalid Request",
                "type" => "placement-log:status-not-(-1)",
                "request" => $request->all()
            ], 400);
        }
    }
}
