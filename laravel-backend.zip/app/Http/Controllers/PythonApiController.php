<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PythonApiController extends Controller
{
    function pythonApiCall(Request $request)
    {
        $output = shell_exec('python3.7 /home/ubuntu/speech-scoring/score.py -l "https://langappnew.s3.amazonaws.com/uploads/interviewprep/userUploads/21631/300_0_2/attempt/2/7062225_UserAttempt.webm"');
        $output2 = shell_exec('ls -lart');

        return response()->json([
            "done" => $output,
            "output2"=>$output2
        ]);
    }
}
