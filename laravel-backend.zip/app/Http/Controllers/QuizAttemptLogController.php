<?php

namespace App\Http\Controllers;

use App\Cohort;
use App\Http\Resources\AttemptLogResource;
use App\Jobs\ProcessQuizAttemptVideoWithAIScript;
use App\Jobs\CombinesQuizAttemptVideos;
use App\Jobs\MarkCompleteS3MultipartUploadFixedM;
use App\Jobs\SendProfileUpdateReminderEmailJob;
use App\QuizAttemptLog;
use App\QuizSetQuestion;
use Illuminate\Http\Request;
use App\Mail\TestAttemptConfirm;
class QuizAttemptLogController extends Controller
{

    public function createAttempt(Request $request, $quizSetId)
    {
        // get userId
        $userId = auth()->user()->email;
        // get employee
        $employee = \App\Employee::where('userId', $userId)->first();
        // get company code
        $companyCode = $employee->CompanyCode;

        // get the quiz set for this company code
        $quizSet = \App\QuizSet::where('companyCode', $companyCode)
            ->where('quizSetId', $quizSetId)
            ->first();

        if (!$quizSet) {
            return response()->json([
                "message" => "Quiz not found!"
            ], 404);
        }

        // get the attempt no.

        $attemptNo = QuizAttemptLog::where([
            'userId' => $userId,
            'quizSetId' => $quizSetId,
        ])->count() + 1;

        // create attempt log record
        if(!$quizSet->cohortId){
        $cohortId = \App\Course::distinct('cohort_id')
            ->join('employeecourse', 'courses.courseNumber', '=', 'employeecourse.courseNumber')
            ->whereNotNull('cohort_id')
            ->where('userId', $userId)
            ->pluck("cohort_id");
        $cohortId = $cohortId && $cohortId[0] ? $cohortId[0] : '';
        } else {
           $cohortId = $quizSet->cohortId;
        }
        $cohort =Cohort::find($cohortId);
        $updateArr =[
            'userId' => $userId,
            'quizSetId' => $quizSetId,
            'attemptNumber' => $attemptNo,
            'cohortId' => $cohortId,
            'attemptStatus' => 0,
            'answerJSON' => json_encode('')
        ];
        if($request->post('streamId')){
            $updateArr['streamId']=$request->post('streamId');
        }
        // return response()->json($updateArr);
        $attempt = QuizAttemptLog::create($updateArr);
        $allotedTime =$cohort->allotted_time;
        //CombinesQuizAttemptVideos::dispatch($attempt->id)->delay(now()->addMinutes($allotedTime+15));
        MarkCompleteS3MultipartUploadFixedM::dispatch($attempt->id)->delay(now()->addMinutes($allotedTime+15))->onQueue('high');
        return response()->json([
            'message' => 'Attempt created!',
            'attempt' => $attempt,
            'cohortId' => $cohortId
        ]);
    }



    public function checkMultiDevice(Request $request)
    {
        // get userId
        $userId = auth()->user()->email;
        $quizSetId = $request->post('id');
        if(!$quizSetId){
            return response()->json([]);
        }
        // get employee
        $employee = \App\Employee::where('userId', $userId)->first();
        // get company code
        $companyCode = $employee->CompanyCode;

        // get the quiz set for this company code
        $quizSet = \App\QuizSet::where('companyCode', $companyCode)
            ->where('quizSetId', $quizSetId)
            ->first();

        if (!$quizSet) {
            return response()->json([
                "message" => "Quiz not found!"
            ], 404);
        }

        // create attempt log record
        if(!$quizSet->cohortId){
        $cohortId = \App\Course::distinct('cohort_id')
            ->join('employeecourse', 'courses.courseNumber', '=', 'employeecourse.courseNumber')
            ->whereNotNull('cohort_id')
            ->where('userId', $userId)
            ->pluck("cohort_id");
        $cohortId = $cohortId && $cohortId[0] ? $cohortId[0] : '';
        } else {
           $cohortId = $quizSet->cohortId;
        }

        $updateArr =[
            'userId' => $userId,
            'quizSetId' => $quizSetId,
            'cohortId' => $cohortId,
        ];
        // return response()->json($updateArr);
        $attempt = QuizAttemptLog::where($updateArr)->latest()->first();
        if($attempt && !$attempt->allowedReattempt){
            return response()->json([
                'status' => false,
                'attempt' => $attempt,
                'data' => 'multi test detected'
            ]);
        }
        return response()->json([
            'status' => true,
            'attempt' => $attempt,
        ]);

    }

    public function saveAttempt(Request $request, $quizSetId, $attemptNo)
    {

        // get the attempt payload
        // $request->validate([
        //     "answers" => "required|array|min:1",
        //     "answers.*.quizSetQuestionId" => "required",
        //     "answers.*.selectedAnswer" => "nullable",
        // ]);

        // get userId
        $userId = auth()->user()->email;
        // get employee
        $employee = \App\Employee::where('userId', $userId)->first();
        // get company code
        $companyCode = $employee->CompanyCode;

        // get the quiz set for this company code
        $quizSet = \App\QuizSet::where('companyCode', $companyCode)
            ->where('quizSetId', $quizSetId)
            ->with('cohort')
            ->first();

        if (!$quizSet) {
            return response()->json([
                "message" => "Quiz not found!"
            ], 404);
        }

        //get the attempt


        // get user answer from payload
        $userAnswers = $request->post('answers');
        // if(!$userAnswers){
        //     return \response()->json(['status'=>false,$userAnswers]);
        // }

        // better answer log
        $correctedAnswerLog = [];

        foreach ($userAnswers as $userAnswer) {
            // get the question from db
            $quizQuestion = QuizSetQuestion::where('quizSetId', $quizSetId)
                ->where('quizSetQuestionId', $userAnswer['quizSetQuestionId'])
                ->first();
            if ($quizQuestion) {
                // if we have a quiz question check if we also have the correct answer

                $correctAnswer =$quizQuestion->questionType==3 ? '' : $this->getCorrectAnswerFromOptionChoices($quizQuestion->optionChoices);

                // log the answer
                array_push($correctedAnswerLog, [
                    'quizSetQuestionId' => $quizQuestion->quizSetQuestionId,
                    'quizSetId' => $quizQuestion->quizSetId,
                    'difficultyLevel' => $quizQuestion->difficultyLevel,
                    'selectedAnswer' => $userAnswer['selectedAnswer'],
                    'correctAnswer' => $correctAnswer,
                    'isAnswerCorrect' => $correctAnswer === $userAnswer['selectedAnswer'],
                ]);
            }
        }
        $user = \Auth::user();
        if(!$quizSet->cohortId){
        $cohort_ids = \App\Course::distinct('cohort_id')
            ->join('employeecourse', 'courses.courseNumber', '=', 'employeecourse.courseNumber')
            ->whereNotNull('cohort_id')
            ->where('userId', $user->email)
            ->pluck("cohort_id");
        $cohortId = $cohort_ids && $cohort_ids[0] ? $cohort_ids[0] : '';
        } else {
            $cohortId =$quizSet->cohortId;
        }
        // update attempt log record
        $isCompleted =$request->post('isCompleted');
        $aiTimer =$request->post('aiTimer');
        $reasonIncomplete =$request->post('reasonIncomplete')? $request->post('reasonIncomplete'): null;
        $toUpdate =[];
        if($reasonIncomplete !=null){
            $toUpdate['reasonIncomplete']=$reasonIncomplete;
        }
        if($aiTimer !=null){
            $toUpdate['ai_result']=$aiTimer;
        }
        if($isCompleted !=null){
            $toUpdate['attemptStatus']=$isCompleted;
        }
        $toUpdate['answerJSON'] =json_encode($correctedAnswerLog);
        $attempt = QuizAttemptLog::updateOrCreate([
            'userId' => $userId,
            'attemptNumber' => $attemptNo,
            'quizSetId' => $quizSetId,
            'cohortId'=>$cohortId
        ],$toUpdate
        );

        // if quiz-proctored set up a Profile update job after 15mins
        if ($quizSet->cohort && $quizSet->cohort->type_id==2 && $isCompleted) {
            // check if already triggered
            if(!QuizAttemptLog::where([
                'userId' => $userId,
                'triggeredProfileEmail' => true
            ])->exists()) {
                if($quizSet->cohort->profile_questionnaire){
                SendProfileUpdateReminderEmailJob::dispatch($userId)->delay(now()->addMinutes(15));
                $attempt->triggeredProfileEmail = true;
                $attempt->save();
            }
            }
        }

        return response()->json([
            'message' => 'Attempt saved!',
            'attempt' => $attempt
        ]);
    }

    public function saveAttemptVideo(Request $request, $quizSetId, $attemptNo)
    {
        if (!$request->file('video')) {
            return response()->json([
                "message" => "video file not found!"
            ], 404);
        }
        // get userId
        $userId = auth()->user()->email;
        // get employee
        $employee = \App\Employee::where('userId', $userId)->with('company')->first();
        // get company code
        $companyCode = $employee->CompanyCode;
        $company = \App\Company::where('Id',$companyCode)->first();

        // get the quiz set for this company code
        $quizSet = \App\QuizSet::where('companyCode', $companyCode)
            ->where('quizSetId', $quizSetId)
            ->first();
        $cohort =$quizSet->cohort;
        $typeTwo =$cohort->type_id==2;


        if (!$quizSet) {
            return response()->json([
                "message" => "Quiz not found!"
            ], 404);
        }

        //get the attempt
        $attempt = QuizAttemptLog::where([
            'userId' => $userId,
            'attemptNumber' => $attemptNo,
            'quizSetId' => $quizSetId,
        ])
            ->whereNull('proctoredVideo')
            ->first();

        // save the video as well, if available

        if ($video = $request->file('video')) {
            $mrl = $employee->i_d . "_" . $quizSetId . "_" . $attemptNo;

            // generate the dir for s3
            $dir = 'proctored-exam-videos';

            // upload to s3
            uploadToS3Exact($dir, $video->getPathname(), $mrl . ".webm"); // mrl creates the file name
        }

        $attempt->proctoredVideo = $dir . "/" . $mrl . ".webm";
        $attempt->ai_result = $request->post('aiTimer');

        $attempt->save();

        // dispatch the job for ai processing
        // if(!$typeTwo){
        //     ProcessQuizAttemptVideoWithAIScript::dispatch($attempt->id);
        // }

        // $FirstName,  $cohortName, $companyTeam, $company,$senderEmail, $sender
        \Mail::to($employee->userId)
        ->send(new TestAttemptConfirm(
            $employee->FirstName,
            $cohort->name,
            $company->Name,
            $company->Id,
            $cohort->senderEmail,
            $company->Name

        ));

        return response()->json([
            "message" => $attempt->proctoredVideo,
            "video" => $video->getPathname()
        ]);
    }

    public function getPreviousAttemptsForAQuizId(Request $request, $quizSetId)
    {
        // get userId
        $userId = auth()->user()->email;
        // get employee
        $employee = \App\Employee::where('userId', $userId)->first();
        // get company code
        $companyCode = $employee->CompanyCode;

        // get the quiz set for this company code
        $quizSet = \App\QuizSet::where('companyCode', $companyCode)
            ->where('quizSetId', $quizSetId)
            ->first();

        if (!$quizSet) {
            return response()->json([
                "message" => "Quiz not found!"
            ], 404);
        }

        //get the attempt
        $attempts = QuizAttemptLog::where([
            'userId' => $userId,
            'quizSetId' => $quizSetId,
        ])
            // ->where('attemptStatus', 1)
            ->get();

        // return the attempts
        return response()->json([
            'message' => 'Attempts list!',
            'quizSet' => $quizSet,
            'attempts' => AttemptLogResource::collection($attempts)
        ]);
    }

    public function getCorrectAnswerFromOptionChoices(string $optionChoices)
    {
        $choiceArray = array_map(function ($choice) {
            // trim white space
            return trim($choice);
        }, explode(" ^&^ ", $optionChoices));
        // first is the answer
        return $choiceArray[0];
    }
}
