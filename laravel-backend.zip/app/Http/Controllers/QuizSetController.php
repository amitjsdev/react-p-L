<?php

namespace App\Http\Controllers;
namespace App\Http\Controllers;

use App\AttemptTimer;
use App\Employee;
use App\EmployeeCourse;
use App\Http\Resources\QuizSetResource;
use App\QuizSet;
use App\QuizSetQuestion;
use Illuminate\Http\Request;

class QuizSetController extends Controller
{
    function getQuizAssignedToUser(Request $request)
    {
        // get userId
        $userId = auth()->user()->email;
        // get employee
        $employee = Employee::where('userId', $userId)->first();
        // get company code
        $companyCode = $employee->CompanyCode;

		$EmployeeCourseNumber = EmployeeCourse::
		where('userId', $userId)->get()->pluck('courseNumber');

		$EmployeeCourseCohort = \App\Course::
		whereIn('courseNumber', $EmployeeCourseNumber)->get()->pluck('cohort_id');

		$cohort_id = $EmployeeCourseCohort;

        // get the quiz sets for this company code
        $quizSets = QuizSet::where('companyCode', $companyCode) ->where('archive', 0)->whereIn('cohortId',$cohort_id)
		->with(['cohort'=> function($q) use($cohort_id) {
			// Query the name field in status table
			$q->whereIn('id', $cohort_id); // '=' is optional
		}])
        ->get()->map(function ($set) use ($userId) {
            // check if we have progression on these
            $set->hasProgression = \App\QuizAttemptLog::where([
                'userId' => $userId,
                'quizSetId' => $set->quizSetId,
            ])
                ->exists();

            // check if it is complete
            $set->quizCompleted = false;
            if ($set->cohort && $set->cohort->type_id ==2) {

                    $attempt =\App\QuizAttemptLog::where([
                        'userId' => $userId,
                        'quizSetId' => $set->quizSetId,
                    ])->latest()->first();
                $timer =null;

                // allowedReattempt == 3 // Start over
                // allowedReattempt == 2 //Resume
                // allowedReattempt == 1 //unblocked
                // allowedReattempt == 0 //blocked
                $timer =null;
                $set->allowedReattempt =$attempt ? $attempt->allowedReattempt  :0 ;
                $set->allowedReattemptStatus ='Start';
                $set->quizCompleted = $attempt? $attempt->attemptStatus: 0;
                $set->attempt =$attempt;
                if($attempt){
                    if($attempt->allowedReattempt==1){
                        $set->allowedReattemptStatus ='Incomplete';
                    } else if($attempt->allowedReattempt==2){
                        $set->allowedReattemptStatus ='Resume';
                    } else if($attempt->allowedReattempt==3){
                        $set->allowedReattemptStatus ='Start Over';
                    }
                }
                if($set->allowedReattempt ==2 && $attempt){
                    $timer =AttemptTimer::where('quizSetId', $attempt->id) ->where('userId', $attempt->userId)->latest()->first();
                    $set->attempt->timer =$timer;
                }
                $set->time  = $timer ? $timer->time: $set->cohort->allotted_time*60;
                $set->time  = floor($set->time /60);
            }

            $set->profileCompleted = \App\Resume::where('userId', $userId)
                ->where('proctoredResume', true)
                ->exists();

            return $set;
        });

        // return the quiz sets
        return response()->json([
            "message" => "Quiz Sets",
            "companyCode" => $companyCode,
            "pan"=>$employee->DNI,
            "quizSets" => QuizSetResource::collection($quizSets)
        ]);
    }

    function updatePAN(Request $request){
        $userId = auth()->user()->email;
        // check pan number duplicate
		$data_duplicate = Employee::where('DNI',$request->post('pan'))->count();
		if($data_duplicate > 0){
			 return response()->json([
				"status"=>0
			]);
		}else{
			// get employee
			 $employee = Employee::where('userId', $userId)->update(['DNI'=>$request->post('pan')]);
		}

        return response()->json([
            "status"=>$employee
        ]);
    }
    function getQuizQuestionsAssignedToUser(Request $request, $quizSetId)
    {

        // get userId
        $userId = auth()->user()->email;
        // get employee
        $employee = Employee::where('userId', $userId)->first();
        // get company code
        $companyCode = $employee->CompanyCode;

        // get the quiz set for this company code
        $quizSet = QuizSet::where('companyCode', $companyCode)
            ->with('cohort')
            ->where('quizSetId', $quizSetId)
            ->first();

        if (!$quizSet) {
            return response()->json([
                "message" => "Quiz not found!"
            ], 404);
        }

        if ($quizSet->cohort && $quizSet->cohort->type_id ==2) {

            $attempt =\App\QuizAttemptLog::where([
                'userId' => $userId,
                'quizSetId' => $quizSet->quizSetId,
            ])->latest()->first();
        $timer =null;

        // allowedReattempt == 3 // Start over
        // allowedReattempt == 2 //Resume
        // allowedReattempt == 1 //unblocked
        // allowedReattempt == 0 //blocked
        $timer =null;
        $quizSet->allowedReattempt =$attempt ? $attempt->allowedReattempt  :0 ;
        $quizSet->allowedReattemptStatus ='Start';
        $quizSet->attempt =$attempt;
        if($attempt){
            if($attempt->allowedReattempt==1){
                $quizSet->allowedReattemptStatus ='Incomplete';
            } else if($attempt->allowedReattempt==2){
                $quizSet->allowedReattemptStatus ='Resume';
            } else if($attempt->allowedReattempt==3){
                $quizSet->allowedReattemptStatus ='Start Over';
            }
        }
        if($quizSet->allowedReattempt ==2 && $attempt){
            $timer =AttemptTimer::where('quizSetId', $attempt->id) ->where('userId', $attempt->userId)->latest()->first();
            $quizSet->attempt->timer =$timer;
            $quizSet->answer =$attempt->answerJSON;
        }
        $quizSet->time  = $timer ? $timer->time: $quizSet->cohort->allotted_time*60;
        $quizSet->time  = floor($quizSet->time /60);
    }


        // check if quiz is proctored
        // if ($quizSet->cohort && $quizSet->cohort->type_id ==2 ) {
        //     // check if the quiz has progression
        //     $hasProgression = \App\QuizAttemptLog::where([
        //         'userId' => $userId,
        //         'quizSetId' => $quizSetId,
        //     ])
        //         ->whereIn('attemptStatus', [0, 1])
        //         ->whereNotIn('allowedReattempt', [1])
        //         ->exists();
        //     // if has progression, dont send test
        //     if ($hasProgression) {
        //         return response()->json([
        //             "message" => "Test already attempted!"
        //         ], 400);
        //     }
        // }

        // get all the quiz questions
        $questions = QuizSetQuestion::where('quizSetId', $quizSetId)->get();

        // return questions
        return response()->json([
            "message" => "Quiz set questions",
            "quizSetId" => $quizSetId,
            "quizSet" => new QuizSetResource($quizSet),
            "questions" => $questions
        ]);
    }
}
