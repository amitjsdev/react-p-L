<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\QuizSetQuestion;
use App\Auth;

class QuizSetsQuestionsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $quizSetId =$request->get('quizSetId');
        $sets =QuizSetQuestion::where('quizSetId',$quizSetId)->get();
        return \response()->json($sets);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $questionId = QuizSetQuestion::max('quizSetQuestionId');
        $postedData =$request->post();
        $postedData['quizSetQuestionId']=(int)$questionId+1;
        $sets =QuizSetQuestion::create($postedData);
        return \response()->json($sets);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $sets =QuizSetQuestion::find($id);

        return \response()->json($sets);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $sets =QuizSetQuestion::find($id);
        return \response()->json($sets);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $sets =QuizSetQuestion::where('id',$id)->update($request->post());
        return \response()->json($sets);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $sets =QuizSetQuestion::destroy($id);
        return \response()->json($sets);
    }
}
