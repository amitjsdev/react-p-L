<?php

namespace App\Http\Controllers;

use App\Cohort;
use App\Course;
use App\Employee;
use App\Lesson;
use App\PlacementExerciseLog;
use App\PlacementLog;
use App\RoundExerciseLog;
use App\RoundLog;
use App\UserTimeLog;
use Carbon\Carbon;
use Illuminate\Http\Request;

class ReportController extends Controller
{
    // various categories
    public static $exercise_categories = [
        "Concept 1",
        "Listening",
        "Concept 2",
        "Speaking",
    ];

    // the relation of exercise type to category
    public static $exercise_categories_relation = [
        'translate_sentence' => "Concept 1",
        'tap_what_you_hear' => "Listening",
        'multiple_choice' => "Concept 1",
        'voice_recognition' => "Speaking",
        '3_pair_of_words' => "Concept 1",
        'tap_words_to_complete_dialog' => "Concept 1",
        'tap_letters_to_complete_word' => "Concept 1",
        'tap_the_pair' => "Concept 1",
        'tap_the_pair_sentences' => "Concept 1",
        'mini_lesson_1' => "Concept 2",
        'mini_lesson_2' => "Concept 2",
        'select_missing_word' => "Concept 1",
        'mini_lesson_3' => "Concept 2",
        'select_correct_translation' => "Concept 1",
        'how_do_you_say' => "Concept 1",
        'pick_correct_type' => "Concept 1",
    ];

    // get users mistakes for a cohort
    public function userMistakes(Request $request, $cohort_id)
    {
        // get cohort for which data is to be seen
        $cohort = Cohort::find($cohort_id);

        if (!$cohort) {
            return response()->json([
                "message" => "Cohort not found!"
            ]);
        }

        // get date for which data is needed
        $date = $request->date ? Carbon::parse($request->date)->startOfDay() : Carbon::now()->subYear()->startOfDay();
        $end_date = Carbon::parse($request->end_date)->endOfDay();

        // get the module numbers in cohort
        $moduleNos = $cohort->program->modules->map(function ($m) {
            return $m->module->moduleno;
        });

        // get users for the the cohort
        $userData = Course::join('employeecourse', 'courses.courseNumber', '=', 'employeecourse.courseNumber')
            ->join('employee', 'employee.userId', '=', 'employeecourse.userId')
            ->distinct('employeecourse.userId')
            ->whereIn('moduleNumber', $moduleNos)
            ->whereNotNull('employeecourse.userId')
            ->where('employeecourse.userId', '!=', "")
            ->select('employeecourse.userId', 'FirstName', 'LastName', 'employee.totalScore', 'employee.last_lesson')
            ->where('employee.CompanyCode', $cohort->company_code)
            ->where('cohort_id', $cohort->id)
            ->get();

        // userNmaes
        $userNames = [];
        $totalScore = [];
        $lastLesson = [];

        foreach ($userData as $user) {
            $userNames[$user->userId] = trim($user->FirstName . " " . $user->LastName);
            $totalScore[$user->userId] = $user->totalScore;
            $lastLesson[$user->userId] = $user->last_lesson;
        }

        $userIds = $userData->map(function ($u) {
            return $u->userId;
        });

        // get the round exercise logs for userids on those modules
        $roundExerciseLogs = RoundExerciseLog::whereIn('userId', $userIds)
            ->whereIn('moduleNo', $moduleNos)
            ->whereBetween('updated_at', [$date, $end_date])
            ->get();

        // hold all users data 
        $users = [];
        // hold all users percentage data 
        $incorrectCount = [];
        $totalCount = [];

        // go through each log and create data for each user
        foreach ($roundExerciseLogs as $log) {
            // create users holder, is not there
            if (!isset($users[$log->userId])) {
                $users[$log->userId] = [
                    "Concept 1" => 0,
                    "Concept 2" => 0,
                    "Listening" => 0,
                    "Speaking" => 0,
                    "Total" => 0,
                ];
            }
            if (!isset($incorrectCount[$log->userId])) {
                $incorrectCount[$log->userId] = [
                    "Concept 1" => 0,
                    "Concept 2" => 0,
                    "Listening" => 0,
                    "Speaking" => 0,
                    "Total" => 0,
                ];
            }
            if (!isset($totalCount[$log->userId])) {
                $totalCount[$log->userId] = [
                    "Concept 1" => 0,
                    "Concept 2" => 0,
                    "Listening" => 0,
                    "Speaking" => 0,
                    "Total" => 0,
                ];
            }
            $category = self::$exercise_categories_relation[$log->type];
            // increment the  in one of the categories for user, if status is false
            if ($log->failCount > 0) {
                $users[$log->userId][$category] += (int) $log->failCount;
                $users[$log->userId]["Total"] += (int) $log->failCount;
            }

            if ($log->failCount > 0) {
                // if($log->failCount > 0 || (int) $log->status < 1) {
                // increment the incorrect count by 1
                $incorrectCount[$log->userId][$category]++;
                $incorrectCount[$log->userId]["Total"]++;
            }

            // increment the percentage values anyway
            $totalCount[$log->userId][$category]++;
            $totalCount[$log->userId]["Total"]++;
            // also push into total
        }

        $incorrectPercentage = [];
        // calculate the incorrect percentage for each user
        foreach ($totalCount as $userId => $data) {
            $percentageData = [];
            // calculate the percentage per category
            foreach ($data as $catName => $value) {
                $percentageData[$catName] = round(($value > 0 ? $incorrectCount[$userId][$catName] / $value : 0) * 100, 2);
            }
            $incorrectPercentage[$userId] = $percentageData;
        }

        // restructure the user
        $restructuredUsers = [];
        foreach ($users as $userId => $data) {
            $restructuredUsers[] = [
                "userId" => $userId,
                "name" => $userNames[$userId],
                "statistics" => $data,
                "incorrectPercentage" => $incorrectPercentage[$userId],
                "totalScore" => $totalScore[$userId],
                "lastLesson" => $lastLesson[$userId],
                // "totalCount" => $totalCount[$userId],
            ];
        }

        return response()->json([
            "message" => "Data fetch successful!",
            "users" => $restructuredUsers,
            "date" => $date,
            "end_date" => $end_date,
        ]);
    }

    // get users mistakes for a cohort
    public function userPlacementMistakes(Request $request, $cohort_id)
    {
        // get cohort for which data is to be seen
        $cohort = Cohort::find($cohort_id);

        if (!$cohort) {
            return response()->json([
                "message" => "Cohort not found!"
            ]);
        }

        // get date for which data is needed
        $date = $request->date ? Carbon::parse($request->date)->startOfDay() : Carbon::now()->subYear()->startOfDay();
        $end_date = Carbon::parse($request->end_date)->endOfDay();

        // get the module numbers in cohort
        $moduleNos = $cohort->program->modules->map(function ($m) {
            return $m->module->moduleno;
        });

        // get users for the the cohort
        $userData = Course::join('employeecourse', 'courses.courseNumber', '=', 'employeecourse.courseNumber')
            ->join('employee', 'employee.userId', '=', 'employeecourse.userId')
            ->distinct('employeecourse.userId')
            ->whereIn('moduleNumber', $moduleNos)
            ->whereNotNull('employeecourse.userId')
            ->where('employeecourse.userId', '!=', "")
            ->select('employeecourse.userId', 'FirstName', 'LastName')
            ->where('employee.CompanyCode', $cohort->company_code)
            ->where('cohort_id', $cohort->id)
            ->get();

        // userNmaes
        $userNames = [];

        foreach ($userData as $user) {
            $userNames[$user->userId] = trim($user->FirstName . " " . $user->LastName);
        }

        $userIds = $userData->map(function ($u) {
            return $u->userId;
        });

        // hold all users mistakes
        $users = [];
        $usersTotal = []; // holds all users totals
        $subsequentRounds = [];
        $usersLastAttempt = [];

        // for each user get the last record
        foreach ($userIds as $userId) {
            // get the last record
            $lastRound = PlacementLog::where('userId', $userId)
                ->whereIn('moduleNo', $moduleNos)
                ->latest()->first();
            // if we have last round, do further calculation
            if ($lastRound) {
                $stats = getCohortMistakesByPlacementRound($lastRound);

                $usersLastAttempt[$lastRound->userId] = $lastRound->created_at;
                $users[$lastRound->userId] = $stats['mistakes'];
                $usersTotal[$lastRound->userId] = $stats['total'];

                // get for all subsequent round as well
                $subsequentRounds[$lastRound->userId] = [];
                $prevRoundData = [];
                $prevRounds = PlacementLog::where('userId', $userId)
                    ->whereIn('moduleNo', $moduleNos)
                    ->where('id', '!=', $lastRound->id)
                    ->latest()->get();
                foreach ($prevRounds as $prevRound) {
                    $roundData = getCohortMistakesByPlacementRound($prevRound);
                    $prevRoundData[] = [
                        'attempted_at' => $prevRound->created_at,
                        'mistakes' => $roundData['mistakes'],
                        'total' => $roundData['total'],
                    ];
                }
                // push to prev rounddata
                $subsequentRounds[$lastRound->userId] = $prevRoundData;
            }
        }

        // restructure the user
        $restructuredUsers = [];
        foreach ($users as $userId => $data) {
            $restructuredUsers[] = [
                "userId" => $userId,
                "name" => $userNames[$userId],
                "lastAttemptAt" => $usersLastAttempt[$userId],
                "statistics" => $data,
                "total" => $usersTotal[$userId],
                "subsequentRounds" => $subsequentRounds[$userId],
            ];
        }

        return response()->json([
            "message" => "Data fetch successful!",
            "users" => $restructuredUsers,
            "date" => $date,
            "end_date" => $end_date,
        ]);
    }



    // get user mistakes for a cohort
    public function usersMistakes(Request $request, $cohort_id, $userId)
    {
        // get cohort for which data is to be seen
        $cohort = Cohort::find($cohort_id);

        if (!$cohort) {
            return response()->json([
                "message" => "Cohort not found!"
            ]);
        }

        // get the employee
        $employee = Employee::where([
            'userId' => $userId,
            'CompanyCode' => $cohort->company_code
        ])->first();

        if (!$employee) {
            return response()->json([
                "message" => "Employee not found!"
            ]);
        }

        // get date for which data is needed
        $date = $request->date ? Carbon::parse($request->date)->startOfDay() : Carbon::now()->subYear()->startOfDay();
        $end_date = Carbon::parse($request->end_date)->endOfDay();

        // get the module numbers in cohort
        $moduleNos = $cohort->program->modules->map(function ($m) {
            return $m->module->moduleno;
        });

        $userId = $employee->userId;

        // get the round exercise logs for userids on those modules
        $roundExerciseLogs = RoundExerciseLog::where('userId', $userId)
            ->whereIn('moduleNo', $moduleNos)
            ->whereBetween('updated_at', [$date, $end_date])
            ->get();

        // hold user data
        $userLogs = [];

        // go through each log and create data for each user
        foreach ($roundExerciseLogs as $log) {
            // create lessons holder, if not there
            $lesson = Lesson::where('moduleno', $log->moduleNo)->where('lesson_no', $log->lessonNo)->first();

            if (!isset($userLogs[$lesson->id])) {
                $userLogs[$lesson->id] = [
                    "Name" => $lesson->long_description,
                    "Concept 1" => 0,
                    "Concept 2" => 0,
                    "Listening" => 0,
                    "Speaking" => 0,
                    "Total" => 0,
                ];
            }

            // increment the  in one of the categories for user, if status is false
            if ($log->failCount > 0) {
                $category = self::$exercise_categories_relation[$log->type];
                $userLogs[$lesson->id][$category] += (int) $log->failCount;
                $userLogs[$lesson->id]["Total"] += (int) $log->failCount;
            }
            // also push into total
        }

        // restructure the user
        $restructuredUser = [
            "userId" => $userId,
            "name" => trim($employee->FirstName . " " . $employee->LastName),
            "cohort_name" => $cohort->name,
            "statistics" => $userLogs
        ];

        return response()->json([
            "message" => "Data fetch successful!",
            "user" => $restructuredUser,
            "cohort_name" => $cohort->name,
            "date" => $date,
            "end_date" => $end_date,
        ]);
    }


    // get user mistakes for a cohort
    public function userTimeReport(Request $request, $cohort_id, $userId)
    {
        // get cohort for which data is to be seen
        $cohort = Cohort::find($cohort_id);

        if (!$cohort) {
            return response()->json([
                "message" => "Cohort not found!"
            ]);
        }

        // get the employee
        $employee = Employee::where([
            'userId' => $userId,
            'CompanyCode' => $cohort->company_code
        ])->first();

        if (!$employee) {
            return response()->json([
                "message" => "Employee not found!"
            ]);
        }

        // get date for which data is needed
        $date = $request->date ? Carbon::parse($request->date)->startOfDay() : Carbon::now()->subWeek()->startOfDay();
        $start_date = Carbon::parse($date)->endOfDay();
        $end_date = Carbon::parse($request->end_date)->endOfDay();

        $timeLogs = collect([]);

        // for each start date to end data
        while ($date->lt($end_date)) {
            // check for time spent
            $timeLogs->push([
                "date" => Carbon::parse($date)->toString(),
                "time_spent" => (int) UserTimeLog::where('userId', $employee->userId)
                    ->selectRaw('sum(time_to_sec(timediff(outTime, inTime))) as time_spent')
                    // ->selectRaw('sec_to_time(sum(time_to_sec(timediff(outTime, inTime)))) as time_spent')
                    ->whereDate('created_at', $date)
                    ->first()->time_spent ?? 0
            ]);
            $date->addDay();
        }

        return response()->json([
            "message" => "Data fetch successful!",
            "cohort_name" => $cohort->name,
            "timeLogs" => $timeLogs,
            "date" => $start_date,
            "end_date" => $end_date,
        ]);
    }



    // get user mistakes for a cohort
    public function usersPlacementMistakes(Request $request, $cohort_id, $userId)
    {
        // get cohort for which data is to be seen
        $cohort = Cohort::find($cohort_id);

        if (!$cohort) {
            return response()->json([
                "message" => "Cohort not found!"
            ]);
        }

        // get the employee
        $employee = Employee::where([
            'userId' => $userId,
            'CompanyCode' => $cohort->company_code
        ])->first();

        if (!$employee) {
            return response()->json([
                "message" => "Employee not found!"
            ]);
        }

        // get date for which data is needed
        $date = $request->date ? Carbon::parse($request->date)->startOfDay() : Carbon::now()->subYear()->startOfDay();
        $end_date = Carbon::parse($request->end_date)->endOfDay();

        // get the module numbers in cohort
        $moduleNos = $cohort->program->modules->map(function ($m) {
            return $m->module->moduleno;
        });

        $userId = $employee->userId;

        // get the round exercise logs for userids on those modules
        $roundExerciseLogs = PlacementExerciseLog::where('userId', $userId)
            ->whereIn('moduleNo', $moduleNos)
            ->whereBetween('updated_at', [$date, $end_date])
            ->get();

        // hold user data
        $userLogs = [];

        // go through each log and create data for each user
        foreach ($roundExerciseLogs as $log) {
            // create lessons holder, if not there
            $lesson = Lesson::where('moduleno', $log->moduleNo)->where('lesson_no', $log->debugLessonNo)->first();

            if ($lesson && !isset($userLogs[$lesson->id])) {
                $userLogs[$lesson->id] = [
                    "Name" => $lesson->long_description,
                    "Concept 1" => 0,
                    "Concept 2" => 0,
                    "Listening" => 0,
                    "Speaking" => 0,
                    "Total" => 0,
                ];
            }

            // increment the  in one of the categories for user, if status is false
            if ($log->failCount > 0) {
                $category = self::$exercise_categories_relation[$log->type];
                $userLogs[$lesson->id][$category] += (int) $log->failCount;
                $userLogs[$lesson->id]["Total"] += (int) $log->failCount;
            }
            // also push into total
        }

        // restructure the user
        $restructuredUser = [
            "userId" => $userId,
            "name" => trim($employee->FirstName . " " . $employee->LastName),
            "cohort_name" => $cohort->name,
            "statistics" => $userLogs
        ];

        return response()->json([
            "message" => "Data fetch successful!",
            "user" => $restructuredUser,
            "cohort_name" => $cohort->name,
            "date" => $date,
            "end_date" => $end_date,
        ]);
    }
}
