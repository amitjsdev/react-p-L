<?php

namespace App\Http\Controllers;

use App\Http\Resources\ResumeResource;
use App\Resume;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ResumeController extends Controller
{

    public function getAllResumes(Request $request)
    {
        $resumes = Resume::where('userId', auth()->user()->email)->select('resumeName', 'id')->get();

        return response()->json([
            'resumes' => $resumes
        ]);
    }

    public function getSpecificResume(Request $request, $id)
    {
        $resume = Resume::where('userId', auth()->user()->email)->where('id', $id)->first();

        return response()->json([
            'resume' => new ResumeResource($resume)
        ]);
    }

    public function createResume(Request $request)
    {
        // validate the payload
        $validator = Validator::make($request->all(), [
            'resumeName' => "required|string",
        ]);

        if ($validator->fails()) {
            return response()->json([
                "errors" => $validator->errors()
            ], 422);
        }

        // get the validated Data
        $validated = $validator->validated();

        //create the record
        $resume = Resume::create([
            'userId' => auth()->user()->email,
            'resumeName' => $validated["resumeName"],
        ]);

        return response()->json([
            'resume' => new ResumeResource($resume)
        ]);
    }

    /**
     * Update basic resume info
     *
     * @param Request $request
     * @param [type] $id
     * @return void
     */
    public function updateResumeBasicInfo(Request $request, $id)
    {
        $resume = Resume::where('userId', auth()->user()->email)->where('id', $id)->first();

        if (!$resume) {
            return response()->json([
                'message' => "resume not found!",
                'id' => $id,
            ], 404);
        }

        // validated the basic info
        $validator = Validator::make($request->all(), [
            'basicInfo' => 'required',
            'basicInfo.firstName' => 'required',
            'basicInfo.lastName' => 'required',
            'basicInfo.phone' => 'required',
            'basicInfo.email' => 'required',
            'basicInfo.address' => 'nullable',
            'basicInfo.linkedin' => 'nullable',
            'basicInfo.twitter' => 'nullable',
            'basicInfo.website' => 'nullable',
        ]);

        if ($validator->fails()) {
            return response()->json([
                "errors" => $validator->errors()
            ], 422);
        }

        $validator = $validator->validated();

        // get resume content
        try {
            $resumeContent = json_decode($resume->resumeContent, true);
            if (!$resumeContent) {
                $resumeContent = [];
            }
        } catch (\Throwable $th) {
            $resumeContent = [];
        }

        // add data to resume content
        $resumeContent["basicInfo"] = $validator["basicInfo"];

        // save the data
        $resume->resumeContent = json_encode($resumeContent);
        $resume->save();

        return response()->json([
            'message' => "data updated",
            'resume' => new ResumeResource($resume)
        ]);
    }


    /**
     * Update summary
     *
     * @param Request $request
     * @param [type] $id
     * @return void
     */
    public function updateResumeSummary(Request $request, $id)
    {
        $resume = Resume::where('userId', auth()->user()->email)->where('id', $id)->first();

        if (!$resume) {
            return response()->json([
                'message' => "resume not found!",
                'id' => $id,
            ], 404);
        }

        // validated the basic info
        $validator = Validator::make($request->all(), [
            'summary' => 'string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                "errors" => $validator->errors()
            ], 422);
        }

        $validator = $validator->validated();

        // get resume content
        try {
            $resumeContent = json_decode($resume->resumeContent, true);
            if (!$resumeContent) {
                $resumeContent = [];
            }
        } catch (\Throwable $th) {
            $resumeContent = [];
        }

        // add data to resume content
        $resumeContent["summary"] = $validator["summary"];

        // save the data
        $resume->resumeContent = json_encode($resumeContent);
        $resume->save();

        return response()->json([
            'message' => "data updated",
            'resume' => new ResumeResource($resume)
        ]);
    }

    /**
     * Update basic resume info
     *
     * @param Request $request
     * @param [type] $id
     * @return void
     */
    public function updateResumeEducation(Request $request, $id)
    {
        $resume = Resume::where('userId', auth()->user()->email)->where('id', $id)->first();

        if (!$resume) {
            return response()->json([
                'message' => "resume not found!",
            ], 404);
        }

        // validated the basic info
        $validator = Validator::make($request->all(), [
            'education' => 'required|array',
            'education.*.sno' => 'nullable',
            'education.*.degree' => 'required',
            'education.*.institution' => 'required',
            'education.*.university' => 'required',
            'education.*.location' => 'nullable',
            'education.*.startYear' => 'required',
            'education.*.endYear' => 'required',
            'education.*.gpaOrPecentage' => 'nullable',
        ]);

        if ($validator->fails()) {
            return response()->json([
                "errors" => $validator->errors()
            ], 422);
        }

        $validator = $validator->validated();

        // get resume content
        try {
            $resumeContent = json_decode($resume->resumeContent, true);
            if (!$resumeContent) {
                $resumeContent = [];
            }
        } catch (\Throwable $th) {
            $resumeContent = [];
        }

        // add data to resume content
        $resumeContent["education"] = $validator["education"];

        // save the data
        $resume->resumeContent = json_encode($resumeContent);
        $resume->save();

        return response()->json([
            'message' => "data updated",
            'resume' => new ResumeResource($resume)
        ]);
    }

    /**
     * Update basic resume info
     *
     * @param Request $request
     * @param [type] $id
     * @return void
     */
    public function updateResumeWorkExperience(Request $request, $id)
    {
        $resume = Resume::where('userId', auth()->user()->email)->where('id', $id)->first();

        if (!$resume) {
            return response()->json([
                'message' => "resume not found!",
            ], 404);
        }

        // validated the basic info
        $validator = Validator::make($request->all(), [
            'workExperience' => 'required|array',
            'workExperience.*.sno' => 'nullable',
            'workExperience.*.companyName' => 'required',
            'workExperience.*.location' => 'required',
            'workExperience.*.monthStart' => 'required',
            'workExperience.*.yearStart' => 'required',
            'workExperience.*.monthEnd' => 'string',
            'workExperience.*.yearEnd' => 'string',
            'workExperience.*.currentlyWorking' => 'required|boolean',
        ]);

        if ($validator->fails()) {
            return response()->json([
                "errors" => $validator->errors()
            ], 422);
        }

        $validator = $validator->validated();

        // get resume content
        try {
            $resumeContent = json_decode($resume->resumeContent, true);
            if (!$resumeContent) {
                $resumeContent = [];
            }
        } catch (\Throwable $th) {
            $resumeContent = [];
        }

        // add data to resume content
        $resumeContent["workExperience"] = $validator["workExperience"];

        // save the data
        $resume->resumeContent = json_encode($resumeContent);
        $resume->save();

        return response()->json([
            'message' => "data updated",
            'resume' => new ResumeResource($resume)
        ]);
    }

    /**
     * Update basic resume info
     *
     * @param Request $request
     * @param [type] $id
     * @return void
     */
    public function updateResumeCertificationsReceived(Request $request, $id)
    {
        $resume = Resume::where('userId', auth()->user()->email)->where('id', $id)->first();

        if (!$resume) {
            return response()->json([
                'message' => "resume not found!",
            ], 404);
        }

        // validated the basic info
        $validator = Validator::make($request->all(), [
            'certificationsReceived' => 'array',
            'certificationsReceived.*.sno' => 'nullable',
            'certificationsReceived.*.certificationName' => 'required',
            'certificationsReceived.*.certificationLink' => 'nullable',
            'certificationsReceived.*.certificationDescription' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                "errors" => $validator->errors()
            ], 422);
        }

        $validator = $validator->validated();

        // get resume content
        try {
            $resumeContent = json_decode($resume->resumeContent, true);
            if (!$resumeContent) {
                $resumeContent = [];
            }
        } catch (\Throwable $th) {
            $resumeContent = [];
        }

        // add data to resume content
        $resumeContent["certificationsReceived"] = $validator["certificationsReceived"];

        // save the data
        $resume->resumeContent = json_encode($resumeContent);
        $resume->save();

        return response()->json([
            'message' => "data updated",
            'resume' => new ResumeResource($resume)
        ]);
    }

    /**
     * Update basic resume info
     *
     * @param Request $request
     * @param [type] $id
     * @return void
     */
    public function updateSkillsPossessed(Request $request, $id)
    {
        $resume = Resume::where('userId', auth()->user()->email)->where('id', $id)->first();

        if (!$resume) {
            return response()->json([
                'message' => "resume not found!",
            ], 404);
        }

        // validated the basic info
        $validator = Validator::make($request->all(), [
            'skillsPossessed' => 'array',
            'skillsPossessed.*.sno' => 'nullable',
            'skillsPossessed.*.skillDescription' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                "errors" => $validator->errors()
            ], 422);
        }

        $validator = $validator->validated();

        // get resume content
        try {
            $resumeContent = json_decode($resume->resumeContent, true);
            if (!$resumeContent) {
                $resumeContent = [];
            }
        } catch (\Throwable $th) {
            $resumeContent = [];
        }

        // add data to resume content
        $resumeContent["skillsPossessed"] = $validator["skillsPossessed"];

        // save the data
        $resume->resumeContent = json_encode($resumeContent);
        $resume->save();

        return response()->json([
            'message' => "data updated",
            'resume' => new ResumeResource($resume)
        ]);
    }



    /**
     * deleteResume
     *
     * @param Request $request
     * @param [type] $id
     * @return void
     */
    public function deleteResume(Request $request, $id)
    {
        $resume = Resume::where('userId', auth()->user()->email)->where('id', $id)->first();

        if (!$resume) {
            return response()->json([
                'message' => "resume not found!",
                'id' => $id,
            ], 404);
        }

        $resume->delete();

        return response()->json([
            'message' => "Resume deleted!",
            'resume' => new ResumeResource($resume)
        ]);
    }

    public function saveProctoredResume(Request $request)
    {
        // get the user data
        $resume = Resume::where('userId', auth()->user()->email)
            ->where('proctoredResume', true)
            ->first();

        if ($resume) {
            return response()->json([
                "message" => "Resume already saved!"
            ], 200);
        }

        // validated the basic info
        $validator = Validator::make($request->all(), [
            'questionnaire' => 'required',
            // 'questionnaire.firstName' => 'nullable',
            // 'questionnaire.location' => 'nullable',
            // 'questionnaire.currentAddress' => 'nullable',
            // 'questionnaire.whatsappNumber' => 'nullable',
            // 'questionnaire.graduationCollegeName' => 'nullable',
            // 'questionnaire.branchOrDepartment' => 'nullable',
            // 'questionnaire.graduationGPAorPercent' => 'nullable',
            // 'questionnaire.class10GPAorPercent' => 'nullable',
            // 'questionnaire.graduationDateIfStudent' => 'nullable',
            // 'questionnaire.finalExamStartIfStudent' => 'nullable',
            // 'questionnaire.areYouWorkingYN' => 'nullable',
            // 'questionnaire.companyName' => 'nullable',
            // 'questionnaire.workExperience' => 'nullable',
            // 'questionnaire.jeeRank' => 'nullable',
            // 'questionnaire.collegeEntranceName' => 'nullable',
            // 'questionnaire.stateExamRank' => 'nullable',
            // 'questionnaire.plansToWorkFullTime' => 'nullable'
        ]);

        if ($validator->fails()) {
            return response()->json([
                "errors" => $validator->errors()
            ], 422);
        }

        $validated = $validator->validated();

        // add data to resume content
        $resumeContent = $validated["questionnaire"];

        // save the data
        $resume = Resume::create([
            'userId' => auth()->user()->email,
            'resumeName' => "Proctored Questionnaire!",
            'resumeContent' => json_encode($resumeContent),
            'proctoredResume' => true
        ]);

        return response()->json([
            "message" => "Resume saved!",
            "resume" => $resume
        ]);
    }
}
