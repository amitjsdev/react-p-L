<?php

namespace App\Http\Controllers;

use App\Employee;
use App\Events\RoundLogSave;
use App\Http\Resources\RoundLogResource;
use App\Jobs\GeneratePlacementTestReportForUser;
use App\PlacementExerciseLog;
use App\PlacementLog;
use App\PlacementTestResult;
use App\RoundExerciseLog;
use App\RoundLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class RoundLogController extends Controller
{
    // check what user wants to save (round or failed round)
    public function saveAccordingly(Request $request)
    {

        if ($request->isPlacementTest) {
            // save the placement test result
            return $this->savePlacementTestResult($request);
        }

        if ($request->isReviewRound) {
            return $this->saveFailedExerciseRoundLog($request);
        } else {
            return $this->save($request);
        }
    }

    /**
     * Save placement test result
     *
     * @param Request $request
     * @return void
     */
    public function savePlacementTestResult(Request $request)
    {
        $userId = auth()->user()->email;

        // check the database to see if the combo exists (no need to see last combo for sake of simplicity)
        $placementLog = PlacementLog::where('userId', $userId)
            ->where("moduleNo", $request->moduleNo)
            ->where("debugRouteNo", $request->debugRouteNo)
            ->where("debugLessonNo", $request->debugLessonNo)
            ->orderBy('roundNo', "desc")
            ->first();
        if (!$placementLog) {
            return response()->json([
                "message" => "Invalid Request",
                "type" => "placement-log:log-not-found",
                "request" => $request->all()
            ], 400);
        }
        if ((int) $placementLog->status === -1) {
            // get v2 exercise for this MRL, and save roundLog
            $placementLog->status = $request->status;
            $placementLog->mistakesMade = $request->mistakesMade;
            $placementLog->additionalLivesClaimed = $request->additionalLivesClaimed;
            $placementLog->save();
            $placementLogExercise = [];
            // save every exrcise too
            foreach ($request->questions as $question) {
                $failCount = isset($question["failCount"]) ? $question["failCount"] : 0;
                // not verifying the existance of record with that question id for sake of simplicity
                if (isset($question["questionId"])) {
                    $placementLogExercise[$question["questionId"]] = PlacementExerciseLog::where('roundLogId', $placementLog->id)
                        ->where('questionId', $question["questionId"])
                        ->update([
                            "status" => isset($question["status"]) ? $question["status"] : -1,
                            "additionalInfo" => isset($question["additionalInfo"]) ? $question["additionalInfo"] : "",
                            "failCount" => $failCount
                        ]);
                } else {
                    $placementLogExercise[$question["questionId"]] = -1;
                }
            }

            // paused
            // GeneratePlacementTestReportForUser::dispatch($placementLog->id);

            // create result
            PlacementTestResult::create([
                'userId' => $userId,
                'moduleNo' => $request->moduleNo,
                'routeNo' => $request->debugRouteNo,
                'lessonNo' => $request->debugLessonNo,
                'placementScore' => $request->placementScore
            ]);

            return response()->json([
                "message" => "Test Result Saved!",
                "request" => $request->all(),
                "placementLog" => $placementLog,
                "placementLogExercise" => $placementLogExercise
            ]);
        } else {
            return response()->json([
                "message" => "Invalid Request",
                "type" => "placement-log:status-not-(-1)",
                "request" => $request->all()
            ], 400);
        }
    }

    // saves the round log request (only difference from above is isMiniRound is checked for value 1)
    public function save(Request $request)
    {
        $userId = auth()->user()->email;
        // request will have MRL and roundNo
        // check the database to see if the combo exists (no need to see last combo for sake of simplicity)
        $roundLog = RoundLog::where('userId', $userId)
            ->where("moduleNo", $request->moduleNo)
            ->where("routeNo", $request->routeNo)
            ->where("lessonNo", $request->lessonNo)
            ->where("isMiniRound", '!=', 1)
            ->whereNull("roundType")
            ->orderBy('roundNo', "desc")
            ->first();
        if (!$roundLog) {
            return response()->json([
                "message" => "Invalid Request"
            ], 400);
        }
        if ($roundLog->status === '-1') {
            // get v2 exercise for this MRL, and save roundLog
            $roundLog->status = $request->status;
            $roundLog->livesLeft = $request->livesLeft;
            $roundLog->additionalLivesClaimed = $request->additionalLivesClaimed;
            $roundLog->save();
            // save every exrcise too
            foreach ($request->questions as $question) {
                $failCount = isset($question["failCount"]) ? $question["failCount"] : 0;
                // not verifying the existance of record with that question id for sake of simplicity
                if (isset($question["questionId"])) {
                    RoundExerciseLog::where('roundLogId', $roundLog->id)
                        ->where('questionId', $question["questionId"])
                        ->update([
                            "status" => isset($question["status"]) ? $question["status"] : -1,
                            "additionalInfo" => isset($question["additionalInfo"]) ? $question["additionalInfo"] : "",
                            "failCount" => $failCount
                        ]);
                }

                // if failcount > 0 , do a thorough calculation for fail count
                // if ($failCount > 0) {
                getUserMistakesCountForLesson($request->moduleNo, $request->routeNo, $request->lessonNo, $userId, true);
                // }
            }

            event(new RoundLogSave($roundLog));

            // save the userScore $request->score
            $courseNumber = getCourseNoFromModuleNo($request->moduleNo, $userId);
            if (isset($courseNumber)) {
                // always use this function it triggers update check for badge event
                updateUserScoreForCourse($userId, $courseNumber, (int) $request->score ?? 0);
            } else {
                Log::error("getCourseNoFromModuleNo helper function returned null, while update score on save roundlog", [$request->all()]);
            }

            return response()->json(new RoundLogResource($roundLog));
        } else {
            return response()->json([
                "message" => "Invalid Request"
            ], 400);
        }
    }
    // saves the round log request for failed exercises
    public function saveFailedExerciseRoundLog(Request $request)
    {
        $userId = auth()->user()->email;
        // request will have MRL and roundNo
        // check the database to see if the combo exists (no need to see last combo for sake of simplicity)
        $roundLog = RoundLog::where('userId', $userId)
            ->where("moduleNo", $request->moduleNo)
            ->where("routeNo", $request->routeNo)
            ->where("lessonNo", $request->lessonNo)
            ->where("isMiniRound", '!=', 1)
            ->where("roundType", "failed_exercise")
            ->orderBy('roundNo', "desc")
            ->first();
        if (!$roundLog) {
            return response()->json([
                "message" => "Invalid Request"
            ], 400);
        }
        if ($roundLog->status === '-1') {
            // get v2 exercise for this MRL, and save roundLog
            $roundLog->status = $request->status;
            $roundLog->livesLeft = $request->livesLeft;
            $roundLog->additionalLivesClaimed = $request->additionalLivesClaimed;
            $roundLog->save();
            // save every exrcise too
            foreach ($request->questions as $question) {
                $failCount = isset($question["failCount"]) ? $question["failCount"] : 0;
                // not verifying the existance of record with that question id for sake of simplicity
                if (isset($question["questionId"])) {
                    RoundExerciseLog::where('roundLogId', $roundLog->id)
                        ->where('questionId', $question["questionId"])
                        ->update([
                            "status" => isset($question["status"]) ? $question["status"] : -1,
                            "additionalInfo" => isset($question["additionalInfo"]) ? $question["additionalInfo"] : "",
                            "failCount" => $failCount
                        ]);
                }

                // if failcount > 0 , do a thorough calculation for fail count
                getUserMistakesCountForLesson($request->moduleNo, $request->routeNo, $request->lessonNo, $userId, true);
            }

            event(new RoundLogSave($roundLog));

            // save the userScore $request->score
            $courseNumber = getCourseNoFromModuleNo($request->moduleNo, $userId);
            if (isset($courseNumber)) {
                // always use this function it triggers update check for badge event
                updateUserScoreForCourse($userId, $courseNumber, (int) $request->score ?? 0);
            } else {
                Log::error("getCourseNoFromModuleNo helper function returned null, while update score on save roundlog", [$request->all()]);
            }

            return response()->json(new RoundLogResource($roundLog));
        } else {
            return response()->json([
                "message" => "Invalid Request"
            ], 400);
        }
    }

    public function sendLastPlacementTestResult(Request $request, $userId)
    {
        // get the employee
        $employee = Employee::where('userId', $userId)->first();

        if (!$employee) {
            return response()->json([
                "message" => "Employee not found!"
            ]);
        }

        // get the last placement log
        $lastPlacementLog = PlacementLog::where('userId', $userId)->latest()->first();

        if (!$lastPlacementLog) {
            return response()->json([
                "message" => "Placement log not found!"
            ]);
        }

        // GeneratePlacementTestReportForUser::dispatch($lastPlacementLog->id);

        return response()->json([
            "message" => "Email triggered!"
        ]);
    }

    // saves the mini round log request
    public function saveMini(Request $request)
    {
        $userId = auth()->user()->email;
        // request will have MRL and roundNo
        // check the database to see if the combo exists (no need to see last combo for sake of simplicity)
        $roundLog = RoundLog::where('userId', $userId)
            ->where("moduleNo", $request->moduleNo)
            ->where("routeNo", $request->routeNo)
            ->where("lessonNo", $request->lessonNo)
            ->where("isMiniRound", 1)
            ->where('roundNo', $request->roundNo)
            ->first();
        if (!$roundLog) {
            return response()->json([
                "message" => "Invalid Request"
            ], 400);
        }
        if ($roundLog->status === '-1') {
            // get v2 exercise for this MRL, and save roundLog
            $roundLog->status = $request->status;
            $roundLog->livesLeft = $request->livesLeft;
            $roundLog->additionalLivesClaimed = $request->additionalLivesClaimed;
            $roundLog->save();
            // save every exrcise too
            foreach ($request->questions as $question) {
                // not verifying the existance of record with that question id for sake of simplicity
                RoundExerciseLog::create([
                    "roundLogId" => $roundLog->id,
                    "questionId" => $question["questionId"],
                    "status" => $question["status"],
                    "type" => $question["type"],
                    "additionalInfo" => $question["additionalInfo"],
                ]);
            }

            // save the userScore $request->score
            $courseNumber = getCourseNoFromModuleNo($request->moduleNo, $userId);
            if (isset($courseNumber)) {
                // always use this function it triggers update check for badge event
                updateUserScoreForCourse($userId, $courseNumber, (int) $request->score ?? 0);
            } else {
                Log::error("getCourseNoFromModuleNo helper function returned null, while update score on save roundlog", [$request->all()]);
            }

            return response()->json(new RoundLogResource($roundLog));
        } else {
            return response()->json([
                "message" => "Invalid Request"
            ], 400);
        }
    }
}
