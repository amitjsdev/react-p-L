<?php

namespace App\Http\Controllers;

use Illuminate\Database\Eloquent\ModelNotFoundException;
use App\Route;
use Illuminate\Http\Request;
use App\Http\Resources\Route as RouteResource;

use App\Http\Resources\CheckUserApiAccess as CheckUserApiAccess;
use DB;
use checkUserPermissionController;
use Session;
use Validator;

class RouteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        
        
        $route = DB::table('route');

        // http://taplingua.devapi/api/route?moduleNumber=10&routeNumber=1

        if ($request->input('routeNumber') != "") {
            $route->where('routeno', $request->input('routeNumber'));
        }

        if ($request->input('moduleNumber') != "") {

            $route->where('moduleno', $request->input('moduleNumber'));
        } 

        
        $route = $route->get();

        return RouteResource::collection($route);

        

    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function list(Request $request)
    {
        
        
        // http://taplingua.devapi/api/route-list?moduleNumber=10&courseNo=201811299

        $route = DB::table('route')
         ->leftJoin('courses', 'route.moduleno', '=', 'courses.moduleNumber');

        if ($request->input('courseNo') != "") {
            $route->where('courses.courseNumber', $request->input('courseNo'));
        }

        if ($request->input('moduleNumber') != "") {

            $route->where('courses.moduleNumber', $request->input('moduleNumber'));
        } 

        
        $route = $route->get();

        return RouteResource::collection($route);

    }


    public function listing(Request $request)
    {
        
        $Route = Route::query(); 

        $Route->orderBy('id','asc');

        if ($request->input('moduleNo') != "") {

            $Route->where('moduleno', $request->input('moduleNo'));
        }

        if ($request->input('routeNo') != "") {

            $Route->where('routeno', $request->input('routeNo'));
        }

       
        if ($request->input('query') != "") {

            $query = $request->input('query');
            
            //SQL AND + OR + Brackets
            $Route->where(function($Route) use ($query) {
                $Route->where('description', 'LIKE', '%'.$query.'%')
                      ->orWhere('long_description', 'LIKE', '%'.$query.'%');
            });

        }

             
        $Route = $Route->paginate(50);

        return RouteResource::collection($Route);


    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $id)
    {
        
        try{

          $Route = Route::findOrFail($id);
          return new RouteResource($Route);
        
        } 
        // catch(Exception $e) catch any exception
        catch(ModelNotFoundException $e)
        {
            return response()->json(['message' => 'Not Found!'], 404);
        } 

    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $request->validate([
            "moduleno"=>"required",
            "routeno"=>"required",
            "description"=>"required"
        ]);

        
        $Route = Route::findOrFail($id);
        
        $Route->update($request->all());

        return response()->json(['message' => 'Data Saved!'], 200);


    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            "moduleno"=>"required",
            "routeno"=>"required",
            "description"=>"required"
        ]);


        $Route = $request->isMethod('put') ? Route::findOrFail($request->id) : new Route;

        $Route->id = $request->input('id');

        //$post->fill($request->input())->save();
        
        $Route->moduleno = $request->input('moduleno'); 
        $Route->routeno = $request->input('routeno'); 
        $Route->description = $request->input('description'); 
        $Route->long_description = $request->input('long_description') ? $request->input('long_description') : ''; 
        $Route->numberofHours = $request->input('numberofHours') ? $request->input('numberofHours') : ''; 
        
        $Route->numberofPoints = $request->input('numberofPoints') ? $request->input('numberofPoints') : ''; 
        $Route->min_points = $request->input('min_points') ? $request->input('min_points') : ''; 
        $Route->routeEmail = $request->input('routeEmail') ? $request->input('routeEmail') : ''; 
        $Route->status = $request->input('status') ? $request->input('status') : ''; 
               
        $Route->adddate = date("Y-m-d H:i:s");
         
       
        if($Route->save()){
            //return new EmployeeResource($Employee);
            return response()->json(['message' => 'Data Saved!'], 200);
        }


    }



     /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        
        //echo "Test...";

        try{  

          $Route = Route::findOrFail($id);

          if($Route->delete()){
            return response()->json(['message' => 'Removed!'], 200);
          }

        }        
        // catch(Exception $e) catch any exception
        catch(ModelNotFoundException $e)
        {
            return response()->json(['message' => 'Not Found!'], 404);
        }

        
    }




    /* CMS */


    public function listRoutes(Request $request)
    {

        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

           $Route = Route::query(); 

        $Route->orderBy('id','asc');

        if ($request->input('moduleNo') != "") {

            $Route->where('moduleno', $request->input('moduleNo'));
        }

        if ($request->input('routeNo') != "") {

            $Route->where('routeno', $request->input('routeNo'));
        }


        if ($request->input('status') != "") {

            $Route->where('status', $request->input('status'));
        }

       
        if ($request->input('query') != "") {

            $query = $request->input('query');
            
            //SQL AND + OR + Brackets
            $Route->where(function($Route) use ($query) {
                $Route->where('description', 'LIKE', '%'.$query.'%')
                      ->orWhere('long_description', 'LIKE', '%'.$query.'%');
            });

        }


        if ($request->input('pageSize') != "") 
         $pageSize = $request->input('pageSize');
        else
         $pageSize = 50;  

        $Route = $Route->paginate($pageSize);


        
        
        return view('admin.ListRoutes')->with(['routes'=>$Route, "pageSize" => $pageSize]);


    }



    public function editRoute(Request $request)
    {

        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        
        if($request->input('id')=="")
          $Route = new Route;
        else
          $Route = Route::findOrFail( $request->input('id') );


        $sql="select * from module where status='1' order by moduleno ";
        $modules = DB::select(DB::raw($sql));

        $sql="SELECT count(id) as cnt FROM `exercise` WHERE routeno = '".$Route->routeno."' group by `routeno`";
        $RouteExerciseCount = DB::select(DB::raw($sql));

        

        
        return view('admin.EditRoute')->with(["route" => $Route, "modules" => $modules, "RouteExerciseCount" => $RouteExerciseCount]);   
      

    }



    public function saveRoute(Request $request)
    {

        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        
        if($request->input('id')!="")
        {
           
           
            $validator = Validator::make($request->all(), [
                "moduleno"=>"required",
                "routeno"=>"required",
                "description"=>"required"
            ]);
            
    
            if ($validator->fails()) {
                
                $allErrors = $validator->errors()->all();
                return redirect()->back()->with('error', $allErrors[0]);
            }


            $reqNew = array();
            foreach($request->all() as $key=>$value)
            {

                if($value!="")
                  $reqNew[$key] = $value;
                else
                  $reqNew[$key] = ''; 

            }
    
            //print_r($reqNew); die;
            
            $Route = Route::findOrFail( $request->input('id') );
            
            //$Route->update($request->all());

            $Route->update($reqNew);

            return redirect()->back()->with('message', 'Route saved successfully!');


        }
        else
        {

            $validator = Validator::make($request->all(), [
                "moduleno"=>"required",
                "routeno"=>"required",
                "description"=>"required"
            ]);
    
            if ($validator->fails()) {
                
                $allErrors = $validator->errors()->all();
                return redirect()->back()->with('error', $allErrors[0]);
            }
    

            $reqNew = array();
            foreach($request->all() as $key=>$value)
            {

                if($value!="")
                  $reqNew[$key] = $value;
                else
                  $reqNew[$key] = ''; 

            }
                    


            //$Route = Route::create($request->all());  

            $Route = Route::create($reqNew);  


            return redirect()->back()->with('message', 'Route saved successfully!');



        }


    }







    public function deleteRoute(Request $request)
    {
        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        $Route = Route::findOrFail( $request->input('id'));

          if($Route->delete()){
            return redirect()->back()->with('message', 'Route removed successfully!');
          }

    }

    
}
