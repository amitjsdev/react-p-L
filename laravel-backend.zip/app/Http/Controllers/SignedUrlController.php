<?php

namespace App\Http\Controllers;

use App\Cohort;
use Aws\Exception\AwsException;
use Aws\S3\Exception\S3Exception;
use Illuminate\Support\Facades\Log;
use App\S3MultiPartUploadLocal;
use Illuminate\Http\Request;
use App\QuizAttemptLog;
use Illuminate\Support\Facades\Storage;
use App\Jobs\CombinesQuizAttemptVideos;
use App\Jobs\MarkCompleteS3MultipartUploadFixedM;
use Aws\Laravel\AwsFacade;
use App\Mail\TestAttemptConfirm;
use Mail;

class SignedUrlController extends Controller
{
    public $bucket = 'langappnew';
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    public function store(Request $request)
    {
        try {
            $quizAttemptLogId = $request->post('quizAttemptLogId');
            $ext = $request->post('ext');
            $etag = $request->post('etag');
            $anyUploadKey = S3MultiPartUploadLocal::where('quizAttemptLogId', $quizAttemptLogId)->latest()->first();
            $bucket = $this->bucket;
            $keyname = 'lkm/multipartupload/' . $quizAttemptLogId . '.' . $ext;
            $s3 = AwsFacade::createClient('s3');
            if (!$anyUploadKey) {

                $response = $s3->createMultipartUpload(array(
                    'Bucket' => $bucket,
                    'Key' => $keyname,
                    "ContentType" => 'video/webm',
                    'ACL' => 'public-read'
                ));

                $uploadId = $response['UploadId'];
                $part_no = 1;
            } else {
                $anyUploadKey->etag = $etag;
                $anyUploadKey->save();
                $uploadId = $anyUploadKey->UploadId;
                $part_no = $anyUploadKey->part_no + 1;
            }
            if (!$uploadId) {
                return response()->json(['status' => false, 'uploadId' => $uploadId]);
            }

            $cmd = $s3->getCommand('UploadPart', [
                'Bucket' => $bucket,
                'Key' =>  $keyname,
                'UploadId' => $uploadId,
                'PartNumber' => $part_no,
                'Body' => '',
                "ContentType" => 'video/webm'
            ]);

            $createPresignedRequest = $s3->createPresignedRequest($cmd, '+60 minutes');
            // // Get the actual presigned-url
            $presignedUrl = (string)$createPresignedRequest->getUri();

            $SignedUrlDb = S3MultiPartUploadLocal::create([
                'quizAttemptLogId' => $quizAttemptLogId,
                'presignedUrl' => $presignedUrl,
                'part_no' => $part_no,
                'UploadId' => $uploadId,
                'name' => $keyname
            ]);
            return response()->json($SignedUrlDb);
        } catch (S3Exception $e) {
            // Catch an S3 specific exception.
            $msg = $e->getMessage();
            $getCode = $e->getCode();
            return response()->json(['status' => false, 'data' => $msg, 'getCode' => $getCode]);
        } catch (AwsException $e) {
            // This catches the more generic AwsException. You can grab information
            // from the exception using methods of the exception object.
            echo $e->getAwsRequestId() . "\n";
            echo $e->getAwsErrorType() . "\n";
            echo $e->getAwsErrorCode() . "\n";

            // This dumps any modeled response data, if supported by the service
            // Specific members can be accessed directly (e.g. $e['MemberName'])
            $data = ($e->toArray());
            $msg = $e->getMessage();
            return response()->json(['status' => false, 'data' => $data]);
        }
    }

    public function AbortUpload(Request $request)
    {
        try {
            $quizAttemptLogId = $request->post('quizAttemptLogId');
            $latestRecord = S3MultiPartUploadLocal::where('quizAttemptLogId', $quizAttemptLogId)->latest()->first();
            if (!$latestRecord) {
                return response()->json(['status' => false]);
            }

            $UploadId = $latestRecord->UploadId;
            $key = $latestRecord->name;
            $bucket = $this->bucket;
            $s3 = AwsFacade::createClient('s3');
            $isAborted = $s3->abortMultipartUpload([
                'Bucket'   => $bucket,
                'Key' => $key,
                'UploadId' => $UploadId,
            ]);
            $metadata = $isAborted->get('@metadata');
            // $isAborted =  ($isAborted->toArray());
            S3MultiPartUploadLocal::where('quizAttemptLogId', $quizAttemptLogId)->update(['processed'=>0,'status'=>'aborted']);
            return response()->json($metadata);
        } catch (S3Exception $e) {
            // Catch an S3 specific exception.
            $msg = $e->getMessage();
            $getCode = $e->getCode();
            return response()->json(['status' => false, 'data' => $msg, 'getCode' => $getCode]);
        } catch (AwsException $e) {
            // This catches the more generic AwsException. You can grab information
            // from the exception using methods of the exception object.
            echo $e->getAwsRequestId() . "\n";
            echo $e->getAwsErrorType() . "\n";
            echo $e->getAwsErrorCode() . "\n";

            // This dumps any modeled response data, if supported by the service
            // Specific members can be accessed directly (e.g. $e['MemberName'])
            $data = ($e->toArray());
            $msg = $e->getMessage();
            return response()->json(['status' => false, 'data' => $data]);
        }
    }
    public function completeMultipartUpload(Request $request)
    {
        // $all =QuizAttemptLog::where('streamId', '')
        // ->where('created_at','>','2022-02-01')
        // ->get()->pluck('id');
        // foreach($all as $i){
        //     MarkCompleteS3MultipartUploadFixedM::dispatch($i)->delay(now()->addMinutes(10))->onQueue('high');

        // }
        // return response()->json(['status' => $all ]);

        // MarkCompleteS3MultipartUploadFixedM::dispatch($quizAttemptLogId)->delay(now()->addMinutes(10))->onQueue('high');
        $quizAttemptLogId = $request->post('quizAttemptLogId');
        if(!$quizAttemptLogId){
            return response()->json(['status' => false]);
        }
        $attempt =QuizAttemptLog::find($quizAttemptLogId);
        if(!$attempt){
            return response()->json(['status' => false]);
        }
        $userId = auth()->user()->email;
        // get employee
        $employee = \App\Employee::where('userId', $userId)->with('company')->first();
        // get company code
        $companyCode = $employee->CompanyCode;
        $company = \App\Company::where('Id',$companyCode)->first();

        $cohort =Cohort::find($attempt->cohortId);
        Mail::to($employee->userId)
        ->send(new TestAttemptConfirm(
            $employee->FirstName,
            $cohort->name,
            $company->Name,
            $company->Id,
            $cohort->senderEmail,
            $company->Name
        ));
        $aiTimer = $request->post('aiTimer');
        $now = $request->post('now');
        if($aiTimer){
            QuizAttemptLog::where('id',$quizAttemptLogId)->update(['ai_result'=>json_encode($aiTimer),'attemptStatus'=>1 ]);
        }
        $latestRecord = S3MultiPartUploadLocal::where('quizAttemptLogId', $quizAttemptLogId)->latest()->first();
        if (!$latestRecord) {
            return response()->json(['status' => false]);
        }

        if ($now) {
           MarkCompleteS3MultipartUploadFixedM::dispatch($quizAttemptLogId)->onQueue('high');
            // $c =new  MarkCompleteS3MultipartUploadFixedM($quizAttemptLogId);
            // $f =$c->handle();
            // return response()->json(['status' => true,$f]);
            return response()->json(['status' => true]);
        } else {
            MarkCompleteS3MultipartUploadFixedM::dispatch($quizAttemptLogId)->delay(now()->addMinutes(10))->onQueue('high');
        }
        return response()->json(['status' => true ]);
    }

    public function CombineS3Files($id)
    {
        $ck = new CombinesQuizAttemptVideos($id, true);
        $r = $ck->handle();
        return response()->json(['id' => $id, 'status' => true, 'r' => $r]);
    }
    public function CombineS3FilesMulti(Request $request)
    {

        $ids = $request->post('ids');
        $mkv = $request->post('mkv');
        $r = '';
        foreach ($ids as $id) {
            if ($mkv) {
                $this->doMkverge($id, true);
            } else {
                $ck = new CombinesQuizAttemptVideos($id, true);
                $r = $ck->handle();
            }

            echo $id;
        }

        return response()->json(['id' => $ids, 'status' => true, 'r' => $r, 'mkv' => $mkv]);
    }
    public function CombineS3FilesMultiBatch(Request $request)
    {

        $ids = $request->post('ids');
        $rows = QuizAttemptLog::whereBetween('id', $ids)->get();
        foreach ($rows as $row) {
            CombinesQuizAttemptVideos::dispatch($row->id, true);
        }

        return response()->json(['id' => $ids, 'status' => true]);
    }
    public function doMkverge($id, $ignore)
    {
        // CombinesQuizAttemptVideos::dispatch($id)->delay(now()->addMinutes(1));
        $rows = SignedUrl::where('quizAttemptLogId', $id)->where('processed', null)->get();
        if ($ignore) {
            $rows = SignedUrl::where('quizAttemptLogId', $id)->get();
        }
        if (!$rows->count()) {
            return null;
        }
        // mkvmerge -o output.webm 1.webm + 2.webm +3.webm
        $names = [];
        foreach ($rows as $row) {
            try {
                $contents = file_get_contents('https://langappnew.s3.amazonaws.com/' . $row->key);
                Storage::disk('local')->put($id . '/' . $row->name, $contents);
                $names[] = storage_path("app/$id/$row->name");
            } catch (\Exception $e) {
                Log::info('CombineS3Files fetch video',  $e->getMessage());
            }
        }
        $names = join(' + ', $names);
        $outputFileLocation = storage_path("app");
        $outputFile = $outputFileLocation . "/$id.mp4";
        $cmd = "mkvmerge -o $outputFile $names";
        exec($cmd, $output);
        $result = ob_get_contents();
        Log::info('s3 upload status', [$result, $output, $cmd]);
        ob_end_clean();
        uploadCombineToS3($id, $outputFile, "$id.mp4", true);

        Storage::deleteDirectory($id);
        foreach ($rows as $row) {
            $row->processed = true;
            $row->save();
        }
        QuizAttemptLog::where('id', $id)->update(['streamId' => "uploads/combinedquizvideos/$id/$id.mp4"]);
        return true;
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\SignedUrl  $signedUrl
     * @return \Illuminate\Http\Response
     */
    public function show(SignedUrl $signedUrl)
    {

        return response()->json($signedUrl);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\SignedUrl  $signedUrl
     * @return \Illuminate\Http\Response
     */
    public function edit(SignedUrl $signedUrl)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\SignedUrl  $signedUrl
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, SignedUrl $signedUrl)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\SignedUrl  $signedUrl
     * @return \Illuminate\Http\Response
     */
    public function destroy(SignedUrl $signedUrl)
    {
        //
    }
    public function test(Request $request)
    {
            $bucket = $this->bucket;
            $name =$request->post('name');
            $UploadId =$request->post('UploadId');
            $s3 = AwsFacade::createClient('s3');
            $partsModel = $s3->listParts(array(
                'Bucket' => $bucket,
                'Key'       => $name,
                'UploadId'  => $UploadId
            ));
            $partsModel =  ($partsModel->toArray());
            $rows =$partsModel['Parts'];
            if(!count($rows)){
               ['status'=>false];
            }
            foreach($rows as $row){
                $parts[] = array(
                    'PartNumber' => $row['PartNumber'],
                    'ETag'       => $row['ETag'],
                );
            }

            $model = $s3->completeMultipartUpload(array(
                'Bucket' => $bucket,
                'Key'       => $name,
                'UploadId'  => $UploadId,
                'MultipartUpload' => Array(
                    'Parts' => $parts,
                ),
            ));
            return response()->json($model);
    }

    public function Reverse($id){
        try {
            $quizAttemptLogId = $id;
            $latestRecord = S3MultiPartUploadLocal::where('quizAttemptLogId', $quizAttemptLogId)->latest()->first();
            if (!$latestRecord) {
                Log::error($quizAttemptLogId,  ['status'=>false,'latestRecord'=>null]);
                return ['status'=>false];
            }
            $bucket = $this->bucket;
            $s3 = AwsFacade::createClient('s3');
            $partsModel = $s3->listParts(array(
                'Bucket' => $bucket,
                'Key'       => $latestRecord->name,
                'UploadId'  => $latestRecord->UploadId
            ));
            $partsModel =  ($partsModel->toArray());
            $rows =$partsModel['Parts'];
            if(!count($rows)){
               ['status'=>false];
            }
            foreach($rows as $row){
                $parts[] = array(
                    'PartNumber' => $row['PartNumber'],
                    'ETag'       => $row['ETag'],
                );
            }

            $model = $s3->completeMultipartUpload(array(
                'Bucket' => $bucket,
                'Key'       => $latestRecord->name,
                'UploadId'  => $latestRecord->UploadId,
                'MultipartUpload' => Array(
                    'Parts' => $parts,
                ),
            ));
            $metadata = $model->get('@metadata');
            $model =  ($model->toArray());

            S3MultiPartUploadLocal::where('quizAttemptLogId', $quizAttemptLogId)->update(['processed'=>1,'status'=>'completed']);
            $info =[$rows,$model,$metadata];
            Log::info($id, $info);
            QuizAttemptLog::where('id',$quizAttemptLogId)->update(['streamId'=>$latestRecord->name]);
            Log::info('all ok  retuning', [$quizAttemptLogId]);
            return $info;
        }
        catch (S3Exception $e) {
            // Catch an S3 specific exception.
            $msg = $e->getMessage();
            $getCode = $e->getCode();
            $err =['status'=>false, 'data'=>$msg, 'getCode'=>$getCode];
            Log::error($id, $err);
            return $err;
        } catch (AwsException $e) {
            $data =($e->toArray());
            $msg =$e->getMessage();
            $err =['status'=>false, 'data'=>$data];
            Log::error($id, $err);
            return $err;
        }
    }

    public function QueueStatus(){

        exec('sudo supervisorctl status 2>&1', $output);
        $msg =is_array($output) ? implode(', ', $output) : $output;
        if($msg){

            if (!strpos($msg, 'aravel')) {
                Mail::raw('Supervisor stopped    '.$msg, function ($message) {
                    $message->to('lkm1developer@gmail.com')
                    ->cc(['santanu@taplingua.com'])
                      ->subject('Supervisor stopped');
                  });

            } else if (strpos($msg, 'aravel') && strpos($msg, 'STOPPED')) {
                Mail::raw('Supervisor stopped    '.$msg, function ($message) {
                    $message->to('lkm1developer@gmail.com')
                    ->cc(['santanu@taplingua.com'])
                      ->subject('Supervisor stopped');
                  });

            }


        }
        return response()->json(['msg'=>$msg,'o'=>$output, 't'=>strpos($msg, 'aravel')]);
    }
}
