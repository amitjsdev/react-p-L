<?php

namespace App\Http\Controllers;

use App\StarAnswer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class StarAnswerController extends Controller
{
    public function getAllAnswersForUser(Request $request)
    {
        $answers = StarAnswer::where('userId', auth()->user()->email)->get()
            ->map(function ($answer) {
                $answer->situationDesc = json_decode($answer->situationDesc);
                $answer->taskDesc = json_decode($answer->taskDesc);
                $answer->actionDesc = json_decode($answer->actionDesc);
                $answer->resultDesc = json_decode($answer->resultDesc);

                return $answer;
            });
        return response()->json([
            "message" => "Star Answers",
            "answers" => $answers,
        ]);
    }

    public function saveAnswer(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'storyTitle' => 'required|max:190',
            'situationDesc' => 'required|array|min:1',
            'situationDesc.*' => 'required|string',
            'taskDesc' => 'required|array|min:1',
            'taskDesc.*' => 'required|string',
            'actionDesc' => 'required|array|min:1',
            'actionDesc.*' => 'required|string',
            'resultDesc' => 'required|array|min:1',
            'resultDesc.*' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                "errors" => $validator->errors()
            ], 422);
        }

        $validated = $validator->validated();

        $answer = StarAnswer::create([
            'userId' => auth()->user()->email,
            'storyTitle' => $validated['storyTitle'],
            'situationDesc' => json_encode($validated['situationDesc']),
            'taskDesc' => json_encode($validated['taskDesc']),
            'actionDesc' => json_encode($validated['actionDesc']),
            'resultDesc' => json_encode($validated['resultDesc']),
        ]);

        $answer->situationDesc = json_decode($answer->situationDesc);
        $answer->taskDesc = json_decode($answer->taskDesc);
        $answer->actionDesc = json_decode($answer->actionDesc);
        $answer->resultDesc = json_decode($answer->resultDesc);

        return response()->json([
            "message" => "Star Answer Saved!",
            "answer" => $answer
        ]);
    }
}
