<?php

namespace App\Http\Controllers;

use App\TeacherBooking;
use App\TeachingSlot;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TeacherBookingController extends Controller
{
    const LIMIT = 1;

    function ui()
    {
        return view('booking');
    }

    /**
     * Get list of free slots for next 7 days
     *
     * @return void
     */
    function getFreeSlots()
    {
        $slots = TeachingSlot::all()->pluck('start_time');

        // get slots for next 7 days
        $freeSlots = [
            today()->format("Y-m-d") => $this->getFreeSlotsFor(today(), $slots),
            today()->addDays(1)->format("Y-m-d") => $this->getFreeSlotsFor(today()->addDays(1), $slots),
            today()->addDays(2)->format("Y-m-d") => $this->getFreeSlotsFor(today()->addDays(2), $slots),
            today()->addDays(3)->format("Y-m-d") => $this->getFreeSlotsFor(today()->addDays(3), $slots),
            today()->addDays(4)->format("Y-m-d") => $this->getFreeSlotsFor(today()->addDays(4), $slots),
            today()->addDays(5)->format("Y-m-d") => $this->getFreeSlotsFor(today()->addDays(5), $slots),
            today()->addDays(6)->format("Y-m-d") => $this->getFreeSlotsFor(today()->addDays(6), $slots),
        ];

        return response()->json([
            'message' => 'Free slots',
            'freeSlots' => $freeSlots
        ]);
    }

    function bookASlot(Request $request)
    {
        $validated = $request->validate([
            'date' => 'required:date',
            'start_time' => 'required'
        ]);

        $slots = TeachingSlot::all()->pluck('start_time');

        $freeSlots = $this->getFreeSlotsFor(Carbon::parse($request->date), $slots);

        if (!isset($freeSlots[$request->start_time])) {
            return response()->json([
                "message" => "Validation error!",
                "errors" => [
                    "start_time" => [
                        "Slot unavailable!"
                    ]
                ]
            ], 422);
        }

        $remainingSlots = $freeSlots[$request->start_time];

        if($remainingSlots < 1) {
            return response()->json([
                "message" => "Validation error!",
                "errors" => [
                    "start_time" => [
                        "Slot unavailable!"
                    ]
                ]
            ], 422);
        }

        // book the slot
        $booking = TeacherBooking::create([
            'start_time' => $request->start_time,
            'dated' => $request->date,
            'userId' => $request->user()->email
        ]);

        return response()->json([
            "message" => "Booking successful!",
            "booking" => $booking
        ]);
    }

    function getFreeSlotsFor(Carbon $date, $slots)
    {
        $filledSlotsCollection = TeacherBooking::whereDate('dated', $date)
            ->select('start_time', DB::raw('count(*) as filled'))
            ->whereIn('start_time', $slots)
            ->groupBy('start_time')
            ->get();

        $filledSlots = array_combine($slots->toArray(), array_fill(0, $slots->count(), 0));

        foreach ($filledSlotsCollection as $slot) {
            $filledSlots[$slot->start_time] = $slot->filled;
        }

        $availableSlots = array_filter(array_map(function ($filled) {
            return self::LIMIT - $filled;
        }, $filledSlots), function($value) {
            return $value > 0;
        });

        return $availableSlots;
    }
}
