<?php

namespace App\Http\Controllers;

use App\Jobs\ProcessQuizAttemptVideoWithAIScript;
use App\Exports\UsersExport;
use Maatwebsite\Excel\Facades\Excel;

class TestController extends Controller
{
    public function test()
    {

        // $ck =\Artisan::call('queue:work');
        // ProcessQuizAttemptVideoWithAIScript::dispatch(184);
        return response()->json(['status' => 'ooo']);
    }
    public function RegenerateInterviewAiRating($id)
    {

        $ck =\Artisan::call("airating:rerun $id");

        // ProcessQuizAttemptVideoWithAIScript::dispatch(184);
        return response()->json(['status' => $id, 'ck'=>$ck]);
    }


    public function export()
    {
        return Excel::download(new UsersExport, 'users.xlsx');
    }

}
