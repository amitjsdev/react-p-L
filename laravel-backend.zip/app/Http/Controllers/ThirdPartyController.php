<?php

namespace App\Http\Controllers;

use App\Events\UserAddedToCohort;
use App\Mail\EnrolledEmployeeWelcomeEmail;
use App\Module;
use App\PaymentLog;
use App\QuickbloxGroupUser;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;

class ThirdPartyController extends Controller
{
    /**
     * Enroll Employee
     *
     * @param Request $request
     * @return void
     */
    public function enrollEmployee(Request $request)
    {
        // validate the request
        $this->validate($request, [
            'courseNo' => 'required|exists:courses,courseNumber',
            'email' => 'required|email',
            'firstName' => 'nullable|string',
            'lastName' => 'nullable|string',
            'mobile' => 'nullable|numeric|digits:10',
            'location' => 'nullable|string',
        ]);

        try {
            // get the course
            $course = \App\Course::where('courseNumber', $request->courseNo)->first();
            // get the module
            $module = Module::where('moduleno', $course->moduleNumber)->first();
            // create an employee with the information
            $employee = \App\Employee::where('userId', $request->email)->first();

            if (!$employee) {
                // check if mobile already token
                if (\App\Employee::where('Mobile', $request->mobile)->exists()) {
                    return response()->json([
                        "message" => "Validator error!",
                        "errors" => [
                            "mobile" => ["Mobile already taken by other user!"]
                        ]
                    ]);
                }

                $employee = \App\Employee::create([
                    'currentCourse' => $request->courseNo,
                    'currentModule' => $course->moduleNumber,
                    'CompanyCode' => $course->Company,
                    'FirstName' => $request->firstName ?? "",
                    'LastName' => $request->lastName ?? "",
                    'userId' => $request->email,
                    'Mobile' => $request->mobile ?? "",
                    'Location' => $request->location ?? "",
                    'accountCreationDate' => now(),
                ]);
            }
            // check if course already there
            $courseSubscribed = \DB::table('employeecourse')->where('userId', $employee->userId)
                ->where('courseNumber', $request->courseNo)->first();
            if ($courseSubscribed) {
                // Send SMS
                sendSMS("+91" . $request->mobile, "Hi " . $request->firstName . " 
                    \nYou are registered to The Taplingua Program.
                    \nPlease download the Taplingua Language app:
                    \nhttps://play.google.com/store/apps/details?id=com.taplingua.languages
                    \nPlease check your email for account login details.
                    \nThanks
                    \nTaplingua Team");
                return response()->json([
                    "message" => "The email address is already registered for the course."
                ], 400);
            }
            // assign the employee to the said course
            \DB::table('employeecourse')->insert([
                'dateRegistered' => now(),
                'userId' => $employee->userId,
                'courseNumber' => $request->courseNo,
            ]);

            $password = substr(md5(now()), 0, 8);

            // get the user
            $user = User::where('email', $employee->userId)->first();

            if (!$user) {
                // create the user
                $user = User::create([
                    "email" => $employee->userId,
                    "fullname" => $employee->FirstName . " " . $employee->LastName,
                    "password" => bcrypt($password),
                    'token' => md5($employee->userId . time()),
                    'uid' => uniqid(),
                    'accesslevel' => 0
                ]);
                $isNewUser = true;
                // send mail
                Mail::to($employee->userId)
                    ->send(new EnrolledEmployeeWelcomeEmail(
                        $user->fullname,
                        $module->description,
                        $employee->userId,
                        $password
                    ));

                // Send SMS
                sendSMS("+91" . $request->mobile, "Hi " . $request->firstName . " 
                    \nYour taplingua account has been created.
                    \nPlease download the Taplingua Language app:
                    \nhttps://play.google.com/store/apps/details?id=com.taplingua.languages
                    \nPlease check your email for account login details.
                    \nThanks
                    \nTaplingua Team");
            } else {
                // send mail
                Mail::to($employee->userId)
                    ->send(new EnrolledEmployeeWelcomeEmail(
                        $user->fullname,
                        $module->description,
                        $employee->userId,
                        ""
                    ));

                // Send SMS
                sendSMS("+91" . $request->mobile, "Hi " . $request->firstName . " 
                    \nYou are registered to The Taplingua Program.
                    \nPlease download the Taplingua Language app:
                    \nhttps://play.google.com/store/apps/details?id=com.taplingua.languages
                    \nThanks
                    \nTaplingua Team");
            }

            // return success message
            return response()->json([
                "message" => "User is registered!",
                "data" => $request->all()
            ]);
        } catch (\Throwable $th) {
            \Log::error("Could not register user to course!");
            return response()->json([
                "message" => "User could not be registered!"
            ], 500);
        }
    }

    public function updateSubscription(Request $request)
    {
        try {
            // get all the data
            $response = $request->validate([
                "email" => "required|exists:employee,userId",
                "mrp" => "required|gte:actualPrice",
                "actualPrice" => "required",
                "discountCode" => "string|nullable",
                "courseNo" => "required|exists:courses,courseNumber",
                "durationInMonth" => "required|numeric|max:12",
                "subscriptionEndDate" => "required|date|after_or_equal:now",
            ]);

            if (Carbon::parse($request->subscriptionEndDate)->gte(now()->addYear())) {
                return response()->json([
                    "message" => "The given data was invalid.",
                    "errors" => [
                        "subscriptionEndDate" => [
                            "The subscription expires date must be a date before one year from now."
                        ]
                    ]
                ], 422);
            }

            // get employeecourse data
            $employeeCourse = DB::table("employeecourse")
                ->where("userId", $request->email)
                ->where("courseNumber", $request->courseNo)
                ->first();

            if (!$employeeCourse) {
                return response()->json([
                    "message" => "Could not update user subscription!"
                ], 400);
            }

            try {
                $moduleNo = getCourseModule($request->courseNo);
            } catch (\Throwable $th) {
                $moduleNo = null;
            }

            if (!$moduleNo) {
                return response()->json([
                    "message" => "Course not found!"
                ], 400);
            }

            // update the subscription end time in employeeCourse;
            DB::table("employeecourse")
                ->where("userId", $request->email)
                ->where("courseNumber", $request->courseNo)
                ->update([
                    'subscriptionExpiresDate' => $request->subscriptionEndDate
                ]);

            // create the record
            $paymentLog = PaymentLog::create([
                "userId" => $request->email,
                "mrp" => $request->mrp,
                "actualPrice" => $request->actualPrice,
                "discountCode" => $request->discountCode,
                "courseNo" => $request->courseNo,
                "moduleNo" => $moduleNo,
                "durationInMonth" => $request->durationInMonth,
                "subscriptionEndDate" => $request->subscriptionEndDate,
            ]);

            return response()->json([
                "message" => "Subscription updated!",
                "paymentLog" => $paymentLog,
            ]);
        } catch (\Throwable $th) {
            \Log::error("Could not update user subscription!");
            return response()->json([
                "message" => "Could not update user subscription!"
            ], 500);
        }
    }

    public function showUpdateSubscriptionAPIForm(Request $request)
    {
        return view("app.test-subscription-update-form");
    }



    /**
     * register user to cohort
     *
     * @param Request $request
     * @param [type] $cohort_id
     * @return void
     */
    public function registerUserToCohort(Request $request)
    {
        $this->validate($request, [
            'cohort_id' => 'required|exists:cohorts,id',
            'email' => 'required|email',
            'FirstName' => 'nullable|string',
            'LastName' => 'nullable|string',
            'mobile' => 'nullable|numeric|digits:10',
            'location' => 'nullable|string',
        ]);

        $cohort = \App\Cohort::find($request->cohort_id);

        $program = $cohort->program;

        // get the module
        $module = $program->first_module;

        $course = $cohort->getCourseByModuleNo($module->moduleno);

        // get employee with the information
        $employee = \App\Employee::where('userId', $request->email)->first();
        // check employee companyCode
        if ($employee && $employee->CompanyCode != $cohort->company_code) {
            return response()->json([
                "message" => "The given data was invalid.",
                "errors" => [
                    "email" => [
                        "The email is registered to another company."
                    ]
                ]
            ]);
        }

        try {

            if (!$employee) {
                // check if mobile already token
                if (\App\Employee::where('Mobile', $request->mobile)->exists()) {
                    return response()->json([
                        "message" => "Validator error!",
                        "errors" => [
                            "mobile" => ["Mobile already taken by other user!"]
                        ]
                    ]);
                }

                $employee = \App\Employee::create([
                    'currentCourse' => $course->courseNumber,
                    'currentModule' => $course->moduleNumber,
                    'CompanyCode' => $course->Company,
                    'FirstName' => $request->firstName ?? "",
                    'LastName' => $request->lastName ?? "",
                    'userId' => $request->email,
                    'Mobile' => $request->mobile ?? "",
                    'Location' => $request->location ?? "",
                    'accountCreationDate' => now(),
                ]);
            }

            // for each cohort module register user if not already registered
            foreach ($program->modules as $module) {
                // the module related course
                $moduleCourse = $cohort->getCourseByModuleNo($module->module_number);
                // check if course already there
                $courseSubscribed = \DB::table('employeecourse')->where('userId', $employee->userId)
                    ->where('courseNumber', $moduleCourse->courseNumber)->first();
                if ($courseSubscribed) {
                    //  do nothing
                    // return redirect()->back()->withInput()->with('error', 'Course already subscribed to!');
                } else {
                    // assign the employee to the said course
                    \DB::table('employeecourse')->insert([
                        'dateRegistered' => now(),
                        'userId' => $employee->userId,
                        'courseNumber' => $moduleCourse->courseNumber,
                    ]);
                }
            }

            $password = substr(md5(now()), 0, 8);

            // get the user
            $user = \App\User::where('email', $employee->userId)->first();

            if (!$user) {
                // create the user
                $user = \App\User::create([
                    "email" => $employee->userId,
                    "fullname" => $employee->FirstName . " " . $employee->LastName,
                    "password" => bcrypt($password),
                    'token' => md5($employee->userId . time()),
                    'uid' => uniqid(),
                    'accesslevel' => 0
                ]);
                $isNewUser = true;
                // send mail
                \Mail::to($employee->userId)
                    ->send(new EnrolledEmployeeWelcomeEmail(
                        $user->fullname,
                        $module->description,
                        $employee->userId,
                        $password
                    ));

                // Send SMS
                sendSMS("+91" . $request->mobile, "Hi " . $request->firstName . " 
                    \nYour taplingua account has been created.
                    \nPlease download the Taplingua Language app:
                    \nhttps://play.google.com/store/apps/details?id=com.taplingua.languages
                    \nPlease check your email for account login details.
                    \nThanks
                    \nTaplingua Team");
            } else {
                // send mail anyway
                Mail::to($employee->userId)
                    ->send(new EnrolledEmployeeWelcomeEmail(
                        $user->fullname,
                        $module->description,
                        $employee->userId,
                        ""
                    ));

                // Send SMS
                sendSMS("+91" . $request->mobile, "Hi " . $request->firstName . " 
                    \nYou are registered to a new course.
                    \nPlease download the Taplingua Language app:
                    \nhttps://play.google.com/store/apps/details?id=com.taplingua.languages
                    \nThanks
                    \nTaplingua Team");
            }

            event(new UserAddedToCohort($employee->userId, $cohort->id));


            // QUICKBLOX: add user to group - start
            \App\Services\QuickBlox::createUserIfNeededAndAddToGroup($cohort->id, $employee->userId);
            // QUICKBLOX: add user to group - end

            // return success message
            return response()->json([
                "message" => "User is registered to {$cohort->name}!",
                "data" => $request->all()
            ]);
        } catch (\Throwable $th) {
            \Log::error("Could not register user to cohort!", [$th]);
            return response()->json([
                "message" => "User could not be registered!"
            ], 500);
        }
    }


    /**
     * Register user to unmanaged progrm, will create the cohort on the go
     *
     * @param Request $request
     * @param [type] $company_code
     * @param [type] $program_id
     * @return void
     */
    public function registerUserToUnmanagedCohort(Request $request)
    {
        $this->validate($request, [
            "companyCode" => "required|exists:company,Id",
            "programId" => "required|exists:programs,id",
            'email' => 'required|email',
            'firstName' => 'nullable|string',
            'lastName' => 'nullable|string',
            'mobile' => 'nullable|numeric|digits:10',
            'location' => 'nullable|string',
        ]);

        $program_id = $request->programId;
        $company_code = $request->companyCode;

        // get program
        $program = \App\Program::find($program_id);

        // get company
        $company = \App\Company::where("Id", $company_code)->first();

        // check if any cohort for curretn user already there
        $cohortAlreadyExists = \App\Cohort::distinct('userId')
            ->join("courses", "courses.cohort_id", "=", 'cohorts.id')
            ->join("employeecourse", "employeecourse.courseNumber", "=", "courses.courseNumber")
            ->where("program_id", $program_id)
            ->where("company_code", $company_code)
            ->where("employeecourse.userId", $request->email)
            ->exists();

        // get the module
        $module = $program->first_module;

        if ($cohortAlreadyExists) {
            // send mail anyway
            Mail::to($request->email)
                ->send(new EnrolledEmployeeWelcomeEmail(
                    $request->firstName,
                    $module->description,
                    $request->email,
                    ""
                ));

            // Send SMS
            sendSMS("+91" . $request->mobile, "Hi " . $request->firstName . " 
                    \nYou are registered to The Taplingua Program.
                    \nPlease download the Taplingua Language app:
                    \nhttps://play.google.com/store/apps/details?id=com.taplingua.languages
                    \nThanks
                    \nTaplingua Team");
            // return success message
            return response()->json([
                "message" => "User is registered to {$program->name}!",
                "data" => $request->all()
            ]);
        }

        // get employee with the information
        $employee = \App\Employee::where('userId', $request->email)->first();
        // check employee companyCode
        if ($employee && $employee->CompanyCode != $company_code) {
            return response()->json([
                "message" => "The given data was invalid.",
                "errors" => [
                    "email" => [
                        "The email is registered to another company."
                    ]
                ]
            ]);
        }

        // create cohort for this program
        $cohort = $this->createCohortFromCompanyCodeAndProgramId($program->id, $company->Id, null, null, true);

        // get the module
        $module = $program->first_module;

        $course = $cohort->getCourseByModuleNo($module->moduleno);

        try {

            if (!$employee) {
                // check if mobile already token
                if (\App\Employee::where('Mobile', $request->mobile)->exists()) {
                    return response()->json([
                        "message" => "Validator error!",
                        "errors" => [
                            "mobile" => ["Mobile already taken by other user!"]
                        ]
                    ]);
                }

                $employee = \App\Employee::create([
                    'currentCourse' => $course->courseNumber,
                    'currentModule' => $course->moduleNumber,
                    'CompanyCode' => $course->Company,
                    'FirstName' => $request->firstName ?? "",
                    'LastName' => $request->lastName ?? "",
                    'userId' => $request->email,
                    'Mobile' => $request->mobile ?? "",
                    'Location' => $request->location ?? "",
                    'accountCreationDate' => now(),
                    'utm_source' => $request->utm_source
                ]);
            }

            // for each cohort module register user if not already registered
            foreach ($program->modules as $module) {
                // the module related course
                $moduleCourse = $cohort->getCourseByModuleNo($module->module_number);
                // check if course already there
                $courseSubscribed = \DB::table('employeecourse')->where('userId', $employee->userId)
                    ->where('courseNumber', $moduleCourse->courseNumber)->first();
                if ($courseSubscribed) {
                    //  do nothing
                    // return redirect()->back()->withInput()->with('error', 'Course already subscribed to!');
                } else {
                    // assign the employee to the said course
                    \DB::table('employeecourse')->insert([
                        'dateRegistered' => now(),
                        'userId' => $employee->userId,
                        'courseNumber' => $moduleCourse->courseNumber,
                    ]);
                }
            }

            $password = substr(md5(now()), 0, 8);

            // get the user
            $user = \App\User::where('email', $employee->userId)->first();

            if (!$user) {
                // create the user
                $user = \App\User::create([
                    "email" => $employee->userId,
                    "fullname" => $employee->FirstName . " " . $employee->LastName,
                    "password" => bcrypt($password),
                    'token' => md5($employee->userId . time()),
                    'uid' => uniqid(),
                    'accesslevel' => 0
                ]);
                $isNewUser = true;
                // send mail
                \Mail::to($employee->userId)
                    ->send(new EnrolledEmployeeWelcomeEmail(
                        $user->fullname,
                        $module->description,
                        $employee->userId,
                        $password
                    ));

                // Send SMS
                sendSMS("+91" . $request->mobile, "Hi " . $request->firstName . " 
                    \nYour taplingua account has been created.
                    \nPlease download the Taplingua Language app:
                    \nhttps://play.google.com/store/apps/details?id=com.taplingua.languages
                    \nPlease check your email for account login details.
                    \nThanks
                    \nTaplingua Team");
            } else {
                // send mail anyway
                Mail::to($employee->userId)
                    ->send(new EnrolledEmployeeWelcomeEmail(
                        $user->fullname,
                        $module->description,
                        $employee->userId,
                        ""
                    ));

                // Send SMS
                sendSMS("+91" . $request->mobile, "Hi " . $request->firstName . " 
                    \nYou are registered to The Taplingua Program.
                    \nPlease download the Taplingua Language app:
                    \nhttps://play.google.com/store/apps/details?id=com.taplingua.languages
                    \nThanks
                    \nTaplingua Team");
            }
            // return success message
            return response()->json([
                "message" => "User is registered to {$program->name}!",
                "data" => $request->all()
            ]);
        } catch (\Throwable $th) {
            \Log::error("Could not register user to cohort!", [$th]);
            return response()->json([
                "message" => "User could not be registered!"
            ], 500);
        }
    }


    private function createCohortFromCompanyCodeAndProgramId($program_id, $company_code, $start_date = null, $name = null, $is_dynamic = false)
    {
        // get a start date
        $startDate = $start_date ? Carbon::parse($start_date) : null;

        $program = \App\Program::find($program_id);

        // create the cohort
        $cohort = \App\Cohort::create([
            "name" => $name ? $name : $program->name,
            "program_id" => $program_id,
            "company_code" => $company_code,
            "start_date" => $startDate,
            "is_dynamic" => $is_dynamic,
        ]);
        // create course for every program in that module, for this cohort
        $modules = $cohort->program->modules->sort(function ($a, $b) {
            return $a->sort_order - $b->sort_order;
        });

        // sort index
        $moduleSortIndex = [];
        foreach ($modules as $module) {
            $moduleSortIndex[] = $module->module_number;
        }

        $moduleSortIndex = array_flip($moduleSortIndex);

        // for each module, create the course
        foreach ($modules as $index => $module) {
            \App\Course::create([
                "cohort_id" => $cohort->id,
                "Company" => $company_code,
                "courseStartDate" => $startDate ? Carbon::parse($startDate)->addWeeks(($moduleSortIndex[$module->moduleno]) * 3) : today(),
                "courseEndDate" => $startDate ? Carbon::parse($startDate)->addWeeks(($moduleSortIndex[$module->moduleno] + 1) * 3) : today(),
                "courseName" => $module->module->description,
                "courseNumber" => time() . $index,
                "moduleNumber" => $module->module_number,
                "numberOfWeeks" => 3
            ]);
        }

        // return $cohort;
        return $cohort;
    }
}
