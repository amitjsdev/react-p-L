<?php

namespace App\Http\Controllers;

use App\Course;
use App\Employee;
use App\Todo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TodoListController extends Controller
{
    public function daily(Request $request)
    {
        // get user id
        $userId = auth()->user()->email;
        // update user's task list status
        updateTodoListStatusForUserId($userId);
        // generate todolist response
        $response = getTodoListByUserId($userId);
        // add useriD and current module
        $response["userId"] = $userId;
        $response["moduleNo"] = Course::where("courseNumber", $response["currentCourse"])->first()->moduleNumber;
        // rename moduleRouteLesson to moduleRouteLevelLesson
        $activities = array_map(function ($activity) {
            // add moduleRouteLevelLesson To the acitivity
            $activity['moduleRouteLevelLesson'] = $activity["moduleRouteLesson"];
            // remove the moduleRouteLesson from activity
            unset($activity["moduleRouteLesson"]);
            return $activity;
        }, $response['activities']);
        // sort them using activity Type
        usort($activities, function ($a, $b) {
            if($a["activityType"] == 981) {
                return -1;
            }
            if ($b["activityType"] == 981) {
                return 1;
            }
            return $a["activityType"] - $b["activityType"];
        });
        $response['activities'] = $activities;
        // send response
        return response()->json($response);
    }

    /**
     * Returns user's streak details -
     *
     * @param Request $request
     * @return mixed json
     */
    public function streak(Request $request)
    {
        // get user id
        $userId = auth()->user()->email;
        // get start date of week
        $startOfWeek = now()->startOfWeek();
        // get current employee
        $employee = Employee::where('userId', $userId)->first();
        $maxStreak = $employee->maxStreak;
        $maxStreakDate = $employee->maxStreakDate;
        $currentStreak = $employee->currentStreak;
        $currentStreakDate = $employee->currentStreakDate;
        // get sum of activity status of todo items grouped by date for current user
        $pointer = \Carbon\Carbon::now()->startOfWeek();

        $progress = [];

        while (!$pointer->isSameDay(\Carbon\Carbon::now()->endOfWeek()->addDay())) {

            $progress[] = \App\UserDailyGoalLog::where('userId', $userId)
                ->select('id', 'userId', 'created_at', 'dated', DB::raw('sum(points) as goal_attained'))
                ->having('goal_attained', '>=', $employee->daily_goal_total)
                ->whereDate('dated', $pointer)
                ->groupBy("dated")
                ->orderBy("dated", 'desc')
                ->exists() ? 1 : 0;

            $pointer->addDay();
        }
        // return response
        return response()->json([
            "userId" => $userId,
            "currentDate" => now()->format("Y-m-d"),
            "daily_goal_attained" => $employee->daily_goal_attained,
            "currentStreak" => $currentStreak,
            "currentStreakDate" => $currentStreakDate,
            "maxStreak" => $maxStreak,
            "maxStreakDate" => $maxStreakDate,
            "progress" => $progress,
        ]);
    }
}
