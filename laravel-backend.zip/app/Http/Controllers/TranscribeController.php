<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\ModelNotFoundException;

use App\Http\Requests;
use App\Transcribe;
use App\Http\Resources\Transcribe as TranscribeResource;

use DB;
use Session;
use Illuminate\Support\Facades\Validator;


class TranscribeController extends Controller
{
    


    /* CMS */

    
    public function listTranscribes(Request $request)
    {

        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

           $Transcribe = Transcribe::query(); 

           $Transcribe->orderBy('id','asc');
   
           /*if ($request->input('moduleNo') != "") {
   
               $cards->where('moduleNo', $request->input('moduleNo'));
           }
   
           if ($request->input('routeNo') != "") {
   
               $cards->where('routeNo', $request->input('routeNo'));
           }
   
           if ($request->input('lessonNo') != "") {
   
               $cards->where('lesssonNo', $request->input('lessonNo'));
           }*/
   
           if ($request->input('query') != "") {
   
               $query = $request->input('query');
               
               //$cards->where('translatedText', 'LIKE', "%{$query}%")->orWhere('originalText', 'LIKE', "%{$query}%");
   
               //SQL AND + OR + Brackets
               $Transcribe->where(function($Transcribe) use ($query) {
                   $Transcribe->where('jobName', 'LIKE', '%'.$query.'%')
                         ->orWhere('mediaFolder', 'LIKE', '%'.$query.'%');
               });
   
           }


        if ($request->input('pageSize') != "") 
         $pageSize = $request->input('pageSize');
        else
         $pageSize = 50;  

        $Transcribe = $Transcribe->paginate($pageSize);


        
        
        return view('admin.ListTranscribes')->with(['transcribes'=>$Transcribe, "pageSize" => $pageSize]);


    }


    public function editTranscribe(Request $request)
    {

        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        
        if($request->input('id')=="")
          $Transcribe = new Transcribe;
        else
          $Transcribe = Transcribe::findOrFail( $request->input('id') );


        //$sql="select * from module where status='1' order by moduleno ";
        //$modules = DB::select(DB::raw($sql));

        //$sql="select * from route where status='1' order by routeno ";
        //$routes = DB::select(DB::raw($sql));

               
        return view('admin.EditTranscribe')->with(["transcribe" => $Transcribe]);   
      

    }



    public function saveTranscribe(Request $request)
    {

        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        
        if($request->input('id')!="")
        {
           
           
            $validator = Validator::make($request->all(), [
                "jobName"=>"required",
                "langCode"=>"required",
                "mediaFolder"=>"required"
            ]);
            
    
            if ($validator->fails()) {
                
                $allErrors = $validator->errors()->all();
                return redirect()->back()->with('error', $allErrors[0]);
            }


            $reqNew = array();
            foreach($request->all() as $key=>$value)
            {

                if($value!="")
                  $reqNew[$key] = $value;
                else
                  $reqNew[$key] = '';                    

            }

            //if($key=="mediaFiles")
            $reqNew['mediaFiles'] = $this->getMP3files($reqNew['mediaFolder']);  

            $reqNew['updated_at'] = date("Y-m-d H:i:s");  ///2020-05-14 14:54:56 
    
            
            
            $Transcribe = Transcribe::findOrFail( $request->input('id') );
            
            $Transcribe->update($reqNew);


            /*$MP3s = explode(", ", $reqNew['mediaFiles']);

            if(is_array($MP3s))
            {

            foreach($MP3s as $mp3)
            {    
            
                $this->AWSTranscribe($reqNew, $mp3);

            }

            }*/



            return redirect()->back()->with('message', 'Transcribe saved successfully!');


        }
        else
        {

            $validator = Validator::make($request->all(), [
                "jobName"=>"required",
                "langCode"=>"required",
                "mediaFolder"=>"required"
            ]);
    
            if ($validator->fails()) {
                
                $allErrors = $validator->errors()->all();
                return redirect()->back()->with('error', $allErrors[0]);
            }
    

            $reqNew = array();
            foreach($request->all() as $key=>$value)
            {

                if($value!="")
                  $reqNew[$key] = $value;
                else
                  $reqNew[$key] = ''; 


            }

            
            //if($key=="mediaFiles")
            $reqNew['mediaFiles'] = $this->getMP3files($reqNew['mediaFolder']);  
                 
            $reqNew['created_at'] = date("Y-m-d H:i:s");  ///2020-05-14 14:54:56  
                    
            //print_r($reqNew);  die;

            
            $Transcribe = Transcribe::create($reqNew); 

            $id = $Transcribe->id;
            
            $MP3s = explode(", ", $reqNew['mediaFiles']);

            if(is_array($MP3s))
            {

            foreach($MP3s as $mp3)
            {    
            
                $this->AWSTranscribe($reqNew, $mp3, $id);

            }

            }

            

            return redirect()->back()->with('message', 'Transcribe saved successfully!');



        }


    }


    public function getMP3files($folder)
    {


        exec("LANG=en_US.UTF-8; AWS_ACCESS_KEY_ID=".env("S3_ACCESSKEY")." AWS_SECRET_ACCESS_KEY=".env("S3_SECRETKEY")." ".env("AWS_CLI")." s3 ls '".$folder."' | awk '{print $4}' | grep '.mp3' 2>&1", $files);

        return implode(", ", $files);


    }


    public function AWSTranscribe($data, $mp3, $id)
    {

        // s3://langappnew/Lesson_0_2_23_Pack/dialogs/   get 4th item
        $dialog_exercise = explode("/", $data['mediaFolder']);

        $jobName = $data['jobName']."_".$dialog_exercise[4]."_".$mp3;

        $MediaFileUri = $data['mediaFolder'].$mp3;

        $created_at = date("Y-m-d H:i:s");

        $json = str_replace(".mp3", ".json", $mp3);


        // Transcribe JObs
        $jobs = "INSERT INTO `transcribe_jobs` (`id`, `transcribeId`, `jobName`, `mediaFile`, `jsonFile`, `transcribeStatus`, `created_at`, `updated_at`) VALUES ('', '".$id."', '".$jobName."', '".$mp3."', '".$json."', '0', '".$created_at."', NULL)";
        DB::select(DB::raw($jobs));

        exec("AWS_ACCESS_KEY_ID=".env("TRANSCRIBE_ACCESSKEY")." AWS_SECRET_ACCESS_KEY=".env("TRANSCRIBE_SECRETKEY")." ".env("AWS_CLI")." transcribe start-transcription-job --language-code '".$data['langCode']."' --region ".env("TRANSCRIBE_REGION")." --media-format 'mp3' --transcription-job-name '".$jobName."' --media '{\"MediaFileUri\": \"".$MediaFileUri."\"}' --output-bucket-name '".env("TRANSCRIBE_BUCKET")."' 2>&1", $pp); 

        //print_r($pp); die;

    }


    public function deleteTranscribe(Request $request)
    {
        if(!Session::get('admin')){
            return redirect('/admin-login');
           }

        $Transcribe = Transcribe::findOrFail( $request->input('id'));

          if($Transcribe->delete()){
            return redirect()->back()->with('message', 'Transcribe removed successfully!');
          }

    }


    public function runTranscribe(Request $request)
    {

        $output = $this->processTranscribe($request);

        return view('admin.RunTranscribe')->with(["output" => $output]);  

    }



    public function processTranscribe(Request $request)
    {


        $q = "SELECT t.id, t.jobName, t.langCode, t.mediaFolder, t.mediaFiles, tj.id as tjid, tj.jobName as tjjob, tj.mediaFile, tj.jsonFile, tj.transcribeStatus  from `transcribe_jobs` tj Join `transcribe` t on tj.transcribeId = t.id  WHERE tj.transcribeStatus='0' order by tj.id ";

          
        $query = DB::select(DB::raw($q)); 


        $return = "";
        
        
        foreach($query as $row){
           
        //print_r($row);

        $mediaFiles = explode(", ", $row->mediaFiles);

        $output = array();

        $processed = 0;
        
        
            $dialog_exercise = explode("/", $row->mediaFolder);

            //$jobName = $row->jobName."_".$dialog_exercise[4]."_".$mp3;
            $jobName = $row->tjjob;

            //$MediaFileUri = $row->mediaFolder.$mp3;

            $jsonFile = $jobName.".json";

            //echo $jsonFile."\r\n";

            //$jsonFileName = str_replace(".mp3", ".json", $mp3);
            $jsonFileName = $row->jsonFile;
            

            // Copy/Move JSON files inside bucket folder like Lesson_0_2_21_Pack/exercises
            $source = "s3://".env("TRANSCRIBE_BUCKET")."/".$jsonFile;
            $target = $row->mediaFolder.$jsonFileName;

            exec("AWS_ACCESS_KEY_ID=".env("S3_ACCESSKEY")." AWS_SECRET_ACCESS_KEY=".env("S3_SECRETKEY")." ".env("AWS_CLI")." s3 mv ".$source." ".$target." --acl public-read 2>&1", $process); 


            $echo = implode(" ", $process);


            $ss = array();

            exec("AWS_ACCESS_KEY_ID=".env("TRANSCRIBE_ACCESSKEY")." AWS_SECRET_ACCESS_KEY=".env("TRANSCRIBE_SECRETKEY")." ".env("AWS_CLI")." transcribe get-transcription-job --transcription-job-name '".$jobName."' --region ".env("TRANSCRIBE_REGION")." 2>&1", $ss);
   
            $status = json_decode( implode("\r\n", $ss), true);
                        

            if($status['TranscriptionJob']['TranscriptionJobStatus']=="COMPLETED")
            {
                $processed = 1;

                //$output[] = $jsonFileName;

                //$outputFiles = $row->jsonFiles." ".$jsonFileName;

                // Save In DB

                $updated_at = date("Y-m-d H:i:s");

                               
                $logs = "UPDATE `transcribe_jobs` SET `transcribeStatus` = '1', `updated_at` = '".$updated_at."' WHERE `id` = '".$row->tjid."'";
                DB::select(DB::raw($logs));


                // Save In DB


                $return .= "Moved: ".$source." => ".$target."<br>";

            }



            //aws s3 rm s3://mybucket/test2.txt

           


        }   

        return $return;

    }


}
