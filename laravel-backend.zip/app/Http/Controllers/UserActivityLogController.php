<?php

namespace App\Http\Controllers;

use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\UserActivityLog;
use App\Http\Resources\UserActivityLog as UserActivityLogResource;
use App\Http\Resources\CheckUserApiAccess as CheckUserApiAccess;
use DB;
use checkUserPermissionController;
use Session;


class UserActivityLogController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        // get items
        


        $userActivityLogs = UserActivityLog::paginate(20);

        return UserActivityLogResource::collection($userActivityLogs);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         
         

         $userActivityLog = $request->isMethod('put') ? UserActivityLog::findOrFail($request->id) : new UserActivityLog;

         $userActivityLog->i_d = $request->input('id');
         $userActivityLog->userId = $request->input('userId'); 
         $userActivityLog->routeNo = $request->input('routeNo'); 
         $userActivityLog->moduleNo = $request->input('moduleNo'); 
         $userActivityLog->lessonNo = $request->input('lessonNo'); 
         $userActivityLog->levelNo = $request->input('levelNo'); 
         $userActivityLog->levelNoFull = $request->input('levelNoFull'); 
         $userActivityLog->courseNumber = $request->input('courseNumber'); 
         $userActivityLog->sessionId = $request->input('sessionId'); 
         $userActivityLog->pointsScored = $request->input('pointsScored'); 
         $userActivityLog->totalQuestions = $request->input('totalQuestions'); 
         $userActivityLog->activityType = $request->input('activityType'); 
         $userActivityLog->statusFlag = $request->input('statusFlag'); 
         $userActivityLog->totalTime = $request->input('totalTime'); 
         $userActivityLog->watchedTime = $request->input('watchedTime'); 
         $userActivityLog->activityDateFrom = $request->input('activityDateFrom'); 
         $userActivityLog->activityDateTo = $request->input('activityDateTo'); 

        
         if($userActivityLog->save()){
            // return new UserActivityLogResource($userActivityLog);
            return response()->json(['message' => 'Data Saved!'], 200);
         }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $id)
    {
        

        try{

        $userActivityLog = UserActivityLog::findOrFail($id);
        return new UserActivityLogResource($userActivityLog);
        
        }
        // catch(Exception $e) catch any exception
        catch(ModelNotFoundException $e)
        {
            return response()->json(['message' => 'Not Found!'], 404);
        } 

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request, $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        


        try { 
        $userActivityLog = UserActivityLog::findOrFail($id);
        
        if($userActivityLog->delete()){
            //return new UserActivityLogResource($userActivityLog);
            return response()->json(['message' => 'Removed!'], 200);
        }

        }
        // catch(Exception $e) catch any exception
        catch(ModelNotFoundException $e)
        {
            return response()->json(['message' => 'Not Found!'], 404);
        } 
         


    }

   
}
