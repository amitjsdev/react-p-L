<?php

namespace App\Http\Controllers;

use App\Employee;
use App\Events\UserDailyGoalLogSave;
use App\UserDailyGoalLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Validator;

class UserDailyGoalLogController extends Controller
{
    /**
     * get the user goal stats for last 7 days
     *
     * @param Request $request
     * @return void
     */
    function history(Request $request)
    {
        $history = getUserGoalDataForLast7Days($request->user()->employee);

        $history['userId'] = $history["employee"]->userId;

        unset($history['employee']);

        return response()->json($history);
    }

    function save(Request $request)
    {
        $userId = auth()->user()->email;


        $validator = Validator::make($request->all(), [
            'dated' => 'required|date',
            "moduleNo" => "numeric|nullable",
            "routeNo" => "numeric|nullable",
            "lessonNo" => "numeric|nullable",
            "type" => "string|nullable",
            'points' => 'required|numeric',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        $validated = $validator->validated();

        $validated['userId'] = $userId;

        $employee = Employee::where('userId', $userId)->first();

        // add total
        try {
            // course number
            if ($request->has('moduleNo')) {
                $courseNumber = getCourseNoFromModuleNo($validated['moduleNo'], $userId);
            } else {
                $courseNumber = $employee->currentCourse;
            }
            // update user score
            $validated['total'] = addUserScoreForCourse($userId, $courseNumber, $request->points);
        } catch (\Exception $th) {
            $validated['total'] = $request->points;
        }

        // the result
        $userDailyGoalLog = UserDailyGoalLog::create($validated);

        // get total for the date for the user
        $userDailyGoalTotal = UserDailyGoalLog::whereDate('dated', $request->dated)->where('userId', $userId)->sum('points');

        // save total to employee
        $employee = Employee::where('userId', $userId)->first();

        // check if daily goal attained just now
        $is_daily_goal_attained = $employee->daily_goal_attained >= $employee->daily_goal_total;

        if ($is_daily_goal_attained) {
            // goal is already attained, set it to false
            $is_daily_goal_attained = false;
        } else {
            if ($userDailyGoalTotal >= $employee->daily_goal_total) {
                // the new attained is more than total, set it to true
                $is_daily_goal_attained = true;
            }
        }
        // check if half of daily goal attained just now
        $is_half_of_daily_goal_attained = $employee->daily_goal_attained >= ($employee->daily_goal_total / 2);

        if ($is_half_of_daily_goal_attained) {
            // goal is already attained, set it to false
            $is_half_of_daily_goal_attained = false;
        } else {
            if ($userDailyGoalTotal >= ($employee->daily_goal_total / 2)) {
                // the new attained is more than total, set it to true
                // $is_half_of_daily_goal_attained = true;
                $is_half_of_daily_goal_attained = false; // send false for now, we are not using half goal
            }
        }

        $employee->daily_goal_attained = $userDailyGoalTotal;
        $employee->save();

        // calculate the new streak
        Artisan::call('cron:updateuserstreaks ' . $employee->userId . ' --skipdailygoalreset');

        // calculate the new ranks
        Artisan::queue('taplingua:calculateleaderboardrank');

        // create response
        $response = [
            'message' => 'Log Saved!',
            'log' => $userDailyGoalLog,
            'daily_goal_attained' => $employee->daily_goal_attained,
            'daily_goal_total' => $employee->daily_goal_total,
            'is_daily_goal_attained' => $is_daily_goal_attained,
            'is_half_of_daily_goal_attained' => $is_half_of_daily_goal_attained,
        ];

        event(new UserDailyGoalLogSave($response));

        // send response
        return response()->json($response);
    }

    function get(Request $request)
    {
        $userId = $request->userId;

        $employee = Employee::where('userId', $userId)->first();

        if (!$employee) {
            return response()->json([
                "message" => "User not found!"
            ], 404);
        }

        $dailyGoalLogs = UserDailyGoalLog::where('userId', $employee->userId)->latest()->get();

        $dailyGoalLogs = $dailyGoalLogs->map(function ($log) {

            $log->time = $log->created_at->toTimeString();
            return $log;
        });

        return response([
            "dailyGoalLogs" => $dailyGoalLogs
        ]);
    }
}
