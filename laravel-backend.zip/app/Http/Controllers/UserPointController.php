<?php

namespace App\Http\Controllers;

use App\Employee;
use App\UserPoint;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class UserPointController extends Controller
{
    public function save(Request $request)
    {
        $userId = auth()->user()->email;
        // validate the data
        $validator = Validator::make($request->all(), [
            "points" => "numeric",
            "pointType" => "string|nullable",
            "moduleNo" => "numeric|nullable",
            "routeNo" => "numeric|nullable",
            "lessonNo" => "numeric|nullable",
        ]);

        // return if error
        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        // save points
        $validated = $validator->validated();

        $validated['userId'] = $request->user()->email;


        // save point
        $userPoint = UserPoint::create($validated);

        // course number
        $courseNumber = getCourseNoFromModuleNo($request->moduleNo, $userId);

        // update user activationDate if necessary
        $employee = Employee::where('userId', $validated['userId'])->first();
        if ($employee && !$employee->activationDate) {
            $employee->activationDate = now();
            $employee->save();
        }

        // update user score
        // updateUserScoreForCourse($userId, $courseNumber, $request->points);

        // return response
        return response()->json($userPoint);
    }
}
