<?php

namespace App\Http\Controllers;

use App\Comment;
use App\Employee;
use App\Events\UserCommented;
use App\FollowingUserQuestion;
use App\Http\Resources\ForumCommentResource;
use App\Http\Resources\UserQuestionDetailResource;
use App\Http\Resources\UserQuestionListResource;
use App\User;
use App\UserQuestion;
use Illuminate\Http\Request;

class UserQuestionController extends Controller
{
    public function list(Request $request)
    {
        $category = "%" . $request->category . "%";

        $userQuestions = UserQuestion::where('category', 'like', $category)->latest()->get();

        $count = $userQuestions->count();

        if($count > 0) {
            $userQuestions[$count - 1]->pinned = true;
        }

        if($count > 1) {
            // make the pinned at top
            $pinnedQuestion = $userQuestions->pop();

            $userQuestions->prepend($pinnedQuestion);
        }

        return response()->json(UserQuestionListResource::collection($userQuestions));
    }
    
    public function following() {
        return response()->json(UserQuestionListResource::collection(auth()->user()->following_user_questions));
    }

    public function show($id) {
        $userQuestion = UserQuestion::find($id);

        return response()->json(new UserQuestionDetailResource($userQuestion));
    }

    public function create(Request $request) {
        $validated = $request->validate([
            'title' => "required|string",
            'category' => "nullable|string",
            'content' => "nullable|string",
        ]);

        $validated['userId'] = $request->user()->email;

        $userQuestion = UserQuestion::create($validated);

        // follow it as well
        FollowingUserQuestion::create([
            'userId' => $validated['userId'],
            'user_question_id' => $userQuestion->id,
        ]);

        return response()->json([
            "message" => "Question posted",
            "question" => new UserQuestionListResource($userQuestion)
        ]);
    }

    public function comment(Request $request, $id)
    {
        // get the question
        $question = UserQuestion::find($id);

        if (!$question) {
            return response()->json([
                'error' => 'Question Not Found!'
            ], 404);
        }

        // get comment by user
        $commentMsg = $request->comment;

        if (empty($commentMsg)) {
            return response()->json([
                'error' => 'Comment is required!'
            ], 422);
        }

        $comment = new Comment();
        $comment->userId = auth()->user()->email;
        $comment->comment = $commentMsg;
        $question->comments()->save($comment);

        // TODO: add notification to it as well
        event(new UserCommented($comment));

        // TODO: add something to follow the question
        followTheCommunityForum($comment->userId, $comment);

        return response()->json([
            'message' => 'Comment Added!',
            "comment" => new ForumCommentResource($comment)
        ]);
    }
}
