<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\ModelNotFoundException;

use App\Http\Requests;
use App\UserSessionLog;
use App\Http\Resources\UserSessionLog as UserSessionLogResource;
use App\Http\Resources\CheckUserApiAccess as CheckUserApiAccess;
use App\UserActivityLog;
use DB;
use checkUserPermissionController;
use Illuminate\Support\Facades\Validator;
use Session;

class UserSessionLogController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        

        $UserSessionLogs = UserSessionLog::paginate(20);

        return UserSessionLogResource::collection($UserSessionLogs);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        date_default_timezone_set("Europe/Madrid");

        $validator = Validator::make($request->all(), [
            'userId' => 'required',
            'moduleNo' => 'required',
            'routeNo' => 'required',
            'routeNo' => 'required',
            'activityType' => 'required',
            'activityDateFrom' => 'required',
        ]);

        if ($validator->fails()) {
            // TODO: Add the mail functionality
            $allErrors = $validator->errors()->all();
            error_logger($allErrors);
            return response()->json(["error" => $allErrors[0]], 412);
        }

        $data = $request->validated();

        $activityDateFrom = str_replace('/', '-', $data['activityDateFrom']);
        $activityDateFrom = date("Y-m-d H:i:s", strtotime($activityDateFrom));
        $data['activityDateFrom'] = $activityDateFrom;

        if ($data['activityDateTo'] != "") {
            $activityDateTo = str_replace('/', '-', $data['activityDateTo']);
            $activityDateTo = date("Y-m-d H:i:s", strtotime($activityDateTo));
            $data['activityDateTo'] = $activityDateTo;
        }
        /* Set startTime for usersessionlog_api as activityDateFrom  */
        $startTime = $data['activityDateFrom'];

        /* Set endTime for usersessionlog_api as activityDateTo OR activityDateFrom */
        if ($data['activityDateTo'] != "")
            $endTime = date("Y-m-d H:i:s", strtotime($data['activityDateTo'] . " +2 minutes"));  // 120 SECS
        else
            $endTime = date("Y-m-d H:i:s", strtotime($data['activityDateFrom'] . " +2 minutes"));  // 120 SECS 

        /* Using adddate for checking sessionId Expiry  */
        if (isset($data['adddate']) && $data['adddate'] != "") {
            $adddate = $data['adddate'];
        } else {
            $adddate = date("Y-m-d H:i:s");
        }

        if (isset($data['ipAddress']) && $data['ipAddress'] != "") {
            $ipAddress = $data['ipAddress'];
        } else {
            $ipAddress = "";
        }

        try {

            $interval = 5;

            /* LLP Listen, Learn, Play interval for sessionId Expire */
            if (intval($data['activityType']) == 1) {
                $interval = 5;
            } else {
                $interval = 8;
            }

            $userSessionLog = UserSessionLog::select('sessionId')
                ->where('userId', $data['userId'])
                ->where('adddate', date_sub(now(), 'interval $interval minute'));

            if ($request->has('moduleNo')) {
                $userSessionLog->where('moduleNo', $data['moduleNo']);
            }

            if ($request->has('routeNo')) {
                $userSessionLog->where('routeNo', $data['routeNo']);
            }

            $userSessionLog = $userSessionLog->first();

            if ($userSessionLog) {
                $sessionId = $userSessionLog->sessionId;
                $isInserted = false;
            } else {
                $sessionId = getGUID();
                $isInserted = true;
            }

            if ($isInserted) {
                UserSessionLog::create([
                    'userId' => $data['userId'],
                    'moduleNo' => $data['moduleNo'],
                    'routeNo' => $data['routeNo'],
                    'sessionId' => $sessionId,
                    'startTime' => $startTime,
                    'endTime' => $endTime,
                    'adddate' => $adddate,
                    'ipAddress' => $ipAddress,
                ]);
            } else {
                if (!empty($data['routeNo']) && !empty($data['moduleNo'])) {
                    $userSessionLog = UserSessionLog::where('sessionId', $sessionId)
                        ->where('moduleNo', $data['moduleNo'])
                        ->where('routeNo', $data['routeNo'])->first();
                    if ($userSessionLog) {
                        $userSessionLog->update([
                            'endTime' => $endTime,
                            'adddate' => $adddate
                        ]);
                    }
                } else {
                    $userSessionLog = UserSessionLog::where('sessionId', $sessionId)->first();
                    if ($userSessionLog) {
                        $userSessionLog->update([
                            'endTime' => $endTime,
                            'adddate' => $adddate
                        ]);
                    }
                }
            }

            $userActivityLog = UserActivityLog::create([
                'routeNo' => $data['routeNo'],
                'activityDateFrom' => $data['activityDateFrom'],
                'moduleNo' => $data['moduleNo'],
                'lessonNo' => $data['lessonNo'],
                'levelNo' => $data['levelNo'],
                'levelNoFull' => $data['levelNoFull'],
                'activityType' => $data['activityType'],
                'userId' => $data['userId'],
                'activityDateTo' => $data['activityDateTo'],
                'totalQuestions' => $data['totalQuestions'],
                'sessionId' => $sessionId,
                'courseNumber' => $data['courseNumber'],
                'pointsScored' => $data['pointsScored'],
                'Id' => $data['Id'],
                'statusFlag' => $data['statusFlag'],
                'totalTime' => $data['totalTime'],
                'watchedTime' => $data['watchedTime'], 
            ]);

            activity_logger(['UserSessionLogController-log-success', $data]);
            return response()->json(["sessionId" => $sessionId, "message" => "Data saved successfully"]);
        } catch (\Exception $e) { 
            error_logger(['UserSessionLogController-log-Error', $e->getMessage(), $data]);
            return response()->json(["error" => $e->getMessage()]);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $id)
    {

        

        try {

            $userSessionLog = UserSessionLog::findOrFail($id);
            return new UserSessionLogResource($userSessionLog);
        }
        // catch(Exception $e) catch any exception
        catch (ModelNotFoundException $e) {
            return response()->json(['message' => 'Not Found!'], 404);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {

        

        try {

            $userSessionLog = UserSessionLog::findOrFail($id);

            if ($userSessionLog->delete()) {
                //return new UserSessionLogResource($userSessionLog);
                return response()->json(['message' => 'Removed!'], 200);
            }
        }
        // catch(Exception $e) catch any exception
        catch (ModelNotFoundException $e) {
            return response()->json(['message' => 'Not Found!'], 404);
        }

        //print_r($userSessionLog->id); die();





    }
}
