<?php

namespace App\Http\Controllers;

use App\UserThumbsUpLog;
use Illuminate\Http\Request;

class UserThumbsUpLogController extends Controller
{
    function giveThumbsUpDaily(Request $request)
    {

        $request->validate([
            'userId' => "required|string|exists:employee,userId",
        ]);

        $userFrom = auth()->user()->email;
        $userTo = $request->userId;

        // Check if user has already not send the thumbs up to other fellow
        $alreadyGivenThumbsUp = UserThumbsUpLog::where('userTo', $userTo)
            ->where('userFrom', $userFrom)
            ->where('type', 'daily')
            ->whereDate('created_at', today())
            ->exists();

        if($alreadyGivenThumbsUp) {
            return response()->json(['message' => 'Thumbs-up already given'], 400);
        }

        // give thumbs-up
        UserThumbsUpLog::create([
            'userFrom' => $userFrom,
            'userTo' => $userTo,
            'type' => 'daily'
        ]);

        // send response
        return response()->json([
            'message' => "Thumbs-up sent!"
        ]);
    }



    public function giveThumbsUpWeekly(Request $request)
    {
        $request->validate([
            'userId' => "required|string|exists:employee,userId",
        ]);


        $startOfWeek = null; // last saturday
        // check if saturday for current week has passed
        if (now()->dayOfWeek >= 6) {
            // today is saturday or more
            $startOfWeek = today()->addDays(6 - now()->dayOfWeek)->startOfDay();
            $endOfWeek = today()->addWeek()->addDays(5 - now()->dayOfWeek)->endOfDay();
        } else {
            // saturday yet to come
            $startOfWeek = today()->subWeek()->addDays(6 - now()->dayOfWeek)->startOfDay();
            $endOfWeek = today()->addDays(5 - now()->dayOfWeek)->endOfDay();
        }



        $userFrom = auth()->user()->email;
        $userTo = $request->userId;

        // Check if user has already not send the thumbs up to other fellow
        $alreadyGivenThumbsUp = UserThumbsUpLog::where('userTo', $userTo)
            ->where('userFrom', $userFrom)
            ->where('type', 'weekly')
            ->whereBetween('created_at', [$startOfWeek, $endOfWeek])
            ->exists();

        if ($alreadyGivenThumbsUp) {
            return response()->json(['message' => 'Thumbs-up already given'], 400);
        }

        // give thumbs-up
        UserThumbsUpLog::create([
            'userFrom' => $userFrom,
            'userTo' => $userTo,
            'type' => 'weekly'
        ]);

        // send response
        return response()->json([
            'message' => "Thumbs-up sent!"
        ]);

    }
}
