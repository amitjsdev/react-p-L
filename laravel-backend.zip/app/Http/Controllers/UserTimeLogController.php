<?php

namespace App\Http\Controllers;

use App\UserTimeLog;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserTimeLogController extends Controller
{
    /**
     * Logs user time on app
     * Rquest has the following format
     * 
        {
            "userId" :"",
            "screenCode": "",
            "inTime" : "",
            "outTime": "",
            "buttonsClicked?": [
                {"type": "", "value": ""}
            ]
        }
     * 
     * @param Request $request
     * @return void
     */
    public function __invoke(Request $request)
    {
        try {
            $userId = auth()->user()->email;

            $userTimeLog = new UserTimeLog();
            $userTimeLog->userId = $userId;
            $userTimeLog->pushId = $request->pushId;
            $userTimeLog->screenCode = $request->screenCode;
            $userTimeLog->moduleNo = $request->moduleNo;
            $userTimeLog->courseNo = getCourseNoFromModuleNo($request->moduleNo, $userId);
            $userTimeLog->routeNo = $request->routeNo;
            $userTimeLog->LessonNo = $request->LessonNo;
            $userTimeLog->appVersion = $request->appVersion;
            $userTimeLog->screenName = getScreenNameFromCode($request->screenCode);
            $userTimeLog->inTime = (new Carbon($request->inTime, $request->timeZone))->setTimezone("UTC");
            $userTimeLog->outTime = (new Carbon($request->outTime, $request->timeZone))->setTimezone("UTC");
            $userTimeLog->buttonsClicked = json_encode($request->buttonsClicked);
            $userTimeLog->save();
            $userTimeLog->buttonsClicked = json_decode($userTimeLog->buttonsClicked);
            return response()->json(["message" => "Logged", "data" => $userTimeLog]);
        } catch (\Exception $e) {
            return response()->json(["message" => "Something went wrong, it failed, but you can continue on.", "data" => null]);
        }
    }
}
