<?php

namespace App\Http\Controllers;

use App\Employee;
use App\Forum;
use App\Http\Resources\V2ExerciseResource;
use App\Lesson;
use App\Module;
use App\PlacementExerciseLog;
use App\PlacementLog;
use App\RoundExerciseLog;
use App\RoundLog;
use App\V2Exercise;
use App\V2ExerciseType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;

class V2ExerciseController extends Controller
{

    private $exerciseType = [];

    function __construct()
    { }

    /**
     * Lists all the exercises for admin panel
     *
     * @param Request $request
     * @return void
     */
    public function index(Request $request)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $pageSize = $request->pageSize ? $request->pageSize : 50;
        $exercises = V2Exercise::query()->orderBy('sequenceNo');

        // check for filters
        if (!empty($request->get('moduleNo'))) $exercises->where('moduleNo', $request->moduleNo);
        if (!empty($request->get('routeNo'))) $exercises->where('routeNo', $request->routeNo);
        if (!empty($request->get('lessonNo'))) $exercises->where('lessonNo', $request->lessonNo);
        if (!empty($request->get('question'))) $exercises->where('question', 'like', "%" . $request->question . "%");
        if (!empty($request->get('exerciseType'))) $exercises->where('exerciseType', $request->exerciseType);
        // check for filters end

        $exercises = $exercises->paginate($pageSize);
        $exerciseType = V2ExerciseType::whereIsActive(true)->get();
        return view("admin/exercise-v2/index", compact('pageSize', 'exercises', 'exerciseType'));
    }

    /**
     * For showing add form
     *
     * @param Request $request
     * @return void
     */
    public function add(Request $request)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $modules = Module::where('status', "1")->orderBy("moduleno")->get();

        if ($request->has('clone')) {
            $exercise = V2Exercise::find($request->clone);
            $exercise->id = null; // so that the edit does not get triggered
        } else {
            $exercise = new V2Exercise();
        }
        $exercise_type = V2ExerciseType::whereIsActive(true)->get();

        return view("admin/exercise-v2/add", compact('exercise', 'modules', 'exercise_type'));
    }

    /**
     * To save new v2 exercise
     *
     * @param Request $request
     * @return void
     */
    public function save(Request $request)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }
        // this is done to make it comaptible with changes by sandeep, so that I can reuse his functionality
        $formData = (array) $request->all();
        $formData['routeNo'] = $formData['routeno'];
        $formData['lessonNo'] = $formData['lesson_no'];


        $validator = Validator::make($formData, [
            "sequenceNo" => "nullable|numeric",
            "moduleNo" => "required|numeric",
            "routeNo" => "required|numeric",
            "lessonNo" => "required|numeric",
            "exerciseType" => "required",
            "forInteractiveListen" => "nullable|in:0,1",
            "question" => "nullable",
            "options" => "nullable",
            "answer" => "nullable",
            "translation" => "nullable",
            "is_hard" => "nullable|numeric",
            "status" => "nullable|numeric",
        ]);

        // $validated = $validator->validated();

        if ($validator->fails()) {
            return redirect()->back()->with('error', $validator->errors()->all()[0])->withInput();
        }

        $validated = $validator->validated();

        $v2exercise = V2Exercise::create($validated);

        // Create polly for v2 , for tap_what_you_hear and voice_recognition
        try {
            if ($v2exercise->exerciseType === 'tap_what_you_hear' || $v2exercise->exerciseType === 'voice_recognition') {
                makeV2PollyFromSSMLAndUploadToS3("<speak>" . $v2exercise->question . "</speak>", $v2exercise->moduleNo . "_" . $v2exercise->routeNo . "_" . $v2exercise->lessonNo, $v2exercise->id);
            }
        } catch (\Exception $e) {
            \Log::error("Couldnt create polly for v2exercise: ", [$e]);
        }

        return redirect()->back()->with('message', 'Exercise saved successfully!');
    }

    /**
     * For showing edit form
     *
     * @param Request $request
     * @param [type] $id
     * @return void
     */
    public function edit(Request $request, $id)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $modules = Module::where('status', "1")->orderBy("moduleno")->get();

        $exercise = V2Exercise::find($id);

        if (!$exercise) {
            return redirect()->back()->with('error', "Exercise not found!");
        }

        $exercise_type = V2ExerciseType::whereIsActive(true)->get();

        return view("admin/exercise-v2/add", compact('exercise', 'modules', 'exercise_type'));
    }



    /**
     * To update existing v2 exercise
     *
     * @param Request $request
     * @return void
     */
    public function update(Request $request, $id)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        // this is done to make it comaptible with changes by sandeep, so that I can reuse his functionality
        $formData = (array) $request->all();
        $formData['routeNo'] = $formData['routeno'];
        $formData['lessonNo'] = $formData['lesson_no'];


        $validator = Validator::make($formData, [
            "sequenceNo" => "nullable|numeric",
            "moduleNo" => "required|numeric",
            "routeNo" => "required|numeric",
            "lessonNo" => "required|numeric",
            "exerciseType" => "required",
            "forInteractiveListen" => "nullable|in:0,1",
            "question" => "nullable",
            "options" => "nullable",
            "answer" => "nullable",
            "translation" => "nullable",
            "is_hard" => "nullable|numeric",
            "status" => "nullable|numeric",
        ]);

        // $validated = $validator->validated();

        if ($validator->fails()) {
            return redirect()->back()->with('error', $validator->errors()->all()[0])->withInput();
        }



        $exercise = V2Exercise::find($id);

        if (!$exercise) {
            return redirect()->back()->with('error', "Exercise not found!");
        }

        $validated = $validator->validated();

        $exercise->update($validated);

        // Create polly for v2 , for tap_what_you_hear and voice_recognition
        try {
            if ($exercise->exerciseType === 'tap_what_you_hear' || $exercise->exerciseType === 'voice_recognition') {
                makeV2PollyFromSSMLAndUploadToS3("<speak>" . $exercise->question . "</speak>", $exercise->moduleNo . "_" . $exercise->routeNo . "_" . $exercise->lessonNo, $exercise->id);
            }
        } catch (\Exception $e) {
            \Log::error("Couldnt create polly for v2exercise: ", [$e]);
        }

        return redirect()->back()->with('message', 'Exercise updated successfully!');
    }


    /**
     * Delete an exercise with specific type
     *
     * @param Request $request
     * @param integer $id
     * @return void
     */
    public function delete(Request $request, $id)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $exercise = V2Exercise::find($id);

        if (!$exercise) {
            return redirect()->back()->with('error', "Exercise not found!");
        }

        $exercise->delete();

        return redirect()->back()->with('message', "Exercise with id " . $id . " deleted!");
    }

    /**
     * For fetching the exercises using moduleNo, routeNo and lessonNo in request
     *
     * @param Request $request
     * @return void
     */
    public function fetch(Request $request)
    {
        $validator = Validator::make($request->all(), [
            "moduleNo" => "required|numeric",
            "routeNo" => "required|numeric",
            "lessonNo" => "required|numeric"
        ]);

        // typecast lesson no so that wrong comparision does not happen
        $request->lessonNo = (int) $request->lessonNo;

        if ($validator->fails()) {
            return response()->json(["message" => "Bad request!", "errors" => $validator->errors()], 400);
        }

        // check if lesson is challenge
        $lesson = Lesson::where('moduleno', $request->moduleNo)->where('routeno', $request->routeNo)->where('lesson_no', $request->lessonNo)->first();


        // check roundNo for this MRL and userId combo
        $userId = auth()->user()->email;
        $exercises = collect([]);
        if ($lesson->is_challenge) {
            $challengeCap = 10;
            $milestoneCap = in_array($userId,  __temp_get_milestone_exception_user_list()) ? (int) __get_variable('milestone_cap_test') : (int) __get_variable('milestone_cap');
            // exerciseType that have to be not included in challenge
            $challengeExceptions = [
                'informational',
                'mini_lesson_1',
                'mini_lesson_2',
                'mini_lesson_3',
                // 'voice_recognition',
                'select_correct_translation',
                'tap_the_pair',
                'tap_the_pair_sentences'
            ];
            if ($lesson->challenge_type == "milestone" && (in_array($userId,  __temp_get_milestone_exception_user_list()) || __check_for_milestone_version_app($userId))) {
                // get exercises
                $exercises = V2Exercise::whereNotIn('exerciseType', $challengeExceptions)
                    ->where("moduleNo", $request->moduleNo)
                    ->where("lessonNo", "<", $request->lessonNo)
                    ->orderBy('is_hard', 'desc')
                    ->where('status', 1)
                    ->limit($milestoneCap)
                    ->get();
                // check if array count is greater than milestoneCap, if so, selectt milestoneCap random
                // removing random order as we need to show is_hard first
   /*              if (count($exercises) > $milestoneCap) {
                    $exercises = $exercises->random($milestoneCap);
                } */
                // add 5 exercise from v2Exercise
                $fiveMore = V2Exercise::where("status", 1)
                    ->where("moduleNo", (string) $request->moduleNo)
                    ->where("routeNo", (string) $request->routeNo)
                    ->where("lessonNo", (string) $request->lessonNo)
                    ->where("forInteractiveListen", "!=", 1)->where('status', 1)
                    ->orderBy("sequenceNo")
                    ->limit(5)
                    ->get();

                foreach ($fiveMore as $more) {
                    $exercises->push($more);
                }
            } else {

                // check for failed exercise in route_exercise_log
                // find all the id of exercises in this module
                $allExerciseIds = V2Exercise::whereNotIn('exerciseType', $challengeExceptions)->where('moduleNo', $request->moduleNo)->where("lessonNo", "<", $request->lessonNo)->where('forInteractiveListen', '!=', 1)->where('status', 1)->pluck('id');
                $failedExerciseIds = [];
                try {
                    // then find the id of those exercises that have status 0 in exercise round log
                    $failedExercises = RoundExerciseLog::whereIn('questionId', $allExerciseIds)
                        ->where('round_exercise_logs.status', '!=', 1)
                        ->join('round_logs', 'round_logs.id', '=', 'round_exercise_logs.roundLogId')
                        ->where('isMiniRound', '!=', 1)
                        ->where('userId', $userId)
                        ->limit($challengeCap)
                        ->pluck('id');
                    // for each failed exercise check if it was attempted by user
                    $failedExerciseIds = $failedExercises;
                } catch (\Exception $e) {
                    $failedExerciseIds = $allExerciseIds->toArray();
                }
                // shuffle failed exercise ids
                shuffle($failedExerciseIds);
                // get exercise for these ids
                $exercises = count($failedExerciseIds) == 0 ? collect([]) : V2Exercise::whereNotIn('exerciseType', $challengeExceptions)->whereIn('id', array_slice($failedExerciseIds, 0, count($failedExerciseIds) > $challengeCap ? $challengeCap : count($failedExerciseIds)))->where('status', 1)->get();
                // if exercise is empty, send him previous exercises
                if ($exercises->isEmpty()) {
                    $exercises = V2Exercise::whereNotIn('exerciseType', $challengeExceptions)->where("moduleNo", $request->moduleNo)->where("lessonNo", "<", $request->lessonNo)->where('status', 1)->get();
                    // check if array count is greater than 5, if so, selectt 5 random
                    if (count($exercises) > $challengeCap) {
                        $exercises = $exercises->random($challengeCap);
                    }
                }
            }
        }
        if ($exercises->isEmpty()) {
            // get all the exercise from v2
            $exercises = V2Exercise::where("status", 1)
                ->where("moduleNo", (string) $request->moduleNo)
                ->where("routeNo", (string) $request->routeNo)
                ->where("lessonNo", (string) $request->lessonNo)
                ->where("forInteractiveListen", "!=", 1)->where('status', 1)
                ->orderBy("sequenceNo")
                ->get();
        }

        // if not placement test, save the log normally
        if ($request->isPlacementTest === "false") {

            $roundNo = RoundLog::where('userId', $userId)
                ->where("moduleNo", $request->moduleNo)
                ->where("routeNo", $request->routeNo)
                ->where("lessonNo", $request->lessonNo)
                ->where("isMiniRound", '!=', 1)
                ->whereNull("roundType")
                ->count(); // add one to the last count
            // create roundLog for new record
            $roundLog = RoundLog::create([
                "userId" => $userId,
                "roundNo" => $roundNo,
                "moduleNo" => $request->moduleNo,
                "routeNo" => $request->routeNo,
                "lessonNo" => $request->lessonNo,
                "isMiniRound" => 0,
                "status" => -1,
            ]);
            // get employee
            $employee = Employee::where('userId', $userId)->first();
            // create log for each exercise
            foreach ($exercises as $exercise) {
                RoundExerciseLog::create([
                    "userId" => $userId,
                    "moduleNo" => $request->moduleNo,
                    "routeNo" => $request->routeNo,
                    "lessonNo" => $request->lessonNo,
                    "mobileOS" => $employee->mobileOS,
                    "roundLogId" => $roundLog->id,
                    "questionId" => $exercise->id,
                    "status" => -1,
                    "type" => $exercise->exerciseType,
                    "additionalInfo" => null,
                ]);
            }
        } else {

            $roundNo = PlacementLog::where('userId', $userId)
                ->where("moduleNo", $request->moduleNo)
                ->where("debugRouteNo", $request->routeNo)
                ->where("debugLessonNo", $request->lessonNo)
                ->count(); // add one to the last count
            // create roundLog for new record
            $roundLog = PlacementLog::create([
                "userId" => $userId,
                "roundNo" => $roundNo,
                "moduleNo" => $request->moduleNo,
                "debugRouteNo" => $request->routeNo,
                "debugLessonNo" => $request->lessonNo,
                "isMiniRound" => 0,
                "status" => -1,
            ]);
            // get employee
            $employee = Employee::where('userId', $userId)->first();
            // create log for each exercise
            foreach ($exercises as $exercise) {
                PlacementExerciseLog::create([
                    "userId" => $userId,
                    "moduleNo" => $request->moduleNo,
                    "debugRouteNo" => $request->routeNo,
                    "debugLessonNo" => $request->lessonNo,
                    "mobileOS" => $employee->mobileOS,
                    "roundLogId" => $roundLog->id,
                    "questionId" => $exercise->id,
                    "status" => -1,
                    "type" => $exercise->exerciseType,
                    "additionalInfo" => null,
                ]);
            }
        }

        return response()->json(V2ExerciseResource::collection($exercises));
    }

    public function failedExercise(Request $request)
    {
        $request->validate([
            'moduleNo' => "required|numeric",
            'routeNo' => "required|numeric",
            'lessonNo' => "required|numeric"
        ]);

        $userId = $request->user()->email;

        $exercises = getUserMistakesForLesson(
            $request->moduleNo,
            $request->routeNo,
            $request->lessonNo,
            $userId
        );

        // get round no
        $roundNo = RoundLog::where('userId', $userId)
            ->where("moduleNo", $request->moduleNo)
            ->where("routeNo", $request->routeNo)
            ->where("lessonNo", $request->lessonNo)
            ->where("isMiniRound", '!=', 1)
            ->where("roundType", "failed_exercise")
            ->count() + 1; // add one to the last count

        $roundLog = RoundLog::create([
            "userId" => $userId,
            "roundNo" => $roundNo,
            "moduleNo" => $request->moduleNo,
            "routeNo" => $request->routeNo,
            "lessonNo" => $request->lessonNo,
            "roundType" => "failed_exercise",
            "isMiniRound" => 0,
            "status" => -1,
        ]);

        // get employee
        $employee = Employee::where('userId', $userId)->first();

        // create log for each exercise
        foreach ($exercises as $exercise) {
            RoundExerciseLog::create([
                "userId" => $userId,
                "moduleNo" => $request->moduleNo,
                "routeNo" => $request->routeNo,
                "lessonNo" => $request->lessonNo,
                "mobileOS" => $employee->mobileOS,
                "roundLogId" => $roundLog->id,
                "questionId" => $exercise->id,
                "roundType" => "failed_exercise",
                "status" => -1,
                "type" => $exercise->exerciseType,
                "additionalInfo" => null,
            ]);
        }

        return response()->json(V2ExerciseResource::collection($exercises));
    }


    public function gotoForum(Request $request, $id)
    {

        if (!Session::get('admin')) {
            return redirect('/admin-login');
        }

        $exercise = V2Exercise::find($id);

        if (!$exercise) {
            return redirect()->back()->with('error', "Exercise not found!");
        }

        $forum = Forum::where('forumable_type', V2Exercise::class)->where('forumable_id', $id)->first();

        if (!$forum) {
            // create a forum for it
            $forum = new Forum();
            $forum->forumable_type = V2Exercise::class;
            $forum->forumable_id = $id;
            $forum->title = $exercise->question;
            $forum->content = $exercise->question;
            $forum->save();
        }
        // redirect to the forum
        return redirect()->to('/forums/' . $forum->id);
    }
}
