<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
//use Session;


class checkUserPermissionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function checkPermission($api_name,$api_method)
    {
        $api_m = strtolower($api_method);

        $user = auth()->user();

        
            $sqlQuery = "SELECT users.id,users.group_id,group_api_maping.*,apis.name FROM users LEFT JOIN group_api_maping ON FIND_IN_SET(group_api_maping.group_id , users.group_id) LEFT JOIN apis ON group_api_maping.api_id = apis.id WHERE users.id ='".$user->id."' && apis.name ='".$api_name."' &&  group_api_maping.".$api_m." = 'true' ";
            $query = DB::select(DB::raw($sqlQuery));
         

            if(sizeof($query) == 0){
                return  "false";
            }else{
                return "true";
            }


       
        
    }

 
}
