<?php

namespace App\Http\Middleware;

use Closure;

class Etagger
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $response =  $next($request);
        if ($request->isMethod('get')) {
            $tag = md5($response->getContent());
            $requestEtag = str_replace('"', '', $request->getETags());
            if ($requestEtag && $requestEtag[0] === $tag) {
                $response->setNotModified();
            }
            $response->setEtag($tag);
        }
        return $response;
    }
}
