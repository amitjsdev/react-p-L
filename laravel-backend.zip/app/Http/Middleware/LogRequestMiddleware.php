<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class LogRequestMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        return $next($request);
    }

    public function terminate(Request $request, $response)
    {
        try {
            $user = auth()->user();
            Log::channel('request_log')->info('Logged Request', [
                'uri' => $request->fullUrl(),
                'ip' => $request->ip(),
                'userId' => $user ? $user->email : "unauthenticated",
                'body' => $request->all(),
                'response' => $response->getData()
            ]);
        } catch(\Exception $e) {
            Log::error("exception occurred at LogRequestMiddleware", [$e]);
        }
    }
}
