<?php

namespace App\Http\Middleware;

use Closure;

class ThirdPartyAuthMiddleware
{
    private $credentials = [
        'd977e1fbc6adfcd66a8a52e622' => "ef0365c0797daf1405b5a.ea0da037dfe5ca64a6e0e8b345a638aa0b33a8fa529"
    ];
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $client_id = $request->header('ClientId');
        $api_key = $request->header('ApiKey');
        if(!isset($this->credentials[$client_id])) {
            return response()->json([
                "message" => "Unauthenticated!"
            ], 401);
        }
        if ($this->credentials[$client_id] === $api_key) {
            return $next($request);
        } else {
            return response()->json([
                "message" => "Unauthenticated!"
            ], 401);
        }
    }
}
