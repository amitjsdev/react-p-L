<?php

namespace App\Http\Middleware;

use App\User;
use Closure;

class WebAppAuthMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {

        $token = $request->token;
        // get email from token
        $email = getUserIdFromToken($token);
        // if not email return 401
        if (empty($email)) {
            // just a gimmicky response
            return abort(response('
            <html>
            <meta name="viewport" content="width=device-width, initial-scale=1.0" />
            <title>LOL</title>
            <body>
            <img src="https://i.imgflip.com/465j9s.jpg" title="Please dont hover"/>
            </body>
            <style>
                body { display: flex; justify-content:center; align-items: center; height: 100vh; margin: 0; }
                img { max-width: 100%; }
            </style>
            </html>
            ', 401));
            return abort(401, 'Y U NO AUTHORISED?!');
        }

        // get user
        $request->webappuser = User::whereEmail($email)->first();
        // handle request
        return $next($request);
    }
}
