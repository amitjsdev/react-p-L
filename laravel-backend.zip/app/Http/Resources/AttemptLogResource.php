<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class AttemptLogResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {

        // get answer array
        $answerArray = json_decode($this->answerJSON, true);

        // get user score (correct / total)
        $scorePercentage = 0;
        if (is_array($answerArray) && count($answerArray) > 0) {
            $scorePercentage = (count(array_filter($answerArray, function ($a) {
                return $a['isAnswerCorrect'];
            })) / count($answerArray)) * 100;
        }

        // get easy question percentage (east / total)
        $easyPercentage = 0;
        $easyCount = 0;
        if (is_array($answerArray) && count($answerArray) > 0) {
            $easyCount = count(array_filter($answerArray, function ($a) {
                if (!isset($a['difficultyLevel'])) {
                    return false;
                }
                return $a['difficultyLevel'] == 1; // difficulty for quiz question is level 1
            }));
            $easyPercentage = ($easyCount / count($answerArray)) * 100;
        }

        // get medium question percentage (east / total)
        $mediumPercentage = 0;
        $mediumCount = 0;
        if (is_array($answerArray) && count($answerArray) > 0) {
            $mediumCount = count(array_filter($answerArray, function ($a) {
                if (!isset($a['difficultyLevel'])) {
                    return false;
                }
                return $a['difficultyLevel'] == 2; // difficulty for quiz question is level 2
            }));
            $mediumPercentage = ($mediumCount / count($answerArray)) * 100;
        }


        // get difficult question percentage (difficult / total)
        $difficultPercentage = 0;
        $difficultCount = 0;
        if (is_array($answerArray) && count($answerArray) > 0) {
            $difficultCount = count(array_filter($answerArray, function ($a) {
                if (!isset($a['difficultyLevel'])) {
                    return false;
                }
                return $a['difficultyLevel'] == 3; // difficulty for quiz question is level 3
            }));
            $difficultPercentage = ($difficultCount / count($answerArray)) * 100;
        }


        return [
            "id" => $this->id,
            "userId" => $this->userId,
            "quizSetId" => $this->quizSetId,
            "attemptNumber" => $this->attemptNumber,
            "attemptStatus" => $this->attemptStatus,
            "answerJSON" => is_array($answerArray) ? array_map(function ($answer) {
                unset($answer["correctAnswer"]);
                return $answer;
            }, $answerArray) : null,
            "scorePercentage" => $scorePercentage,
            "quizTopic" => $this->quizSet->quizTopic,
            "easyCount" => $easyCount,
            "easyPercentage" => $easyPercentage,
            "mediumCount" => $mediumCount,
            "mediumPercentage" => $mediumPercentage,
            "difficultCount" => $difficultCount,
            "difficultPercentage" => $difficultPercentage,
            "created_at" => $this->created_at,
            "updated_at" => $this->updated_at
        ];
    }
}
