<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class ExercisePolly extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        //return $this->resource;

        return [
            "id" => (string) $this->resource->id ?? "",
            "lesson_id" => (string) $this->resource->lesson_id ?? "",
            "moduleno" => (string) $this->resource->moduleno ?? "",
            "routeno" => (string) $this->resource->routeno ?? "",
            "lesson_no" => (string) $this->resource->lesson_no ?? "",
            "exercise_no" => (string) $this->resource->exercise_no ?? "",
            "title" => (string) $this->resource->title ?? "",
            "voice_id" => json_decode($this->resource->voice_id, true),  //(string) $this->resource->voice_id ?? "",
            "voice_ssml" => json_decode(base64_decode($this->resource->voice_ssml), true), //(string) $this->resource->voice_ssml ?? "",
            "voice_mp3" => $this->pollyMP3($this->resource),
            "status" => (string) $this->resource->status ?? "",
            "sequence" => (string) $this->resource->sequence ?? "",
        ];

    }


    public function pollyMP3($void)
    {
   
        $mp3Folder = env("S3_MEDIA_LINK");

        $voidc = count(json_decode($void->voice_id)); 

        $polly = array();

        if($voidc>0)
        {

            for($i=1;$i<=$voidc;$i++)
            {

                $mp3Link = $mp3Folder."Lesson_".$void->moduleno."_".$void->routeno."_".$void->lesson_no."_Pack/exercises/".$void->lesson_no.".".$i.".mp3";

                $polly[] = $mp3Link;

            }

        }

        

        
        return $polly;

    }
    

}
