<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class ForumCommentResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            "id" => $this->id,
            "comment" => $this->comment,
            "userId" => $this->userId,
            "isByMe" => $this->userId === auth()->user()->email,
            "employee" => [
                "FirstName" => $this->employee ? $this->employee->FirstName : $this->userId,
            ],
            "created_at" => $this->created_at->diffForHumans(),
            "upvotes" => $this->upvotes()->pluck('userId'),
            "replies" => ForumCommentResource::collection($this->comments)
        ];
    }
}
