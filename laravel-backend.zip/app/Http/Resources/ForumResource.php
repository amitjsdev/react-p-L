<?php

namespace App\Http\Resources;

use App\Employee;
use App\Module;
use Illuminate\Http\Resources\Json\JsonResource;

class ForumResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $employee = Employee::where('userId', auth()->user()->email)->first();
        // get module name
        $forumFor = $this->forumFor;
        if($forumFor instanceof \App\V2Exercise) {
            $module = Module::where('moduleno', $forumFor->moduleNo)->first();
            $lessonNo = $forumFor->lessonNo;
        } else {
            // for lesson (video/listen)
            $module = Module::where('moduleno', $forumFor->moduleno)->first();
            $lessonNo = $forumFor->lesson_no;
        }
        $moduleName = $module ? $module->description : "";
        return [
            "employee" => [
                "userId" => $employee->userId,
                "FirstName" => $employee->FirstName
            ],
            "forum" => [
                "id" => $this->id,
                "moduleName" => $moduleName,
                "lessonNo" => $lessonNo,
                "lang" => $module->language,
                "title" => $this->title,
                "content" => $this->content,
                "entity_id" => $this->forumable_id,
                "entity_type" => $this->for,
                "comments" => ForumCommentResource::collection($this->comments)
            ]
        ];
    }
}
