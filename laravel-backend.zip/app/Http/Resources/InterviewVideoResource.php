<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class InterviewVideoResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'vpi_score' => $this->vpi_score ? json_decode( $this->vpi_score) :null,
            'audio' => $this->audio,
            'lesson' => $this->lesson,
            'student_practice_answers' => $this->student_practice_answers,
            'moduleNo' => $this->moduleNo,
            'routeNo' => $this->routeNo,
            'lessonNo' => $this->lessonNo,
            'sagFlag' => $this->sagFlag,
            'userId' => $this->userId,
            'attemptNo' => $this->attemptNo,
            'filePath' => $this->filePath,
            'lessonName' => $this->lessonName,
            'created_at' => $this->created_at,
            'uuid' => $this->uuid,
            'reviewStatus' => $this->reviewStatus,
            'debugInfo' => $this->debugInfo,
            'isReviewedByInstructor' => $this->isReviewedByInstructor,
            'reviewFileLocation' => $this->reviewFileLocation,
            'self_rating' => $this->self_rating ? new InterviewVideoReviewResource($this->self_rating) : null,
            'self_rating_avg' => $this->self_rating ? $this->getAverage($this->self_rating->reviewJSON) : null,
            'external_rating' => $this->external_rating ? InterviewVideoReviewResource::collection($this->external_rating) : null,
            'my_rating' => $this->my_rating ? new InterviewVideoReviewResource($this->my_rating) : null,
            'external_rating_avg' => $this->external_rating ? $this->getAverageExternalRating($this->external_rating) : null,
            'ai_rating' => $this->ai_rating ? new InterviewVideoReviewResource($this->ai_rating) : null,
            'ai_rating_avg' => $this->ai_rating ? $this->getAverage($this->ai_rating->reviewJSON) : null,
        ];
    }

    private function getAverage($reviewJSON = '')
    {
        try {
            $json = (array) json_decode($reviewJSON);
            if (count($json) > 0) {
                return array_sum($json) / count($json);
            }
        } catch (\Throwable $th) { }
        return null;
    }

    private function getAverageExternalRating($externalRatings = [])
    {
        // holds all averages of ratings
        $ratings = [];
        try {
            foreach ($externalRatings as $externalRating) {
                $json = (array) json_decode($externalRating->reviewJSON);
                if (count($json) > 0) {
                    $ratings[] = array_sum($json) / count($json);
                }
            }
            return array_sum($ratings) / count($ratings);
        } catch (\Throwable $th) { }
        return null;
    }
}
