<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class InterviewVideoReviewResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $resource =  [
            'id' => $this->id,
            'audio' => $this->audio,
            'video' => $this->video,
            'interviewVideoId' => $this->interviewVideoId, // attemptId
            'userId' => $this->userId,
            'reviewType' => $this->reviewType, // '1 for self, 2 for external, 3 for AI'
            'reviewerName' => $this->reviewerName,
            'reviewerEmail' => $this->reviewerEmail,
            'comment' => $this->comment,
            'reviewJSON' => $this->reviewJSON ? json_decode($this->reviewJSON, true) : null,
            'reviewJSONArray' => $this->reviewJSON ? $this->getReviewJSONArray(json_decode($this->reviewJSON)) : null,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];

        // if review is ai review
        if ((int) $this->reviewType === 3) {
            try {
                $rawJSON = json_decode($this->comment, true);
                // create the raw json
                $resource['rawJSON'] = [
                    'Pace of speech' => $rawJSON["nlp"]["words-per-minute"],
                    'Um counter' => null,
                    'Vocabulary sophistication' => null,
                    'Length of answer' => $rawJSON["nlp"]["duration"],
                    'Eye contact' => null,
                    'Volume' => null,
                    'Lighting' => $rawJSON["cv"]["brightness"],
                    'Unnecessary pauses' => null
                ];
            } catch (\Throwable $th) { }
        }

        return $resource;
    }

    private function getReviewJSONArray($json = [])
    {
        $array = [];
        foreach ($json as $key => $value) {
            $array[] = [
                "parameterName" => $key,
                "parameterValue" => $value
            ];
        }
        return $array;
    }
}
