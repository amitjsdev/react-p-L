<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class LeaderboardWeeklyResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            "userId" => $this->userId,
            "current" => $this->current,
            "moduleNo" => $this->employee->currentModule ?? null,
            "lingoCoins" => $this->employee->lingoCoins ?? null,
            "total" => $this->employee ? $this->employee->totalScore > $this->current ? $this->employee->totalScore : $this->current : null,
            "FirstName" => $this->employee ? $this->employee->FirstName === $this->employee->LastName
                ? $this->employee->FirstName
                : trim($this->employee->FirstName . " " . $this->employee->LastName) : null
                ?? "Anonymous",
            "rank" => $this->weekly_rank->rank ?? null,
            "delta" => $this->weekly_rank->delta ?? 0,
            "dailyThumbsUp" => $this->daily_thumbs_up ?? 0,
            "weeklyThumbsUp" => $this->weekly_thumbs_up ?? 0,
            "isDailyThumbsUpedByMe" => isThumbsUpedByMe($this->userId, 'daily'),
            "isWeeklyThumbsUpedByMe" => isThumbsUpedByMe($this->userId, 'weekly'),
            "lastActive" => $this->employee ? $this->employee->lastLoginDate : null,
            "accountCreationDate" => $this->employee->accountCreationDate ?? null,
        ];
    }
}
