<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class QuizSetResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            "id" => $this->id,
            "time" => $this->time,
            "timer" => $this->timer,
            "answer" => $this->answer,
            "allowedReattemptStatus" => $this->allowedReattemptStatus,
            "quizSetId" => $this->quizSetId,
            "companyCode" => $this->companyCode,
            "isProctored" => $this->cohort && $this->cohort->type_id ==2 ? true : false,
            "quizTopic" => $this->quizTopic,
            "timeAllotted" => $this->timeAllotted,
            "questionCap" => $this->questionCap,
            "quizSubTopic" => $this->quizSubTopic,
            "quizSubject" => $this->quizSubject,
            "hasProgression" => $this->hasProgression,
            "quizCompleted" => $this->quizCompleted,
            "profileCompleted" => $this->profileCompleted,
            "quizNeedsRetest" => $this->quizNeedsRetest,
            "allowedReattempt" => $this->allowedReattempt,
            "created_at" => $this->created_at,
            "updated_at" => $this->updated_at,
            "questionCount" => $this->question_count,
            "cohort" => $this->cohort,
            "attempt" => $this->attempt,
        ];
    }
}
