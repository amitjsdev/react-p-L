<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class Route extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            "id" => (string) $this->resource->id ?? "",
            "moduleNo" => (string) $this->resource->moduleno ?? "",
            "routeNo" => (string) $this->resource->routeno ?? "",
            "description" => (string) $this->resource->description ?? "",
            "long_description" => (string) $this->resource->long_description ?? "",
        ];
    }
}
