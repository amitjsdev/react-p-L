<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class UserBadgeResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            "id" => $this->id,
            "badge_code" => $this->badge_code,
            "name" => $this->badge->name,
            "category" => $this->badge->category,
            "identifier" => $this->badge->identifier,
            "description" => createBadgeDescription($this->badge->description, $this->userId),
            "course_number" => $this->course_number,
            "userId" => $this->userId,
            "created_at" => $this->created_at,
            "updated_at" => $this->updated_at,
        ];
    }
}
