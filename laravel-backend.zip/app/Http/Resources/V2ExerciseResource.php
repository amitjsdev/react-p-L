<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class V2ExerciseResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {

        $exerciseDescription = "";

        try {
            $exerciseDescription = strtolower($this->module->language) === "es" ? $this->type->description_es : $this->type->description;
        } catch(\Exception $e) {
            \Log::error("exerciseDescription error in V2ExerciseResource", [$e]);
        }

        return [
                    "id" => $this->id,
                    "sequenceNo" => $this->sequenceNo,
                    "moduleNo" => $this->moduleNo,
                    "routeNo" => $this->routeNo,
                    "lessonNo" => $this->lessonNo,
                    "toLanguage" => $this->module->tolanguage,
                    "fromLanguage" => $this->module->language,
                    "exerciseType" => $this->exerciseType,
                    "exerciseDescription" => $exerciseDescription,
                    "question" => $this->question ?? "",
                    "options" => $this->options ?? "",
                    "answer" => $this->answer ?? "",
                    "translation" => $this->translation ?? "",
                    // "status" => $this->status,
                    // "created_at" => $this->created_at,
                    // "updated_at" => $this->updated_at,
        ];
    }
}
