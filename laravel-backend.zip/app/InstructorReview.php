<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
class InstructorReview extends Model
{
    protected $fillable = [
        'videoId',
        'instructorEmail',
        'videoEmailOpened',
        'reviewCompleted',
        'userId',
    ];
}
