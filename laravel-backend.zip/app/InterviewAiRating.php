<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InterviewAiRating extends Model
{
    protected $fillable = [
        'interview_video_id',
        'moduleNo',
        'routeNo',
        'lessonNo',
        'userId',
        'attemptNo',
        'fluency',
        'wordsPerMinute',
        'unnecessaryPauses',
        'unnecessaryUmsAndAhs'
    ];
}
