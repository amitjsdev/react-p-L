<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InterviewInstructorRating extends Model
{
    protected $fillable = [
        'interview_video_id',
        'moduleNo',
        'routeNo',
        'lessonNo',
        'userId',
        'attemptNo',
        'overallAnswer',
        'concisenessOfAnswer',
        'confidenceLevel',
        'clarityOfSpeech'
    ];
}
