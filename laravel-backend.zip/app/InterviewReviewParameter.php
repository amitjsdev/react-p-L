<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InterviewReviewParameter extends Model
{
    protected $fillable = [
        'reviewParameterId',
        'reviewType',
        'reviewParameter',
    ];
}
