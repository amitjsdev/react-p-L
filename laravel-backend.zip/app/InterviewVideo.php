<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InterviewVideo extends Model
{
    protected $fillable = [
        'moduleNo',
        'routeNo',
        'lessonNo',
        'userId',
        'attemptNo',
        'filePath',
        'reviewStatus', // 0 => idle, 1 => processing, 2 => success, 3 => failed
        'reviewFileLocation',
        'debugInfo',
        'uuid',
        'vpi_score'
    ];

    public function getSelfRatingParameter()
    {
        return InterviewVideoReview::where([
            ['interviewVideoId', $this->id],
            ['reviewType', 1]
        ])->first();
    }


    public function getAiRatingParameter()
    {
        return InterviewVideoReview::where([
            ['interviewVideoId', $this->id],
            ['reviewType', 3]
        ])->first();
    }



    public function getExternalRatingParameter()
    {
        return InterviewVideoReview::where([
            ['interviewVideoId', $this->id],
            ['reviewType', 2]
        ])->get();
    }

    public function getLessonAttribute() // gives the practice question
    {
        return PracticeQuestion::where([
            ['practiceQuestionId', $this->lessonNo],
            ['practiceSetId', $this->moduleNo],
        ])->first();
    }
    public function External()
    {
        return $this->hasMany('App\InterviewVideoReview','interviewVideoId', 'id')->where('reviewType',2);
    }

}
