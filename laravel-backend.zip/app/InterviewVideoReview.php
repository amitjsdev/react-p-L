<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InterviewVideoReview extends Model
{
    protected $fillable = [
        'interviewVideoId', // attemptId
        'userId',
        'audio',
        'video',
        'reviewType', // '1 for self, 2 for external, 3 for AI'
        'reviewerName',
        'reviewerEmail',
        'reviewJSON',
        'comment'
    ];
}
