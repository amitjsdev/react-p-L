<?php

namespace App\Jobs;

use App\Mail\EmailSequence\SpecialPrizeInfo;
use App\UserDailyGoalLog;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Mail;

class CheckForSpecialPrizeInfo implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $employee;
    public $attemptNo;
    const LASTATTEMPT = 4;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($employee, $attemptNo = 1)
    {
        $this->employee = $employee;
        $this->attemptNo = $attemptNo;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $pointsScored = UserDailyGoalLog::where('userId', $this->employee->userId)->sum('points');

        if($pointsScored < 1000 && checkIfEmailSubscribed($this->employee->userId)) {
            SendMailToSubscriber::dispatch(new SpecialPrizeInfo($this->employee), $this->employee->userId);
            if ($this->attemptNo <= $this::LASTATTEMPT) {
                // FIXME: change to days after testing
                CheckForSpecialPrizeInfo::dispatch($this->employee, $this->attemptNo + 1)->delay(now()->addDay());
            }
        }
    }
}
