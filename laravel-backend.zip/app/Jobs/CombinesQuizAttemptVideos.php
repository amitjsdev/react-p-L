<?php

namespace App\Jobs;

use App\QuizAttemptLog;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Symfony\Component\Process\Process;
use Illuminate\Support\Facades\Log;
use App\SignedUrl;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;

class CombinesQuizAttemptVideos implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $quizAttemptLogId;
    public $isAdmin;
    public $timeout = 600;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($quizAttemptLogId,$isAdmin=false)
    {
        $this->quizAttemptLogId = $quizAttemptLogId;
        $this->isAdmin = $isAdmin;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function uploadToS3ExactT(string $location = "", $fileLocation = "", $fileName = "file.txt", $unlink = true)
    {
        echo "$location $fileLocation $fileName";
        // Copy the polly mp3 on s3 media folder
        $S3Dir = "s3://" . env("S3_MEDIA_BUCKET") . '/' . $location . "/" . $fileName;
        ob_start();
        $command = "LANG=en_US.UTF-8; AWS_ACCESS_KEY_ID=" . env("S3_ACCESSKEY") . " AWS_SECRET_ACCESS_KEY=" . env("S3_SECRETKEY") . " " . env("AWS_CLI") . " s3 cp '" . $fileLocation . "' " . $S3Dir . " --acl public-read 2>&1";
        exec($command, $output);
        // $result = ob_get_contents();
        // Log::info('s3 upload status', [$S3Dir, $result, $output, $command]);
        ob_end_clean();
        // remove the localfile
        if ($unlink) {
            @unlink($fileLocation);
        }
    }
    public function handle(){
        $id = $this->quizAttemptLogId;
        $ignore = $this->isAdmin;
        $rows =SignedUrl::where('quizAttemptLogId',$id)->where('processed',null)->get();
        if($ignore){
            $rows =SignedUrl::where('quizAttemptLogId',$id)->get();
        }
        if(!$rows->count()){
            return null;
        }
        // mkvmerge -o output.webm 1.webm + 2.webm +3.webm
        $names =[];
        foreach($rows as $row){
            try {
            $contents = file_get_contents('https://langappnew.s3.amazonaws.com/'.$row->key);
            Storage::disk('local')->put($id.'/'.$row->name, $contents);
            $names[]=storage_path("app/$id/$row->name");
            } catch (\Exception $e) {
                Log::info('CombineS3Files fetch video',  [$e->getMessage()]);
            }

        }
        $names =join(' + ',$names);
        $outputFileLocation =storage_path("app");
        $outputFile =$outputFileLocation."/$id.mp4";
        Log::info('lets create file ', [$outputFile]);
        $cmd ="mkvmerge -o $outputFile $names";
        exec($cmd, $output);
        // $result = ob_get_contents();
        // Log::info('s3 upload status', [$result, $output, $cmd]);
        // ob_end_clean();
        Log::info('lets upload file ', [$outputFile]);
        $this->uploadToS3ExactT($id,$outputFile,"$id.mp4", true);

        Storage::deleteDirectory($id);
        Log::info('directory deleted', [$id]);
        foreach($rows as $row){
          $row->processed=true;
            $row->save();
        }
        QuizAttemptLog::where('id',$id)->update(['streamId'=>"uploads/combinedquizvideos/$id/$id.mp4"]);
        Log::info('all ok  retuning', [$id]);
        return true;
    }
    public function handleOld()
    {
        $id = $this->quizAttemptLogId;
        $isAdmin = $this->isAdmin;
        // Log::info('CombineS3Files fetch video start',[]);
        $rows = SignedUrl::where('quizAttemptLogId', $id)->where('processed', null)->get();
        if($isAdmin){
            $rows = SignedUrl::where('quizAttemptLogId', $id)->get();
        }
        // $rows =SignedUrl::where('quizAttemptLogId',$id)->get();
        if (!$rows->count()) {
            return null;
        }
        // mkvmerge -o output.webm 1.webm + 2.webm +3.webm
        $names = [];
        foreach ($rows as $row) {
            $names[] = 'file https://langappnew.s3.amazonaws.com/'.$row->key;
            // try {
            //     $contents = file_get_contents('https://langappnew.s3.amazonaws.com/' . $row->key);
            //     Storage::disk('local')->put($id . '/' . $row->name, $contents);
            //     $names[] = storage_path("app/$id/$row->name");
            // } catch (\Exception $e) {
            //     Log::info('CombineS3Files fetch video bk',  [$e->getMessage()]);
            // }
        }
        // sleep(60);
        //         ffmpeg -i 41_2313489.webm -i 40_406663.webm \
        // -filter_complex "[0:v] [0:a] [1:v] [1:a] \
        // concat=n=2:v=1:a=1 [v] [a]" \
        // -map "[v]" -map "[a]" output.webm
        // $finalNames = [];
        // $str1 = '';
        // $str2 = '';
        // $n = 0;
        // foreach ($names as $key => $f) {
        //     // if (file_exists($f)) {
        //         $finalNames[] = $f;
        //         $str1 = $str1 . ' -i ' . $f;
        //         $str2 = $str2 . " [$key:v] [$key:a] ";
        //         $n++;
        //     // }
        // }
        // $names = join(' + ', $finalNames);
        // Log::info('CombineS3Files fetch video names',  [$names]);
        $fileContent =join('  '. PHP_EOL, $names);
        $outputFileLocation = storage_path("app");
        $textFile =$outputFileLocation."/attempt{$id}.txt";
        // Storage::put($textFile, $fileContent);
        Storage::disk('local')->put("attempt{$id}.txt", $fileContent);
        sleep(2);
        $outputFile = $outputFileLocation . "/$id.ts";
        $outputFileMp4 = $outputFileLocation . "/$id.mp4";
        // if (file_exists($outputFile)) {
        //     @unlink($outputFile);
        // }
        // $cmd ="mkvmerge -o $outputFile $names";
        // $cmd = 'ffmpeg -y ' . $str1 . ' \
        // -filter_complex "' . $str2 . ' \
        // concat=n=' . $n . ':v=1:a=1 [v] [a]" \
        // -map "[v]" -map "[a]" ' . $outputFile;
        $cmd = ' ffmpeg -f  concat -safe 0 -protocol_whitelist "file,http,https,tcp,tls" -i '.$textFile.' -c copy '.$outputFile;
        exec($cmd, $ou);
        Log::info('ffmpeg ', [$cmd, $ou]);

        // $result = ob_get_contents();
        Log::info('uploadCombineToS3333 status333', ['download and Combined lets upload neww', $outputFile]);
        // if(ob_get_length() > 0) {
        //     ob_clean();
        // }
        if (!file_exists($outputFile)) {
            Log::error("file not exist $outputFile");
        }

        $cmd ="mkvmerge -o $outputFileMp4 $outputFile";
        exec($cmd, $outputmkv);
        sleep(2);
        $this->uploadToS3ExactT("uploads/combinedquizvideos/$id", $outputFileMp4, "$id.mp4", true);

        // Storage::deleteDirectory($id);
        foreach ($rows as $row) {
            $row->processed = true;
            $row->save();
        }
        QuizAttemptLog::where('id', $id)->update(['streamId' => "uploads/combinedquizvideos/$id/$id.mp4"]);
        return $outputFile;
    }
}
