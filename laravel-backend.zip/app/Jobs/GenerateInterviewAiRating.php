<?php

namespace App\Jobs;

use App\InterviewAiRating;
use App\InterviewVideo;
use App\InterviewVideoReview;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Symfony\Component\Process\Process;

class GenerateInterviewAiRating implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $attemptId;
    public $filePath;
    public $s3Process;

    public $timeout = 600;

    public $tries = 5;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($attemptId, $filePath, $s3Process = false)
    {
        $this->attemptId = $attemptId;
        $this->filePath = $filePath;
        $this->s3Process = $s3Process;
    }

    public function handle()
    {

        // get interview video 
        $interviewVideo = InterviewVideo::find($this->attemptId);

        if (!$interviewVideo) {
            sendServerErrorMail("Interview video could not be ai rated , id not found!", ["attemptId" => $this->attemptId, "filePath" => $this->filePath]);
            \Log::error("interview video could not be ai rated id: " . $this->attemptId);
            return;
        }
        if (!$interviewVideo->reviewFileLocation) {
            $interviewVideo->reviewStatus = 3;
            $interviewVideo->save();
            sendServerErrorMail("Interview video could not be ai rated , filePath in attempt missing!", ["attemptId" => $this->attemptId, "filePath" => $this->filePath]);
            \Log::error("interview video could not be ai rated [video missing] id: " . $this->attemptId);
            return;
        }

        $userId = $interviewVideo->userId;

        try {
            $pythonFileLocation = $this->s3Process ? config('taplingua.FEEDBACKPYSCRIPTS3_LOCATION') : config('taplingua.FEEDBACKPYSCRIPT_LOCATION');

            // feed the file to the ai program
            $aiFeedbackProcess = new Process([
                "python3.7",
                $pythonFileLocation,
                // $mp4Path
                "-l",
                $this->filePath
            ]);

            $aiFeedbackProcess->setTimeout(600);

            $aiFeedbackProcess->run();

            if (!$aiFeedbackProcess->isSuccessful()) {
                $interviewVideo->reviewStatus = 3;
                $interviewVideo->save();
                sendServerErrorMail("Interview video could not be ai rated , " . $pythonFileLocation . " py failed!", [
                    "attemptId" => $this->attemptId,
                    "filePath" => $this->filePath,
                    "command" => $aiFeedbackProcess->getCommandLine(),
                    // "mp4Path" => $mp4Path,
                    "userId" => $userId,
                    "aiFeedbackErrorOutput" => $aiFeedbackProcess->getErrorOutput(),
                    "aiFeedbackStandardOutput" => $aiFeedbackProcess->getOutput(),
                ]);
                \Log::error("interview video could not be ai rated [feedback.py failed] id: " . $this->attemptId, [
                    $aiFeedbackProcess->getErrorOutput(),
                    // $mp4Path
                ]);
                return;
            }

            // get the json after response
            // get the json
            // $mp4PathArray = explode("/", $mp4Path);
            // $mp4FileName = array_pop($mp4PathArray);
            // $jsonFilePath = config('taplingua.FEEDBACKPYJSON_LOCATION') . str_replace(".mp4", ".json", $mp4FileName);
            $webmPathArray = explode(".com/", $this->filePath);
            $webmFileName = str_replace("/", "--", array_pop($webmPathArray));
            $jsonFilePath = config('taplingua.FEEDBACKPYJSON_LOCATION') . str_replace(".webm", ".json", $webmFileName);
            try {

                if (!file_exists($jsonFilePath)) {
                    $interviewVideo->reviewStatus = 3;
                    $interviewVideo->save();
                    sendServerErrorMail("Interview video could not be ai rated , jsonfile Missing!", [
                        "attemptId" => $this->attemptId,
                        "filePath" => $this->filePath,
                        // "mp4Path" => $mp4Path,
                        "userId" => $userId,
                        "jsonFilePath" => $jsonFilePath,
                    ]);
                    \Log::error("interview video could not be ai rated [file missing] id: " . $this->attemptId, [
                        $aiFeedbackProcess->getOutput(),
                        $jsonFilePath
                    ]);
                    return;
                }

                $response = json_decode(file_get_contents($jsonFilePath), true);

                // check if error is set
                if (isset($response["Error"])) {
                    sendServerErrorMail("Interview video json logged error", [
                        "attemptId" => $this->attemptId,
                        "filePath" => $this->filePath,
                        // "mp4Path" => $mp4Path,
                        "jsonFilePath" => $jsonFilePath,
                        "jsonFileOutput" => $response,
                        "userId" => $userId,
                    ]);
                    $interviewVideo->reviewStatus = 3;
                    try {
                        $interviewVideo->debugInfo = $response["Error"];
                    } catch (\Throwable $th) { }
                    $interviewVideo->save();
                }

                // $response = json_decode($aiFeedbackProcess->getOutput());
            } catch (\Throwable $th) {
                $interviewVideo->reviewStatus = 3;
                $interviewVideo->save();
                sendServerErrorMail("Interview video could not be ai rated , something else went wrong!", [
                    "attemptId" => $this->attemptId,
                    "filePath" => $this->filePath,
                    // "mp4Path" => $mp4Path,
                    "jsonFilePath" => $jsonFilePath,
                    "jsonFileOutput" => $response,
                    "exception" => $th,
                    "userId" => $userId,
                    "exceptionArr" => $th->__toString(),
                    "exceptionMessage" => $th->getMessage(),
                    "exceptionTrace" => $th->getTraceAsString(),
                ]);
                \Log::error("interview video could not be ai rated [unparsable output] id: " . $this->attemptId, [
                    $aiFeedbackProcess->getOutput(),
                    $jsonFilePath
                ]);
                return;
            }

            try {

                // modify the review json to make compatible with other review json

                $reviewJSON = [];

                foreach (array_merge($response["nlp"], $response["cv"]) as $value) {
                    if (isset($value["headerText"])) {
                        $reviewJSON[$value["headerText"]] = $value["parameterScore"];
                    }
                }

                // save the ratings
                $review = InterviewVideoReview::create([
                    'userId' => $userId,
                    'reviewType' => 3,
                    'interviewVideoId' => $interviewVideo->id,
                    'comment' => json_encode($response),
                    'reviewJSON' => json_encode($reviewJSON)
                ]);

                \Log::info("interview video  ai rated [successfully] id: " . $this->attemptId, [
                    $aiFeedbackProcess->getOutput(),
                    $jsonFilePath
                ]);
                $interviewVideo->reviewStatus = 2;
                $interviewVideo->save();

                // TODO: remove the video from local, save to server
                @unlink($this->filePath);
                // @unlink($mp4Path);
                @unlink($jsonFilePath);
            } catch (\Throwable $th) {

                $interviewVideo->reviewStatus = 3;
                $interviewVideo->save();
                sendServerErrorMail("Interview video could not be ai rated , something else went wrong while accessing the json response!", [
                    "attemptId" => $this->attemptId,
                    "filePath" => $this->filePath,
                    "jsonFilePath" => $jsonFilePath,
                    "response" => $response,
                    "exception" => $th,
                    "userId" => $userId,
                    "exceptionArr" => $th->__toString(),
                    "exceptionMessage" => $th->getMessage(),
                    "exceptionTrace" => $th->getTraceAsString(),
                ]);
                \Log::error("interview video  ai rated [not successfully] id: " . $this->attemptId, [
                    $aiFeedbackProcess->getOutput(),
                    $jsonFilePath,
                    $th
                ]);
            }
        } catch (\Throwable $th) {

            $interviewVideo->reviewStatus = 3;
            $interviewVideo->save();
            sendServerErrorMail("Interview video could not be ai rated , something else went wrong!", [
                "attemptId" => $this->attemptId,
                "filePath" => $this->filePath,
                "userId" => $userId,
                "exception" => $th,
                "exceptionArr" => $th->__toString(),
                "exceptionMessage" => $th->getMessage(),
                "exceptionTrace" => $th->getTraceAsString(),
            ]);
            \Log::error("interview video  ai rated [not successfully] id: " . $this->attemptId, [
                $aiFeedbackProcess->getOutput(),
                "exception" => $th,
                "exceptionArr" => $th->__toString(),
                "exceptionMessage" => $th->getMessage(),
                "exceptionTrace" => $th->getTraceAsString(),
            ]);
        }
    }

    public function failed(\Throwable $th)
    {

        // get interview video 
        $interviewVideo = InterviewVideo::find($this->attemptId);

        if (!$interviewVideo) {
            return;
        }

        $userId = $interviewVideo->userId;

        sendServerErrorMail("Interview video could not be ai rated , the job failed!", [
            "attemptId" => $this->attemptId,
            "filePath" => $this->filePath,
            "userId" => $userId,
            "exception" => $th,
            "exceptionArr" => $th->__toString(),
            "exceptionMessage" => $th->getMessage(),
            "exceptionTrace" => $th->getTraceAsString(),
        ]);
    }

    public function getPaceOfSpeechRating($actualWordsPerMinute = 0)
    {
        $idealWordsPerMinute = 150;
        // calculate the variance from normal
        $variance = abs($idealWordsPerMinute - $actualWordsPerMinute);

        if ($variance < ($idealWordsPerMinute * 0.1)) {
            return 5;
        }
        if (
            $variance < ($idealWordsPerMinute * 0.15)
        ) {
            return 4;
        }
        if (
            $variance < ($idealWordsPerMinute * 0.2)
        ) {
            return 3;
        }
        if (
            $variance < ($idealWordsPerMinute * 0.25)
        ) {
            return 2;
        }

        if ($variance < ($idealWordsPerMinute * 0.3)) {
            return 1;
        }
        // return 1 rating by default
        return 1;
    }

    public function getFillerWordsRating($wordsSpoken = 0)
    {
        if ($wordsSpoken < 10) {
            return 5;
        }
        if ($wordsSpoken < 15) {
            return 4;
        }
        if ($wordsSpoken < 20) {
            return 3;
        }
        if ($wordsSpoken < 25) {
            return 2;
        }
        return 1;
    }

    public function getLengthOfAnswerRating($durationInSeconds = 0)
    {
        // calculate the variance from normal
        $variance = abs(90 - $durationInSeconds);

        if ($variance < (90 * 0.1)) {
            return 5;
        }
        if (
            $variance < (90 * 0.15)
        ) {
            return 4;
        }
        if (
            $variance < (90 * 0.2)
        ) {
            return 3;
        }
        if (
            $variance < (90 * 0.25)
        ) {
            return 2;
        }

        if ($variance < (90 * 0.3)) {
            return 1;
        }
        // return 1 rating by default
        return 1;
    }

    /**
     * Execute the job of azure (not using rn).
     *
     * @return void
     */
    public function handleAzure()
    {

        // get interview video 
        $interviewVideo = InterviewVideo::find($this->attemptId);

        if (!$interviewVideo) {
            \Log::error("interview video could not be ai rated id: " . $this->attemptId);
            return;
        }
        if (!$interviewVideo->filePath) {
            \Log::error("interview video could not be ai rated [video missing] id: " . $this->attemptId);
            return;
        }



        // process the video to get wav file
        $wavFilePath = storage_path() . "/tmp/interview-video-output" . uniqid() . ".wav";
        $ffmpeg = new Process([
            "ffmpeg",  // ffmpeg
            "-i",
            "https://langappnew.s3.amazonaws.com/uploads/" . $interviewVideo->filePath, // input video
            "-acodec",
            "pcm_s16le",
            "-ac",
            "2",
            "-ar",
            "44100",
            "-y", // parameters
            $wavFilePath // output file
        ]);

        $ffmpeg->run();
        if (!$ffmpeg->isSuccessful()) {
            \Log::error("interview video could not be ai rated [ffmpeg failed] id: " . $this->attemptId, [
                $ffmpeg->getErrorOutput(),
            ]);
            return;
        }

        // use azure sdk to get response
        $command = "node " . config('taplingua.AZURESCRIPT_LOCATION') . " proass " . $wavFilePath;

        $process = new Process([
            "node",
            config('taplingua.AZURESCRIPT_LOCATION'),
            "proass",
            $wavFilePath
        ]);

        $process->run();

        if (!$process->isSuccessful()) {
            \Log::error("interview video could not be ai rated [azurescript failed] id: " . $this->attemptId, [
                $process->getErrorOutput()
            ]);
            return;
        }

        $result = json_decode(explode("RESULT:", $process->getOutput())[1]);

        // get the assessment
        $pronunciationAssessment = $result->privPronJson->PronunciationAssessment;

        // create ratings
        $aiRating = InterviewAiRating::create([
            'interview_video_id' => $interviewVideo->id,
            'moduleNo' => $interviewVideo->moduleNo,
            'routeNo' => $interviewVideo->routeNo,
            'lessonNo' => $interviewVideo->lessonNo,
            'userId' => $interviewVideo->userId,
            'attemptNo' => $interviewVideo->attemptNo,
            'fluency' => ceil($pronunciationAssessment->FluencyScore / 20),
            'wordsPerMinute' => rand(2, 5),
            'unnecessaryPauses' => rand(2, 5),
            'unnecessaryUmsAndAhs' => rand(2, 5)
        ]);

        // remove the wav file
        @unlink($wavFilePath);
    }
}
