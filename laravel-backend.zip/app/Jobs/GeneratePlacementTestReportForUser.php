<?php

namespace App\Jobs;

use App\Employee;
use App\Module;
use App\PlacementExerciseLog;
use App\PlacementLog;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class GeneratePlacementTestReportForUser implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $placementLogId;

    // the relation of exercise type to category
    public static $exercise_categories_relation = [
        'translate_sentence' => "Concept 1",
        'tap_what_you_hear' => "Listening",
        'multiple_choice' => "Concept 1",
        'voice_recognition' => "Speaking",
        '3_pair_of_words' => "Concept 1",
        'tap_words_to_complete_dialog' => "Concept 1",
        'tap_letters_to_complete_word' => "Concept 1",
        'tap_the_pair' => "Concept 1",
        'tap_the_pair_sentences' => "Concept 1",
        'mini_lesson_1' => "Concept 2",
        'mini_lesson_2' => "Concept 2",
        'select_missing_word' => "Concept 1",
        'mini_lesson_3' => "Concept 2",
        'select_correct_translation' => "Concept 1",
        'how_do_you_say' => "Concept 1",
        'pick_correct_type' => "Concept 1",
    ];

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($placementLogId)
    {
        $this->placementLogId = $placementLogId;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        try {

            // get the placement log
            $placementLog = PlacementLog::find($this->placementLogId);

            // get the employee
            $employee = Employee::where('userId', $placementLog->userId)->first();

            // 
            $roundExerciseLogs = PlacementExerciseLog::where('userId', $employee->userId)
                ->where('roundLogId', $placementLog->id)
                ->get();

            $module = Module::where('moduleno', $placementLog->moduleNo)->first();

            // hold user data
            $userLogs = [
                "Concept 1" => 0,
                "Concept 2" => 0,
                "Listening" => 0,
                "Speaking" => 0,
                "Total" => 0,
            ];

            $incorrectCount = [
                "Concept 1" => 0,
                "Concept 2" => 0,
                "Listening" => 0,
                "Speaking" => 0,
                "Total" => 0,
            ];

            $totalCount = [
                "Concept 1" => 0,
                "Concept 2" => 0,
                "Listening" => 0,
                "Speaking" => 0,
                "Total" => 0,
            ];


            // go through each log and create data for each user
            foreach ($roundExerciseLogs as $log) {
                // increment the  in one of the categories for user, if status is false
                $category = self::$exercise_categories_relation[$log->type];
                if ($log->failCount > 0) {
                    $userLogs[$category] += (int) $log->failCount;
                    $userLogs["Total"] += (int) $log->failCount;
                    // increment the incorrect count by 1
                    $incorrectCount[$category]++;
                    $incorrectCount["Total"]++;
                }
                // increment the percentage values anyway
                $totalCount[$category]++;
                $totalCount["Total"]++;
            }

            // correct percentage
            $correctPercentage = [];
            foreach ($totalCount as $catName => $value) {
                $correctPercentage[$catName] = round(($value > 0 ? ($value - $incorrectCount[$catName]) / $value : 0) * 100, 2);
            }

            $emailLog = logEmail($employee->userId, "placement-test-report-for-user");

            $email = new \App\Mail\PlacementTestResultEmail($module, $employee, $correctPercentage);

            SendMailToSubscriber::dispatch($email, $employee->userId);
        } catch (\Throwable $th) {
            \Log::error("placement-test-report-for-user failed!", [$th]);
        }
    }
}
