<?php

namespace App\Jobs;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Aws\Exception\AwsException;
use Aws\S3\Exception\S3Exception;
use Illuminate\Support\Facades\Log;
use App\S3MultiPartUploadLocal;
use App\QuizAttemptLog;
use AWS;
use App\Http\Controllers\SignedUrlController;

class MarkCompleteS3MultipartUploadFixedM implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $quizAttemptLogId;
    public $bucket;
    public $timeout = 600;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($quizAttemptLogId)
    {
        $this->quizAttemptLogId = $quizAttemptLogId;
        $this->bucket ='langappnew';
    }

    /**
     * Execute the job.
     *
     * @return void
     */

    public function handle(){
        $ck = new SignedUrlController();
        $ck->Reverse($this->quizAttemptLogId);

}

}
