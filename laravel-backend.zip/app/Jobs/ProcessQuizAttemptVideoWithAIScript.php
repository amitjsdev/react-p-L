<?php

namespace App\Jobs;

use App\QuizAttemptLog;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Symfony\Component\Process\Process;
use Illuminate\Support\Facades\Log;
class ProcessQuizAttemptVideoWithAIScript implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $quizAttemptLogId;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($quizAttemptLogId)
    {
        $this->quizAttemptLogId = $quizAttemptLogId;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        // get the attempt
        $quizAttemptLog = QuizAttemptLog::find($this->quizAttemptLogId);

        if (!$quizAttemptLog) {
            sendServerErrorMail("Quiz Attempt video could not be ai rated , id not found!", ["quizAttemptLogId" => $this->quizAttemptLogId]);
            Log::error("Quiz Attempt video could not be ai rated id: " . $this->quizAttemptLogId);
            return;
        }

        if (!$quizAttemptLog->proctoredVideo) {
            sendServerErrorMail("Quiz Attempt video could not be ai rated , proctoredVideo not found!", ["quizAttemptLogId" => $this->quizAttemptLogId]);
            Log::error("Quiz Attempt video could not be ai rated id: " . $this->quizAttemptLogId);
            return;
        }

        $filePath = "https://langappnew.s3.amazonaws.com/" . $quizAttemptLog->proctoredVideo;

        // try rating the video
        try {
            $pythonFileLocation = config('taplingua.FEEDBACKPYSCRIPTS3_LOCATION');

            // feed the file to the ai program
            $aiFeedbackProcess = new Process([
                "python3.7",
                $pythonFileLocation,
                // $mp4Path
                // "proctoring=true",
                "-l",
                $filePath
            ]);

            $aiFeedbackProcess->setTimeout(600);
            Log::error("aiFeedbackProcess");
            $aiFeedbackProcess->run();
            Log::error("aiFeedbackProcess", [$aiFeedbackProcess]);

            // if process has error, send it
            if (!$aiFeedbackProcess->isSuccessful()) {
                $quizAttemptLog->aiStatus = 2;
                $quizAttemptLog->save();
                sendServerErrorMail("Quiz Attempt could not be ai rated , " . $pythonFileLocation . " py failed!", [
                    "quizAttemptLogId" => $this->quizAttemptLogId,
                    "filePath" => $filePath,
                    "command" => $aiFeedbackProcess->getCommandLine(),
                    // "mp4Path" => $mp4Path,
                    "aiFeedbackErrorOutput" => $aiFeedbackProcess->getErrorOutput(),
                    "aiFeedbackStandardOutput" => $aiFeedbackProcess->getOutput(),
                ]);
                Log::error("Quiz Attempt video could not be ai rated [feedback.py failed] id: " . $this->quizAttemptLogId, [
                    $aiFeedbackProcess->getErrorOutput(),
                    // $mp4Path
                ]);
                return;
            }

            // get the json after response
            $webmPathArray = explode(".com/", $filePath);
            $webmFileName = str_replace("/", "--", array_pop($webmPathArray));
            $jsonFilePath = config('taplingua.FEEDBACKPYJSON_LOCATION') . str_replace(".webm", ".json", $webmFileName);
            try {

                // if json file non existant, show error
                if (!file_exists($jsonFilePath)) {
                    $quizAttemptLog->aiStatus = 2;
                    $quizAttemptLog->save();
                    sendServerErrorMail("Quiz Attempt video could not be ai rated , jsonfile Missing!", [
                        "quizAttemptLogId" => $this->quizAttemptLogId,
                        "filePath" => $filePath,
                        // "mp4Path" => $mp4Path,
                        "jsonFilePath" => $jsonFilePath,
                    ]);
                    Log::error("Quiz Attempt video could not be ai rated [file missing] id: " . $this->attemptId, [
                        $aiFeedbackProcess->getOutput(),
                        $jsonFilePath
                    ]);
                    return;
                }

                // get json response
                $response = json_decode(file_get_contents($jsonFilePath), true);

                // check if error is set
                if (isset($response["Error"])) {
                    sendServerErrorMail("Quiz Attempt video json logged error", [
                        "quizAttemptLogId" => $this->quizAttemptLogId,
                        "filePath" => $filePath,
                        // "mp4Path" => $mp4Path,
                        "jsonFilePath" => $jsonFilePath,
                        "jsonFileOutput" => $response,
                    ]);
                    $quizAttemptLog->aiStatus = 2;
                    $quizAttemptLog->save();
                }

                // save response to video
                $quizAttemptLog->aiOutput = $response;
                $quizAttemptLog->save();

                // $response = json_decode($aiFeedbackProcess->getOutput());
            } catch (\Throwable $th) {
                $quizAttemptLog->aiStatus = 2;
                $quizAttemptLog->save();
                sendServerErrorMail("Quiz Attempt could not be ai rated , something else went wrong!", [
                    "quizAttemptLogId" => $this->quizAttemptLogId,
                    "filePath" => $filePath,
                    // "mp4Path" => $mp4Path,
                    "jsonFilePath" => $jsonFilePath,
                    "jsonFileOutput" => $response,
                    "exception" => $th,
                    "exceptionArr" => $th->__toString(),
                    "exceptionMessage" => $th->getMessage(),
                    "exceptionTrace" => $th->getTraceAsString(),
                ]);
                Log::error("Quiz attempt video could not be ai rated [unparsable output] id: " . $this->attemptId, [
                    $aiFeedbackProcess->getOutput(),
                    $jsonFilePath
                ]);
                return;
            }
        } catch (\Throwable $th) {
            //throw $th;
        }
    }
}
