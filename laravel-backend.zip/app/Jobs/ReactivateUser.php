<?php

namespace App\Jobs;

use App\Employee;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class ReactivateUser implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $userId;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct(String $userId)
    {
        $this->userId = $userId;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $employee = Employee::where('userId', $this->userId)->first();
        // Set employee status to was on break
        $employee->was_on_break = true;
        $employee->save();
        // reactivate the user if needed
        reactivateUserIfNeeded($employee);
        Log::info("User [" . $this->userId . "] reactivated after 4 days");
    }
}
