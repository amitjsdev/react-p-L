<?php

namespace App\Jobs;

use App\Console\Commands\CheckForUserStateUsingUserPoints;
use App\UserSegment;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;

class SendConditionalPushToPhasedUser implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $payload = [];
    private $userId = "";
    private $campaign_id = "";
    private $screenCode = "";
    private $notificationTitle = "";
    private $notificationBody = "";

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct(string $userId = "", array $payload = [], string $campaign_id = "", $screenCode = null, $notificationTitle = "A new Notification", $notificationBody = "")
    {
        $this->userId = $userId;
        $this->payload = $payload;
        $this->campaign_id = $campaign_id;
        $this->screenCode = $screenCode;
        $this->notificationTitle = $notificationTitle;
        $this->notificationBody = $notificationBody;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        // Send push if user not in active segment
        $activeSegment = UserSegment::where('code', CheckForUserStateUsingUserPoints::SEGMENT_ACTIVE_USERS)->first();
        $isUserInActiveSegment = DB::table('user_user_segment')
            ->where('userId', $this->userId)
            ->where('user_segment_id', $activeSegment->id)
            ->exists();
        if (!$isUserInActiveSegment) {
            // send the push
            SendPush::dispatch(
                $this->userId,
                $this->payload,
                $this->campaign_id,
                $this->screenCode,
                $this->notificationTitle,
                $this->notificationBody
            );
        }
    }
}
