<?php

namespace App\Jobs;

use App\Card;
use App\Employee;
use App\Module;
use App\PushLog;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class SendContentfulFlashPush implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    const CONTENTFULFLASHPUSH_ONE = "contentfulflashpush_one";
    const CONTENTFULFLASHPUSH_TWO = "contentfulflashpush_two";

    public $employee;
    public $campaignId;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct(Employee $employee, string $campaignId)
    {
        $this->employee = $employee;
        $this->campaignId = $campaignId;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        return;
        $forbiddenTypes = [
            'conditional-push-2hr',
            'conditional-push-0800',
            'conditional-push-1300',
            SendContentfulFlashPush::CONTENTFULFLASHPUSH_ONE,
            SendContentfulFlashPush::CONTENTFULFLASHPUSH_TWO,
        ];
        // check if this contentful push is already pushed to user today, if so,
        if (PushLog::where('userId', $this->employee->userId)->whereDate('created_at', Carbon::today())->where('type', $this->campaignId)->exists()) {
            \Log::info("pushed to user already", [$this->employee->userId, $this->campaignId]);
            // create a cache
            markJobDispatched($this->employee->userId, $this->campaignId, "push_job");
            return;
        }

        // check if specific pushes to user have been more than limit today?
        if (in_array($this->campaignId, $forbiddenTypes)) {
            if (PushLog::where('userId', $this->employee->userId)->whereDate('created_at', Carbon::today())->whereIn('type', $forbiddenTypes)->count() > \App\Employee::where('userId', $this->employee->userId)->first()->max_daily_push) {
                \Log::info("limit reached", [$this->employee->userId, $this->campaignId]);
                // create a cache
                markJobDispatched($this->employee->userId, $this->campaignId, "push_job");
                return;
            }
        }

        $toLanguage = '';
        $cards = [];
        // get the current Module and lessonNo for that module upto which the user is done
        $currentCourseNumber =  $this->employee->currentCourse;
        if($currentCourseNumber) {
            // get the last lesson from employeecourse table
            $employeeCourse = DB::table('employeecourse')->where('userId', $this->employee->userId)->where('courseNumber', $currentCourseNumber)->first();
            if($employeeCourse) {
                // get lessonNo
                $lessonNo = $employeeCourse->last_lesson ? $employeeCourse->last_lesson : 1;
                // get moduleNo
                $moduleNo = getCourseModule($currentCourseNumber);

                $toLanguage = Module::where('moduleno', $moduleNo)->first()->tolanguage;

                // get cards below this level number for this module
                $cards = Card::where('moduleNo', $moduleNo)->where('lesssonNo', '<=', $lessonNo)->take(3)->inRandomOrder()->get()->toArray();

            }
        } else {
            Log::error('could not get current course for employee', [
                'userId' => $this->employee->userId,
                'currentCourseNumber' => $currentCourseNumber
            ]);
        }
        // create a log
        markJobDispatched($this->employee->userId, $this->campaignId, "push_job");
        // send push
        SendPush::dispatch($this->employee->userId, [ 'toLanguage' => $toLanguage, 'cards' => $cards], $this->campaignId, 112, "Do you remember the phrase \"". $cards[0]['originalText'] . '"'); // 112 is for contentful flash push
    }
}
