<?php

namespace App\Jobs;

use App\Employee;
use App\RoundLog;
use App\UserActivityLog;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SendContentfulFlashToInactiveUser implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $userId;
    public $screenCode;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($userId, $screenCode = null)
    {
        $this->userId = $userId;
        $this->screenCode = $screenCode;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        return;
        // get employee
        $employee = Employee::where('userId', $this->userId)->first();
        // check if user has done any user activity till now
        // Check for the push
        $this->checkForPush($employee);
    }

    private function checkForPush(Employee $employee)
    {
        // check if user activity log exists
        $isUserActivityAvailable = UserActivityLog::where('userId', $employee->userId)->exists();
        // check if round log exists
        $isRoundLogAvailable = RoundLog::where('userId', $employee->userId)->exists();

        // if neither user activity or round log doesnt exists
        if (((!$isRoundLogAvailable || !$isUserActivityAvailable) && $this->screenCode === null)  || $this->screenCode === 113) {
            SendPush::dispatch(
                $employee->userId,
                [],
                "inactive-user-1-" . time(),
                113,
                "Hi " . $employee->FirstName,
                "Did you forget to checkout Taplingua?"
            );
            return;
        }

        // if there is activity type 3 (play done) but not activity type 2 (video not done)
        $playDone = UserActivityLog::where('userId', $employee->userId)
            ->where('activityType', 3)->exists();
        $videoNotDone = UserActivityLog::where('userId', $employee->userId)
            ->where('activityType', 2)->doesntExist();

        // if user played  but not watched video
        if (($isUserActivityAvailable && $this->screenCode === null)  || $this->screenCode === 114) {
            if (($playDone && $videoNotDone && $this->screenCode === null)  || $this->screenCode === 114) {
                SendPush::dispatch(
                    $employee->userId,
                    [],
                    "inactive-user-2-" . time(),
                    114,
                    "Hi " . $employee->FirstName . ", Hope you liked the Taplingua the exercise",
                    "Did you know that we  have video explanations also?"
                );
                return;
            }
        }

        // if user watched video but not played
        if (($isUserActivityAvailable  && $this->screenCode === null)  || $this->screenCode === 115) {
            if ((!$playDone && !$videoNotDone  && $this->screenCode === null)  || $this->screenCode === 115) {
                SendPush::dispatch(
                    $employee->userId,
                    [],
                    "inactive-user-3-" . time(),
                    115,
                    $employee->FirstName . ". Put it into practice.",
                    "Hope you found the videos helpful. Now let's put it into practice by playing a game."
                );
                return;
            }
        }

        // round log exists but not completed exercise
        // get all round log for user
        $roundLogs = RoundLog::where('userId', $employee->userId)->get();
        if (($roundLogs->where('status', 1)->count() === 0 && $roundLogs->where('status', -1)->count() > 0 && $this->screenCode === null)  || $this->screenCode === 116) {
            SendPush::dispatch(
                $employee->userId,
                [],
                "inactive-user-4-" . time(),
                116,
                "Hi " . $employee->FirstName,
                "Don't forget to finish your game!"
            );
            return;
        }
    }
}
