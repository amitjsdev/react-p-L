<?php

namespace App\Jobs;

use App\ContentfulExerciseLog;
use App\Employee;
use App\PushLog;
use App\RoundExerciseLog;
use App\RoundLog;
use App\V2Exercise;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SendContentfulPush implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $userId;
    public $moduleNo;
    public $campaignId;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($userId, $moduleNo, $campaignId)
    {
        $this->userId = $userId;
        $this->moduleNo = $moduleNo;
        $this->campaignId = $campaignId;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        return;
        try {

            $forbiddenTypes = [
                'conditional-push-2hr',
                'conditional-push-0800',
                'conditional-push-1300',
                SendContentfulFlashPush::CONTENTFULFLASHPUSH_ONE,
                SendContentfulFlashPush::CONTENTFULFLASHPUSH_TWO,
            ];
            // check if this contentful push is already pushed to user today, if so,
            if (PushLog::where('userId', $this->userId)->whereDate('created_at', Carbon::today())->where('type', $this->campaignId)->exists()) {
                \Log::channel('pushlog')->info("pushed to user already", [$this->userId, $this->campaignId]);
                return;
            }

            // check if specific pushes to user have been more than limit today?
            if (in_array($this->campaignId, $forbiddenTypes)) {
                if (PushLog::where('userId', $this->userId)->whereDate('created_at', Carbon::today())->whereIn('type', $forbiddenTypes)->count() > \App\Employee::where('userId', $this->userId)->first()->max_daily_push) {
                    \Log::channel('pushlog')->info("limit reached", [$this->userId, $this->campaignId]);
                    return;
                }
            }

            $employee = Employee::where('userId', $this->userId)->first();

            // check roundNo for this MRL and userId combo
            // get failed exercise
            $allExerciseIds = V2Exercise::where('moduleNo', $this->moduleNo)
                ->where('lessonNo', $employee->last_lesson ?? 1)
                ->where('forInteractiveListen', '!=', 1)
                ->where('exerciseType', 'tap_the_pair')
                ->pluck('id');
            $failedExercises = RoundExerciseLog::whereIn('questionId', $allExerciseIds)
                ->where('round_exercise_logs.status', '!=', 1)
                ->join('round_logs', 'round_logs.id', '=', 'round_exercise_logs.roundLogId')
                ->where('isMiniRound', '!=', 1)
                ->where('round_logs.userId', $this->userId)
                ->get();
            if (count($failedExercises) > 0) {
                // if failed exercises are available
                $oneRandomFailedExercise = $failedExercises->random();
                $exercise = V2Exercise::where("id", $oneRandomFailedExercise->questionId)->first();
            } else {
                // take any random exercise
                $exercise = V2Exercise::where('moduleNo', $this->moduleNo)
                    ->where('lessonNo', $employee->last_lesson ? $employee->last_lesson : 1)
                    ->where('exerciseType', 'tap_the_pair')
                    ->where('status', 1)
                    ->inRandomOrder()
                    ->first();
            }
            // create contentful exercise log for new record
            $contentfulExerciseLog = ContentfulExerciseLog::create([
                "userId" => $this->userId,
                "questionId" => $exercise->id,
                "status" => -1,
            ]);
            // set roundNo with exercise
            $exercise->roundId = $contentfulExerciseLog->id;
            SendPush::dispatch(
                $this->userId,
                $exercise->toArray(),
                $this->campaignId,
                111,
                "2 Min Exercise Review " . $employee->FirstName . "?"
            ); // 111 screencode for contentful push
        } catch (\Throwable $th) {
            \Log::channel('pushlog')->info("push failed", [$this->userId, $this->campaignId, $th]);
        }
    }
}
