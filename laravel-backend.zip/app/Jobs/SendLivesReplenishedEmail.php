<?php

namespace App\Jobs;

use App\EmailTemplate;
use App\Employee;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SendLivesReplenishedEmail implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    const CAMPAIGN_ID = 'lives-replenished-email';

    public $userId;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct(String $userId)
    {
        // get userId
        $this->userId = $userId;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        return;
        // get employee
        $employee = Employee::where('userId', $this->userId)->first();

        // get the template
        $pushCampaign = EmailTemplate::findByIdentifier(self::CAMPAIGN_ID);

        // send the push
        $pushCampaign->sendMail($employee, now());
    }
}
