<?php

namespace App\Jobs;

use App\Employee;
use App\PushCampaign;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SendLivesReplenishedPush implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    const CAMPAIGN_ID = 'lives-replenished-push';

    public $userId;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct(String $userId)
    {
        // get userId
        $this->userId = $userId;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        return;
        // get employee
        $employee = Employee::where('userId', $this->userId)->first();

        // get the template
        $pushCampaign = PushCampaign::findByCampaignId(self::CAMPAIGN_ID);

        // send the push
        $pushCampaign->sendPush($employee, now());
    }
}
