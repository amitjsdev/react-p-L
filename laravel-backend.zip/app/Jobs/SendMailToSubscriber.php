<?php

namespace App\Jobs;

use App\Employee;
use App\Mail\EmailSequence\PollyWelcomeEmail;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

class SendMailToSubscriber implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $mail;
    public $to;
    public $forced;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct(Mailable $mail, string $to, bool $forced = false)
    {
        $this->mail = $mail;
        $this->to = $to;
        $this->forced = $forced;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {

        $employee = Employee::where('userId', $this->to)->first();
        // send mail only if user not unsubscribed
        if (checkIfEmailSubscribed($this->to)) {
            if (!$this->forced) {
                // TODO: check if limit expired
            }
            $mail = Mail::to($this->to);
            if($this->mail instanceof PollyWelcomeEmail) {
                $mail = $mail->bcc("santanu@taplingua.com", "Santanu");
            }
            $mail->send($this->mail);
            Log::info("mail sent to " . $this->to);
        } else {
            Log::info("mail not sent to " . $this->to . " as user is unsubscribed!");
        }
    }
}
