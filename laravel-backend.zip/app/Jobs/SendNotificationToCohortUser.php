<?php

namespace App\Jobs;

use App\Cohort;
use App\Course;
use App\EmailTemplate;
use App\Employee as AppEmployee;
use App\Http\Resources\Employee;
use App\Mail\TemplateMail;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SendNotificationToCohortUser implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $userId;
    public $cohortId;
    public $type;
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($userId, $cohortId, $type)
    {
        $this->userId = $userId;
        $this->cohortId = $cohortId;
        $this->type = $type;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    { }
}
