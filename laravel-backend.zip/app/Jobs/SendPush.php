<?php

namespace App\Jobs;

use App\Employee;
use App\Mail\NotificationMail;
use App\PushLog;
use App\UserTimeLog;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Kreait\Firebase\Messaging;
use Kreait\Firebase\Messaging\CloudMessage;

class SendPush implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $payload = [];
    private $userId = "";
    private $campaign_id = "";
    private $screenCode = "";
    private $notificationTitle = "";
    private $notificationBody = "";
    private $sendExplicitAlert = false;
    private $forced = false;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct(string $userId = "", array $payload = [], string $campaign_id = "", $screenCode = null, $notificationTitle = "A new Notification", $notificationBody = "", $sendExplicitAlert = false, $forced = false)
    {
        $this->userId = $userId;
        $this->payload = $payload;
        $this->campaign_id = $campaign_id;
        $this->screenCode = $screenCode;
        $this->notificationTitle = $notificationTitle;
        $this->notificationBody = $notificationBody;
        $this->sendExplicitAlert = $sendExplicitAlert;
        $this->forced = $forced;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle(Messaging $messaging)
    {
        return;

        $employee = Employee::where('userId', $this->userId)->first();

        // check for validations
        if(!$this->forced) {
            if($employee->receivePush !== 1) {
                \Log::channel('pushlog')->error('The User doesnt want push', [$employee->userId]);
                return;
            }

            // check for validation only when the push is not forced
            if ($this->isTheUserLost($employee)) {
                \Log::channel('pushlog')->error('The User is Lost', [$employee->userId]);
                return;
            }
            // if ($this->isTheUserAnnoyed($employee)) {
            //     \Log::channel('pushlog')->error('The User is annoyed', [$employee->userId]);
            //     return;
            // }

            // check for time to be less than 10pm and more than 6am in user time
            if (Carbon::createFromTimeString('22:00', $employee->timezone)->lte(now()) || Carbon::createFromTimeString('06:00', $employee->timezone)->gte(now())) {
                \Log::channel('pushlog')->error('not pushed {after 10pm or before 6am}', [$this->campaign_id, $employee->userId, $this->payload]);
                return;
                // no pushes to the user
            }
        }

        $fcmToken = $employee->fcmToken;


        // save push log for each push
        $pushLog = PushLog::create([
            "userId" => $this->userId,
            "type" => $this->campaign_id,
            "screenCode" => $this->screenCode, // 201 is for weekly completion screen receive and 301 for open
            "moduleNo" => "",
            "routeNo" => "",
            "lessonNo" => "",
            "status" => 1,
            "result" => "success",
            'app_version' => $employee->versionNumber,
        ]);

        // create payload
        $payload = [
            'isDeepLink' => 1,
            'screenCode' => $this->screenCode,
            'pushId' => $pushLog->id,
            'campaign_id' => $this->campaign_id,
            'title' => $this->notificationTitle,
            "body" => $this->notificationBody,
            'pushMsg' => $this->payload,
        ];

        // create branch.io link of payload and add to payload
        $payload['branch'] = getBranchIOLink(['branch_key' => config('taplingua.BRANCHIO_KEY'), 'data' => $payload]);
        // make fields
        $fields = [
            'token' => $fcmToken,
            'data' => [
                'data' => json_encode($payload, JSON_UNESCAPED_SLASHES)
            ],
            'android' => [
                'priority' => 'high'
            ],
            'apns' => [
                // https://firebase.google.com/docs/reference/fcm/rest/v1/projects.messages#apnsconfig
                'headers' => [
                    'apns-priority' => '10',
                ],
                'payload' => [
                    'aps' => [
                        "category" => "taplingua_push",
                        "mutable-content" => 1,
                        'alert' => [
                            'title' => $this->notificationTitle,
                            "body" => $this->notificationBody,
                        ],
                        'badge' => 1,
                        "sound" => "notification.wav",
                    ],
                ],
            ],
        ];

        if($this->sendExplicitAlert) {
            $fields["android"]["notification"] = [
                "title" => $this->notificationTitle,
                "body" => $this->notificationBody,
            ];
        }
        // send push
        try {
            // create the notificaiton
            $message = new \Kreait\Firebase\Messaging\RawMessageFromArray($fields);
            // send the notification
            $result = $messaging->send($message);
            // send the user mail of the same notification
            $this->sendMail($employee,  $payload['branch'], $pushLog);
            // log the push
            \Log::channel('pushlog')->info('pushed', [$this->campaign_id, $employee->userId, $result, $fields]);
        } catch (\Exception $e) {
            $this->declareTheUserAsLost($employee, $e);
            $result = $e;
            $pushLog->update([
                "status" => 0,
                "result" => $e->getMessage(),
            ]);
            $employee->update([
                "receivePush" => "-1"
            ]);
            \Log::channel('pushlog')->error('not pushed', [$this->campaign_id, $employee->userId, $result, $fields]);
        }
    }

    private function isTheUserLost(Employee $employee) {
        return $employee->is_user_lost;
    }

    private function isTheUserAnnoyed(Employee $employee)
    {
        return $employee->push_paused;
    }

    /**
     * Function to declare the user as lost.
     */
    private function declareTheUserAsLost(Employee $employee,\Exception $exception) {
        // its an exception so yeah, he/she is lost
        $employee->is_user_lost = true;
        $employee->user_lost_at = today();
        $employee->save();
    }

    private function sendMail(Employee $employee, $branchURL, PushLog $pushLog) {
        // TODO: check if employee in allowed list
        if(!in_array($employee->userId, getTestPushUsers()) && $this->campaign_id !== "comment_notification_push") {
            // return if not
            $pushLog->update([
                'emailSent' => 0
            ]);
            \Log::channel('pushlog')->error('mail not sent', [$this->campaign_id, $employee->userId, 'employee not in allowed list']);
            return;
        }
        // return if mail limit for today is reached
        $limit = 1;
        if(PushLog::where('userId', $employee->userId)->where('emailSent', 1)->whereDate('created_at', today())->count() >= $limit && $this->campaign_id !== "comment_notification_push") {
            $pushLog->update([
                'emailSent' => -1
            ]);
            \Log::channel('pushlog')->error('mail not sent', [$this->campaign_id, $employee->userId, 'daily limit of ' . $limit . " mail reached!"]);
            return;
        }
        // send mail to the user
        sendNotificationMail($employee, $this->notificationTitle, $this->notificationBody, $branchURL, $this->campaign_id);
        $pushLog->update([
            'emailSent' => 1
        ]);
        \Log::channel('pushlog')->error('mail sent', [$this->campaign_id, $employee->userId,  $this->notificationTitle, $this->notificationBody, $branchURL]);
    }
}
