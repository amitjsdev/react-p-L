<?php

namespace App\Jobs;

use App\UserDailyGoalLog;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SendPushForNewStrategy implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $userId;
    public $campaignId;
    public $isForced;

    const NEWUSERMORNINGPUSH1 = 'PushN_Morn1';
    const NEWUSERMORNINGPUSH2 = 'PushN_Morn2';
    const NEWUSERMORNINGPUSH3 = 'PushN_Morn3';
    const NEWUSERMORNINGPUSH1_TIME = '09:00';

    const NEWUSERLUNCHPUSH = 'PushN_Afternoon1';
    const NEWUSERLUNCHPUSH_TIME = '13:00';

    const NEWUSEREVENINGPUSH = 'PushN_Evening1';
    const NEWUSEREVENINGPUSH_TIME = '18:00';

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct(String $userId, String $campaignId, bool $isForced = false)
    {
        $this->userId = $userId;
        $this->isForced =$isForced;
        $this->campaignId = $campaignId;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        return;
        $total = UserDailyGoalLog::where('userId', $this->userId)
            ->whereDate('dated', today())
            ->sum('points');

        if ($total >= 25 && !$this->isForced) {
            // no need to send the push
            \Log::channel('pushlog')->error('user has more than 25 points', [$this->campaign_id, $this->userId,  $this->notificationTitle, $this->notificationBody]);
            return;
        }
        // check if user has done 25 points today
        // switch on campaign ID
        if ($this->campaignId === self::NEWUSERMORNINGPUSH1) {
            // switch between the three
        }

        $this->sendPush();
    }

    private function sendPush()
    {

        $notificationTitle = "";
        $notificationBody = "";


        if ($this->campaignId === self::NEWUSERMORNINGPUSH1) {
            switch (rand(1, 3)) {
                case 1:
                    $this->campaignId = self::NEWUSERMORNINGPUSH1;
                    $notificationTitle = "🤔 Do you rememeber this word?";
                    $notificationBody = "Recalling is the best way to learn! Do your daily dose! ⏰💘";
                    break;
                case 2:
                    $this->campaignId = self::NEWUSERMORNINGPUSH2;
                    $notificationTitle = "⏰ Time for your daily lesson. Jump in and play for 2 minutes!";
                    $notificationBody = "A little bit everyday and soon you'll be a native! 😀";
                    break;
                case 3:
                    $this->campaignId = self::NEWUSERMORNINGPUSH3;
                    $notificationTitle = "👨‍🎓 Little steps everyday";
                    $notificationBody = "Consistency is key! Little steps, everyday. 💪";
                default:
                    break;
            }
        }

        // Make notificationTitle and notificationBody
        switch ($this->campaignId) {
            case self::NEWUSEREVENINGPUSH:
                $notificationTitle = "⏱ Don't lose your streak. Play 2 mins and win. 🏆";
                $notificationBody = "Good way to unwind, have fun and keep your streak! 💆‍♂️";
                break;
            case self::NEWUSERLUNCHPUSH:
                $notificationTitle = "🕛 Easy Lunchtime Session? You got 2 mins?";
                $notificationBody = "Time for a break? Have fun and learn Spanish 😁";
                break;
            default:
                break;
        }

        SendPush::dispatch(
            $this->userId,
            [],
            $this->campaignId,
            117,
            $notificationTitle,
            $notificationBody
        );
    }
}
