<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class SendRegistrationPush implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;


    /**
     * First push is after two hours of registration
     */
    const FIRSTPUSH = 'FIRSTPUSH';
    /**
     * Second push is after 24 hours of registration
     */
    const SECONDPUSH = 'SECONDPUSH';
    /**
     * Third push if after 48 hours of registration
     */
    const THIRDPUSH = 'THIRDPUSH';


    public $userId, $type;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($userId = null, $type = SendRegistrationPush::FIRSTPUSH)
    {
        $this->userId = $userId;
        $this->type = $type;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        return;
        try {
            $campaignId = 101;
            $title = "";
            $message = "";
            switch ($this->type) {
                case SendRegistrationPush::FIRSTPUSH:
                    $campaignId = 101;
                    $title = "Welcome to Taplingua";
                    $message = "You will learn how to use the languages in practical situations in the fastest way possible.";
                    break;
                case SendRegistrationPush::SECONDPUSH:
                    $campaignId = 102;
                    $title = "Hi";
                    $message = rand(1, 2) === 1
                        ? "How is it going with Taplingua? Finish the first 3 lessons today and unlock your first Taplingua badge !"
                        : "Do Taplingua 5 minutes today and maintain your streak";
                    break;
                case SendRegistrationPush::THIRDPUSH:
                    $campaignId = 103;
                    $title = "Hi";
                    $message = "Do your next lesson to maintain your streak.";
                    break;
                default:
                    break;
            }
            // create payload
            $payLoad = [
                "isDeepLink" => 1,
                "screenCode" => 106,
                "pushMsg" => [
                    "campaign_id" => $campaignId,
                    "title" => $title,
                    "message" => $message,
                ]
            ];
            // create a branchlink for payload, branch key is the api key needed by branch and data is the daya we need to create code for
            $payLoad["branch"] = getBranchIOLink([
                'branch_key' => config('taplingua.BRANCHIO_KEY'),
                'data' => $payLoad
            ]);
            // push the payload
            $status = pushPayloadToUserId($this->userId, $payLoad);
            Log::info("SendRegistrationPush successful for ", [$this->userId, "status is - " . json_encode($status), $payLoad]);
        } catch (\Exception $e) {
            Log::info("exception at SendRegistrationPush job", [$e]);
        }
    }
}
