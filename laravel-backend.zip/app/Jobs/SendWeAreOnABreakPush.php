<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SendWeAreOnABreakPush implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $userId;

    const CAMPAIGN_ID = "we-were-on-a-break";

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct(String $userId)
    {
        $this->userId = $userId;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
       return;
        // Send the user push that we are on a break
        SendPush::dispatch(
            $this->userId,
            [],
            SendWeAreOnABreakPush::CAMPAIGN_ID,
            null,
            "Seems you are too busy for Taplingua these days.",
            "We are gonna pause for a while now.",
            true,
            true
        );
        // reactive user after 4 days
        // ReactivateUser::dispatch($this->userId)->delay(now()->addDays(4));
    }
}
