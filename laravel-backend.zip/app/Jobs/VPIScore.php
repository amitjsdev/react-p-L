<?php

namespace App\Jobs;

use App\InterviewVideo;
use App\PracticeQuestion;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Symfony\Component\Process\Process;
use Illuminate\Support\Facades\Log;
class VPIScore implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $interviewVideoId;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($interviewVideoId)
    {
        $this->interviewVideoId = $interviewVideoId;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $video = InterviewVideo::find($this->interviewVideoId);
        if (!$video) {
            Log::error("VPI Score video could not be ai rated id: " . $this->interviewVideoId);
            return ['status'=>0,'data'=> 'Video not found'];
        }
        $q = PracticeQuestion::where('practiceSetId',$video->moduleNo)
        ->where('practiceQuestionId',$video->lessonNo)->first();
        if (!$q) {
            Log::error("VPI Score video could not be ai rated id: " . $this->interviewVideoId);
            return ['status'=>0,'data'=> 'Question not found'];
        }

        $filePath =  $video->reviewFileLocation;
        $RefText =  $q->referenceAnswer;
        $url ='http://3.66.13.135:9001/video/?url='.$filePath;
            if($RefText){
                $url =$url.'&refText='.$RefText;
            }

        // return $q;
        Log::info('url '.$url);

        try {
            $client = new \GuzzleHttp\Client();

            // return $url;
            $response = $client->get($url);

            $responseJSON = json_decode($response->getBody(), true);
            if($responseJSON){
                $video->vpi_score = json_encode($responseJSON);
                $video->save();
            }
            return ['status'=>1,'data'=>$responseJSON,'RefText'=>$RefText];
            } catch (\Throwable $th) {
                Log::error("VPI Score video could not be ai rated [unparsable output] id: " . $this->interviewVideoId, [
                    $th->getMessage()
                ]);
                return ['status'=>0,'data'=>$th,'RefText'=>$RefText];
            }
    }
}
