<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LeaderboardRank extends Model
{
    protected $fillable = ['userId', 'companyCode', 'rank', 'delta', 'type'];
}
