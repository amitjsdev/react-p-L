<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lesson extends Model
{
    protected $table = 'lessons';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'moduleno', 'routeno', 'lesson_type', 'lesson_no', 'level_no', 'title', 'description', 'long_description', 'lesson_image', 'pre_lesson', 'pre_exercise', 'pre_dialog_msg',
        'pre_video_msg', 'video', 'speakers', 'video_english', 'video_spanish', 'video_english_subtitles', 'video_spanish_subtitles', 'image', 'dialog', 'dialog_translation', 'dialog_extra_info', 'reviewLesson', 'audio', 'virtualModule', 'virtualRoute', 'virtualLesson', 'virtualLessonFlag', 'examLevel', 'holidayWeek', 'status', 'updatedate', 'zipsize', 'production', 'is_challenge', 'challenge_type', 'speaker_gender', 'has_dialogs'
    ];

    public function videoForum()
    {
        return $this->morphOne(\App\Forum::class, 'forumable')->where('for', 'video');
    }

    public function listenForum()
    {
        return $this->morphOne(\App\Forum::class, 'forumable')->where('for', 'listen');
    }
}
