<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LessonFailCount extends Model
{
    protected $fillable = [
        'moduleNo',
        'routeNo',
        'lessonNo',
        'userId',
        'fail_count',
    ];
}
