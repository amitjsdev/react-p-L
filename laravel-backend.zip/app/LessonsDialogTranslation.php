<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LessonsDialogTranslation extends Model
{
    protected $table = 'lessons_dialog_translation';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'lesssonId', 'moduleNo', 'routeNo', 'lessonNo', 'dialog_translation', 'created_at'
    ];
}
