<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LingoCoinLog extends Model
{
    protected $fillable = ['userId', 'date', 'coins', 'type', 'rank'];
}
