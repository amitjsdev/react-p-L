<?php

namespace App\Listeners;

use App\Events\UserLoggedIn;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class Activate15DayTrialForFirstLogin
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  UserLoggedIn  $event
     * @return void
     */
    public function handle(UserLoggedIn $event)
    {
        // get employee
        $employee = $event->employee;

        // if activation is null, set activation to now
        if (!$employee->activationDate) {
            $employee->activationDate = now();
        }

        // if employee doesnt have last login date, add date as 15 days from now
        if (!$employee->lastLoginDate) {
            $employee->subscriptionExpires = now()->addDays(15);
        }

        // if last login data is not available
        // update all courses to have expiration date 15days from now
        \DB::table('employeecourse')->where('userId', $employee->userId)
            ->whereNull('subscriptionExpiresDate')
            ->update([
                "subscriptionExpiresDate" => now()->addDays(15)
            ]);

        $employee->save();
    }
}
