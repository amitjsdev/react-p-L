<?php

namespace App\Listeners;

use App\Events\UserLoggedIn;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Carbon;

class ActivateUserCohortIfRequired
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  UserLoggedIn  $event
     * @return void
     */
    public function handle(UserLoggedIn $event)
    {
        // get employee
        $employee = $event->employee;

        // get cohorts for user
        $cohort_ids = \App\Course::distinct('cohort_id')
            ->join('employeecourse', 'courses.courseNumber', '=', 'employeecourse.courseNumber')
            ->whereNotNull('cohort_id')
            ->where('userId', $employee->userId)
            ->pluck("cohort_id");

        // get all cohorts where start_date null
        $cohorts = \App\Cohort::whereIn('id', $cohort_ids)
            ->whereNull('start_date')
            ->get();

        // for each cohort update the dates
        foreach ($cohorts as $cohort) {
            $this->updateCohortTimings($cohort, today());
        }
    }

    /**
     * Undocumented function
     *
     * @param [type] $program_id
     * @param [type] $company_code
     * @param [type] $start_date
     * @param [type] $name
     * @return void
     */
    private function updateCohortTimings($cohort, $start_date)
    {
        // get a start date
        $startDate = $start_date ? Carbon::parse($start_date) : null;

        // create course for every program in that module, for this cohort
        $modules = $cohort->program->modules->sort(function ($a, $b) {
            return $a->sort_order - $b->sort_order;
        });
        $modulesToKeep = $modules->map(function ($module) {
            return $module->module_number;
        });

        // sort index
        $moduleSortIndex = [];
        foreach ($modules as $module) {
            $moduleSortIndex[] = $module->module_number;
        }

        $moduleSortIndex = array_flip($moduleSortIndex);

        // get model of each module
        $modulesToKeepModel = \App\Module::whereIn('moduleno', $modulesToKeep)
            ->get()->sort(function ($a, $b) use ($moduleSortIndex) {
                return $moduleSortIndex[$a->moduleno] - $moduleSortIndex[$b->moduleno];
            });
        // for each module, create the course
        foreach ($modulesToKeepModel as $index => $module) {
            \App\Course::updateOrCreate([
                "cohort_id" => $cohort->id,
                "Company" => $cohort->company_code,
                "moduleNumber" => $module->moduleno,
            ], [
                "courseStartDate" => $startDate ? Carbon::parse($startDate)->addWeeks(($moduleSortIndex[$module->moduleno]) * 3) : today(),
                "courseEndDate" => $startDate ? Carbon::parse($startDate)->addWeeks(($moduleSortIndex[$module->moduleno] + 1) * 3) : today(),
            ]);
        }

        $cohort->start_date = $start_date;
        $cohort->save();

        // return $cohort;
        return $cohort;
    }
}
