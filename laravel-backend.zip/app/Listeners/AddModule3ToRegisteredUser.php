<?php

namespace App\Listeners;

use App\Employee;
use App\Events\UserRegistered;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AddModule3ToRegisteredUser
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  UserRegistered  $event
     * @return void
     */
    public function handle(UserRegistered $event)
    {
        $employee = $event->employee;
        // if and only if companyCode is 0, set module 3 or whatever he selected
        if((int) $employee->CompanyCode === 0) {
            $courseNumber = $this->addModuleAsUserCourse($employee->currentModule, $employee->userId);
            $employee->currentCourse = $courseNumber;
            $employee->save();
        }
    }

    /**
     * This function adds a seperate course for current module,
     *  adds user to the coursem adds module 3 by default
     *
     * @param string $userId
     * @return int
     */
    private function addModuleAsUserCourse($moduleNumber = 3, $userId)
    {
        // check if user needs be registered to the course
        if ($courseNumber = getCourseNoFromModuleNo($moduleNumber, $userId)) {
            return $courseNumber;
        }

        // else register the user for the course
        $courseStartDate = "";
        $Company = "";
        $courseNumber = time();
        $courseEndDate = "";
        $courseFlag = "";
        $holidayInCourseFlag = "";
        $holidayWeek = "";
        $courseBatch = "";
        $courseNumberOfStudents = "";
        $numRoutes = "";
        $evaluation_required = "";
        $weeklyEmail = "";
        $Status = "";
        $numberOfWeeks = "";
        $courseName = explode('@', $userId)[0] . " " . getModuleNameByCourse($moduleNumber) . " " . $Company;

        // insert the course
        $query = "insert into courses set Id='" . time() . "', courseNumberOfStudents='" . $courseNumberOfStudents . "', numRoutes='" . $numRoutes . "', holidayInCourseFlag='" . $holidayInCourseFlag . "', courseFlag='" . $courseFlag . "', courseName='" . $courseName . "', Company='" . $Company . "', holidayWeek='" . $holidayWeek . "', courseStartDate = '" . $courseStartDate . "', courseEndDate='" . $courseEndDate . "', evaluationRequired='" . $evaluation_required . "', courseNumber='" . $courseNumber . "', moduleNumber='" . $moduleNumber . "', courseBatch='" . $courseBatch . "', weeklyEmail='" . $weeklyEmail . "', numberOfWeeks='" . $numberOfWeeks . "', Status='" . $Status . "'";
        DB::insert($query);

        $request = new Request([
            'userId' => $userId,
            'courseNumber' => $courseNumber
        ]);

        // check if the user has company code 0
        if (Employee::where('userId', $userId)->first()->companyCode == 0) {
            // call this to add employee to the course
            $response = app(\App\Http\Controllers\EmployeeController::class)->addEmployeeCourse($request)->getData();
        }

        return $response->courseNumber;
    }
}
