<?php

namespace App\Listeners;

use App\Events\UserActivitySave;
use App\Http\Resources\UserBadgeResource;
use App\Jobs\SendPush;
use App\Mail\Badges\PointsGain1;
use App\UserBadge;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

class CheckForBadges
{
    // event type
    public static $usercourseadded = "usercourseadded";
    public static $usertodoactivate = "usertodoactivate";
    public static $pointsgains = "pointsgains";
    public static $streak = "streak";


    // badge type
    public static $level_completion_4 = "level-completion-4";
    public static $level_completion_3 = "level-completion-3";
    public static $level_completion_1 = "level-completion-1";
    public static $level_completion_2 = "level-completion-2";
    public static $points_use_4 = "points-use-4";
    public static $points_use_3 = "points-use-3";
    public static $points_use_2 = "points-use-2";
    public static $points_use_1 = "points-use-1";
    public static $points_gains_4 = "points-gains-4";
    public static $points_gains_3 = "points-gains-3";
    public static $points_gains_2 = "points-gains-2";
    public static $points_gains_1 = "points-gains-1";
    public static $streaks_5 = "streaks-5";
    public static $streaks_4 = "streaks-4";
    public static $streaks_3 = "streaks-3";
    public static $streaks_2 = "streaks-2";
    public static $streaks_1 = "streaks-1";
    public static $gen_act_6 = "gen-act-6";
    public static $gen_act_5 = "gen-act-5";
    public static $gen_act_4 = "gen-act-4";
    public static $gen_act_3 = "gen-act-3";
    public static $gen_act_2 = "gen-act-2";
    public static $gen_act_1 = "gen-act-1";
    public static $accuracy_1 = "accuracy-1";
    public static $accuracy_2 = "accuracy-2";
    public static $accuracy_3 = "accuracy-3";
    public static $challenges_1 = "challenges-1";
    public static $challenges_2 = "challenges-2";


    /**
     * Data will have the payload of what data is needed for the badge to be checked
     * eventType - it is necessary to see if we need to check for the badge
     * userId - Id of the user
     * courseNumber - nullable, if for specific course
     *
     * @var [type]
     */
    private $data;
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    { }

    /**
     * Handle the event.
     *
     * @param  UserAcitivitySave  $event
     * @return void
     */
    public function handle($event)
    {
        try {
            $this->data = $event->data;
            $this->checkForRegistrationBadge();
            $this->checkForPointsGains();
            $this->checkForMaxStreak();
            // TODO: add new badge functionality

            // check below only if userActivityLog is provided
            if ($event instanceof UserActivitySave) {
                $this->checkForLevelCompletion();
                // use user activity log data and check for all the badges here
                // $this->checkForCompletionist();
            }
        } catch (\Exception $e) {
            if (App::environment('development')) {
                dd($e);
            } else {
                Log::error("Checkforbadges failed", [$e]);
            }
        }
    }


    /**
     * Give user a registration badge if not given already
     *
     * @return void
     */
    private function checkForRegistrationBadge()
    {
        if ($this->data["eventType"] === CheckForBadges::$usercourseadded) {
            $userBadge = UserBadge::create([
                "userId" => $this->data["userId"],
                "badge_code" => "gen-act-1",
                "course_number" => $this->data["courseNumber"],
            ]);
            // send push notification to user
            $this->sendPushForBadge($userBadge);
        }
    }


    /**
     * Function checks for point gain badges and hands the user them, if applicable
     *
     * @return void
     */
    private function checkForPointsGains()
    {
        if ($this->data["eventType"] === CheckForBadges::$pointsgains) {
            try {
                $gainedBadge = []; // array to hold multiple badges gained
                // check what badge will user earn
                if ($this->data['score'] >= 10000) {
                    $gainedBadge[] = CheckForBadges::$points_gains_4;
                    $gainedBadge[] = CheckForBadges::$points_gains_3;
                } elseif ($this->data['score'] >= 1200) {
                    $gainedBadge[] = CheckForBadges::$points_gains_2;
                } elseif ($this->data['score'] >= 100) {
                    $gainedBadge[] = CheckForBadges::$points_gains_1;
                }
                // insert every badge gained
                foreach ($gainedBadge as $badgeCode) {
                    // check if the user already has the badge
                    if (!UserBadge::where("userId", $this->data['userId'])->where("badge_code", $badgeCode)->where('course_number', $this->data["courseNumber"])->exists()) {
                        $userBadge = UserBadge::create([
                            "userId" => $this->data["userId"],
                            "badge_code" => $badgeCode,
                            "course_number" => $this->data["courseNumber"],
                        ]);
                        // send push notification to user
                        $this->sendPushForBadge($userBadge);
                    }
                }
            } catch (\Exception $e) {
                Log::error("checkForPointsGains event listener", [$e]);
            }
        }
    }


    /**
     * Function checks for max streak achieved by user
     *
     * @return void
     */
    private function checkForMaxStreak()
    {
        if ($this->data["eventType"] === CheckForBadges::$streak) {
            try {
                $gainedBadge = []; // array to hold multiple badges gained
                // check what badge will user earn
                if ($this->data['maxStreak'] >= 28) { //  4 weeks
                    $gainedBadge[] = CheckForBadges::$streaks_4;
                } elseif ($this->data['maxStreak'] >= 14) { // 2 weeks
                    $gainedBadge[] = CheckForBadges::$streaks_3;
                } elseif ($this->data['maxStreak'] >= 7) { // 1 week
                    $gainedBadge[] = CheckForBadges::$streaks_2;
                } elseif ($this->data['maxStreak'] >= 2) { // 2 days
                    $gainedBadge[] = CheckForBadges::$streaks_1;
                }
                // insert every badge gained
                foreach ($gainedBadge as $badgeCode) {
                    // check if the user already has the badge
                    if (!UserBadge::where("userId", $this->data['userId'])->where("badge_code", $badgeCode)->exists()) {
                        $userBadge = UserBadge::create([
                            "userId" => $this->data["userId"],
                            "badge_code" => $badgeCode,
                            "course_number" => $this->data["courseNumber"],
                        ]);
                        // send push notification to user
                        $this->sendPushForBadge($userBadge);
                    }
                }
            } catch (\Exception $e) {
                Log::error("checkForMaxStreak event listener", [$e]);
            }
        }
    }

    /**
     * Function checks for levels completed by user on currentCourse
     *
     * @return void
     */
    private function checkForLevelCompletion()
    {
        try {
            $courseNumber = getCourseNoFromModuleNo($this->data->moduleNo, $this->data->userId);
            $lessonCount = count(getLessonsCompleteForCourse($this->data->userId, $courseNumber));
            $gainedBadge = []; // array to hold multiple badges gained
            // check what badge will user earn
            if ($lessonCount >= 50) {
                $gainedBadge[] = CheckForBadges::$level_completion_4;
            } elseif ($lessonCount >= 30) {
                $gainedBadge[] = CheckForBadges::$level_completion_3;
            } elseif ($lessonCount >= 10) {
                $gainedBadge[] = CheckForBadges::$level_completion_2;
            } elseif ($lessonCount >= 3) {
                $gainedBadge[] = CheckForBadges::$level_completion_1;
            }
            // insert every badge gained
            foreach ($gainedBadge as $badgeCode) {
                // check if the user already has the badge
                if (!UserBadge::where("userId", $this->data['userId'])->where("badge_code", $badgeCode)->where('course_number', $this->data["courseNumber"])->exists()) {
                    $userBadge = UserBadge::create([
                        "userId" => $this->data["userId"],
                        "badge_code" => $badgeCode,
                        "course_number" => $this->data["courseNumber"],
                    ]);
                    // send push notification to user
                    $this->sendPushForBadge($userBadge);
                }
            }
        } catch (\Exception $e) {
            Log::error("checkForLevelCompletion event listener", [$e]);
        }
    }

    private function sendPushForBadge(UserBadge $userBadge)
    {
        // FIXME: disabled-all-push-except-flash
        if($userBadge->badge_code === CheckForBadges::$points_gains_1) {
            // send first badge success email
            Mail::to($this->data['userId'])->send(new PointsGain1($userBadge));
        }
        return;
        SendPush::dispatch($userBadge->userId, (new UserBadgeResource($userBadge))->toArray(request()), "", 105);
    }
}
