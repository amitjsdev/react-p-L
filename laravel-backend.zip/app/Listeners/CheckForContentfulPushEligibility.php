<?php

namespace App\Listeners;

use App\Employee;
use App\Events\UserActivitySave;
use Carbon\Carbon;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Artisan;

class CheckForContentfulPushEligibility
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  UserActivitySave  $event
     * @return void
     */
    public function handle(UserActivitySave $event)
    {
        // below code if ran, would run contentful push fot getTestPushUsers()
        // check if the user is created after 1 august
        $employee = Employee::where('userId', $event->data->userId)->whereDate('accountCreationDate', '>=', Carbon::createFromDate(2020, 8, 1))->first();

        if ($employee) {
            // it automatically checks if pushes should be sent or not
            Artisan::call('taplingua:checkforcontentfulpush', [
                'userId' => $event->data->userId
            ]);
        }
    }
}
