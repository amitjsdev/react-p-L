<?php

namespace App\Listeners;

use App\Employee;
use App\Events\UserDailyGoalLogSave;
use App\UserDailyGoalLog;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class CheckForPayWallEligibility
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  UserDailyGoalLogSave  $event
     * @return void
     */
    public function handle(UserDailyGoalLogSave $event)
    {
        /* $response = [
            'message' => 'Log Saved!',
            'log' => $userDailyGoalLog,
            'daily_goal_attained' => $employee->daily_goal_attained,
            'daily_goal_total' => $employee->daily_goal_total,
            'is_daily_goal_attained' => $is_daily_goal_attained,
            'is_half_of_daily_goal_attained' => $is_half_of_daily_goal_attained,
        ]; */
        $response = $event->response;

        // get userId
        $userId = $response['log']->userId;

        // get employee
        $employee = Employee::where('userId', $userId)->first();

        // check if paywall already exists
        if($employee->enforceWall === 0) {
            // if needs to enforce paywall

            // get total
            $userTotal = UserDailyGoalLog::where('userId', $userId)->sum('points');

            if($userTotal > 500) {
                // set paywall
                $employee->enforceWall = 1;
                $employee->payWallLesson = 3;
                $employee->save();
            }
        }
    }
}
