<?php

namespace App\Listeners;

use App\Events\RoundLogSave;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class ConsumeAdditionalLivesClaimed
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  RoundLogSave  $event
     * @return void
     */
    public function handle(RoundLogSave $event)
    {
        $roundLog = $event->roundLog;

        // get employee
        $employee = $roundLog->employee;


        // dailylivesleft
        // if lives left is more than three, subtract the incoming livesLeft from 3 and then subtract the result from remainingleft in employee
        if($employee->dailyLivesLeft > 3) {
            $employee->dailyLivesLeft = $employee->dailyLivesLeft - (3 - $roundLog->livesLeft);
        } else {
            // just set lives left as employee lives left
            $employee->dailyLivesLeft = $roundLog->livesLeft;
        }

        if($employee->dailyLivesLeft >= 0) {
            $employee->save();
        }

        // additionalLivesClaimed
        if($roundLog->additionalLivesClaimed > 0) {
            // calculate replenishesLeft, removed the claimed lives
            $replenishesLeft = $employee->replenishesLeft - $roundLog->additionalLivesClaimed;

            if($replenishesLeft >= 0) {
                $employee->replenishesLeft = $replenishesLeft;
            } else {
                $employee->replenishesLeft = 0;
            }
            $employee->save();
        }

    }
}
