<?php

namespace App\Listeners;

use App\Events\UserCourseAdded;
use App\Jobs\SendRegistrationPush;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class CourseRegistrationPush
{
    public $data;
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  UserCourseAdded  $event
     * @return void
     */
    public function handle(UserCourseAdded $event)
    {
        $this->data = $event->data;
        if(in_array($this->data["userId"], ["april3003@taplingua.com"])) {
            // Send immediately for development only for specific user
            SendRegistrationPush::dispatch($this->data["userId"], SendRegistrationPush::FIRSTPUSH);
        }
        // Send after two hours
        SendRegistrationPush::dispatch($this->data["userId"], SendRegistrationPush::FIRSTPUSH)->delay(now()->addHours(2));
        // send after 24 hours
        SendRegistrationPush::dispatch($this->data["userId"], SendRegistrationPush::SECONDPUSH)->delay(now()->addHours(24));
        // send after 48 hours
        SendRegistrationPush::dispatch($this->data["userId"], SendRegistrationPush::THIRDPUSH)->delay(now()->addHours(48));
    }
}
