<?php

namespace App\Listeners;

use App\Events\UserRegistered;
use App\Jobs\CheckForSpecialPrizeInfo;
use App\Jobs\SendMailToSubscriber;
use App\Mail\EmailSequence\DailyGoalHistory;
use App\Mail\EmailSequence\EmailFromCristina;
use App\Mail\EmailSequence\PollyWelcomeEmail;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Mail;

class InitiateEmailSequence
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  UserRegistered  $event
     * @return void
     */
    public function handle(UserRegistered $event)
    {
        // for now keep it closed
        $employee = $event->employee;

        /* if (!str_ends_with($employee->userId, '@taplingua.com') && $employee->userId !== 'thefallenmerc@gmail.com') {
            return;
        } */
        // FIXME: change to days after testing
        // Initiate the user sequence.
        // 1. Send Polly Welcome Email
        SendMailToSubscriber::dispatch(new PollyWelcomeEmail($employee), $employee->userId)->delay(now()->addMinutes(5));
        // 2. A Special Prize Awaits You
        // CheckForSpecialPrizeInfo::dispatch($employee, 1)->delay(now()->addDay());
        // Send for two days until completed
        // Send a checklist of Steps to do to complete
        // 3. Congrats first badge once user scores 100 points.
        // this will be sent from badge mail
        // 4. Reminder
        // 4. Email From Cristina
        // SendMailToSubscriber::dispatch(new EmailFromCristina($employee), $employee->userId)->delay(now()->addDays(3));
        // 5. Graph of Daily user points
        // SendMailToSubscriber::dispatch(new DailyGoalHistory($employee), $employee->userId)->delay(now()->addMinutes(4));
    }
}
