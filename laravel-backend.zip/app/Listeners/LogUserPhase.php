<?php

namespace App\Listeners;

use App\Console\Commands\CheckForUserStateUsingUserPoints;
use App\Events\UserAddedToSegment;
use App\UserPhaseLog;
use App\UserSegment;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Log;

class LogUserPhase
{
    public $segmentCode = "";
    public $userId = "";
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  UserAddedToSegment  $event
     * @return void
     */
    public function handle(UserAddedToSegment $event)
    {
        try {
            // get segmentcode and user id
            $this->segmentCode = $event->segmentCode;
            $this->userId = $event->userId;

            // check if user has gone in one of the phases segment
            if (in_array($this->segmentCode, array_keys(CheckForUserStateUsingUserPoints::SEGMENTS))) {
                // Continue
                $segment = UserSegment::where('code', $this->segmentCode)->first();
                // TODO: Check if user is not already in this phase
                if (true) {
                    UserPhaseLog::create([
                        'userId' => $this->userId,
                        'user_segment_id' => $segment->id
                    ]);
                }
            }
        } catch (\Throwable $th) {
            Log::error("error while logging user phase", [$th]);
        }
    }
}
