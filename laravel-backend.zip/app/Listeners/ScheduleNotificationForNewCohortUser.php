<?php

namespace App\Listeners;

use App\Cohort;
use App\Course;
use App\EmailTemplate;
use App\Employee;
use App\Events\UserAddedToCohort;
use App\Jobs\SendMailToSubscriber;
use App\Jobs\SendNotificationToCohortUser;
use App\Mail\TemplateMail;
use Carbon\Carbon;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class ScheduleNotificationForNewCohortUser
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    { }

    /**
     * Handle the event.
     *
     * @param  UserAddedToCohort  $event
     * @return void
     */
    public function handle(UserAddedToCohort $event)
    {
        // return for now
        return;

        // get cohort
        $cohort = Cohort::find($event->cohortId);

        // get the user
        $employee = Employee::where('userId', $event->userId)->first();

        if ($cohort && $employee) {
            // check if notification on on cohort
            if ($cohort->notification_on) {
                // send the notification based on type foreach course in the cohort

                // get courses
                $courses = Course::where('cohort_id', $cohort->id)->get();

                foreach ($courses as $course) {

                    // one week before course start
                    $oneWeekBeforeCourseStart = Carbon::parse($course->courseStartDate)->subWeek();
                    // send notification
                    $this->sendNotificationToUser($employee, 'cohort-notification-email-1-week-before-course-start', 'SMS', $oneWeekBeforeCourseStart);


                    // one day before course start
                    $oneDayBeforeCourseStart = Carbon::parse($course->courseStartDate)->subDay();
                    // send notification
                    $this->sendNotificationToUser($employee, 'cohort-notification-email-1-day-before-course-start', 'SMS', $oneDayBeforeCourseStart);

                    // one week before course end
                    $oneWeekBeforeCourseEnd = Carbon::parse($course->courseStartDate)->addWeeks(2);
                    // send notification
                    $this->sendNotificationToUser($employee, 'cohort-notification-email-1-week-before-course-end', 'SMS', $oneWeekBeforeCourseEnd);

                    // one day before course end
                    $oneDayBeforeCourseEnd = Carbon::parse($course->courseStartDate)->addWeeks(3)->subDay();
                    // send notification
                    $this->sendNotificationToUser($employee, 'cohort-notification-email-1-day-before-course-end', 'SMS', $oneDayBeforeCourseEnd);
                }

                // about subscription

                // 2 weeks before subscription end date

                // 1 week before subscription end date

                // 1 days before subscription end
            }
        }
    }

    private function sendNotificationToUser($employee, $template_identifier, $text, $time)
    {
        // get template
        $template = EmailTemplate::where('template_identifier', $template_identifier)
            ->first();
        // send email if template
        if ($template) {
            // create email
            $email = new TemplateMail($employee->userId, $template);
            // send email
            SendMailToSubscriber::dispatch($email, $employee->userId)
                ->delay($time);
        }
        // send sms if user mobile and $text
        if ($text && $employee->Mobile) {
            // Send SMS
            sendSMS("+91" . $employee->Mobile, "Hi " . $employee->FirstName . $text);
        }
    }
}
