<?php

namespace App\Listeners;

use App\Console\Commands\CheckForUserStateUsingUserPoints;
use App\Events\UserAddedToSegment;
use App\Jobs\SendConditionalPushToPhasedUser;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class ScheduleUserPhasePushes
{
    public $segmentCode = "";
    public $userId = "";
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  UserAddedToSegment  $event
     * @return void
     */
    public function handle(UserAddedToSegment $event)
    {
        return;
        // get segmentcode and user id
        $this->segmentCode = $event->segmentCode;
        $this->userId = $event->userId;

        switch ($this->segmentCode) {
            case CheckForUserStateUsingUserPoints::SEGMENT_AT_RISK_1_USERS:
                // user is at risk 1
                // $this->scheduleForRisk1User();
                break;
            case CheckForUserStateUsingUserPoints::SEGMENT_AT_RISK_2_USERS:
                // user is at risk 2
                // $this->scheduleForRisk2User();
                break;
            case CheckForUserStateUsingUserPoints::SEGMENT_LAPSED_USERS:
                // user is lost
                // $this->scheduleForLapsedUser();
            default:
                // Do not do anything
                break;
        }
    }

    function scheduleForRisk1User()
    {
        return;
        $time1 = now()->addSeconds(1);
        $time2 = now()->addSeconds(5);
        $time3 = now()->addSeconds(10);
        $time4 = now()->addSeconds(15);
        // user is at risk 1
        // Day 1 Push
        SendConditionalPushToPhasedUser::dispatch(
            $this->userId,
            [], // payload
            'at-risk-1-user-1', // campaign id
            01, // screen code
            "Yo 1", // notification title
            "Yo 2" // notification body
        )
            ->delay($time1);
        // Day 2 Push
        SendConditionalPushToPhasedUser::dispatch(
            $this->userId,
            [], // payload
            'at-risk-1-user-2', // campaign id
            01, // screen code
            "Yo 1", // notification title
            "Yo 2" // notification body
        )
            ->delay($time2);
        // Day 4 Push
        SendConditionalPushToPhasedUser::dispatch(
            $this->userId,
            [], // payload
            'at-risk-1-user-3', // campaign id
            01, // screen code
            "Yo 1", // notification title
            "Yo 2" // notification body
        )
            ->delay($time3);
        // Day 5 Push
        SendConditionalPushToPhasedUser::dispatch(
            $this->userId,
            [], // payload
            'at-risk-1-user-4', // campaign id
            01, // screen code
            "Yo 1", // notification title
            "Yo 2" // notification body
        )
            ->delay($time4);
    }

    function scheduleForRisk2User()
    {
        return;
        $time1 = now()->addSeconds(1);
        $time2 = now()->addSeconds(5);
        // user is risk 2
        // Day 1 Push
        SendConditionalPushToPhasedUser::dispatch(
            $this->userId,
            [], // payload
            'at-risk-2-user-1', // campaign id
            01, // screen code
            "Yo 1", // notification title
            "Yo 2" // notification body
        )
            ->delay($time1);
        // Day 2 Push
        SendConditionalPushToPhasedUser::dispatch(
            $this->userId,
            [], // payload
            'at-risk-2-user-2', // campaign id
            01, // screen code
            "Yo 1", // notification title
            "Yo 2" // notification body
        )
            ->delay($time2);
    }

    function scheduleForLapsedUser()
    {
        return;
        $time1 = now()->addSeconds(1);
        $time2 = now()->addSeconds(5);
        // user is lost
        // Day 1 Push
        SendConditionalPushToPhasedUser::dispatch(
            $this->userId,
            [], // payload
            'lapsed-user-1', // campaign id
            01, // screen code
            "Yo 1", // notification title
            "Yo 2" // notification body
        )
            ->delay($time1);
        // Day 2 Push
        SendConditionalPushToPhasedUser::dispatch(
            $this->userId,
            [], // payload
            'lapsed-user-2', // campaign id
            01, // screen code
            "Yo 1", // notification title
            "Yo 2" // notification body
        )
            ->delay($time2);
    }
}
