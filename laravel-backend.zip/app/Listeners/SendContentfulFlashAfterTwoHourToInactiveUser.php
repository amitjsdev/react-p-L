<?php

namespace App\Listeners;

use App\Events\UserRegistered;
use App\Jobs\SendContentfulFlashToInactiveUser;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class SendContentfulFlashAfterTwoHourToInactiveUser
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  UserRegistered  $event
     * @return void
     */
    public function handle(UserRegistered $event)
    {
        $employee = $event->employee;
        // Two Hours Later...
        SendContentfulFlashToInactiveUser::dispatch($employee->userId)->delay(now()->addHours(2));
        // Six Hours Later...
        SendContentfulFlashToInactiveUser::dispatch($employee->userId)->delay(now()->addHours(6));
        // Twenty Four Hours Later...
        SendContentfulFlashToInactiveUser::dispatch($employee->userId)->delay(now()->addHours(24));
    }
}
