<?php

namespace App\Listeners;

use App\Events\UserRegistered;
use App\Jobs\SendEmailAfter24HoursOfInactivity as AppSendEmailAfter24HoursOfInactivity;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class SendEmailAfter24HoursOfInactivity
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  UserRegistered  $event
     * @return void
     */
    public function handle(UserRegistered $event)
    {
        $employee = $event->employee;
        // 24 hrs later
        AppSendEmailAfter24HoursOfInactivity::dispatch($employee->userId)
            ->delay(now()->addDay());
    }
}
