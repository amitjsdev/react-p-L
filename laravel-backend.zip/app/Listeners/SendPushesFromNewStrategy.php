<?php

    namespace App\Listeners;

    use App\Employee;
    use App\Events\UserRegistered;
    use App\Jobs\SendPush;
    use App\Jobs\SendPushForNewStrategy;
    use Illuminate\Contracts\Queue\ShouldQueue;
    use Illuminate\Queue\InteractsWithQueue;
    use Illuminate\Support\Carbon;

    class SendPushesFromNewStrategy
    {
        /**
         * Create the event listener.
         *
         * @return void
         */
        public function __construct()
        { }

        /**
         * Handle the event.
         *
         * @param  UserRegistered  $event
         * @return void
         */
        public function handle(UserRegistered $event)
        {
            // get employee
            $employee = $event->employee;

            // send the five pushes at their time tomorrow
            // morning push
            $this->sendStrategyPush(
                $employee,
                SendPushForNewStrategy::NEWUSERMORNINGPUSH1,
                SendPushForNewStrategy::NEWUSERMORNINGPUSH1_TIME
            );
            // lunch push
            $this->sendStrategyPush(
                $employee,
                SendPushForNewStrategy::NEWUSERLUNCHPUSH,
                SendPushForNewStrategy::NEWUSERLUNCHPUSH_TIME
            );
            // night push
            $this->sendStrategyPush(
                $employee,
                SendPushForNewStrategy::NEWUSEREVENINGPUSH,
                SendPushForNewStrategy::NEWUSEREVENINGPUSH_TIME
            );

            // send the five pushes at their time tomorrow + 1
            // morning push
            $this->sendStrategyPush(
                $employee,
                SendPushForNewStrategy::NEWUSERMORNINGPUSH1,
                SendPushForNewStrategy::NEWUSERMORNINGPUSH1_TIME,
                1
            );
            // lunch push
            $this->sendStrategyPush(
                $employee,
                SendPushForNewStrategy::NEWUSERLUNCHPUSH,
                SendPushForNewStrategy::NEWUSERLUNCHPUSH_TIME,
                1
            );
            // night push
            $this->sendStrategyPush(
                $employee,
                SendPushForNewStrategy::NEWUSEREVENINGPUSH,
                SendPushForNewStrategy::NEWUSEREVENINGPUSH_TIME,
                1
            );

            // send the five pushes at their time tomorrow + 2
            // morning push
            $this->sendStrategyPush(
                $employee,
                SendPushForNewStrategy::NEWUSERMORNINGPUSH1,
                SendPushForNewStrategy::NEWUSERMORNINGPUSH1_TIME,
                2
            );
            // lunch push
            $this->sendStrategyPush(
                $employee,
                SendPushForNewStrategy::NEWUSERLUNCHPUSH,
                SendPushForNewStrategy::NEWUSERLUNCHPUSH_TIME,
                2
            );
            // night push
            $this->sendStrategyPush(
                $employee,
                SendPushForNewStrategy::NEWUSEREVENINGPUSH,
                SendPushForNewStrategy::NEWUSEREVENINGPUSH_TIME,
                2
            );
        }

        // generate and send strategy push
        private function sendStrategyPush(Employee $employee, String $campaignId, String $time, int $addDay = 1)
        {
            SendPushForNewStrategy::dispatch(
                $employee->userId,
                $campaignId
            )
                ->delay($this->getTime($time, $employee)->addDays($addDay));
        }

        private function getTime(String $time, Employee $employee)
        {
            return Carbon::createFromTimeString(
                $time,
                $employee->timezone ?? "GMT+1"
            );
        }
    }
