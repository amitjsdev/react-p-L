<?php

namespace App\Listeners;

use App\Events\UserAddedToSegment as UserAddedToSegmentEvent;
use App\Jobs\SendPush;
use App\UserSegment;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Log;

class UserAddedToSegment
{
    public $userSegment = "";
    public $userId = "";
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  UserAddedToSegment  $event
     * @return void
     */
    public function handle(UserAddedToSegmentEvent $event)
    {
        // get segmentcode and user id
        $this->segmentCode = $event->segmentCode;
        $this->userId = $event->userId;

        // switch case one segmentcode
        switch($this->segmentCode) {
            case UserSegment::REGISTERED_USERS:
                $this->doStuffForRegisteredUser();
                break;
        }
    }


    /**
     * Function that handles all the functionality that is to be done when user 
     * has been added to registered user segment
     *
     * @return void
     */
    private function doStuffForRegisteredUser() {
        // Send push to prompt him to come back and get his Streak 1 badge
        // FIXME: disabled-all-push-except-flash
        return;
        SendPush::dispatch($this->userId, [
            "title" => "Hey there!",
            "message" => "Comeback tomorrow and collect your Streak 1 Badge"
        ]);
    }
}
