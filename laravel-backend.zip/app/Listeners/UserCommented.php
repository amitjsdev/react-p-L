<?php

namespace App\Listeners;

use App\Comment;
use App\Events\UserCommented as UserCommentedEvent;
use App\Jobs\SendPush;
use App\Mail\UserCommented as UserCommentedMail;
use App\UserQuestion;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

class UserCommented
{
    public $comment;
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  UserCommented  $event
     * @return void
     */
    public function handle(UserCommentedEvent $event)
    {
        $this->comment = $event->comment;

        $commentOn = $this->comment->commentOn;

        // send push to owner
        $this->sendPushToOwner($this->comment);

        if ($this->comment->userId === 'santanu@taplingua.com') {
            // admin should not get his own notification
            return;
        }

        // // check what the comment is on
        // switch (get_class($commentOn)) {
        //     case \App\Forum::class:
        //         // if on forum, check the forum type
        //         // NOTE: currently only for admin so we can use
        //         $url = url('/forums/open', $commentOn->id) . "?comment_id=" . $this->comment->id;
        //         Mail::to('santanu@taplingua.com')->send(new UserCommentedMail($this->comment, $url));
        //         break;
        //     case \App\Comment::class:
        //         //FIXME: add mail to be sent for user question as well
        //         // if the user comment on another comment, 
        //         // get the comment that is targeted and then get its target so that we get forum, assuming this is just a level 2 comment
        //         if (get_class($commentOn->commentOn) === \App\Forum::class) {
        //             $url = url('/forums/open', $commentOn->commentOn->id) . "?comment_id=" . $this->comment->id;
        //             Mail::to('santanu@taplingua.com')->send(new UserCommentedMail($this->comment, $url));
        //         }
        //         break;
        // }
    }


    private function sendPushToOwner(Comment $comment)
    {
        $commentOn = $comment->commentOn;
        // if this comment is on another comment
        if ($commentOn instanceof \App\Comment) {
            // send the comment data needed to the original 
            switch (get_class($commentOn->commentOn)) {
                case UserQuestion::class:
                    $payload = [
                        'id' => $comment->id,
                        'comment' => $comment->comment,
                        'userId' => $comment->userId,
                        'created_at' => $comment->created_at,
                        // fixing this as one level nesting for now 
                        'entity_type' => "user_question",
                        'entity_id' => $commentOn->commentOn->id
                    ];
                    break;
                default:
                    $payload = [
                        'id' => $comment->id,
                        'comment' => $comment->comment,
                        'userId' => $comment->userId,
                        'created_at' => $comment->created_at,
                        // fixing this as one level nesting for now 
                        'entity_type' => $commentOn->commentOn->for ?? "other", // current comment has a parent comment and it has a parent forum
                        // 'entity_type' => $commentOn->commentOn->forumable_type === \App\V2Exercise::class ? "v2exercise" : "other", // current comment has a parent comment and it has a parent forum
                        'entity_id' => $commentOn->commentOn->forumable_id
                    ];
                    break;
            }
        } else if ($commentOn instanceof \App\Forum) {
            $payload = [
                'id' => $comment->id,
                'comment' => $comment->comment,
                'userId' => $comment->userId,
                'created_at' => $comment->created_at,
                // fixing this as one level nesting for now 
                'entity_type' => $commentOn->for ?? "other", // current comment has a parent comment and it has a parent forum
                // 'entity_type' => "forum", // current comment has a parent comment and it has a parent forum
                'entity_id' => $commentOn->forumable_id
            ];
        } else if ($commentOn instanceof \App\UserQuestion) {
            $payload = [
                'id' => $comment->id,
                'comment' => $comment->comment,
                'userId' => $comment->userId,
                'created_at' => $comment->created_at,
                // fixing this as one level nesting for now 
                'entity_type' => "user_question", // current comment has a parent comment and it has a parent forum
                'entity_id' => $commentOn->id
            ];
        } else {
            $payload = [];
        }

        // set exceptions to not send notification to (when getting all the comments userId)
        $exceptionUsers = [
            $comment->userId, // remove the user who commented from the list
            'shubham@truetechpro.com',
            'cristina@taplingua.com',
            'rajeev.bajpai@taplingua.com',
            'santanu@taplingua.com',
        ];

        // send notification to original user
        if ($commentOn->userId) {
            SendPush::dispatch(
                $commentOn->userId,
                $payload,
                'comment_notification_push',
                110,
                ($comment->employee->FirstName ?? Str::substr($comment->employee->userId, 0, 5)) . " replied to your comment!"
            ); // 110 is for comment notification
            $exceptionUsers[] = $commentOn->userId;
        }
        // send notification to other users that have commented
        // get all the users who commented on the question
        $commentsOnQuestion = Comment::where('commentable_id', $commentOn->id)
            ->whereNotIn('userId', $exceptionUsers) // except admins and actual owner and also the actual commentor
            ->get();
        // for every user who has commented, send them a notification
        foreach ($commentsOnQuestion as $c) {
            SendPush::dispatch(
                $c->userId,
                $payload,
                'comment_notification_push',
                110,
                ($comment->employee->FirstName ?? Str::substr($comment->employee->userId, 0, 5)) . " replied in the thread!"
            ); // 110 is for comment notification
        }

        // send email to all admins
        $this->sendPushToAdmin(
            'santanu@taplingua.com',
            $payload,
            'comment_notification_push',
            110,
            ($comment->employee->FirstName ?? Str::substr($comment->employee->userId, 0, 5)) . " replied in the thread!",
            null,
            $comment
        );
    }

    private function sendPushToAdmin($userId, $payload, $campaign_id, $screen_code, $notificationTitle = "", $notificationBody = "", $comment)
    {
        $employee = \App\Employee::where('userId', $userId)->first();
        $employee2 = \App\Employee::where('userId', 'shubham@truetechpro.com')->first();
        $employee3 = \App\Employee::where('userId', 'cristina@taplingua.com')->first();
        $employee4 = \App\Employee::where('userId', 'rajeev.bajpai@taplingua.com')->first();

        $payload = [
            'isDeepLink' => 1,
            'screenCode' => $screen_code,
            'pushId' => null,
            'title' => $notificationTitle,
            "body" => $notificationBody,
            'pushMsg' => $payload,
        ];
        $webAppLink = getForumWebAppLink($userId, getForumForComment($comment));
        // dd($payload['pushMsg']['entity_type']);
        // dd($payload['pushMsg']['entity_id']);

        $branchURL = getBranchIOLink(['branch_key' => config('taplingua.BRANCHIO_KEY'), 'data' => $payload]);
        sendNotificationMail($employee, $notificationTitle, $notificationBody, $branchURL, $campaign_id, $webAppLink);
        sendNotificationMail($employee2, $notificationTitle, $notificationBody, $branchURL, $campaign_id, $webAppLink);
        sendNotificationMail($employee3, $notificationTitle, $notificationBody, $branchURL, $campaign_id, $webAppLink);
        sendNotificationMail($employee4, $notificationTitle, $notificationBody, $branchURL, $campaign_id, $webAppLink);
    }
}
