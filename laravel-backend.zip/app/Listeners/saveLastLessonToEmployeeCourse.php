<?php

namespace App\Listeners;

use App\Employee;
use App\Events\RoundLogSave;
use App\RoundLog;
use App\UserActivityLog;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\DB;

class saveLastLessonToEmployeeCourse
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  UserActivitySave  $event
     * @return void
     */
    public function handle(RoundLogSave $event)
    {
        $roundLog = $event->roundLog;
        // get courseNumber for current Module
        $courseNumber = getCourseNoFromModuleNo($roundLog->moduleNo, $roundLog->userId);
        // get the employee
        $employee = Employee::where('userId', $roundLog->userId)->first();

        // get max last lesson for user
        $maxLesson = RoundLog::where('userId', $roundLog->userId)->where('moduleNo', $roundLog->moduleNo)->where('status', 1)->max('lessonNo');

        $employee->currentCourse = $courseNumber;
        $employee->currentModule = $roundLog->moduleNo;
        $employee->last_lesson = $maxLesson;
        $employee->save();
        // if $employeecourse->last_lesson < $activity->lessonNo
        // update the employeecourse for current employee and course with the current lessonNo
        DB::table('employeecourse')
            ->where('courseNumber', $courseNumber)
            ->where('userId', $roundLog->userId)
            ->update([
                'last_lesson' => $maxLesson,
            ]);
    }
}
