<?php

namespace App\Mail\Admin;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class ServerErrorEmail extends Mailable
{
    use Queueable, SerializesModels;

    public $description;
    public $data;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($description = "", $data = [])
    {
        $this->description = $description;
        $this->data = $data;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->view('emails.admin.server-error', [
            "description" => $this->description,
            "data" => $this->data
        ]);
    }
}
