<?php

namespace App\Mail\Badges;

use App\Employee;
use App\UserBadge;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class PointsGain1 extends Mailable
{
    use Queueable, SerializesModels;

    public $userBadge;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(UserBadge $userBadge)
    {
        $this->userBadge = $userBadge;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $employee = Employee::where('userId', $this->userBadge->userId)->first();
        return $this
            ->from('cristina.guijarro@taplingua.com', "Taplingua")
            ->subject("Congratulations!")
            ->view('emails.badges.points-gain-one')
            ->with([
                'employee' => $employee
            ]);
    }
}
