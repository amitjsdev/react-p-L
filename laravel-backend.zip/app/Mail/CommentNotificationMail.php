<?php

namespace App\Mail;

use App\Employee;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class CommentNotificationMail extends Mailable
{
    use Queueable, SerializesModels;

    public $notificationTitle;
    public $notificationBody;
    public $employee;
    public $branchURL;
    public $webAppLink;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(Employee $employee, $notificationTitle = "A New Notification", $notificationBody = "", $branchURL = "", $webAppLink = "")
    {
        $this->notificationTitle = $notificationTitle;
        $this->notificationBody = $notificationBody;
        $this->branchURL = $branchURL;
        $this->webAppLink = $webAppLink;
        $this->employee = $employee;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this
            ->from('forum@taplingua.com', "Taplingua Forum")
            ->subject($this->notificationTitle)
            ->view('emails.comment-notification', [
                'notificationTitle' => $this->notificationTitle,
                'notificationBody' => $this->notificationBody,
                'branchURL' => $this->branchURL,
                'employee' => $this->employee,
                'webAppLink' => $this->webAppLink
            ]);
    }
}
