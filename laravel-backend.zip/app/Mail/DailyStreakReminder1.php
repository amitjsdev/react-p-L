<?php

namespace App\Mail;

use App\Employee;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class DailyStreakReminder1 extends Mailable
{
    use Queueable, SerializesModels;

    public $employee;
    public $label;
    public $campaign_id;
    public $message;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(Employee $employee, String $label, $campaign_id = "", $message = "Learning a language is fun and easy, do just 2 minutes a day and be a native in no time! 
    Our motto: A little bit of play everyday!!")
    {
        $this->employee = $employee;
        $this->label = $label;
        $this->campaign_id = $campaign_id;
        $this->message = $message;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return;
        $emailLog = logEmail($this->employee->userId, $this->campaign_id);

        $label = $this->label;
        $username = $this->employee->FirstName ?? "Buddy";
        $userId = $this->employee->userId;
        $pixelUrl = $emailLog->pixelUrl;
        $text = $this->message;

        $link = $label ? getBranchIOLink([
            'branch_key' => config('taplingua.BRANCHIO_KEY'),
            'data' => [
                'screenCode' => 11,
                'isDeepLink' => 1,
                'pushMsg' => [],
                'campaign_id' => $this->campaign_id,
            ]
        ]) : "";

        $link = getCTATrakerForBranchLink($emailLog->log_uuid, $link);

        return $this
        ->subject("⏰ Hi " . $username . "! Time for your daily dose of fun and learning!")
        ->view('emails.reminders.daily-streak-reminder-1', compact('label', 'link', 'username', 'userId', 'pixelUrl', 'text'));
    }
}
