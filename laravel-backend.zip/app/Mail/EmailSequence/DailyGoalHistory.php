<?php

namespace App\Mail\EmailSequence;

use App\Employee;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class DailyGoalHistory extends Mailable
{
    use Queueable, SerializesModels;

    public $employee;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(Employee $employee)
    {
        $this->employee = $employee;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $history = getUserGoalDataForLast7Days($this->employee);

        $history["last7Days"] = array_reverse($history["last7Days"]);

        $data = [
            "type" => "bar",
            "data" => [
                "labels" => array_map(function($value) {
                    return Carbon::parse($value)->format("d M");
                }, array_keys($history["last7Days"])),
                "datasets" => [
                    [
                        "label" => "Goal Points",
                        "data" => array_values($history["last7Days"])
                    ]
                ]
            ]
        ];

        $chartURL = "https://quickchart.io/chart?bkg=white&c=" . json_encode($data);

        return $this
            ->from('cristina.guijarro@taplingua.com', "Taplingua")
            ->subject('Check Your Progress!')
            ->view('emails.sequence.daily-goal-history')
            ->with([
                'employee' => $this->employee,
                'chartURL' => $chartURL
            ]);
    }
}
