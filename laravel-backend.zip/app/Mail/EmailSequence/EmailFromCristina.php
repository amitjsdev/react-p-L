<?php

namespace App\Mail\EmailSequence;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class EmailFromCristina extends Mailable
{
    use Queueable, SerializesModels;

    public $employee;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($employee)
    {
        $this->employee = $employee;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this
            ->from('cristina.guijarro@taplingua.com', "Taplingua")
            ->subject("Hey There, Welcome to Taplingua")
            ->view('emails.sequence.email-from-cristina')
            ->with([
                'employee' => $this->employee
            ]);
    }
}
