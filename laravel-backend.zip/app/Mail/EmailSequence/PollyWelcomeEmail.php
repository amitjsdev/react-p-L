<?php

namespace App\Mail\EmailSequence;

use App\Employee;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class PollyWelcomeEmail extends Mailable
{
    use Queueable, SerializesModels;

    public $employee;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(Employee $employee)
    {
        $this->employee = $employee;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $emailLog = logEmail(
            $this->employee->userId,
            'polly-welcome-email'
        );

        $link = getBranchIOLink([
            'branch_key' => config('taplingua.BRANCHIO_KEY'),
            'data' => [
                'screenCode' => 113,
                'isDeepLink' => 1,
                'pushMsg' => [],
                'campaign_id' => 'polly-welcome-email',
            ]
        ]);

        $link = getCTATrakerForBranchLink($emailLog->log_uuid, $link);

        $pixelUrl = $emailLog->pixelUrl;

        try {
            $moduleName = getModuleNameByCourse($this->employee->currentModule);
            
            if(empty($moduleName)) {
                $moduleName = "the language you want";
            }
        } catch (\Throwable $th) {
            //throw $th;
            $moduleName = "the language you want";
        }

        return $this
            ->from('cristina.guijarro@taplingua.com', "Taplingua")
            ->subject("It's Polly. Welcome to Taplingua")
            ->view('emails.sequence.polly-welcome-email')
            ->with([
                'employee' => $this->employee,
                'moduleName' => $moduleName,
                'link' => $link,
                'pixelUrl' => $pixelUrl
            ]);
    }
}
