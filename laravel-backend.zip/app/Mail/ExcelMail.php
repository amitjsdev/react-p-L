<?php

namespace App\Mail;

use App\Employee;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class ExcelMail extends Mailable
{
    use Queueable, SerializesModels;
    private $name = "";
    private $email = "";
    private $filename = "";
    private $cohortName = "";
    private $quizName = "";

    /**
     * Create a new message instance.
     *
     * @return void
     */

    public function __construct($name, $email, $cohortName, $quizName,$filename)
    {
        $this->name = $name;
        $this->email = $email;
        $this->filename = $filename;
        $this->cohortName = $cohortName;
        $this->quizName = $quizName;
        $this->senderEmail ='info@taplingua.com';
        $this->sender = 'Taplingua';
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $location = storage_path("app/$this->filename");
        return $this
            ->from($this->senderEmail,  $this->sender)
            ->subject("Report  ")
            ->view('emails.excel-email', [
                'filename' => $this->filename,
                'cohortName' => $this->cohortName,
                'quizName' => $this->quizName
            ])->attach($location);
    }
}
