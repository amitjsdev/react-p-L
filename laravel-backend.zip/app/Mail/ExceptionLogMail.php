<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class ExceptionLogMail extends Mailable
{
    use Queueable, SerializesModels;

    public $message;
    public $exceptionLogId;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($message = "", $exceptionLogId = "")
    {
        $this->message = $message;
        $this->exceptionLogId = $exceptionLogId;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this
        ->from('inspector@taplingua.com', 'Taplingua Inspector')
        ->subject('Taplingua - Server encountered an error!')
        ->view('emails.exception-log-email', [
                'text' => $this->message,
                'exceptionLogId' => $this->exceptionLogId
            ]);
    }
}
