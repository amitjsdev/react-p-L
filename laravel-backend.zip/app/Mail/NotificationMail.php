<?php

namespace App\Mail;

use App\Employee;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class NotificationMail extends Mailable
{
    use Queueable, SerializesModels;

    public $notificationTitle;
    public $notificationBody;
    public $employee;
    public $branchURL;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(Employee $employee, $notificationTitle = "A New Notification", $notificationBody = "", $branchURL = "")
    {
        $this->notificationTitle = $notificationTitle;
        $this->notificationBody = $notificationBody;
        $this->branchURL = $branchURL;
        $this->employee = $employee;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $emailLog = logEmail($this->employee->userId, "notification");

        return $this
            ->from('cristina.guijarro@taplingua.com', "Taplingua")
            ->subject($this->notificationTitle)
            ->view('emails.notification', [
                'notificationTitle' => $this->notificationTitle,
                'notificationBody' => $this->notificationBody,
                'branchURL' => $this->branchURL,
                'employee' => $this->employee,
                'pixelUrl' => $emailLog->pixelUrl,
            ]);
    }
}
