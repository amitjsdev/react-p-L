<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class PlacementTestResultEmail extends Mailable
{
    use Queueable, SerializesModels;

    public $module;
    public $employee;
    public $correctPercentage;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($module, $employee, $correctPercentage)
    {
        $this->module = $module;
        $this->employee = $employee;
        $this->correctPercentage = $correctPercentage;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $emailLog = logEmail($this->employee->userId, "notification");

        return $this
            ->subject("Your placement test results are ready!")
            ->view('emails.placement-test-result-email', [
            'module' => $this->module,
            'correctPercentage' => $this->correctPercentage,
            'employee' => $this->employee,
            'pixelUrl' => $emailLog->pixelUrl,
            'link' => "/"
        ]);
    }
}
