<?php

namespace App\Mail;

use App\EmailLog;
use App\PushLog;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;

class SummaryReportForEmailAndPush extends Mailable
{
    use Queueable, SerializesModels;

    public $date = null;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($date = null)
    {
        $this->date = $date ?? today();
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $emailBounceCount = 0;
        $emailUnsubscribeCount = 0;

        // get the users
        $users = \App\Employee::whereDate('accountCreationDate', '>=', \Carbon\Carbon::createFromDate(2020, 8, 1))->get();

        // $total user count
        $totalUserCount = $users->count();

        // user that have probably deleted the app
        $lostUserCount = $users->where('is_user_lost', 1)->count();

        // user that have turned notification off
        $userCountWithNotificationOff = $users->where('is_user_lost', '!=', 1)->where('receivePush', '!=', 1)->count();

        // potential user base
        $potentialUserCount = $totalUserCount - ($lostUserCount + $userCountWithNotificationOff);

        // build the report for email and push for today,
        $today = $this->date;

        //  get count of bounces and unsubscribes
        $ses = DB::table('ses_sns_email_list')
            ->selectRaw("emailType, DATE(emailDate) as date, count(*) as count")
            ->whereDate("emailDate", $today)
            ->groupBy('date', 'emailType')
            ->get();

        // get count of sent and opens
        $elogByCampaign = EmailLog::selectRaw("type, DATE(created_at) as date, sum(emailSent) as emailSent, sum(emailOpened) as emailOpened, sum(ctaClicked) as ctaClicked")
            ->whereDate("created_at", $today)
            ->groupBy('date', 'type')
            ->get();

        foreach ($ses as $log) {
            if ($log->emailType == "b") {
                $emailBounceCount = $log->count;
            } else if ($log->emailType == "u") {
                $emailUnsubscribeCount = $log->count;
            }
        }

        $plogByCampaign = PushLog::selectRaw("type, DATE(created_at) as date, sum(status) as pushSent, sum(pushReceived) as pushReceived, sum(pushOpened) as pushOpened")
            ->whereDate("created_at", $today)
            ->groupBy('date', 'type')
            ->get();



        $failedPushes = PushLog::whereDate("created_at", $today)
            ->where('status', 0)
            ->count();

        return $this
            ->subject($today->format('d M Y') . " - Summary report for email and push")
            ->view('emails.reports.summary-report-for-email-and-push', compact(
                'today',
                'totalUserCount',
                'lostUserCount',
                'userCountWithNotificationOff',
                'potentialUserCount',
                'emailBounceCount',
                'emailUnsubscribeCount',
                'elogByCampaign',
                'plogByCampaign',
                'failedPushes'
            ));
    }
}
