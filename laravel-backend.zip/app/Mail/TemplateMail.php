<?php

namespace App\Mail;

use App\EmailTemplate;
use App\Employee;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Str;

class TemplateMail extends Mailable
{
    use Queueable, SerializesModels;

    public $email;
    public $employee;
    public $emailTemplate;
    public $isPreview = false;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($email, EmailTemplate $emailTemplate, $isPreview = false)
    {
        $this->email = $email;
        $this->emailTemplate = $emailTemplate;
        $this->employee = Employee::where('userId', $this->email)->first();
        $this->isPreview = $isPreview;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $email = $this->email;
        $subject = $this->processData($this->emailTemplate->template_subject);
        $content = $this->processData($this->emailTemplate->template_content);

        $label = $this->processData($this->emailTemplate->call_to_action_label);
        $link = $label ? $this->emailTemplate->call_to_action_type == "branch"
            ? getBranchIOLink([
                'branch_key' => config('taplingua.BRANCHIO_KEY'),
                'data' => [
                    'screenCode' => $this->emailTemplate->call_to_action_screen,
                    'isDeepLink' => 1,
                    'pushMsg' => [],
                    'campaign_id' => $this->emailTemplate->template_identifier,
                ]
            ])
            : $this->emailTemplate->call_to_action_link : "";

        // Log the email if not preview
        if ($this->isPreview) {
            $pixelUrl = "";
        } else {
            $emailLog = logEmail(
                $this->email,
                $this->emailTemplate->template_identifier ?
                    $this->emailTemplate->template_identifier : Str::kebab($this->emailTemplate->template_name)
            );

            $pixelUrl = $emailLog->pixelUrl;


            if (!empty($link)) {
                // if link exists, add cta tracker to it
                $link = getCTATrakerForBranchLink($emailLog->log_uuid, $link);
            }
        }

        return $this
            ->from('cristina.guijarro@taplingua.com', 'Taplingua')
            ->subject($subject)
            ->view('emails.template-email', compact('email', 'subject', 'content', 'label', 'link', 'pixelUrl'));
    }

    // to convert tags to actual values
    public function processData($string)
    {

        // check for username
        if ($this->employee) {
            $string = str_replace('{username}', $this->employee->FirstName, $string);
        }

        // check for image src
        $matches = [];
        preg_match_all("/(\{img:)([^\}])+(\})/", $string, $matches);
        foreach ($matches[0] as $match) {
            $string = str_replace($match, "<img style=\"width: 100%\" src=\"" . substr($match, 5, strlen($match) - 6) . "\" />", $string);
        }

        return $string;
    }
}
