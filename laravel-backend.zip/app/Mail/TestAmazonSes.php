<?php

namespace App\Mail;
use App\Models\Customer;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class TestAmazonSes extends Mailable
{
    use Queueable, SerializesModels;
    
    public $data;
    
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($data)
    {
        $this->data = $data;
    }
    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        /*return $this->from($this->data['from'], $this->data['from_name'])
            ->subject($this->data['subject'])
            ->view('emails.tpl');*/

        return $this->from($this->data['from'], $this->data['from_name'])
            //->bcc("sv_mbm@yahoo.com", "Sandeep")
            ->bcc("santanu.dasgupta@taplingua.com", "Santanu")
            ->subject($this->data['subject'])
            ->view('emails.tpl');    
        
    }
}