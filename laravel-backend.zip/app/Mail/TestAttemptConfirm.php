<?php

namespace App\Mail;

use App\Employee;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class TestAttemptConfirm extends Mailable
{
    use Queueable, SerializesModels;
    private $FirstName = "";
    private $cohortName = "";
    private $companyTeam = "";
    private $company = "";
    private $senderEmail = "";
    private $sender = "";

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($FirstName,  $cohortName, $companyTeam, $company,$senderEmail, $sender)
    {
        $this->FirstName = $FirstName;
        $this->cohortName = $cohortName;
        $this->companyTeam = $companyTeam;
        $this->company = $company;
        $this->senderEmail = $senderEmail ? $senderEmail :'info@taplingua.com';
        $this->sender = $sender ? $sender :'Taplingua';
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {

        return $this
        ->from($this->senderEmail, $this->sender)
        ->subject("Test submission successfully recorded")
        ->view('emails.test-attempt-confirm', [
                'name' => $this->FirstName,
                'cohortName' => $this->cohortName,
                'companyTeam' => $this->companyTeam,
                'companyId' => $this->company
            ]
        );

    }
}
