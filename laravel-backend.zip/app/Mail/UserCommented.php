<?php

namespace App\Mail;

use App\Comment;
use App\Forum;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class UserCommented extends Mailable
{
    use Queueable, SerializesModels;

    public $comment;
    public $url;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(Comment $comment, string $url)
    {
        $this->comment = $comment;
        $this->url = $url;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $userId = $this->comment->userId;
        $url = $this->url;
        $comment = $this->comment;
        $employee = $this->comment->employee;
        
        $exercise = null;

        if($comment->commentOn instanceof \App\Forum) {
            if($comment->commentOn->forumFor instanceof \App\V2Exercise) {
                $exercise = $comment->commentOn->forumFor;
            }
        }
        if ($comment->commentOn instanceof \App\Comment) {
            if($comment->commentOn->commentOn) {
                if ($comment->commentOn->commentOn->forumFor instanceof \App\V2Exercise) {
                    $exercise = $comment->commentOn->commentOn->forumFor;
                }
            }
        }

        return $this->view('emails.user-commented', compact('userId', 'url', 'employee', 'comment', 'exercise'));
    }
}
