<?php

namespace App\Mail;

use App\Employee;
use App\Cohort;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class VpiEmployeeWelcomeEmail extends Mailable
{
    use Queueable, SerializesModels;
    private $name = "";
    private $moduleName = "";
    private $email = "";
    private $password = "";

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($name, $moduleName, $email, $password, $type_id, $companyName,$companyId,$senderEmail,$cohortName = '')
    {
        $this->name = $name;
        $this->moduleName = $moduleName;
        $this->email = $email;
        $this->password = $password;
        $employee = Employee::where("userId", $this->email)->first();
        $this->companyCode = $employee->CompanyCode;
        $this->type_id = $type_id;
        $this->companyName = $companyName;
        $this->companyId = $companyId;
        $this->senderEmail = $senderEmail ? $senderEmail :'info@taplingua.com';
        $this->sender = $companyName ? $companyName :'Taplingua';
        $this->cohortName = $cohortName;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $emailLog = logEmail($this->email, "enrolled-employee-welcome-email");
       if($this->type_id ==3){
            return $this
        ->from($this->senderEmail,  $this->sender)
        ->subject('Communications Assessment Test ('.$this->companyName.'/'.$this->cohortName.')')
        ->view('emails.vpi-employee-welcome-email-type-three', [
                'name' => $this->name,
                'moduleName' => $this->moduleName,
                'email' => $this->email,
                'companyCode' => $this->companyCode,
                'password' => $this->password,
                'companyName' => $this->companyName,
                'companyId' => $this->companyCode,
                'cohortName'=>$this->cohortName,
            ]);
        }
        else {
            return $this
        ->from($this->senderEmail, $this->sender)
        ->subject("Welcome to $this->companyName / $this->cohortName")
        ->view('emails.enrolled-employee-welcome-email', [
                'name' => $this->name,
                'moduleName' => $this->moduleName,
                'email' => $this->email,
                'companyCode' => $this->companyCode,
                'password' => $this->password,
                'companyName' => $this->companyName,
                'companyId' => $this->companyCode,
                'cohortName'=>$this->cohortName,
            ]);
        }

    }
}
