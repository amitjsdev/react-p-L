<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class VpiVideoShareMail extends Mailable
{
    use Queueable, SerializesModels;

    public $link;
    public $user;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($name = "", $cohortName = "")
    {
        $this->name = $name;
        $this->cohortName = $cohortName;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->subject('Your answers have been received.')
        ->view('emails.vpi-video-submitted-mail', [
            'name' => $this->name,
            'cohortName' => $this->cohortName,
        ]);
    }
}
