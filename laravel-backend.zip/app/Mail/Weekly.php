<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class Weekly extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Undocumented function
     *
     * @param mixed $data
     * @param string $lang
     * @param array $payload Payload for branch.io
     */
    public function __construct($data, $lang, $payload = [])
    {
        $this->data = $data;
        $this->payload = $payload;
        \App::setlocale($lang);
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {

        return $this
            ->subject(__('email.weekly.subject', [
                'moduleName' => $this->data['moduleName']
            ]))
            ->view('emails.weekly', [
            'data' => $this->data,
            'branchLink' => getBranchIOLink($this->payload)
        ]);
    }
}
