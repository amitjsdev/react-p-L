<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class WeeklyCompletionReport extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($data, $companyCode, $lang, $payload = [])
    {
        $this->data = $data;
        $this->companyCode = $companyCode;
        $this->payload = $payload;
        $this->lang = $lang;
        \App::setlocale(strtolower($lang));
    }
    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $this
            ->subject(__('email.completion-report.subject', [
                'moduleName' => $this->data['moduleName']
            ]))
            ->view('emails.weekly-completion-report', [
                'data' => $this->data,
                'branchLink' => getBranchIOLink($this->payload)
            ]);
    }
}
