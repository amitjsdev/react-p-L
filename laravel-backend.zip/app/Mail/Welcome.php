<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class Welcome extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($data, $companyCode, $lang)
    {
        // add dates to routes
        $isFirst = true;
        $weekStartDate = $data['courseStartDate'];
        $courseDate = $weekStartDate;
        foreach($data['Routes'] as $key => $route) { {
                $date = date_create($courseDate);
                $days = '7';
                if (!$isFirst) {
                    date_add($date, date_interval_create_from_date_string($days . " days"));
                    $courseDate = date_format($date, "d-m-Y");
                }
                $endDate = date_create($courseDate);
                date_add($endDate, date_interval_create_from_date_string($days . " days"));
                $courseEndDate = date_format($endDate, "d-m-Y");
                $data['Routes'][$key]['courseStartDate'] = $courseDate;
                $data['Routes'][$key]['courseEndDate'] = $courseEndDate;
                $isFirst = false;
            }
        }
        $this->data = $data;
        $this->companyCode = $companyCode;
        $this->lang = $lang;
        \App::setlocale(strtolower($lang));
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->subject(__('email.welcome.subject', [
            'moduleName' => $this->data['moduleName'],
            'companyName' => $this->data['companyName'],
        ]))
            ->view('emails.welcome', [
                'data' => $this->data
            ]);
    }
}
