<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Module extends Model
{
    protected $table = 'module';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'moduleno', 'companyno', 'description', 'long_description', 'startDate', 'numberOfWeeks', 'numberOfHours', 'numberOfStudentsRegistered', 'tutor1', 'tutor2', 
        'module_level', 'module_type', 'module_tags', 'module_image', 'adddate', 'status', 'lite_zip_flag',
        'language', 'tolanguage', 'moduleDetailInformation', 'categoryRanking', 'single_speaker', 'presentationModule'
    ];
}
