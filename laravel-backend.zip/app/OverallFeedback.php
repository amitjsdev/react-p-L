<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OverallFeedback extends Model
{
    

        protected $table = 'overall_feedback';
        protected $primaryKey = 'id';
        public $timestamps = true;
        protected $fillable = [
            'feedback', 'practiceSetId', 'email'
        ];
    
}
