<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaymentLog extends Model
{
    protected $fillable = [
        "userId",
        "mrp",
        "actualPrice",
        "discountCode",
        "courseNo",
        "moduleNo",
        "durationInMonth",
        "subscriptionEndDate",
    ];
}
