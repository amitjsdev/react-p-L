<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PlacementExerciseLog extends Model
{
    protected $fillable = [
        'userId',
        'mobileOS',
        'roundLogId',
        "moduleNo",
        "debugRouteNo",
        "debugLessonNo",
        "failCount",
        "questionId",
        "status",
        "type",
        "additionalInfo",
        "roundType",
    ];

    public function round()
    {
        return $this->belongsTo(\App\RoundLog::class, 'roundLogId');
    }
}
