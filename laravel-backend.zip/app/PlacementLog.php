<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PlacementLog extends Model
{
    protected $fillable = [
        "userId",
        "moduleNo",
        "debugRouteNo",
        "debugLessonNo",
        "roundNo",
        "status",
        "mistakesMade",
        "additionalLivesClaimed",
        "isMiniRound",
        "roundType",
    ];


    public function employee()
    {
        return $this->hasOne(\App\Employee::class, 'userId', 'userId');
    }

    public function exercise()
    {
        return $this->hasMany(\App\PlacementExerciseLog::class, 'roundLogId');
    }
}
