<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PlacementTestResult extends Model
{
    protected $fillable = [
        'userId',
        'moduleNo',
        'routeNo',
        'lessonNo',
        'placementScore'
    ];
}
