<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PracticeQuestion extends Model
{
    protected $fillable = [
        'practiceQuestionId',
        'practiceSetQuestion',
        'practiceSetTip',
        'practiceSetDfficultyLevel',
        'practiceSetId',
        'practiceQuestionText',
        'referenceAnswer',
        'video_type',
        'practicetype',
    ];
}
