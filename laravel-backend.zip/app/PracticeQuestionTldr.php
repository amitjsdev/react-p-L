<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PracticeQuestionTldr extends Model
{
    protected $fillable = [
        'practiceQuestionId',
        'practiceSetId',
        'title',
        'description',
    ];

}
