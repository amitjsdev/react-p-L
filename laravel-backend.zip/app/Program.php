<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Program extends Model
{
    protected $guarded = [];

    public function modules() {
        return $this->hasMany(ProgramModule::class, 'program_id', 'id');
    }

    

    /**
     * Get the first module of the program
     *
     * @return void
     */
    public function getFirstModuleAttribute() {
        $firstProgramModule = $this->modules()->orderBy('level_number')->orderBy('sort_order')->first();
        return $firstProgramModule ? $firstProgramModule->module : null;
    }

    /**
     * get strcuture of a program
     *
     * @return void
     */
    public function getWithStructureAttribute() {
        $program = $this;
        $levels = [];
        foreach ($program->modules as $module) {
            // check if level array there, create if not
            if (!isset($levels[$module->level_number])) {
                $levels[$module->level_number] = [];
            }
            $module->moduleName = $module->module ? $module->module->description : null;
            unset($module->module);
            // add to level
            $levels[$module->level_number][] = $module;
        }
        $program->levels = $levels;
        unset($program->modules);
        return $program;
    }


    public function employees() {
        return $this->hasManyThrough(Employee::class, ProgramUser::class, "program_id", "userId", "id", "userId");

        // first key is the foreign key in intermediate table, for current table
        // second key is the foreign key in intermediate table, for other table
        // third key is the localkey in current table
        // fourth key is the localkey in other table
    }
}
