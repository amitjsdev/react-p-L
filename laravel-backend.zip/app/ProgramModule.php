<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProgramModule extends Model
{
    protected $guarded = [];

    public function module() {
        return $this->belongsTo(Module::class, 'module_number', 'moduleno');
    }
}
