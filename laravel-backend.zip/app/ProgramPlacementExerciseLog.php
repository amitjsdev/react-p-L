<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProgramPlacementExerciseLog extends Model
{
    protected $fillable = [
        'userId',
        'mobileOS',
        'roundLogId',
        'programId',
        'failCount',
        'questionId',
        'status',
        'type',
        'additionalInfo',
        'roundType',
    ];
}
