<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProgramPlacementLog extends Model
{
    protected $fillable = [
        'userId',
        'programId',
        'roundNo',
        'status',
        'mistakesMade',
        'isMiniRound',
        'placementScore',
        'additionalLivesClaimed',
    ];
}
