<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProgramPlacementTestResult extends Model
{
    protected $fillable = [
        'userId',
        'programId',
        'placementScore'
    ];
}
