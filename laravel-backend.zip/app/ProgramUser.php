<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProgramUser extends Model
{
    protected $guarded = [];

    public function programModules() {
        return $this->hasMany(ProgramModule::class, 'program_id', 'program_id');
    }
}
