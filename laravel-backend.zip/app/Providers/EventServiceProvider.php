<?php

namespace App\Providers;

use Illuminate\Support\Facades\Event;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;

class EventServiceProvider extends ServiceProvider
{
    /**
     * The event listener mappings for the application.
     *
     * @var array
     */
    protected $listen = [
        'App\Events\UserRegistered' => [
            'App\Listeners\AddModule3ToRegisteredUser', // now add custom module or else module 3
            'App\Listeners\SendContentfulFlashAfterTwoHourToInactiveUser',
            'App\Listeners\SendPushesFromNewStrategy',
            // 'App\Listeners\SendEmailAfter24HoursOfInactivity',
            'App\Listeners\InitiateEmailSequence',
        ],
        'App\Events\UserLoggedIn' => [
            'App\Listeners\AddModuleToUserIfRequired',
            'App\Listeners\ActivateUserCohortIfRequired',
            'App\Listeners\Activate15DayTrialForFirstLogin',
        ],
        'App\Events\UserActivitySave' => [
            'App\Listeners\CheckForBadges',
            'App\Listeners\CheckForContentfulPushEligibility',
        ],
        'App\Events\RoundLogSave' => [
            'App\Listeners\saveLastLessonToEmployeeCourse',
            'App\Listeners\ConsumeAdditionalLivesClaimed',
        ],
        'App\Events\UserCourseAdded' => [
            'App\Listeners\CheckForBadges',
            '\App\Listeners\CourseRegistrationPush',
        ],
        'App\Events\UserTodoActivated' => [
            'App\Listeners\CheckForBadges',
        ],
        'App\Events\CheckForBadges' => [
            'App\Listeners\CheckForBadges',
        ],
        'App\Events\UserAddedToSegment' => [
            'App\Listeners\UserAddedToSegment', // has the user registered push
            'App\Listeners\LogUserPhase',
            'App\Listeners\ScheduleUserPhasePushes',
        ],
        'App\Events\UserCommented' => [
            'App\Listeners\UserCommented'
        ],
        'App\Events\UserDailyGoalLogSave' => [
            'App\Listeners\CheckForPayWallEligibility',
        ],
        'App\Events\UserAddedToCohort' => [
            'App\Listeners\ScheduleNotificationForNewCohortUser'
        ]
    ];

    /**
     * Register any events for your application.
     *
     * @return void
     */
    public function boot()
    {
        parent::boot();

        //
    }
}
