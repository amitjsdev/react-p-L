<?php

namespace App;

use App\Jobs\SendPush;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

class PushCampaign extends Model
{
    protected $fillable = [
        "title",
        "campaign_id",
        "message"
    ];

    /**
     * Find an email template using the template_identifier
     *
     * @param String $identifier
     * @return PushCampaign
     */
    public static function findByCampaignId(String $identifier)
    {
        return PushCampaign::where('campaign_id', $identifier)->first();
    }

    /**
     * Send the push to the user
     *
     * @param Employee $employee
     * @return void
     */
    public function sendPush(Employee $user, Carbon $time)
    {
        // generate payload
        $payload = [
            'title' => $this->parseText($this->title, $user),
            'message' => $this->parseText($this->message, $user),
        ];

        // send the push
        return SendPush::dispatch(
            $user->userId,
            $payload,
            $this->campaign_id,
            117,
            $payload['title'],
            $payload['message']
        )->delay($time);
    }

    /**
     * Parse the text with variables
     *
     * @param string $string
     * @return void
     */
    private function parseText(string $string, Employee $employee)
    {
        // check for username
        if ($this->employee) {
            $string = str_replace('{username}', $this->employee->FirstName, $string);
        }

        return $string;
    }
}
