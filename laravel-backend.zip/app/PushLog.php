<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PushLog extends Model
{
    protected $fillable = [
        "userId",
        "type",
        "screenCode",
        "moduleNo",
        "routeNo",
        "lessonNo",
        "pushReceived",
        "pushOpened",
        "emailSent",
        "status",
        "result",
        "app_version",
    ];
}
