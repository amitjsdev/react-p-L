<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class QuickbloxGroupUser extends Model
{
    protected $fillable = [
        'cohort_id',
        'email',
        'quickblox_userid',
        'login',
        'password',
    ];
}
