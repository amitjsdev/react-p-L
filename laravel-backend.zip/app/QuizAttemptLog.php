<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class QuizAttemptLog extends Model
{
    protected $fillable = [
        'userId',
        'quizSetId',
        'streamId',
        'attemptNumber',
        'attemptStatus',
        'proctoredVideo',
        'aiOutput',
        'ai_result',
        'aiStatus',
        'answerJSON',
        'cohortId',
        'reasonIncomplete',
        'allowedReattempt',
    ];
    // allowedReattempt == 3 // Start over
    // allowedReattempt == 2 //Resume
    // allowedReattempt == 1 //unblocked
    // allowedReattempt == 0 //blocked

    public function employee()
    {
        return $this->hasOne(\App\Employee::class, 'userId', 'userId');
    }

    public function quizSet()
    {
        return $this->hasOne(\App\QuizSet::class, 'quizSetId', 'quizSetId');
    }
    public function resume()
    {
        return $this->hasOne(\App\Resume::class, 'userId', 'userId');
    }

}
