<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class QuizSet extends Model
{
    protected $fillable = [
        'quizSetId',
        'cohortId',
        'companyCode',
        'quizTopic',
        'timeAllotted',
        'questionCap',
        'quizSubTopic',
        'quizSubject',
        'archive',
    ];

    public function questions()
    {
        return $this->hasMany(QuizSetQuestion::class, 'quizSetId', 'quizSetId');
    }
    public function cohort()
    {
        return $this->hasOne(Cohort::class,'id', 'cohortId');
    }
    public function proctoredCohort()
{
    return $this->hasOne(Cohort::class,'id', 'cohortId')->where('type_id', '=', 2);
}

    public function getQuestionCountAttribute()
    {
        return $this->questions()->count();
    }
}
