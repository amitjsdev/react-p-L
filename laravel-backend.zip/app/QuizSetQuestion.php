<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class QuizSetQuestion extends Model
{
    protected $fillable = [
        'quizSetId',
        'quizSetQuestionId',
        'questionType',
        'quizSubTopic',
        'questionText',
        'optionChoices',
        'difficultyLevel',
    ];
}
