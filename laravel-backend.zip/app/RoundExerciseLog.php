<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RoundExerciseLog extends Model
{
    protected $fillable = [
        'userId',
        'mobileOS',
        'roundLogId',
        "moduleNo",
        "routeNo",
        "lessonNo",
        "failCount",
        "questionId",
        "status",
        "type",
        "additionalInfo",
        "roundType",
    ];

    public function round()
    {
        return $this->belongsTo(\App\RoundLog::class, 'roundLogId');
    }
}
