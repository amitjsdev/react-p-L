<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RoundLog extends Model
{
    protected $fillable = [
        "userId",
        "moduleNo",
        "routeNo",
        "lessonNo",
        "roundNo",
        "status",
        "livesLeft",
        "additionalLivesClaimed",
        "isMiniRound",
        "roundType",
    ];


    public function employee()
    {
        return $this->hasOne(\App\Employee::class, 'userId', 'userId');
    }

    public function exercise() {
        return $this->hasMany(\App\RoundExerciseLog::class, 'roundLogId');
    }
}
