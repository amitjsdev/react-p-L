<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Route extends Model
{
    protected $table = 'route';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'moduleno', 'routeno', 'description', 'long_description', 'numberofHours', 'numberofPoints', 'min_points', 'routeEmail', 'adddate', 'status'
    ];
}
