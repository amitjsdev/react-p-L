<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class S3MultiPartUploadLocal extends Model
{
    protected $table = 's3_multipart_upload';
    protected $fillable = [
        'quizAttemptLogId',
        'processed',
        'etag',
        'UploadId',
        'part_no',
        'presignedUrl',
        'name'
    ];
}
