<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;

class QuickBlox
{
    public $token;

    // initialize the class
    function __construct()
    {
        $this->token = $this->createSession();
    }

    /**
     * Create quickblox session
     *
     * @return void
     */
    private function createSession()
    {
        $payload = [
            "application_id" => "88821",
            "auth_key" => "EuN6sjpNTTqt5Pr",
            "nonce" => time(),
            "timestamp" => time(),
            "user" => [
                "login" => "taplingua_admin",
                "password" => "taplingua_admin@"
            ]
        ];

        $payload["signature"] = hash_hmac("sha1", urldecode(http_build_query($payload)), "DqbgCcXBh-nxXqT");

        $client = Http::withHeaders([
            "Content-Type" => "application/json"
        ])
            ->post('https://api.quickblox.com/session.json', $payload);

        $response = $client->json();

        return isset($response["session"]) ? $response["session"]["token"] : null;
    }

    /**
     * Create chat group/dialog
     *
     * @param string $name
     * @param array $member_ids
     * @return void
     */
    public function createChatGroup($name = "New Group", $member_ids = [])
    {
        $client = Http::withHeaders([
            "Content-Type" => "application/json",
            "QB-Token" => $this->token
        ])
            ->post('https://api.quickblox.com/chat/Dialog.json', [
                "type" => 2,
                "name" => $name,
                "occupants_ids" => implode(",", $member_ids),
                // "photo" => "68123"
            ]);

        return $client->json();
    }

    /**
     * Add user to chat group
     *
     * @param [type] $group_id
     * @param [type] $user_id
     * @return void
     */
    public function addUserToChatGroup($group_id, $user_id)
    {
        $client = Http::withHeaders([
            "Content-Type" => "application/json",
            "QB-Token" => $this->token
        ])
            ->put('https://api.quickblox.com/chat/Dialog/' . $group_id . '.json', [
                "push_all" => [
                    "occupants_ids" => [$user_id]
                ]
            ]);

        $response = $client->json();

        return (isset($response['_id']) ? true : (isset($response["errors"]) ? ($response["errors"][0] === "Users are already present in occupants_ids" ? true : false)  : false));
    }

    /**
     * Create user
     *
     * @param string $name
     * @param array $member_ids
     * @return void
     */
    public function createUser($login, $email, $password, $full_name = "")
    {
        $client = Http::withHeaders([
            "Content-Type" => "application/json",
            "QB-Token" => $this->token
        ])
            ->post('https://api.quickblox.com/users.json', [
                "user" => [
                    "login" => $login,
                    "email" => $email,
                    "password" => $password,
                    "full_name" => $full_name,
                ]
            ]);

        $response = $client->json();

        return isset($response['user']) ? $response['user'] : null;
    }

    /**
     * Get quickblox user by email
     *
     * @param string email
     * @return void
     */
    public function getUserByEmail($email)
    {
        $client = Http::withHeaders([
            "Content-Type" => "application/json",
            "QB-Token" => $this->token
        ])
            ->get('https://api.quickblox.com/users/by_email.json?email=' . $email);

        $response = $client->json();

        return isset($response['user']) ? $response['user'] : null;
    }

    // helpers functions

    /**
     * Helper to Create cohort group if needed
     *
     * @param [type] $cohortId
     * @return void
     */
    public static function createCohortGroupIfNeededHelper($cohortId, $qbc = null)
    {
        try {
            // create quickbloxClient
            if (!$qbc) {
                $qbc = new \App\Services\QuickBlox();
            }
            // check if cohort chat already created
            $quickBloxGroupModel = \App\QuickbloxGroup::where('cohort_id', $cohortId)->first();
            if (!$quickBloxGroupModel) {
                // create the cohort chat group

                //  get cohort
                $cohort = \App\Cohort::find($cohortId);
                $quickblox_group = $qbc->createChatGroup($cohort->name);
                logger("quickblox_group_user create chat group output", [$quickblox_group]);
                $quickBloxGroupModel = \App\QuickbloxGroup::create([
                    "quickblox_id" => $quickblox_group['_id'],
                    "cohort_id" => $cohort->id,
                ]);
            }
            //  return the model
            return $quickBloxGroupModel;
        } catch (\Throwable $th) {
            logger("quickblox_group_user creation failed", [$th]);
        }
    }

    public static function createUserIfNeededAndAddToGroup($cohortId, $email)
    {
        // create quickbloxClient
        $qbc = new \App\Services\QuickBlox();
        // create cohort group if needed
        $quickBloxGroupModel = self::createCohortGroupIfNeededHelper($cohortId, $qbc);
        // check if user already there
        $quickbloxGroupUser = \App\QuickbloxGroupUser::where('email', $email)->first();
        // check if user already in group
        $quickbloxGroupUserCurrentCohort = \App\QuickbloxGroupUser::where('email', $email)
            ->where('cohort_id', $cohortId)->first();
        // create quickblox user if necessary
        if (!$quickbloxGroupUser) {
            $employee = \App\Employee::where('userId', $email)->first();
            // get quickbloc user from their side
            $quickblox_user = $qbc->getUserByEmail($email);
            if (!$quickblox_user) {
                $quickblox_user = $qbc->createUser($email, $email, "Quickblox.23", trim(implode(" ", [$employee->FirstName, $employee->LastName])));
            }
            $quickbloxGroupUser = \App\QuickbloxGroupUser::create([
                "cohort_id" => $cohortId,
                "email" => $email,
                "quickblox_userid" => $quickblox_user['id'],
                "login" => $email,
                "password" => "Quickblox.23",
            ]);
        }
        // add user to group if necessary, also check if normal group is created already just now with same cohort
        if (!$quickbloxGroupUserCurrentCohort && $quickbloxGroupUser->cohort_id != $cohortId) {
            \App\QuickbloxGroupUser::create([
                "cohort_id" => $cohortId,
                "email" => $email,
                "quickblox_userid" => $quickbloxGroupUser->quickblox_userid,
                "login" => $email,
                "password" => "Quickblox.23",
            ]);
        }
    }
}
