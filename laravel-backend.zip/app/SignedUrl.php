<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SignedUrl extends Model
{
    protected $fillable = [
        'quizAttemptLogId',
        'processed',
        'name',
        'key',
        'uploadURL'
    ];
}
