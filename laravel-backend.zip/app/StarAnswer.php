<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StarAnswer extends Model
{
    protected $fillable = [
        'userId',
        'storyTitle',
        'situationDesc',
        'taskDesc',
        'actionDesc',
        'resultDesc',
    ];

    protected $gaurded = [];
}
