<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TeacherBooking extends Model
{
    protected $fillable = [
        'start_time',
        'dated',
        'userId',
    ];
}
