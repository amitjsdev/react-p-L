<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Todo extends Model
{
    protected $fillable = [
        "date",
        "userId",
        "title",
        "description",
        "moduleRouteLesson",
        "activityType",
        "activityStatus",
        "courseNumber"
    ];
}
