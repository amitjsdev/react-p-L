<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Transcribe extends Model
{
    protected $table = 'transcribe';
    protected $primaryKey = 'id';
    public $timestamps = true;
    protected $fillable = [
        'jobName', 'langCode', 'mediaFolder', 'mediaFiles'
    ];
}
