<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Passport\HasApiTokens;
use App\Address;
class User extends Authenticatable
{
    use HasApiTokens, Notifiable;

    protected $table = 'userLogin';

    protected $guarded = [];

    const CREATED_AT = 'submittedAt';
    const UPDATED_AT = 'updatedAt';


    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function address() {
        return $this->hasOne(\App\Address::class);
    }

    public function employee() {
        return $this->hasOne(\App\Employee::class, 'userId', 'email');
    }

    public function following_user_questions()
    {
        return $this->hasManyThrough(UserQuestion::class, FollowingUserQuestion::class, 'userId', 'id', 'email', 'user_question_id');
    }

    public function programs()
    {
        return $this->hasManyThrough(Program::class, ProgramUser::class, 'userId', 'id', 'email', 'program_id');
    }
}
