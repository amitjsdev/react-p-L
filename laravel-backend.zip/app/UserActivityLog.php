<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserActivityLog extends Model
{

    // ActivityType is listen learn and play, 1 for listen, 2 for learn and 3 for play
    // to find a lesson is complete or not just search for 4 as activity Type
    

        protected $table = 'useractivitylog_api';
        protected $primaryKey = 'i_d';
        protected $fillable = [
        'userId', 'routeNo', 'moduleNo', 'lessonNo', 'levelNo', 'levelNoFull', 'courseNumber', 'sessionId','pointsScored','totalQuestions','activityType','statusFlag','totalTime',
        'watchedTime','activityDateFrom','activityDateTo'
    ];

}
