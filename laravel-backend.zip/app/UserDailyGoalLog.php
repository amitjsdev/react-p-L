<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserDailyGoalLog extends Model
{
    protected $fillable = [
        'dated',
        'points',
        'userId',
        'moduleNo',
        'routeNo',
        'lessonNo',
        'type',
        'total',
    ];

    public function employee()
    {
        return $this->belongsTo(Employee::class, 'userId', 'userId');
    }

    public function ranks()
    {
        
        return $this->hasMany(LeaderboardRank::class, 'userId', 'userId')->where('companyCode', (int) $this->employee->CompanyCode);
    }

    public function getDailyRankAttribute()
    {
        return $this->ranks()->where('type', 'daily')->whereDate('updated_at', today())->first();
    }

    public function getWeeklyRankAttribute()
    {
        return $this->ranks()->where('type', 'weekly')->first();
    }

    public function getDailyThumbsUpAttribute()
    {
        return UserThumbsUpLog::where('userTo', $this->userId)
            ->whereDate('created_at', today())
            ->where('type', 'daily')
            ->count();
    }

    public function getWeeklyThumbsUpAttribute()
    {


        $startOfWeek = null; // last saturday
        // check if saturday for current week has passed
        if (now()->dayOfWeek >= 6) {
            // today is saturday or more
            $startOfWeek = today()->addDays(6 - now()->dayOfWeek)->startOfDay();
            $endOfWeek = today()->addWeek()->addDays(5 - now()->dayOfWeek)->endOfDay();
        } else {
            // saturday yet to come
            $startOfWeek = today()->subWeek()->addDays(6 - now()->dayOfWeek)->startOfDay();
            $endOfWeek = today()->addDays(5 - now()->dayOfWeek)->endOfDay();
        }

        return UserThumbsUpLog::where('userTo', $this->userId)
            ->where('type', 'weekly')
            ->whereBetween('created_at', [$startOfWeek, $endOfWeek])
            ->count();
    }
}
