<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserDailyPhaseLog extends Model
{
    protected $fillable = ['dated', 'userId', 'phase'];
}
