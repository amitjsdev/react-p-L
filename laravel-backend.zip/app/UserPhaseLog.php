<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserPhaseLog extends Model
{
    protected $fillable = [
        "userId",
        "user_segment_id"
    ];
}
