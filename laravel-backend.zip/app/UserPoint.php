<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserPoint extends Model
{
    protected $fillable = [
        "userId",
        "points",
        "pointType",
        "moduleNo",
        "routeNo",
        "lessonNo",
    ];
}
