<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserQuestion extends Model
{
    protected $fillable = [
        'userId',
        'title',
        'category',
        'content',
    ];

    public function employee() {
        return $this->hasOne(\App\Employee::class, "userId", "userId");
    }

    public function comments() {
        return $this->morphMany(\App\Comment::class, 'commentable')->oldest();
    }
}
