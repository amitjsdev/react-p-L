<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserSegment extends Model
{
    const REGISTERED_USERS = "registered_users";

    protected $fillable = [
        "code",
        "name",
        "description",
        "user_count",
    ];

    public function users() {
        return $this->belongsToMany(\App\Employee::class, 'user_user_segment', 'user_segment_id', 'userId', 'id', 'userId');
    }
}
