<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserSessionLog extends Model
{
    //

    protected $table = 'usersessionlog_api';
    protected $guarded = [];
    protected $primaryKey = 'i_d';
    public $timestamps = false;
}
