<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserThumbsUpLog extends Model
{
    protected $fillable = ['userFrom', 'userTo', 'type'];
}
