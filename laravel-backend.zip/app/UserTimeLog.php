<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserTimeLog extends Model
{
    protected $fillable = [
        'id',
        'userId',
        'pushId',
        'screenCode',
        'moduleNo',
        'courseNo',
        'routeNo',
        'lessonNo',
        'AppVersion',
        'inTime',
        'outTime',
        'buttonsClicked',
        'created_at',
        'updated_at',
        'screenName',
    ];
}
