<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserTimeLogReport extends Model
{
    protected $fillable = [
        "userId",
        "dateRegistered",
        "moduleNo",
        "courseNo",
        "routeNo",
        "lessonNo",
        "time_spent",
        "groupBy",
    ];
}
