<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class V2Exercise extends Model
{
    protected $fillable = [
        "sequenceNo",
        "moduleNo",
        "routeNo",
        "lessonNo",
        "exerciseType",
        "forInteractiveListen",
        "question",
        "options",
        "answer",
        "is_hard",
        "status",
        "translation",
    ];

    public function lesson() {
        return $this->belongsTo(\App\Lesson::class, 'lessonNo', 'lesson_no');
    }

    public function module() {
        return $this->belongsTo(\App\Module::class, 'moduleNo', 'moduleno');
    }

    public function type() {
        return $this->belongsTo(\App\V2ExerciseType::class, 'exerciseType', 'type');
    }

    public function forum() {
        return $this->morphOne(\App\Forum::class, 'forumable');
    }

}
