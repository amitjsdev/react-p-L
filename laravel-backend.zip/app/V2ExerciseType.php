<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class V2ExerciseType extends Model
{
    protected $fillable = [
        "type", "title", "description", "description_es", "is_active"
    ];
}
