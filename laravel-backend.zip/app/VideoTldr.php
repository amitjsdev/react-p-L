<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VideoTldr extends Model
{
    protected $fillable = [
        'moduleNo',
        'routeNo',
        'lessonNo',
        'title',
        'description',
        'voice',
        'extra_info',
        'image',
        'miniLesson',
        'videoTime'
    ];
}
