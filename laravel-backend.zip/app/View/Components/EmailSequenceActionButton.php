<?php

namespace App\View\Components;

use Illuminate\View\Component;

class EmailSequenceActionButton extends Component
{
    public $subMessage;
    public $message;
    public $imageSrc;
    public $buttonLabel;
    public $buttonLink;
    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct($subMessage = "", $message = "", $imageSrc = "", $buttonLabel = "Go", $buttonLink = null)
    {
        $this->subMessage = strtoupper($subMessage);
        $this->message = $message;
        $this->imageSrc = $imageSrc;
        $this->buttonLabel = $buttonLabel;
        $this->buttonLink = $buttonLink ?? getBranchIOLink([
            'branch_key' => config('taplingua.BRANCHIO_KEY'),
            'data' => [
                'isDeepLink' => 1,
                'pushMsg' => []
            ]
        ]);
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\View\View|string
     */
    public function render()
    {
        return view('components.email-sequence-action-button');
    }
}
