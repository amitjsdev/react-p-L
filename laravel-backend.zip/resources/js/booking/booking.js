import Axios from 'axios';
import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';


export default function BookingPage() {

    const [slots, setSlots] = useState([]);
    const [date, setDate] = useState("");
    const [errors, setErrors] = useState({});
    const [message, setMessage] = useState("");
    const [token, setToken] = useState("");
    const [slot, setSlot] = useState("");
    const [isLoading, setIsLoading] = useState(true);
    const [isSubmitting, setIsSubmitting] = useState(false);


    useEffect(() => {

        // get auth token
        const params = new URLSearchParams(window.location.search);

        const t = params.get('token');
        setToken(t);

        // get slots
        Axios.get('/api/get-free-slots', {
            headers: {
                Authorization: "Bearer " + t
            }
        })
            .then(response => {
                setSlots(response.data.freeSlots);
                setIsLoading(false)
            })
            .catch(error => {
                console.log({ error })
                setIsLoading(false)
            })
    }, []);
    return (
        <div className="flex justify-center py-8">
            {
                isLoading
                    ? <span>Please wait...</span>
                    : (
                        <form style={{ width: "300px" }}>
                            <div className="text-lg font-bold text-red-500 text-center mb-4">BOOK A TEACHER</div>
                            <div>
                                <label className="font-bold">Date:</label>
                                <select name="date" className="px-2 py-1 border rounded block w-full" onChange={event => {
                                    setDate(event.target.value);
                                }}
                                    value={date}
                                >
                                    {
                                        Object.keys(slots).map(s => (
                                            <option key={s} value={s}>{s}</option>
                                        ))
                                    }
                                </select>
                                {errors && errors.date && errors.date.map((err, i) => <span key={i} className="text-xs text-red-500 mb-2 block">{err}</span>)}
                            </div>
                            {
                                date
                                    ? (
                                        <div>
                                            <label className="font-bold">Slot:</label>
                                            <select name="slot" className="px-4 py-1 border rounded block w-full mb-2" onChange={event => {
                                                setSlot(event.target.value);
                                            }}
                                            onClick={() => {
                                                setSlot(event.target.value);
                                            }}
                                                value={slot}
                                            >
                                                {
                                                    Object.keys(slots[date]).map(s => (
                                                        <option key={s} value={s}>{s}</option>
                                                    ))
                                                }
                                            </select>
                                            {errors && errors.start_time && errors.start_time.map((err, i) => <span key={i} className="text-xs text-red-500 mb-2 block">{err}</span>)}
                                        </div>
                                    )
                                    : <span className="px-2 py-1 text-center block w-full">Please select a date first!</span>
                            }
                            <div className="flex justify-center">
                                {
                                    isSubmitting
                                        ? (
                                            <span className="px-4 py-2">Please wait...</span>
                                        )
                                        : (
                                            <button
                                                className="px-4 py-2 rounded text-white my-2 shadow uppercase bg-red-500"
                                                onClick={
                                                    () => {
                                                        setIsSubmitting(true);
                                                        setErrors({});
                                                        setMessage("");
                                                        Axios.post('/api/book-a-slot', {
                                                            date,
                                                            start_time: slot
                                                        }, {
                                                            headers: {
                                                                Authorization: "Bearer " + token
                                                            }
                                                        })
                                                            .then(response => {
                                                                setMessage(response.data.message);
                                                                setIsSubmitting(false);
                                                            })
                                                            .catch(error => {
                                                                setErrors(error.response.data.errors);
                                                                setIsSubmitting(false);
                                                            })
                                                    }
                                                }
                                            >Create Booking!</button>
                                        )
                                }
                            </div>
                            {
                                message && <div className="text-center text-green-500 block mt-2 text-sm">{message}</div>
                            }
                        </form>
                    )
            }
        </div >
    )
}
if (document.getElementById('root')) {
    ReactDOM.render(<BookingPage />, document.getElementById('root'));
}