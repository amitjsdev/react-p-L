import Axios from 'axios';
import React, { useEffect, useState } from 'react';
import ReactDOM from 'react-dom';

function Forum() {

    const [token, setToken] = useState("");
    const [forum, setForum] = useState(null);
    const [error, setError] = useState(null);
    const [employee, setEmployee] = useState(null);
    const [message, setMessage] = useState("");
    const [isLoading, setIsLoading] = useState(true);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [commentToFocusOn, setcommentToFocusOn] = useState(null)

    useEffect(() => {

        // get auth token
        const params = new URLSearchParams(window.location.search);

        const t = params.get('token');

        const exerciseId = params.get('exerciseId');
        const forumFor = params.get('forumFor');
        const moduleNo = params.get('moduleNo');
        const routeNo = params.get('routeNo');
        const lessonNo = params.get('lessonNo');
        const ctfo = params.get('commentToFocusOn');

        setToken(t);
        setcommentToFocusOn(ctfo);

        // 
        const forumUrl = exerciseId
            ? `/api/forum/exercise-v2/${exerciseId}`
            : `/api/forum/${forumFor}/${moduleNo}/${routeNo}/${lessonNo}`;

        // get forum and employee
        Axios.get(forumUrl, {
            headers: {
                Authorization: "Bearer " + t
            }
        })
            .then(response => {
                const { employee: e, forum: f } = response.data;
                setForum(f);
                setEmployee(e);
                setIsLoading(false);
            })
            .catch(error => {
                setError(error.response.statusText);
                setIsLoading(false);
            });

    }, []);

    if (error) {
        return <span className="w-screen h-screen flex justify-center items-center text-red-500">{error}</span>;
    }

    if (!forum) {
        return <span className="w-screen h-screen flex justify-center items-center">Loading...</span>;
    }

    return (
        <div>
            <div className="px-8 pt-10">
                {message && <div className="text-green text-sm">{message}</div>}

                {/* show the question */}
                <div>
                    <h2 className="text-gray-400 text-xs">{forum.entity_type} {forum.entity_id}</h2>
                    <h2>{forum.moduleName}</h2>
                    <h2 className="text-gray-500 text-xs">Lesson no: {forum.lessonNo}</h2>
                    <div className="text-2xl font-bold border-b pb-1">{forum.title}</div>
                    <div dangerouslySetInnerHTML={{ __html: forum.content }} className="py-4" />
                </div>
            </div>

            {/* Show all the comments */}
            <div className="bg-gray-200 px-8 py-2 font-bold text-purple-800">
                {forum.comments.length} comment{forum.comments.length !== 1 ? "s" : ""}
            </div>
            <div className="px-8 py-2">
                {
                    forum.comments.map(comment => <CommentBox key={comment.id} comment={comment} token={token} commentToFocusOn={commentToFocusOn} />)
                }
            </div>
        </div>
    )
}

function CommentBox({ comment, token, commentToFocusOn, isNested = false }) {
    const [isReplying, setisReplying] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [reply, setReply] = useState("");

    return (
        <div className={"flex py-3 border-l pl-2"} key={comment.id}>
            {/* user icon */}
            <div
                className="rounded-full block w-5 h-5 p-3 mr-3 bg-red-500 text-white text-xs flex justify-center items-center">
                {comment.employee.FirstName[0]}
            </div>
            {/* other things */}
            <div className="flex-grow">
                <div>
                    <span className="text-xs font-bold">{comment.employee.FirstName}</span>
                    <span className="text-xs text-gray-500 px-2">{comment.created_at}</span>
                    <span className="text-xs text-gray-500 px-2">Edit</span>
                    <span className="text-xs text-gray-500 px-2">Delete</span>
                </div>
                <div className={"p-1" + (parseInt(commentToFocusOn) === comment.id ? " bg-purple-100" : "")}>
                    {
                        comment.comment.split("\n").map((line, i) => <p key={i}>{line}</p>)
                    }
                </div>
                <div className="my-1 flex">
                    <span
                        className="rounded-full inline-block w-5 h-5 p-1 mr-3 bg-gray-300 text-white text-xs text-gray-600 flex justify-center items-center">
                        {comment.upvotes.length}
                    </span>
                    {
                        !isNested &&
                        <div>
                            {
                                isReplying
                                    ?
                                    <span className="text-xs text-red-500 px-2 cursor-pointer" onClick={() => {
                                        setisReplying(false);
                                        setReply("");
                                    }}>Cancel</span>
                                    :
                                    <span className="text-xs text-gray-500 px-2 cursor-pointer" onClick={() => {
                                        setisReplying(true);
                                    }}>Reply</span>
                            }
                        </div>
                    }
                </div>
                {
                    !isNested && (
                        <div>
                            {
                                comment.replies.map(reply => <CommentBox key={reply.id} comment={reply} token={token} commentToFocusOn={commentToFocusOn} isNested={true} />)
                            }
                            {
                                isReplying && (
                                    <div className="my-2">
                                        <textarea className="border rounded w-full" value={reply}
                                            onChange={event => {
                                                setReply(event.target.value);
                                            }}>

                                        </textarea>
                                        {
                                            isSubmitting
                                                ? <span
                                                    className="px-4 py-1 rounded text-sm mt-1">Replying...</span>
                                                : <button
                                                    className="bg-purple-500 text-white px-4 py-1 rounded text-sm mt-1"
                                                    onClick={() => {
                                                        if (!reply.trim()) {
                                                            return alert("Comment is required!");
                                                        }
                                                        setIsSubmitting(true);
                                                        // Save the comment and add it to the list
                                                        Axios.post('/api/comments/add/' + comment.id, {
                                                            comment: reply
                                                        }, {
                                                            headers: {
                                                                Authorization: "Bearer " + token
                                                            }
                                                        })
                                                            .then(response => {
                                                                setIsSubmitting(false);
                                                                // refresh the app
                                                                window.location.reload();
                                                            })
                                                            .catch(error => {
                                                                setIsSubmitting(false);
                                                                setError(error.response.statusText);
                                                                alert("Something went wrong, please refresh and try again!");
                                                            })
                                                    }}
                                                >Reply</button>}
                                    </div>
                                )
                            }
                            {
                                isReplying
                                    ?
                                    <span className="text-xs text-red-500 px-2 cursor-pointer" onClick={() => {
                                        setisReplying(false);
                                        setReply("");
                                    }}>Cancel</span>
                                    :
                                    <span className="text-xs text-gray-500 px-2 cursor-pointer" onClick={() => {
                                        setisReplying(true);
                                    }}>Reply</span>
                            }
                        </div>
                    )
                }
            </div>
        </div>
    );
}

if (document.getElementById('root')) {
    ReactDOM.render(<Forum />, document.getElementById('root'));
}