<?php

return [
    "completion-report" => [
        "subject" => "Percentage of weekly completion in :moduleName",
        "greeting" => "Hi, :Name!",
        'line1' => "You can see the percentage of weekly course completion in :moduleName (:companyName).",
        'duration' => 'Duration',
        'trivia' => "<b>83%</b> of course completers in <b>:moduleName</b> cited that they
                received a tangible career benefit from what they learned. Whether your goal
                is to get a promotion, increase productivity, find a new job, or learn new skills, keep at it to achieve!",
        'motivation' => 'Keep Going To Get A <b>Certificate!</b>',
        'motivation2' => "Great job, you've already completed :coursePercent% of the course.
                Practice everyday to get even better results.",
        'resume-button' => "Resume Learning",
    ],
    "welcome" => [
        "subject" => "Welcome to :moduleName for :companyName",
        "greeting" => "Hi, :Name!",
        "line1" => "Thank you for joining Taplingua! You have signed up for :moduleName course. Below you can see the course structure. Good luck.",
        "schedule-title" => ":moduleName <b>Schedule</b>",
        'motivation' => 'Get a Course <b>Certificate!</b>',
        "motivation2" => "Try to complete at least 75% of the course each week to receive a certificate of course completion that will help you to succeed in your professional life.",
    ],
    "weekly" => [
        "subject" => "Your objectives next week in :moduleName",
        "greeting" => "Hi, :Name!",
        "line1" => "Here you can see the next week's objectives in :moduleName :companyName",
        "task-title" => "Your Objectives <b>Next Week</b>",
        'message' => 'Next week you need to complete 5 levels. You can decide when you want to complete each level whenever you finish before the deadline',
        'duration' => 'duration',
        'resume' => 'Go to Week :weekNo',
    ]
];
