<?php

return [
    "exercise" => [
        "you" => "you",
        "new-user" => "New User",
        "no-comments" => "Write your comment or question for this exercise",
        "add-comment" => "Add comment",
        "comment" => "Comment",
        "save" => "Salvar",
        "cancel" => "Cancelar",
        "edit" => "edit",
        "delete" => "delete",
        "upvote" => "Upvote",
        "upvotes" => "Upvotes",
        "delete-confirmation" => "Delete the comment?",
    ],
];
