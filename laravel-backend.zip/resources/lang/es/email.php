<?php

return [
    "completion-report" => [
        "subject" => "Porcentaje de finalizción semanal en :moduleName",
        "greeting" => "Hola, :Name!",
        'line1' => "Puede ver el porcentaje de finalizción semanal del curso en :moduleName (:companyName).",
        'duration' => 'Duration',
        'trivia' => "<b>83%</b> of course completers in <b>:moduleName</b> cited that they
                received a tangible career benefit from what they learned. Whether your goal
                is to get a promotion, increase productivity, find a new job, or learn new skills, keep at it to achieve!",
        'motivation' => 'Keep Going To Get A <b>Certificate!</b>',
        'motivation2' => "Great job, you've already completed :coursePercent% of the course.
                Practice everyday to get even better results.",
        'resume-button' => "Resume Learning",
    ],
    "welcome" => [
        "subject" => "Bienvenido a :moduleName para :companyName",
        "greeting" => "Hola, :Name!",
        "line1" => "Thank you for joining Taplingua! You have signed up for :moduleName course. Below you can see the course structure. Good luck.",
        "schedule-title"=> ":moduleName <b>Schedule</b>",
        'motivation' => 'Get a Course <b>Certificate!</b>',
        "motivation2" => "Try to complete at least 75% of the course each week to receive a certificate of course completion that will help you to succeed in your professional life.",
    ],
    "weekly" => [
        "subject" => "Tus objetivos esta semana en :moduleName",
        "greeting" => "Hi, :Name!",
        "line1" => "aquí puedes ver los objetivos de la esta semana en :moduleName :companyName",
        "task-title" => "Tus objetivos <b>esta samana</b>",
        'message' => 'La próxima semana debes completar 5 niveles. Puedes decidir cuándo quieres completar cada nivel cuando termines antes de la fecha límite',
        'duration' => 'duración',
        'resume' => 'Ir Week :weekNo',
    ]
];
