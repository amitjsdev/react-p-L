<?php

return [
    "exercise" => [
        "you" => "tú",
        "new-user" => "Nuevo usuario",
        "no-comments" => "Escribe aquí tu pregunta o comentario sobre el ejercicio.",
        "add-comment" => "Agregar contenido",
        "comment" => "Comentario",
        "save" => "Salvar",
        "cancel" => "Cancelar",
        "edit" => "editar",
        "delete" => "eliminar",
        "upvote" => "Voto a favor",
        "upvotes" => "Votos a favor",
        "delete-confirmation" => "¿Eliminar el comentario?",
    ],
];