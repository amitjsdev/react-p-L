<?php

return [
    "completion-report" => [
        "subject" => "Porcentagem de conclusão semanal em in :moduleName",
        "greeting" => "Oi, :Name!",
        'line1' => "Você pode ver a porcentagem de conclusão semanal do curso em :moduleName (:companyName).",
        'duration' => 'Duration',
        'trivia' => "<b>83%</b> of course completers in <b>:moduleName</b> cited that they
                received a tangible career benefit from what they learned. Whether your goal
                is to get a promotion, increase productivity, find a new job, or learn new skills, keep at it to achieve!",
        'motivation' => 'Keep Going To Get A <b>Certificate!</b>',
        'motivation2' => "Great job, you've already completed :coursePercent% of the course.
                Practice everyday to get even better results.",
        'resume-button' => "Resume Learning",
    ],
    "welcome" => [
        "subject" => "Bem-vindo ao :moduleName para :companyName",
        "greeting" => "Oi, :Name!",
        "line1" => "Thank you for joining Taplingua! You have signed up for :moduleName course. Below you can see the course structure. Good luck.",
        "schedule-title" => ":moduleName <b>Schedule</b>",
        'motivation' => 'Get a Course <b>Certificate!</b>',
        "motivation2" => "Try to complete at least 75% of the course each week to receive a certificate of course completion that will help you to succeed in your professional life.",
    ],
    "weekly" => [
        "subject" => "Seus objetivos na esta semana em :moduleName",
        "greeting" => "Hi, :Name!",
        "line1" => "Aqui Você pode ver os objetivos da esta semana em :moduleName :companyName",
        "task-title" => "Seus objetivos na <b>Next Week</b>",
        'message' => 'Na próxima semana Você precisa completar 5 níveis. Você pode decidir quando deseja concluir cada nível  sempre que terminar antes do prazo',
        'duration' => 'duração',
        'resume' => 'Vamos para Week :weekNo',
    ],
];
