<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unsubscribe</title>
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
</head>

<body class="d-flex justify-content-center align-items-center" style="height: 100vh;">

    @if(session()->has('success'))
    <div class="text-center">
        <div class="text-success text-center d-block mb-2">{{session()->get('success')}}</div>
        <span>Please close this window now!</span>
    </div>
    @elseif(session()->has('error'))
    <div class="text-center">
        <div class="text-danger text-center d-block mb-2">{{session()->get('error')}}</div>
        <span>Please close this window now!</span>
    </div>
    @elseif(count($messages) > 0)
    @foreach($messages as $message)
    <div class="text-center">
        <div class="text-danger text-center d-block mb-2">{{$message}}</div>
        <span>Please try again!</span>
    </div>
    @endforeach
    @else
    <div>

        <h5 class="text-center pb-3">
            <img src="{{asset('/images/taplingua.logo.png')}}" />
            <br>
            Unsubscribe
        </h5>
        <div class="row">

            <form action="/unsubscribe" method="post" class="p2 mx-auto" style="width: 300px">
                @csrf
                
                <div class="form-group">
                    <input type="text" name="email" id="email" required class="form-control" placeholder="email" value="{{ $email }}">
                </div>
                
                <div class="form-group text-center">
                    <button class="btn btn-danger" type="submit">Submit</button>
                </div>

            </form>

        </div>
    </div>
    @endif
</body>

</html>