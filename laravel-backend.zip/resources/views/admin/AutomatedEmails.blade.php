@include('admin.layouts.partials.head')


<div class="card-body">
                <table class="table table-bordered">
                  <thead>                  
                    <tr>
                      <th style="width: 10px">#</th>
                      <th>Name</th>
                      <th>Id</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>

                  	   
                   @foreach($courses as $item => $value)
                      <tr>
                        <td>{{$value->i_d}}</td>
                        <td>{{$value->courseName}}</td>
                        <td>{{$value->courseNumber}}</td>
                        <td>
                            <i class="fas fa-trash" onclick="delete_group('{{$value->id}}','/delete-api')" style="cursor: pointer;"></i>
                        </td>
                      </tr>
                   @endforeach  
                  </tbody>
                </table>
              </div>


{{$courses->links()}}


<div class="login-box">
  <div class="login-logo">
    <a href="../../index2.html"><b>Admin</b> Login</a>
  </div>
  <!-- /.login-logo -->
  <div class="card">
    <div class="card-body login-card-body">

      @if(app('request')->input('status') == 'false')
        <div class="alert alert-danger">
          <strong>Invalid</strong> username and password.
        </div>
      @endif

      <form action="/admin-login" method="post">
        <div class="input-group mb-3">
          <input type="text" class="form-control" placeholder="Username" name="username">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-envelope"></span>
            </div>
          </div>
        </div>
        <div class="input-group mb-3">
          <input type="password" class="form-control" placeholder="Password" name="password">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-8">
            <div class="icheck-primary">
              <input type="checkbox" id="remember">
              <label for="remember">
                Remember Me
              </label>
            </div>
          </div>
          <!-- /.col -->
          <div class="col-4">
            <button type="submit" class="btn btn-primary btn-block">Sign In</button>
          </div>
          <!-- /.col -->
        </div>
      </form>

   

    
    </div>
    <!-- /.login-card-body -->
  </div>
</div>