<select class="form-control" id="courseBatch" name="courseBatch">

    <option value="">Select</option>

    
    <?php 

     foreach($results as $cbs) { 

    ?>

    <option value="<?php echo trim($cbs->batchNumber); ?>" <?php if(trim($cbs->batchNumber)==app('request')->input('courseBatch')) echo 'selected="selected"'; ?>><?php echo trim($cbs->batchNumber); ?></option>

    <?php }  ?>

    
  </select>   