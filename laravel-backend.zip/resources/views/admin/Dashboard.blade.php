@include('admin.layouts.mainlayout')

 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Groups</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Groups</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
     <section class="content">
      <div class="container-fluid">
      	@if(session()->has('message'))
		    <div class="alert alert-success">
		        {{ session()->get('message') }}
		    </div>
		@endif
        <div class="row">
          <div class="col-md-3"></div>
          <div class="col-md-6">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Groups</h3>
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-whatever="@fat" style="float: right;">Add Group</button>

              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table class="table table-bordered">
                  <thead>                  
                    <tr>
                      <th style="width: 10px">#</th>
                      <th>Group Name</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                  	@foreach($groups as $item => $value)
	                    <tr>
	                      <td>1</td>
	                      <td>{{$value->name}}</td>
	                      <td>
	                          <i class="fas fa-edit" onclick="edit_group('{{$value->id}}','{{$value->id}}')"></i>
	                          <i class="fas fa-trash" onclick="delete_group('{{$value->id}}','/delete-group')" style="cursor: pointer;"></i>
	                      </td>
	                    </tr>
	                @endforeach    
                   
                    </tr>
                  </tbody>
                </table>
              </div>
           
            </div>
            <!-- /.card -->

        
            <!-- /.card -->
          </div>
          <div class="col-md-3"></div>
       
        </div>
        <!-- /.row -->
   
   
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>

    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Add Group</h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>

	        <form method="post" action="/add-group">
			@csrf
		      <div class="modal-body">
		      
		          <div class="form-group">
		            <label for="recipient-name" class="col-form-label">Group Name:</label>
		            <input type="text" class="form-control" id="group" name="group">
		          </div>
		          
		      
		      </div>
		      <div class="modal-footer">
		        <button type="submit" class="btn btn-primary">Save</button>
		      </div>

		    </form>   
	    </div>
	  </div>
	</div>

	<div class="modal fade" id="groups_api" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog modal-lg" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Assign Api:</h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>

	        <form >

	        	<input type="hidden" name="group_id" id="group_id" />
		      <div class="modal-body">
		      
		          <div class="form-group">
		             <div class="row" id="checkboxes">
		             	<input type="hidden" id="api_size" value={{$size}}>
			            @foreach($apies as $item => $value)
			            <div class="row">
			             <div class="col-sm-4" style="width: 109px;">
			             	<label for="one" id="checked_label_{{$item+1}}">
						        <input type="checkbox" class="checked_api_id_{{$value->id}}" id="checked_api_id_{{$item+1}}" style="margin-right: 10px;" name="api_id[]" value="{{$value->id}}" />{{$value->name}}
						     </label>
			             	
			             </div>
			             <div class="col-sm-2"  style="width: 109px;">
			             	<label for="one">
						        <input type="checkbox" class="checked_get_{{$value->id}}"  id="checked_get_{{$value->name}}" style="margin-right: 10px;" name="get_{{$value->name}}" value="get" />Get
						     </label>
			             	
			             </div>
			             <div class="col-sm-2"  style="width: 109px;">
			             	<label for="one">
						        <input type="checkbox"  class="checked_post_{{$value->id}}" id="checked_post_{{$value->name}}" style="margin-right: 10px;" name="post_{{$item+1}}" value="post" />Post
						     </label>
			             	
			             </div>
			             <div class="col-sm-2"  style="width: 109px;">
			             	<label for="one">
						        <input type="checkbox" class="checked_delete_{{$value->id}}" id="checked_delete_{{$value->name}}" style="margin-right: 10px;" name="delete_{{$item+1}}" value="delete" />Delete
						     </label>
			             	
			             </div>
			             <div class="col-sm-2"  style="width: 109px;">
			             	<label for="one">
						       <input type="checkbox" class="checked_put_{{$value->id}}" id="checked_put_{{$value->name}}" style="margin-right: 10px;" name="put_{{$item+1	}}" value="put" />Put
						     </label>
			             	
			             </div>
				        </div>    
						      
					    @endforeach  
					</div>    
				    
		          </div>
		          
		      
		      </div>
		      <div class="modal-footer">
		        <button type="button" class="btn btn-primary" onclick="Assign_api()">Save</button>
		      </div>

		    </form>   
	    </div>
	  </div>
	</div>
    <!-- /.content -->
  </div>

  @include('admin.layouts.partials.footer')

