@include('admin.layouts.mainlayout')

 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Courses</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Edit Course</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
     <section class="content">
      <div class="container-fluid">
      	@if(session()->has('message'))
		    <div class="alert alert-success">
		        {{ session()->get('message') }}
		    </div>
		@endif

        @if(session()->has('error'))
		    <div class="alert alert-danger">
		        {{ session()->get('error') }}
		    </div>
		@endif

 
        


        <div class="row">
           
          <div class="col-md-12 edit-form">
            <div class="card">
               
                
              
              <div class="card-body">
                <div class="table-responsive">
                
                <form method="post" action="/save-course">
          @csrf
            
          <div class="modal-body">
          
              <div class="form-group">
                 

                 <div class="marginb10"> 
<div class="left">Course No: (*)</div>
<div class="right"><input class="form-control" type="text" name="courseNumber" value="{{$course->courseNumber}}" />
</div>
</div>

<div style="clear:both">&nbsp;</div>


 <div class="marginb10"> 
<div class="left">Course Name: (*)</div>
<div class="right"><input class="form-control" type="text" name="courseName" value="{{$course->courseName}}" />
</div>
</div>



<div style="clear:both">&nbsp;</div>

 
<div class="marginb10"> 
<div class="left">Tutor:</div>
<div class="right">

<select class="form-control" name="tutorid">
  
<option value="">Select</option>  
 
<?php 

 



foreach($tutors as $data){  ?>

<option <?php if($data->tutorid==$course->tutorid) { ?> selected="selected" <?php } ?> value="<?php echo $data->tutorid; ?>"><?php echo $data->tutorFirstName." ".$data->tutorLastName." - ".$data->tutorEmail; ?></option>

<?php } ?>
 	
</select>    

</div>
</div>





<div style="clear:both">&nbsp;</div>

 
<div class="marginb10"> 
<div class="left">Modules: (*)</div>
<div class="right">

<select class="form-control" name="moduleNumber">

<option value="">Select</option>  
  
 
<?php 

 

foreach($modules as $data){  ?>



<option <?php if($data->moduleno==$course->moduleNumber  && strlen($course->moduleNumber)) { ?> selected="selected" <?php } ?> value="<?php echo $data->moduleno; ?>"><?php echo $data->moduleno."-".$data->description; ?></option>




<?php } ?>
 	
</select>    

</div>
</div>


<div style="clear:both">&nbsp;</div>

<div class="marginb10"> 
<div class="left">Company: (*)</div>
<div class="right">

<select class="form-control" name="Company" onchange="changeCourseBatch(this.value, '{{$course->courseBatch}}')">
  
<option value="">Select</option>   
 
<?php 

 

foreach($companies as $cmp){  ?>

 

<option <?php if($cmp->Id==$course->Company && strlen($course->Company)) { ?> selected="selected" <?php } ?> value="<?php echo $cmp->Id; ?>"><?php echo $cmp->Id; ?> - <?php echo $cmp->Name; ?></option>

 


<?php } ?>
  
</select>    

</div>
</div>



<div style="clear:both">&nbsp;</div>  

<div class="marginb10"> 
<div class="left">Course Start Date: (*) [Y-m-d H:i:s   i.e.  2018-01-08 00:00:00]</div>
<div class="right"><input class="form-control" type="text" id="courseStartDate" name="courseStartDate" value="{{$course->courseStartDate}}" />
</div>
</div>
   
<div style="clear:both">&nbsp;</div>    
           
<div class="marginb10"> 
<div class="left">Course End Date:</div>
<div class="right"><input class="form-control" type="text" id="courseEndDate" name="courseEndDate" value="{{$course->courseEndDate}}" />
</div>
</div>

<div style="clear:both">&nbsp;</div>

           
<div class="marginb10"> 
<div class="left">Course Number Of Students:</div>
<div class="right"><input class="form-control" type="text" name="courseNumberOfStudents" value="{{$course->courseNumberOfStudents}}" />
</div>
</div>


<div class="marginb10"> 
<div class="left">Number of Routes:</div>
<div class="right"><input class="form-control" type="text" name="numRoutes" value="{{$course->numRoutes}}" />
</div>
</div>

<div style="clear:both">&nbsp;</div>

<div class="clear"></div>


<div class="marginb10"> 
<div class="left">Number Of Weeks:</div>
<div class="right"><input class="form-control" type="text" name="numberOfWeeks" value="{{$course->numberOfWeeks}}" />
</div>
</div>

<div style="clear:both">&nbsp;</div>

<div class="clear"></div>

 


<div class="clear"></div>
<div class="margint10"> 
<div class="left">courseFlag:</div>
<div class="right">
 <select class="status form-control" name="courseFlag">
   <option value="Y" <?php if (isset($course->courseFlag) && $course->courseFlag=="Y"){echo " selected ";}?>>Yes</option>
   <option value="N" <?php if (isset($course->courseFlag) && $course->courseFlag=="N"){echo " selected ";}?>>No</option>
 </select></div>
</div>

<div style="clear:both">&nbsp;</div>



<div class="clear"></div>
<div class="margint10"> 
<div class="left">holidayInCourseFlag:</div>
<div class="right">
 <select class="status form-control" name="holidayInCourseFlag">
   <option value="Y" <?php if (isset($course->holidayInCourseFlag) && $course->holidayInCourseFlag=="Y"){echo " selected ";}?>>Yes</option>
   <option value="N" <?php if (isset($course->holidayInCourseFlag) && $course->holidayInCourseFlag=="N"){echo " selected ";}?>>No</option>
 </select></div>
</div>

<div style="clear:both">&nbsp;</div>


<div class="marginb10"> 
<div class="left">holidayWeek:</div>
<div class="right"><input class="form-control" type="text" name="holidayWeek"  value="{{$course->holidayWeek}}" />
</div>
</div>

<div style="clear:both">&nbsp;</div>


<div class="marginb10"> 
<div class="left">courseBatch:</div>
<div class="right">

  
  <div id="DivBatchNo">
   <?php //include("courseBatch.php"); ?>
  </div>  
  

  

</div>
</div>

<div style="clear:both">&nbsp;</div>


 

<div class="clear"></div>
<div class="margint10"> 
<div class="left">Status:</div>
<div class="right">
 <select class="status form-control" name="status">
   <option value="1" <?php if (isset($course->Status) && $course->Status==1){echo " selected ";}?>>Active</option>
   <option value="0" <?php if (isset($course->Status) && $course->Status==0){echo " selected ";}?>>Deactive</option>
 </select></div>
</div>


<div style="clear:both">&nbsp;</div>


<div class="clear"></div>
<div class="margint10"> 
<div class="left">Evaluation Required:</div>
<div class="right">
 <select class="status form-control" name="evaluation_required">

  <option value="N" <?php if (isset($course->evaluationRequired) && $course->evaluationRequired=="N"){echo " selected ";}?>>No</option>
   <option value="Y" <?php if (isset($course->evaluationRequired) && $course->evaluationRequired=="Y"){echo " selected ";}?>>Yes</option>
   
 </select></div>
</div>


<div style="clear:both">&nbsp;</div>



<div class="margint10"> 
<div class="left">Weekly Email?:</div>
<div class="right">
 <select class="status form-control" name="weekly_email">

   <option value="N" <?php if (isset($course->weeklyEmail) && $course->weeklyEmail=="N"){echo " selected ";}?>>No</option>
   <option value="Y" <?php if (isset($course->weeklyEmail) && $course->weeklyEmail=="Y"){echo " selected ";}?>>Yes</option>
   
 </select></div>
</div>


<div style="clear:both">&nbsp;</div>


<input type="hidden" name="id" value="{{$course->i_d}}" />


 
          <div class="modal-footer">
            <button type="submit" class="btn btn-primary">Save</button>
          </div>

        </div>
      </div>

        </form>  


              </div>
              </div>






           
            </div>
            <!-- /.card -->

        
            <!-- /.card -->
          </div>
           
       
        </div>
        <!-- /.row -->
   
   
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>

 

	 
    <!-- /.content -->
  </div>

  @include('admin.layouts.partials.footer')


<script>


function changeCourseBatch(c, b)
{

   $('#DivBatchNo').html("loading...");

   $.ajax({
        type:"GET",
        cache:false,
        headers: {
                  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
               },
        url:"/company-batch",
        data:{companyCode:c, courseBatch:b},    // multiple data sent using ajax
        success: function (html) {

           //console.log( html ); 

           $('#DivBatchNo').html(html);
      
        }
      });

}


$(document).ready(function() {

<?php //if($course->Company!="") { ?>
 changeCourseBatch('<?php echo $course->Company; ?>', '<?php echo $course->courseBatch; ?>')
<?php //} ?>

});  


</script>