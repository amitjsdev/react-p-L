@include('admin.layouts.mainlayout')

 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Exercises</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Edit Exercises</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
     <section class="content">
      <div class="container-fluid">
      	@if(session()->has('message'))
		    <div class="alert alert-success">
		        {{ session()->get('message') }}
		    </div>
		@endif

        @if(session()->has('error'))
		    <div class="alert alert-danger">
		        {{ session()->get('error') }}
		    </div>
		@endif

 
        


        <div class="row">
           
          <div class="col-md-12 edit-form">
            <div class="card">
               
                
              
              <div class="card-body">
                <div class="table-responsive">
                
                <form method="post" action="/save-exercise">
          @csrf
            
          <div class="modal-body">
          
              <div class="form-group">
                 

              <?php  

$descr_C = count(explode("\n", $exercise->description));
$media_C = count(explode("\n", $exercise->media));
$media_alt1_C = count(explode("\n", $exercise->media_alt1)); 

$alt1_tmp = explode("\n", $exercise->media);


#1. If there are commas in the above fields, can you put a warning as well. As currently commas aren't permitted

$searchString = ',';
$comma = 0;
$lessonStr = 0;


if( strpos($exercise->description, $searchString) !== false ) {
   $comma = 1;
}

if( strpos($exercise->media, $searchString) !== false ) {
   $comma = 1;
}

if( strpos($exercise->media_alt1, $searchString) !== false ) {
   $comma = 1;
}

 

#2. Another warning is needed, if the Media (dialogs) have a number that doesn't match the lesson number

//Match lesson number in Media MP3
$searchString = $exercise->lesson_no.".";

foreach ($alt1_tmp as $key => $value) {

if( strstr($value, $searchString) !== false ) {
   $lessonStr = 1;
}
else
{
   $lessonStr = 0;
   break; 	
}

}

//echo $lessonStr;

///echo 'Pack File';


if($descr_C==$media_C && $media_C==$media_alt1_C && $media_alt1_C==$descr_C)
{

    echo '<div style="color: #00ff00;">';
	echo "Description: (".$descr_C.")  "; echo "Media: (".$media_C.")  "; echo "Media Alt1: (".$media_alt1_C.")  <br>";
    echo '</div>';
}
else	
{

?>
<div style="color: #ff0000;">Array size for Description, media and media_alt1 fields doesn't match
<br>

<?php echo "Description: (".$descr_C.")  "; echo "Media: (".$media_C.")  "; echo "Media Alt1: (".$media_alt1_C.")  ";  ?>


</div>

<br>

<br>

<?php } ?>

<div style="color: #ff0000;">
	


<?php if($comma==1) echo "Commas aren't permitted in Description, Media and Media Alt1";  ?>

<br>

<?php if($lessonStr==0) echo "Media (dialogs) have a number that doesn't match the lesson number";  ?>

<br><br>

</div>
                   

 
<div class="marginb10"> 
<div class="left">Module No:</div>
<div class="right">

<select name="moduleno" class="form-control" onchange="changeRoutes(this.value);">

<option value="">Select</option>  
  
 
<?php 

 

foreach($modules as $data){  ?>



<option <?php if($data->moduleno==$exercise->moduleno  && strlen($exercise->moduleno)) { ?> selected="selected" <?php } ?> value="<?php echo $data->moduleno; ?>"><?php echo $data->moduleno."-".$data->description; ?></option>




<?php } ?>
 	
</select>    

</div>
</div>


<div style="clear:both">&nbsp;</div>

<div class="left">Route No:</div>
<div class="right">


<div id="DivRouteNo" class="marginb10"> 

<select class="form-control" name="routeno">
<option value="">Select</option>
</select>

 
</div>

</div>

<div style="clear:both">&nbsp;</div>


<div class="marginb10"> 
<div class="left">Lesson No:</div>
<div class="right">

<div id="DivLessonNo" class="marginb10"> 

<select class="form-control" name="routeno">
<option value="">Select</option>
</select>

 
</div>


</div>
</div>


<div style="clear:both">&nbsp;</div>



<div class="marginb10"> 
<div class="left">Exercise No:</div>
<div class="right">
<input type="text" class="form-control"  value="{{$exercise->exercise_no}}" name="exercise_no">

</div>
</div>


<div style="clear:both">&nbsp;</div>


<div class="marginb10"> 
<div class="left">Exercise Type:</div>
<div class="right">
<select class="form-control"  name="exercise_type_id">
<?php 
foreach($exercise_type as $data){  ?>
<option value="<?php echo $data->id;?>" <?php echo $exercise->exercise_type_id==$data->id ? 'selected="selected"' : '';?>><?php echo $data->title;?></option>
<?php } ?>
</select>	

</div>
</div>


<div style="clear:both">&nbsp;</div>


 <div class="marginb10"> 
<div class="left">Title:</div>
<div class="right"><input type="text" name="title"  class="form-control"  value="{{$exercise->title}}" />
</div>
</div>

<div style="clear:both">&nbsp;</div>

<div class="marginb10"> 
<div class="left">Description:</div>
<div class="right"><textarea name="description" rows="10" cols="80" class="form-control" >{{$exercise->description}}</textarea>
</div>
</div>


<div style="clear:both">&nbsp;</div>


<div class="marginb10"> 
<div class="left">Media:</div>
<div class="right"><textarea name="media" rows="10" cols="80" class="form-control" >{{$exercise->media}}</textarea>
</div>
</div>


<div style="clear:both">&nbsp;</div>

<div class="marginb10"> 
<div class="left">Media Alt1:</div>
<div class="right"><textarea name="media_alt1" rows="10" cols="80" class="form-control" >{{$exercise->media_alt1}}</textarea>
</div>
</div>


<div style="clear:both">&nbsp;</div>

<div class="marginb10"> 
<div class="left">Media Alt2:</div>
<div class="right"><textarea name="media_alt2" rows="10" cols="80" class="form-control" >{{$exercise->media_alt2}}</textarea>
</div>
</div>

<div style="clear:both">&nbsp;</div>

<div class="marginb10"> 
<div class="left">Media Alt3:</div>
<div class="right"><textarea name="media_alt3" rows="10" cols="80" class="form-control" >{{$exercise->media_alt3}}</textarea>
</div>
</div>


<div style="clear:both">&nbsp;</div>

<div class="marginb10"> 
<div class="left">Summary Translation:</div>
<div class="right"><textarea name="summary_translation" rows="10" cols="80" class="form-control" >{{$exercise->summary_translation}}</textarea>
</div>
</div>

<div style="clear:both">&nbsp;</div>

<div class="margint10"> 
<div class="left">Summary New Format:</div>
<div class="right">

<?php $summary_new_format = $exercise->summary_new_format;  ?>

 <select class="form-control"  name="summary_new_format">
   <option value="1" <?php if (isset($summary_new_format) && $summary_new_format=="1"){echo " selected ";}?>>Yes</option>
   <option value="0" <?php if (isset($summary_new_format) && $summary_new_format=="0"){echo " selected ";}?>>No</option>
 </select></div>
</div>

<div style="clear:both">&nbsp;</div>

<div class="marginb10"> 
<div class="left">Image:</div>
<div class="right"><input type="text" name="image" id="uploadimage" class="form-control"  value="{{$exercise->image}}" /> 
</div>
</div>

<div style="clear:both">&nbsp;</div>


<div class="margint10"> 
<div class="left">Status:</div>
<div class="right">

<?php $status = $exercise->status; ?>

 <select class="form-control" name="status">
   <option value="1" <?php if (isset($status) && $status==1){echo " selected ";}?>>Active</option>
   <option value="0" <?php if (isset($status) && $status==0){echo " selected ";}?>>Deactive</option>
 </select></div>
</div>

<div style="clear:both">&nbsp;</div>


<input type="hidden" name="id" value="{{$exercise->id}}" />


 
          <div class="modal-footer">
            <button type="submit" class="btn btn-primary">Save</button>
          </div>

        </div>
      </div>

        </form>  


              </div>
              </div>






           
            </div>
            <!-- /.card -->

        
            <!-- /.card -->
          </div>
           
       
        </div>
        <!-- /.row -->
   
   
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>

 

	 
    <!-- /.content -->
  </div>

  @include('admin.layouts.partials.footer')


<script>


function changeRoutes(m, r)
{

   $('#DivRouteNo').html("loading...");

   $.ajax({
        type:"GET",
        cache:false,
        headers: {
                  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
               },
        url:"/module-route?name=routeno",
        data:{moduleNo:m, routeNo: r},    // multiple data sent using ajax
        success: function (html) {

           //console.log( html ); 

           $('#DivRouteNo').html(html);
      
        }
      });

}


$(document).ready(function() {

<?php //if($lesson->moduleno!="") { ?>
  changeRoutes('<?php echo $exercise->moduleno; ?>', '<?php echo $exercise->routeno; ?>')
<?php //} ?>

}); 



function changeLessons(m, r, l)
{

   $('#DivLessonNo').html("loading...");

   $.ajax({
        type:"GET",
        cache:false,
        headers: {
                  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
               },
        url:"/module-route-lesson?name=lesson_no",
        data:{moduleNo:m, routeNo: r, lessonNo: l},    // multiple data sent using ajax
        success: function (html) {

           //console.log( html ); 

           $('#DivLessonNo').html(html);
      
        }
      });

}


$(document).ready(function() {

<?php //if($lesson->moduleno!="") { ?>
    changeLessons('<?php echo $exercise->moduleno; ?>', '<?php echo $exercise->routeno; ?>', '<?php echo $exercise->lesson_no; ?>')
<?php //} ?>

}); 


</script>