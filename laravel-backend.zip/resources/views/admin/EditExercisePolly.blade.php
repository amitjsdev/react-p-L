@include('admin.layouts.mainlayout')

 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Exercises Polly</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Edit Exercises</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
     <section class="content">
      <div class="container-fluid">
      	@if(session()->has('message'))
		    <div class="alert alert-success">
		        {{ session()->get('message') }}
		    </div>
		@endif

        @if(session()->has('error'))
		    <div class="alert alert-danger">
		        {{ session()->get('error') }}
		    </div>
		@endif

 
        


        <div class="row">
           
          <div class="col-md-12 edit-form">
            <div class="card">
               
                
              
              <div class="card-body">
                <div class="table-responsive">

                
                
                <form method="post" action="/save-exercise-polly">
          @csrf
            
          <div class="modal-body">
          
              <div class="form-group">
                 


              <div style="color: #ff0000;">
              <?php /* ?>MP3 Folder: <?php echo storage_path()."/Lesson_Module_Packs/Lesson_".$exercisePolly->moduleno."_".$exercisePolly->routeno."_".$exercisePolly->lesson_no."_Pack/exercises/"; ?> <?php */ ?>
  
</div>

<?php 

//$dir = storage_path()."/Lesson_Module_Packs/Lesson_".$exercisePolly->moduleno."_".$exercisePolly->routeno."_".$exercisePolly->lesson_no."_Pack/exercises/";

/*if (is_writable($dir)) {
        echo '<div style="color: #00ff00;">Above dir is writable.</div>';
    } else {
        echo '<div style="color: #ff0000;">Above dir is not writable. Permissions may have to be adjusted.</div>';
    }*/ 

?>


                   

 
<div class="marginb10"> 
<div class="left">Module No:</div>
<div class="right">

<select name="moduleno" class="form-control" onchange="changeRoutes(this.value);">

<option value="">Select</option>  
  
 
<?php 

 

foreach($modules as $data){  ?>



<option <?php if($data->moduleno==$exercisePolly->moduleno  && strlen($exercisePolly->moduleno)) { ?> selected="selected" <?php } ?> value="<?php echo $data->moduleno; ?>"><?php echo $data->moduleno."-".$data->description; ?></option>




<?php } ?>
 	
</select>    

</div>
</div>


<div style="clear:both">&nbsp;</div>

<div class="left">Route No:</div>
<div class="right">


<div id="DivRouteNo" class="marginb10"> 

<select class="form-control" name="routeno">
<option value="">Select</option>
</select>

 
</div>

</div>

<div style="clear:both">&nbsp;</div>


<div class="marginb10"> 
<div class="left">Lesson No:</div>
<div class="right">

<div id="DivLessonNo" class="marginb10"> 

<select class="form-control" name="routeno">
<option value="">Select</option>
</select>

 
</div>


</div>
</div>


<div style="clear:both">&nbsp;</div>



<div class="marginb10"> 
<div class="left">Exercise No:</div>
<div class="right">
<input type="text" class="form-control" value="{{$exercisePolly->exercise_no}}" name="exercise_no">

</div>
</div>



<div style="clear:both">&nbsp;</div>

 


 <div class="marginb10"> 
<div class="left">Title:</div>
<div class="right"><input type="text" name="title"  class="form-control" value="{{$exercisePolly->title}}" />
</div>
</div>

<div class="clear">&nbsp;</div>




<div class="marginb10"> 
<div class="left">Voice ID / SSML: </div>
<div class="right">

<div><input type="button" id="addScnt" name="addmore" class="btn btn-primary" value="Add More"> <br>  (i.e. SSML &lt;speak&gt;Hello world&lt;/speak&gt;)</div>

<div>
  
&lt;emphasis&gt; PRUEBA &lt;/emphasis&gt;<br>

&lt;say-as interpret-as="value"&gt; PRUEBA &lt;/say-as&gt;<br>

&lt;s&gt; PRUEBA &lt;/s&gt;<br>

&lt;p&gt; PRUEBA &lt;/p&gt;<br>

</div>


<br><br>

<div id="p_scents">

<?php

//echo $exercisePolly->voice_id;

$voice_ids = json_decode($exercisePolly->voice_id, true);


/* get decoded for special chars & lang */
$voice_ssml = base64_decode($exercisePolly->voice_ssml);

//echo $voice_ssml."sandeep";

$voice_ssmls = json_decode($voice_ssml, true);

//print_r($voice_ssmls);

if(is_array($voice_ids))
 $voice_c = count($voice_ids);
else
 $voice_c = 0;

$big_file = "";

if($voice_c==0)
{

?>

<p>	
<input class="form-control" type="text" name="voice_id[]"  class="form-control" value="Joanna" placeholder="Voice ID" required />
&nbsp;<textarea name="voice_ssml[]" class="form-control" rows="10" cols="80" required><speak><amazon:auto-breaths></amazon:auto-breaths><break time="1s"/></speak></textarea>
</p>

<?php
}

for($ivc=0; $ivc < $voice_c; $ivc++)
{
?>	

<p>	

<?php 

//$mp3folder = "http://root.tapclix.com/langappnew/media/polly_audio/".$moduleno."_".$routeno."_".$lesson_no."/exercises/";

///var/www/html/langappnew/media/lesson_packs/Lesson_Module_Packs/Lesson_1_1_61_Pack/exercises
//$mp3folder = "http://root.tapclix.com/langappnew/media/lesson_packs/Lesson_Module_Packs/Lesson_".$exercisePolly->moduleno."_".$exercisePolly->routeno."_".$exercisePolly->lesson_no."_Pack/exercises/";

$mp3Polly = env("S3_MEDIA_LINK");

$mp3folder = $mp3Polly."Lesson_".$exercisePolly->moduleno."_".$exercisePolly->routeno."_".$exercisePolly->lesson_no."_Pack/exercises/";


//$mp3file = $mp3folder.$moduleno."_".$routeno."_".$lesson_no.".".($ivc+1).".mp3";
$mp3file = $mp3folder.$exercisePolly->lesson_no.".".($ivc+1).".mp3";

//$big_file = $mp3folder.$moduleno."_".$routeno."_".$lesson_no.".mp3";
$big_file = $mp3folder.$exercisePolly->lesson_no.".mp3";

?>

<audio controls><source src="<?php echo $mp3file; ?>?r=<?php echo rand(100,600); ?>" type="audio/mpeg">Your browser does not support the audio element.</audio> 

<?php /* ?><a href="<?php echo str_replace(".mp3", ".slow.mp3", $mp3file); ?>?r=<?php echo rand(100,600); ?>" target="_blank">Slow Audio</a>
<br><br><?php */ ?>

<input type="text" name="voice_id[]"  class="form-control" value="<?php echo $voice_ids[$ivc]; ?>" placeholder="Voice ID" required />
&nbsp;<textarea name="voice_ssml[]" class="form-control" rows="10" cols="80" required><?php echo $voice_ssmls[$ivc]; ?></textarea>
<br><a href="javascript:void(0);" onclick="$(this).parents('p').remove();" id="remScnt">Remove</a>
</p>
        

<?php } ?>



</div>






</div>
</div>


<div class="clear">&nbsp;</div>

 <div style="display: none;" class="marginb10"> 
<div class="left">Final MP3:</div>
<div class="right"><audio controls><source src="<?php echo $big_file; ?>?r=<?php echo rand(100,600); ?>" type="audio/mpeg">Your browser does not support the audio element.</audio> <br><br>
</div>
</div>

 

<div class="clear">&nbsp;</div>


<div class="clear"></div>
<div class="margint10"> 
<div class="left">Status:</div>
<div class="right">

<?php $status = $exercisePolly->status; ?>

 <select class="form-control" name="status">
   <option value="1" <?php if (isset($status) && $status==1){echo " selected ";}?>>Active</option>
   <option value="0" <?php if (isset($status) && $status==0){echo " selected ";}?>>Deactive</option>
 </select></div>
</div>
<div class="clear"></div>


 

<div style="clear:both">&nbsp;</div>


<input type="hidden" name="id" value="{{$exercisePolly->id}}" />


 
          <div class="modal-footer">
            <button type="submit" class="btn btn-primary">Save</button>
          </div>

        </div>
      </div>

        </form>  


        <a name="focusMe" id="focusMe"></a>


              </div>
              </div>






           
            </div>
            <!-- /.card -->

        
            <!-- /.card -->
          </div>
           
       
        </div>
        <!-- /.row -->
   
   
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>

 

	 
    <!-- /.content -->
  </div>

  @include('admin.layouts.partials.footer')


  <script type="text/javascript">


function changeRoutes(m, r)
{

   $('#DivRouteNo').html("loading...");

   $.ajax({
        type:"GET",
        cache:false,
        headers: {
                  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
               },
        url:"/module-route?name=routeno",
        data:{moduleNo:m, routeNo: r},    // multiple data sent using ajax
        success: function (html) {

           //console.log( html ); 

           $('#DivRouteNo').html(html);
      
        }
      });

}


$(document).ready(function() {

<?php //if($lesson->moduleno!="") { ?>
  changeRoutes('<?php echo $exercisePolly->moduleno; ?>', '<?php echo $exercisePolly->routeno; ?>')
<?php //} ?>

}); 



function changeLessons(m, r, l)
{

   $('#DivLessonNo').html("loading...");

   $.ajax({
        type:"GET",
        cache:false,
        headers: {
                  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
               },
        url:"/module-route-lesson?name=lesson_no",
        data:{moduleNo:m, routeNo: r, lessonNo: l},    // multiple data sent using ajax
        success: function (html) {

           //console.log( html ); 

           $('#DivLessonNo').html(html);
      
        }
      });

}


$(document).ready(function() {

<?php //if($lesson->moduleno!="") { ?>
    changeLessons('<?php echo $exercisePolly->moduleno; ?>', '<?php echo $exercisePolly->routeno; ?>', '<?php echo $exercisePolly->lesson_no; ?>')
<?php //} ?>

}); 



$(document).ready(function() { 
        var scntDiv = $('#p_scents');
        var i = $('#p_scents p').length + 1;
        
        $('#addScnt').bind('click', function() {
                $('<p><label for="p_scnts"><input type="text" name="voice_id[]" style="width: 100% !important; max-width: 100% !important;"  class="form-control" value="Joanna" placeholder="Voice ID" required />&nbsp;<textarea name="voice_ssml[]" style="width: 100% !important; max-width: 100% !important;" class="form-control" rows="10" cols="80"  required><speak><amazon:auto-breaths></amazon:auto-breaths><break time="1s"/></speak></textarea></label> <br> <a href="javascript:void(0);" onclick="$(this).parents(`p`).remove();" id="remScnt">Remove</a></p>').appendTo(scntDiv);
                //i++;
                
                //$("#p-"+i).focus();

                document.getElementById('focusMe').scrollIntoView(true);

                //$("html, body").animate({ scrollBottom: 0 }, "slow");

                return false;
        });
        
        /*$( "#remScnt" ).click(function() {   alert("test"+i);
                if( i > 2 ) {
                        $(this).parents('p').remove();
                        i--;
                }
                return false;
        });*/
});


</script>