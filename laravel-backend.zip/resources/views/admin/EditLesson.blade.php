@include('admin.layouts.mainlayout')

 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Lessons</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Edit Lesson</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
     <section class="content">
      <div class="container-fluid">
      	@if(session()->has('message'))
		    <div class="alert alert-success">
		        {{ session()->get('message') }}
		    </div>
		@endif

        @if(session()->has('error'))
		    <div class="alert alert-danger">
		        {{ session()->get('error') }}
		    </div>
		@endif

 
        


        <div class="row">
           
          <div class="col-md-12 edit-form">
            <div class="card">
               
                
              
              <div class="card-body">
                <div class="table-responsive">
                
                <form method="post" action="/save-lesson">
          @csrf
            
          <div class="modal-body">
          
              <div class="form-group">
                 


              <?php  

$dialog_C = count(explode("\n", $lesson->dialog));
$dialog_trans_C = count(explode("\n", $lesson->dialog_translation));
$audio_C = count(explode("\n", $lesson->audio)); 

$audio_tmp = explode("\n", $lesson->audio);

$lessonStr = 0;


//Match lesson number in Media MP3
$searchString = $lesson->lesson_no.".";

foreach ($audio_tmp as $key => $value) {

if( strstr($value, $searchString) !== false ) {
   $lessonStr = 1;
}
else
{
   $lessonStr = 0;
   break;   
}

}

if($dialog_C==$dialog_trans_C && $dialog_trans_C==$audio_C && $dialog_C==$audio_C)
{

    echo '<div style="color: #00ff00;">';
    echo "Dialog: (".$dialog_C.")  "; echo "Dialog Translation: (".$dialog_trans_C.")  "; echo "Audio: (".$audio_C.")  <br>";
    echo '</div>';

    echo '<br><br>';
}
else  
{

?>
<div style="color: #ff0000;">Array size for Dialog, Dialog Translation and Audio fields doesn't match
<br>

<?php echo "Dialog: (".$dialog_C.")  "; echo "Dialog Translation: (".$dialog_trans_C.")  "; echo "Audio: (".$audio_C.")  <br>";  ?>


</div>

<br><br>

<?php } ?>


<div style="color: #ff0000;">
<?php if($lessonStr==0) echo "Audio have a number that doesn't match the lesson number<br><br>";  ?>
</div>



 <div class="marginb10"> 
<div class="left">Title:</div>
<div class="right"><input class="form-control" type="text" name="title" value="{{$lesson->title}}" />
</div>
</div>

<div style="clear:both">&nbsp;</div>


<?php //echo $moduleno; ?>
<div class="marginb10"> 
<div class="left">Module No:</div>
<div class="right">
<select name="moduleno" class="form-control" onchange="changeRoutes(this.value);">
<option value="">Select</option>
<?php 
foreach($modules as $data){  ?>
<option value="<?php echo $data->moduleno;?>" <?php if($lesson->moduleno==$data->moduleno && strlen($lesson->moduleno)) { ?> selected="selected" <?php } ?>><?php echo $data->moduleno.". ".$data->description;?></option>
<?php }?>
</select>	
</div>
</div>


<div style="clear:both">&nbsp;</div>


<div class="left">Route No:</div>
<div class="right">


<div id="DivRouteNo" class="marginb10"> 

<select class="form-control" name="routeno">
<option value="">Select</option>
</select>

 
</div>

</div>

<div style="clear:both">&nbsp;</div>


 <div class="marginb10"> 
<div class="left">Lesson Type:</div>
<div class="right"><input type="text" class="form-control" name="lesson_type" value="{{$lesson->lesson_type}}" />
</div>
</div>


<div style="clear:both">&nbsp;</div>


<div class="marginb10"> 
<div class="left">Lesson No:</div>
<div class="right"><input type="text" class="form-control" name="lesson_no" value="{{$lesson->lesson_no}}" />
</div>
</div>

<div style="clear:both">&nbsp;</div>


<div class="marginb10"> 
<div class="left">Level No:</div>
<div class="right"><input type="text" class="form-control" name="level_no" value="{{$lesson->level_no}}" />
</div>
</div>

<div style="clear:both">&nbsp;</div>


<div class="marginb10"> 
<div class="left">Virtual Module Number:</div>
<div class="right"><input type="text" class="form-control" name="virtualModule" value="{{$lesson->virtualModule}}" />
</div>
</div>

<div style="clear:both">&nbsp;</div>

<div class="marginb10"> 
<div class="left">Virtual Route Number:</div>
<div class="right"><input type="text" class="form-control" name="virtualRoute" value="{{$lesson->virtualRoute}}" />
</div>
</div>

<div style="clear:both">&nbsp;</div>


<div class="marginb10"> 
<div class="left">Virtual Lesson Number:</div>
<div class="right"><input type="text" class="form-control" name="virtualLesson" value="{{$lesson->virtualLesson}}" />
</div>
</div>

<div style="clear:both">&nbsp;</div>



<div class="marginb10"> 
<div class="left">Virtual Lesson Flag:</div>
<div class="right">

<select class="form-control" name="virtualLessonFlag">

<option value="N" <?php if($lesson->virtualLessonFlag=="N"){ ?> selected<?php } ?>>No</option>
<option value="Y" <?php if($lesson->virtualLessonFlag=="Y"){ ?> selected<?php } ?>>Yes</option>

</select>

</div>
</div>

<div style="clear:both">&nbsp;</div>

<!-- 
<div class="marginb10"> 
<div class="left">examLevel:</div>
<div class="right">

<select class="form-control" name="examLevel">

<option value="N" <?php if($lesson->examLevel=="N"){ ?> selected<?php } ?>>No</option>
<option value="Y" <?php if($lesson->examLevel=="Y"){ ?> selected<?php } ?>>Yes</option>

</select>

</div>
</div>

<div style="clear:both">&nbsp;</div> -->

<!-- 
<div class="marginb10"> 
<div class="left">holidayWeek:</div>
<div class="right">

<select class="form-control" name="holidayWeek">

<option value="N" <?php if($lesson->holidayWeek=="N"){ ?> selected<?php } ?>>No</option>
<option value="Y" <?php if($lesson->holidayWeek=="Y"){ ?> selected<?php } ?>>Yes</option>

</select>

</div>
</div>

<div style="clear:both">&nbsp;</div> -->


<div class="marginb10"> 
<div class="left">Description:</div>
<div class="right"><textarea class="form-control" name="description" rows="15" cols="30">{{$lesson->description}}</textarea>
</div>
</div>

<div style="clear:both">&nbsp;</div>

<div class="marginb10"> 
<div class="left">Long Description:</div>
<div class="right"><textarea class="form-control" name="long_description" rows="15" cols="60">{{$lesson->long_description}}</textarea>
</div>
</div>

<div style="clear:both">&nbsp;</div>


<!-- <div class="marginb10"> 
<div class="left">Lesson Image:</div>
<div class="right"><input type="text" class="form-control" name="lesson_image" value="{{$lesson->lesson_image}}" />
</div>
</div> -->


<!-- <div style="clear:both">&nbsp;</div> -->

<!-- 
<div class="marginb10"> 
<div class="left">reviewLesson:</div>
<div class="right">

<select class="form-control" name="reviewLesson">

<option value="N" <?php if($lesson->reviewLesson=="N"){ ?> selected<?php } ?>>No</option>
<option value="Y" <?php if($lesson->reviewLesson=="Y"){ ?> selected<?php } ?>>Yes</option>

</select>

</div>
</div>




<div style="clear:both">&nbsp;</div> -->


<div class="marginb10"> 
<div class="left">Pre Lesson:</div>
<div class="right">

<textarea class="form-control" name="pre_lesson" rows="10" cols="80">{{$lesson->pre_lesson}}</textarea>


</div>
</div>

<div style="clear:both">&nbsp;</div>




<div class="marginb10"> 
<div class="left">Video English:</div>
<div class="right">

<textarea class="form-control" name="video_english" rows="10" cols="80">{{$lesson->video_english}}</textarea>


</div>
</div>



<div class="marginb10"> 
<div class="left">Pre Dialog Message:</div>
<div class="right">

<textarea class="form-control" name="pre_dialog_msg" rows="10" cols="80">{{$lesson->pre_dialog_msg}}</textarea>


</div>
</div>

<div style="clear:both">&nbsp;</div>


<div class="marginb10"> 
<div class="left">Pre Video Message:</div>
<div class="right">

<textarea class="form-control" name="pre_video_msg" rows="10" cols="80">{{$lesson->pre_video_msg}}</textarea>


</div>
</div>

<div style="clear:both">&nbsp;</div>


<div class="marginb10"> 
<div class="left">Pre Exercise:</div>
<div class="right">

<textarea class="form-control" name="pre_exercise" rows="10" cols="80">{{$lesson->pre_exercise}}</textarea>


</div>
</div>

<div style="clear:both">&nbsp;</div>



<div class="marginb10"> 
<div class="left">Dictionary Translation: (New Line New Entry)</div>
<div class="right">

<textarea class="form-control" name="video" rows="10" cols="80">{{$lesson->video}}</textarea>


</div>
</div>

<div style="clear:both">&nbsp;</div>

<!---- 5 fields -------------->

<div class="marginb10"> 
<div class="left">Speakers: </div>
<div class="right">

<textarea class="form-control" name="speakers" rows="10" cols="80">{{$lesson->speakers}}</textarea>


</div>
</div>


<div style="clear:both">&nbsp;</div>
<!-- 
<div class="marginb10"> 
<div class="left">Video English: </div>
<div class="right">

<textarea class="form-control" name="video_english" rows="10" cols="80">{{$lesson->video_english}}</textarea>


</div>
</div>

<div style="clear:both">&nbsp;</div>

<div class="marginb10"> 
<div class="left">Video Spanish: </div>
<div class="right">

<textarea class="form-control" name="video_spanish" rows="10" cols="80">{{$lesson->video_spanish}}</textarea>


</div>
</div>

<div style="clear:both">&nbsp;</div>

<div class="marginb10"> 
<div class="left">Video English Subtitles: </div>
<div class="right">

<textarea class="form-control" name="video_english_subtitles" rows="10" cols="80">{{$lesson->video_english_subtitles}}</textarea>


</div>
</div>

<div style="clear:both">&nbsp;</div>

<div class="marginb10"> 
<div class="left">Video Spanish Subtitles: </div>
<div class="right">

<textarea class="form-control" name="video_spanish_subtitles" rows="10" cols="80">{{$lesson->video_spanish_subtitles}}</textarea>


</div>
</div>

<div style="clear:both">&nbsp;</div> -->

<!---- 5 fields -------------->



<div class="marginb10"> 
  <div class="left">Speaker Gender:</div>
    <div class="right">
      <input type="text" name="speaker_gender" class="form-control" value="{{$lesson->speaker_gender}}">
  </div>
</div>

<div style="clear:both">&nbsp;</div>





<div class="marginb10"> 
<div class="left">Interactive Listen: (New Line New Entry)</div>
<div class="right">

<textarea class="form-control" name="image" rows="10" cols="80">{{$lesson->image}}</textarea>


</div>
</div>


<div class="marginb10"> 
  <div class="left">Is a challenge:</div>
    <div class="right">
      <select name="is_challenge" id="" class="form-control">
        <option value="0" {{$lesson->is_challenge ? "" : "selected"}}>No</option>
        <option value="1" {{$lesson->is_challenge ? "selected" : ""}}>Yes</option>
      </select>
  </div>
</div>

<div style="clear:both">&nbsp;</div>


<div class="marginb10"> 
  <div class="left">Challenge Type (only used when Is Challenge is selected as yes):</div>
    <div class="right">
      <input type="text" class="form-control" name="challenge_type" value="{{$lesson->challenge_type}}" />
  </div>
</div>

<div style="clear:both">&nbsp;</div>

<div class="marginb10"> 
<div class="left">Dialog: (New Line New Entry)</div>
<div class="right">

<textarea class="form-control" name="dialog" rows="10" cols="80">{{$lesson->dialog}}</textarea>


</div>
</div>

<div style="clear:both">&nbsp;</div>

<div class="marginb10"> 
<div class="left">Dialog Translation: (New Line New Entry)</div>
<div class="right">

<textarea class="form-control" name="dialog_translation" rows="10" cols="80">{{$lesson->dialog_translation}}</textarea>


</div>
</div>

<div style="clear:both">&nbsp;</div>



<div class="marginb10"> 
<div class="left">Video English:</div>
<div class="right">

<textarea class="form-control" name="video_english" rows="10" cols="80">{{$lesson->video_english}}</textarea>


</div>
</div>

<div style="clear:both">&nbsp;</div>

<div class="marginb10"> 
<div class="left">Dialog Extra Info: (New Line New Entry)</div>
<div class="right">

<textarea class="form-control" name="dialog_extra_info" rows="10" cols="80">{{$lesson->dialog_extra_info}}</textarea>


</div>
</div>

<div style="clear:both">&nbsp;</div>




<div class="marginb10"> 
<div class="left">Audio: (New Line New Entry)</div>
<div class="right">

<textarea class="form-control" name="audio" rows="10" cols="80">{{$lesson->audio}}</textarea>


</div>
</div>



<div style="clear:both">&nbsp;</div>




<!-- 

<div class="margint10"> 
<div class="left">Status:</div>
<div class="right">
 <select class="status form-control" name="status">
   <option value="1" <?php if (isset($lesson->status) && $lesson->status==1){echo " selected ";}?>>Active</option>
   <option value="0" <?php if (isset($lesson->status) && $lesson->status==0){echo " selected ";}?>>Deactive</option>
 </select></div>
</div>

<div style="clear:both">&nbsp;</div> -->


<div class="margint10"> 
<div class="left">Has Dialogs:</div>
<div class="right">
 <select class="status form-control" name="has_dialogs">
   <option value="1" <?php if (isset($lesson->has_dialogs) && $lesson->has_dialogs==1){echo " selected ";}?>>yes</option>
   <option value="0" <?php if (isset($lesson->has_dialogs) && $lesson->has_dialogs==0){echo " selected ";}?>>No</option>
 </select></div>
</div>

<div style="clear:both">&nbsp;</div>

<div class="margint10"> 
<div class="left">Status:</div>
<div class="right">
 <select class="status form-control" name="status">
   <option value="1" <?php if (isset($lesson->status) && $lesson->status==1){echo " selected ";}?>>Active</option>
   <option value="0" <?php if (isset($lesson->status) && $lesson->status==0){echo " selected ";}?>>Inactive</option>
 </select></div>
</div>

<div style="clear:both">&nbsp;</div>


<div class="clear"></div>

<div class="clear"></div>

<input type="hidden" value="{{$lesson->id}}" name="id" />


                    


                

             
              </div>
 
          <div class="modal-footer">
            <button type="submit" class="btn btn-primary">Save</button>
          </div>

        </div>
      </div>

        </form>  


              </div>
              </div>






           
            </div>
            <!-- /.card -->

        
            <!-- /.card -->
          </div>
           
       
        </div>
        <!-- /.row -->
   
   
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>

 

	 
    <!-- /.content -->
  </div>

  @include('admin.layouts.partials.footer')


<script>


function changeRoutes(m, r)
{

   $('#DivRouteNo').html("loading...");

   $.ajax({
        type:"GET",
        cache:false,
        headers: {
                  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
               },
        url:"/module-route",
        data:{moduleNo:m, routeNo: r},    // multiple data sent using ajax
        success: function (html) {

           //console.log( html ); 

           $('#DivRouteNo').html(html);
      
        }
      });

}


$(document).ready(function() {

<?php //if($lesson->moduleno!="") { ?>
  changeRoutes('<?php echo $lesson->moduleno; ?>', '<?php echo $lesson->routeno; ?>')
<?php //} ?>

}); 
  


</script>