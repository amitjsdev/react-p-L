@include('admin.layouts.mainlayout')

 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Modules</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Edit Modules</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
     <section class="content">
      <div class="container-fluid">
      	@if(session()->has('message'))
		    <div class="alert alert-success">
		        {{ session()->get('message') }}
		    </div>
		@endif

        @if(session()->has('error'))
		    <div class="alert alert-danger">
		        {{ session()->get('error') }}
		    </div>
		@endif

 
        


        <div class="row">
           
          <div class="col-md-12 edit-form">
            <div class="card">
               
                
              
              <div class="card-body">
                <div class="table-responsive">
                
                <form method="post" action="/save-module">
          @csrf
            
          <div class="modal-body">
          
              <div class="form-group">
                 

                   

           
              <div class="marginb10"> 
<div class="left">Module No:</div>
<div class="right"><input type="text" name="moduleno" class="form-control" value="{{$module->moduleno}}" />
</div>
</div>


<div style="clear:both">&nbsp;</div>


 <div class="marginb10"> 
<div class="left">Module Level:</div>
<div class="right">

<?php $module_level = $module->module_level; ?>

<select class="form-control" name="module_level">
   <option value="" <?php if (isset($module_level) && $module_level==""){echo " selected ";}?>>Select</option>
   <option value="1" <?php if (isset($module_level) && $module_level=="1"){echo " selected ";}?>>1</option>
   <option value="2" <?php if (isset($module_level) && $module_level=="2"){echo " selected ";}?>>2</option>
   <option value="3" <?php if (isset($module_level) && $module_level=="3"){echo " selected ";}?>>3</option>
 </select>


</div>
</div>

<div style="clear:both">&nbsp;</div>

           
 <div class="marginb10"> 
<div class="left">Module Type:</div>
<div class="right">

<?php $module_type = $module->module_type; ?>

  <select class="form-control" name="module_type">
   <option value="" <?php if (isset($module_type) && $module_type==""){echo " selected ";}?>>Select</option>
   <option value="GC" <?php if (isset($module_type) && $module_type=="GC"){echo " selected ";}?>>General Course</option>
   <option value="SC" <?php if (isset($module_type) && $module_type=="SC"){echo " selected ";}?>>Skills Course</option>
   <option value="DC" <?php if (isset($module_type) && $module_type=="DC"){echo " selected ";}?>>Department Course</option>
   <option value="IC" <?php if (isset($module_type) && $module_type=="IC"){echo " selected ";}?>>Industry Course</option>
   <option value="TC" <?php if (isset($module_type) && $module_type=="TC"){echo " selected ";}?>>Tourism Course</option>
 </select>

 

</div>
</div>

<div style="clear:both">&nbsp;</div>




           
 <div class="marginb10"> 
<div class="left">Module Tags:</div>
<div class="right"><input type="text" name="module_tags" class="form-control"  value="{{$module->module_tags}}" />
</div>
</div>


<div style="display: none;" class="marginb10"> 
<div class="left">Module Image:</div>
<div class="right"><input type="text" name="module_image" class="form-control"  value="{{$module->module_image}}" />
</div>
</div>


<div style="clear:both">&nbsp;</div>

<div class="marginb10"> 
  <div class="left">Single Speaker:</div>
  <div class="right">
    <input type="text" name="single_speaker" class="form-control"  value="{{$module->single_speaker}}" />
  </div>
</div>


<div style="clear:both">&nbsp;</div>

<div class="marginb10"> 
<div class="left">Description:</div>
<div class="right"><textarea class="form-control" name="description" rows="5" cols="40">{{$module->description}}</textarea>
</div>
</div>

<div style="clear:both">&nbsp;</div>

<div class="marginb10"> 
<div class="left">Long Description:</div>
<div class="right"><textarea class="form-control" name="long_description" rows="5" cols="40">{{$module->long_description}}</textarea>
</div>
</div>


<div style="clear:both">&nbsp;</div>

<div class="marginb10"> 
<div class="left">module Detail Information:</div>
<div class="right"><input type="text" name="moduleDetailInformation" class="form-control" value="{{$module->moduleDetailInformation}}" />
</div>
</div>


<div style="clear:both">&nbsp;</div>


<?php /*?>Español, Portuguese, German, French<?php */?>

<div class="clear"></div>
<div class="margint10"> 
<div class="left">From Language:</div>
<div class="right">

<?php $language = $module->language; ?>

 <select class="form-control" name="language">
   <option value="EN" <?php if (isset($language) && $language=="EN"){echo " selected ";}?>>English</option>
   <option value="ES" <?php if (isset($language) && $language=="ES"){echo " selected ";}?>>Español</option>
   <option value="PT" <?php if (isset($language) && $language=="PT"){echo " selected ";}?>>Portuguese</option>
   <option value="DE" <?php if (isset($language) && $language=="DE"){echo " selected ";}?>>German</option>
   <option value="FR" <?php if (isset($language) && $language=="FR"){echo " selected ";}?>>French</option>
   <option value="CH" <?php if (isset($language) && $language=="CH"){echo " selected ";}?>>China</option>
 </select></div>
</div>


<div style="clear:both">&nbsp;</div>

<div class="margint10"> 
<div class="left">To Language:</div>
<div class="right">

<?php $tolanguage = $module->tolanguage; ?>

 <select class="form-control" name="tolanguage">
   <option value="EN" <?php if (isset($tolanguage) && $tolanguage=="EN"){echo " selected ";}?>>English</option>
   <option value="ES" <?php if (isset($tolanguage) && $tolanguage=="ES"){echo " selected ";}?>>Español</option>
   <option value="PT" <?php if (isset($tolanguage) && $tolanguage=="PT"){echo " selected ";}?>>Portuguese</option>
   <option value="DE" <?php if (isset($tolanguage) && $tolanguage=="DE"){echo " selected ";}?>>German</option>
   <option value="FR" <?php if (isset($tolanguage) && $tolanguage=="FR"){echo " selected ";}?>>French</option>
   <option value="CH" <?php if (isset($tolanguage) && $tolanguage=="CH"){echo " selected ";}?>>China</option>
   <option value="IT" <?php if (isset($tolanguage) && $tolanguage=="ITA"){echo " selected ";}?>>Italian</option>

 </select></div>
</div>


<div style="clear:both">&nbsp;</div>

<div class="margint10"> 
<div class="left">Status:</div>
<div class="right">

<?php $status = $module->status; ?>

 <select class="form-control" name="status">
   <option value="1" <?php if (isset($status) && $status==1){echo " selected ";}?>>Active</option>
   <option value="0" <?php if (isset($status) && $status==0){echo " selected ";}?>>Deactive</option>
 </select></div>
</div>


<div style="clear:both">&nbsp;</div>


<div class="margint10"> 
<div class="left">Lite Zip Flag:</div>
<div class="right">

<?php $lite_zip_flag = $module->lite_zip_flag; ?>

 <select class="form-control" name="lite_zip_flag">
   
   <option value="Y" <?php if (isset($lite_zip_flag) && $lite_zip_flag=="Y"){echo " selected ";}?>>YES</option>
   <option value="N" <?php if (isset($lite_zip_flag) && $lite_zip_flag=="N"){echo " selected ";}?>>NO</option>
   
 </select></div>
</div>

<div class="marginb10"> 
<div class="left">Category Ranking:</div>
<div class="right"><input type="text" name="categoryRanking" class="form-control" value="{{$module->categoryRanking}}" />
</div>
</div>



<div style="clear:both">&nbsp;</div>

<div class="marginb10"> 
<div class="left">Presentation Module:</div>

<div class="right">
   <select class="form-control" name="presentationModule">
   
   <option value="1" <?php if ($module->presentationModule){echo " selected ";}?>>YES</option>
   <option value="0" <?php if (!$module->presentationModule){echo " selected ";}?>>NO</option>
   
 </select>
</div>
</div>



<div style="clear:both">&nbsp;</div>



<input type="hidden" name="id" value="{{$module->id}}" />


 
          <div class="modal-footer">
            <button type="submit" class="btn btn-primary">Save</button>
          </div>

        </div>
      </div>

        </form>  


              </div>
              </div>






           
            </div>
            <!-- /.card -->

        
            <!-- /.card -->
          </div>
           
       
        </div>
        <!-- /.row -->
   
   
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>

 

	 
    <!-- /.content -->
  </div>

  @include('admin.layouts.partials.footer')


<script>    


</script>