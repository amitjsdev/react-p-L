@include('admin.layouts.mainlayout')

 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Profile</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Edit Profile</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
     <section class="content">
      <div class="container-fluid">
      	@if(session()->has('message'))
		    <div class="alert alert-success">
		        {{ session()->get('message') }}
		    </div>
		@endif

        @if(session()->has('error'))
		    <div class="alert alert-danger">
		        {{ session()->get('error') }}
		    </div>
		@endif

 
        


        <div class="row">
           
          <div class="col-md-12 edit-form">
            <div class="card">
               
                
              
              <div class="card-body">
                <div class="table-responsive">
                
                <form method="post" action="/edit-profile">
          @csrf
            
          <div class="modal-body">
          
              <div class="form-group">
                 



<div style="clear:both">&nbsp;</div>

 <div class="marginb10"> 
<div class="left">Username:</div>
<div class="right"><input type="text" name="username" class="form-control" value="admin" />
</div>
</div>

<div style="clear:both">&nbsp;</div>

 

 <div class="marginb10" style="padding-top:10px; padding-bottom:10px;"> 
<div class="left">Old Password:</div>
<div class="right"><input type="password" name="old_password" class="form-control" value="" />
</div>
</div>

<div style="clear:both">&nbsp;</div>

<div class="marginb10" style="padding-top:10px; padding-bottom:10px;"> 
<div class="left">New Password:</div>
<div class="right"><input type="password" name="new_password" class="form-control" value="" />
</div>
</div>


 

 
          <div class="modal-footer">
            <button type="submit" class="btn btn-primary">Save</button>
          </div>

        </div>
      </div>

        </form>  


              </div>
              </div>






           
            </div>
            <!-- /.card -->

        
            <!-- /.card -->
          </div>
           
       
        </div>
        <!-- /.row -->
   
   
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>

 

	 
    <!-- /.content -->
  </div>

  @include('admin.layouts.partials.footer')


<script>    


</script>