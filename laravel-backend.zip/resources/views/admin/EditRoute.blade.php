@include('admin.layouts.mainlayout')

 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Routes</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Edit Routes</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
     <section class="content">
      <div class="container-fluid">
      	@if(session()->has('message'))
		    <div class="alert alert-success">
		        {{ session()->get('message') }}
		    </div>
		@endif

        @if(session()->has('error'))
		    <div class="alert alert-danger">
		        {{ session()->get('error') }}
		    </div>
		@endif

 
        


        <div class="row">
           
          <div class="col-md-12 edit-form">
            <div class="card">
               
                
              
              <div class="card-body">
                <div class="table-responsive">
                
                <form method="post" action="/save-route">
          @csrf
            
          <div class="modal-body">
          
              <div class="form-group">
                 

Route Exercise Count:  <?php if(@$RouteExerciseCount[0]->cnt) echo @$RouteExerciseCount[0]->cnt; else echo "0"; ?>
                   


              <div class="marginb10"> 
<div class="left">Module No: </div>
<div class="right">
<select name="moduleno" class="form-control">
<option value="">Select</option>
<?php 
foreach($modules as $data){  ?>
<option value="<?php echo $data->moduleno;?>" <?php if($route->moduleno==$data->moduleno && strlen($route->moduleno)) { ?> selected="selected" <?php } ?>><?php echo $data->moduleno.". ".$data->description;?></option>
<?php }?>
</select>		
</div>
</div>


<div style="clear:both">&nbsp;</div>
   
           
 <div class="marginb10"> 
<div class="left">Route No:</div>
<div class="right"><input type="text" name="routeno" class="form-control" value="{{$route->routeno}}" />
</div>
</div>


 
<div style="clear:both">&nbsp;</div>




<div class="marginb10"> 
<div class="left">Description:</div>
<div class="right"><textarea name="description" class="form-control" rows="5" cols="40">{{$route->description}}</textarea>
</div>

</div>

<div style="clear:both">&nbsp;</div>

<div class="marginb10"> 
<div class="left">Long Description:</div>
<div class="right"><textarea name="long_description" class="form-control" rows="5" cols="40">{{$route->long_description}}</textarea>
</div>
</div>

<div style="clear:both">&nbsp;</div>

 <div class="marginb10"> 
<div class="left">numberofHours:</div>
<div class="right"><input type="text" name="numberofHours" class="form-control" value="{{$route->numberofHours}}" />
</div>
</div>

<div style="clear:both">&nbsp;</div>

 <div class="marginb10"> 
<div class="left">numberofPoints: (% of completion for each week)</div>
<div class="right"><input type="text" name="numberofPoints" class="form-control" value="{{$route->numberofPoints}}" /> 
</div>
</div>

<div style="clear:both">&nbsp;</div>

 <div class="marginb10" style="padding-top:10px; padding-bottom:10px;"> 
<div class="left">Min. Points:</div>
<div class="right"><input type="text" name="min_points" class="form-control" value="{{$route->min_points}}" />
</div>
</div>



<div style="clear:both">&nbsp;</div>

 <div class="marginb10" style="padding-top:10px; padding-bottom:10px;"> 
<div class="left">Route Email:</div>
<div class="right">



<textarea  id="routeEmail" class="form-control" name="routeEmail" style="width: 100%; height: 300px;">{{$route->routeEmail}}</textarea>



</div>
</div>




<div style="clear:both">&nbsp;</div>

<div class="margint10"> 
<div class="left">Status:</div>
<div class="right">

<?php $status = $route->status; ?>

 <select class="form-control" name="status">
   <option value="1" <?php if (isset($status) && $status==1){echo " selected ";}?>>Active</option>
   <option value="0" <?php if (isset($status) && $status==0){echo " selected ";}?>>Deactive</option>
 </select></div>
</div>


<div style="clear:both">&nbsp;</div>        
              




<input type="hidden" name="id" value="{{$route->id}}" />


 
          <div class="modal-footer">
            <button type="submit" class="btn btn-primary">Save</button>
          </div>

        </div>
      </div>

        </form>  


              </div>
              </div>






           
            </div>
            <!-- /.card -->

        
            <!-- /.card -->
          </div>
           
       
        </div>
        <!-- /.row -->
   
   
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>

 

	 
    <!-- /.content -->
  </div>

  @include('admin.layouts.partials.footer')


<script>    


</script>