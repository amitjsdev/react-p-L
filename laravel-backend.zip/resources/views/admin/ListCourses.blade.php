@include('admin.layouts.mainlayout')

 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Courses</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Courses</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
     <section class="content">
      <div class="container-fluid">
      	@if(session()->has('message'))
		    <div class="alert alert-success">
		        {{ session()->get('message') }}
		    </div>
		@endif

        


        <div class="row">
           
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                
              Show: <select name="pageSize" onchange="pageSizeChange(this);">

               <option value="10" <?php if( $pageSize==10 ) { ?> selected="selected" <?php } ?> >10</option>
               <option value="25" <?php if( $pageSize==25 ) { ?> selected="selected" <?php } ?>>25</option>
               <option value="50" <?php if( $pageSize==50 ) { ?> selected="selected" <?php } ?>>50</option>
               <option value="100" <?php if( $pageSize==100 ) { ?> selected="selected" <?php } ?>>100</option>

              </select> 

          

                <div align="center">

                <form> 


                <input type="text" name="moduleNo" id="moduleNo" placeholder="moduleNo" style="width:80px;" value="{{ app('request')->input('moduleNo') }}" /> 

                <select name="companyCode" onchange="switchCompany(this);">


                <option value="">Company</option>

                <?php 


                foreach($companies as $cmp) {  ?>

                <option <?php if( app('request')->input('companyCode')!="" && $cmp->Id==app('request')->input('companyCode')) { ?> selected="selected" <?php } ?> value="<?php echo $cmp->Id; ?>"><?php echo $cmp->Id; ?> - <?php echo $cmp->Name; ?></option>


                <?php } ?>

                </select>

                <select name="batchNo" onchange="checkUncheckBatch(this);">

                <option value="">Batch</option>

                <?php for($bb=1;$bb<=10;$bb++) { ?>
                <option value="<?php echo $bb; ?>" <?php if($bb==app('request')->input('batchNo')) echo 'selected="selected"'; ?>><?php echo $bb; ?></option>
                <?php } ?>

                </select> 

                
                 <input type="text" name="query" placeholder="Search"  value="{{ app('request')->input('query') }}" />

                 <select class="status" name="status">
                   <option value="">Status</option>
                   <option value="1" <?php if(app('request')->input('status')==1){echo " selected ";}?>>Active</option>
                   <option value="0" <?php if(app('request')->input('status')==0  && strlen(app('request')->input('status'))){echo " selected ";}?>>Deactive</option>
                 </select>

                 <input type="hidden" name="pageSize" value="{{ app('request')->input('pageSize') }}" />

                 <input type="submit" class="btn btn-primary" name="go" value="Go" />


                </form>

                </div>


                <a href="/add-course"><button type="button" class="btn btn-primary" style="float: right;">Add Course</button></a>

              </div>
              <!-- /.card-header -->
              
              <div class="card-body">
                <div class="table-responsive">
                <table class="table table-bordered  tablesorter sortable">
                  <thead>                  
                    <tr>
                      <th style="width: 10px">#</th>
                      <th>Name</th>
                      <th>CourseNo</th>
                      <th>ModuleNo</th>
                      <th>BatchNo</th>
                      <th>Company</th>
                      <th>StartDate</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>

                  	   
                   @foreach($courses as $item => $value)
                      <tr>
                        <td>{{$value->i_d}}</td>
                        <td><a href="/edit-course?id={{$value->i_d}}">{{$value->courseName}}</a></td>
                        <td>{{$value->courseNumber}}</td>
                        <td>{{$value->moduleNumber}}</td>
                        <td>{{$value->courseBatch}}</td>
                        <td>{{$value->Company}}</td>
                        <td>{{$value->courseStartDate}}</td>
                        <td>{{$value->Status}}</td>
                        <td>
                            
                            <a href="/edit-course?id={{$value->i_d}}"><i class="fas fa-edit" style="cursor: pointer;"></i></a>
                            <a href="/delete-course?id={{$value->i_d}}" onclick="return confirm('Are you sure?');"><i class="fas fa-trash" style="cursor: pointer;"></i></a>

                        </td>
                      </tr>
                   @endforeach  
                  </tbody>
                </table>
              </div>
              </div>


{{$courses->appends(request()->query())->links()}}   


<!--<div>Showing {{($courses->currentpage()-1)*$courses->perpage()+1}} to {{$courses->currentpage()*$courses->perpage()}} of  {{$courses->total()}} entries </div>-->

<div style="padding-left: 20px; font-weight: bold;">Showing {{ $courses->firstItem() }} to {{ $courses->lastItem() }} of total {{$courses->total()}} entries</div>
<div style="clear: both;">&nbsp;</div>


           
            </div>
            <!-- /.card -->

        
            <!-- /.card -->
          </div>
           
       
        </div>
        <!-- /.row -->
   
   
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>

    



	 



    <!-- /.content -->
  </div>

  @include('admin.layouts.partials.footer')


<script>
    
function switchCompany(v)
{

  var val = $(v).val();

  location.href="/courses?batchNo=<?php echo app('request')->input('batchNo'); ?>&companyCode="+val+"&pageSize=<?php echo app('request')->input('pageSize'); ?>";

}


function checkUncheckBatch(v)
{

  var val = $(v).val();

  location.href="/courses?batchNo="+val+"&companyCode=<?php echo app('request')->input('companyCode'); ?>&pageSize=<?php echo app('request')->input('pageSize'); ?>";


} 


function pageSizeChange(v)
{

  var val = $(v).val();

  location.href="/courses?pageSize="+val+"&companyCode=<?php echo app('request')->input('companyCode'); ?>";

}

</script>

