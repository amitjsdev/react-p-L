@include('admin.layouts.mainlayout')

 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Exercises Media Alt3</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Exercises Media Alt3</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
     <section class="content">
      <div class="container-fluid">
      	@if(session()->has('message'))
		    <div class="alert alert-success">
		        {{ session()->get('message') }}
		    </div>
		@endif

        


        <div class="row">
           
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                
              Show: <select name="pageSize" onchange="pageSizeChange(this);">

               <option value="10" <?php if( $pageSize==10 ) { ?> selected="selected" <?php } ?> >10</option>
               <option value="25" <?php if( $pageSize==25 ) { ?> selected="selected" <?php } ?>>25</option>
               <option value="50" <?php if( $pageSize==50 ) { ?> selected="selected" <?php } ?>>50</option>
               <option value="100" <?php if( $pageSize==100 ) { ?> selected="selected" <?php } ?>>100</option>

              </select> 

          

                <div align="center">

                <form> 

                
                <input type="text" name="moduleNo" id="moduleNo" placeholder="moduleNo" style="width:80px;" value="{{ app('request')->input('moduleNo') }}" /> 
                <input type="text" name="routeNo" id="routeNo" placeholder="routeNo" style="width:80px;" value="{{ app('request')->input('routeNo') }}" /> 
                <input type="text" name="lessonNo" id="lessonNo" placeholder="lessonNo" style="width:80px;" value="{{ app('request')->input('lessonNo') }}" />
                

                
                

                
                 <input type="text" name="query" placeholder="Search"  value="{{ app('request')->input('query') }}" />

              

                 <input type="hidden" name="pageSize" value="{{ app('request')->input('pageSize') }}" />


                 <input type="submit" class="btn btn-primary" name="go" value="Go" />


                </form>

                </div>


               <!-- <a href="/add-exercise"><button type="button" class="btn btn-primary" style="float: right;">Add Exercise</button></a>-->

              </div>
              <!-- /.card-header -->
              
              <div class="card-body">
                <div class="table-responsive">
                <table class="table table-bordered  tablesorter sortable">
                  <thead>                  
                    <tr>
                      <th style="width: 10px">#</th>
                      <th>ExerciseId</th>
                      <th>ModuleNo</th>
                      <th>RouteNo</th>
                      <th>LessonNo</th>
                      <th>ExerciseNo</th>
                      <th>Media Alt3</th>
                      <th>Action</th>                      
                    </tr>
                  </thead>
                  <tbody>

                  	   
                   @foreach($exercisesMediaAlt3 as $item => $value)
                      <tr>
                        <td>{{$value->id}}</td>
                        <td>{{$value->exerciseId}}</td>
                        <td>{{$value->moduleNo}}</td>
                        <td>{{$value->routeNo}}</td>
                        <td>{{$value->lessonNo}}</td>
                        <td>{{$value->exerciseNo}}</td>
                        <td>{{$value->media_alt3}}</td>                        
                        
                        <td width="100px">
                            
                            
                            <a href="#"><i class="fas fa-edit" style="cursor: pointer;"></i></a>
                            <a href="#"><i class="fas fa-trash" style="cursor: pointer;"></i></a>

                        </td>
                      </tr>
                   @endforeach  
                  </tbody>
                </table>
              </div>
              </div>


              {{$exercisesMediaAlt3->appends(request()->query())->links()}}


              <div style="padding-left: 20px; font-weight: bold;">Showing {{ $exercisesMediaAlt3->firstItem() }} to {{ $exercisesMediaAlt3->lastItem() }} of total {{$exercisesMediaAlt3->total()}} entries</div>
<div style="clear: both;">&nbsp;</div>


           
            </div>
            <!-- /.card -->

        
            <!-- /.card -->
          </div>
           
       
        </div>
        <!-- /.row -->
   
   
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>

    



	 



    <!-- /.content -->
  </div>

  @include('admin.layouts.partials.footer')


<script>
    
 
function pageSizeChange(v)
{

  var val = $(v).val();

  location.href="/exercises-media-alt3?pageSize="+val;

}

</script>

