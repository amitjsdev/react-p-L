@include('admin.layouts.mainlayout')

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Exercises</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item"><a href="{{ url('/exercise-v2') }}">Exercise V2</a></li>
                        <li class="breadcrumb-item active">Edit Exercises</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            @if(session()->has('message'))
            <div class="alert alert-success">
                {{ session()->get('message') }}
            </div>
            @endif

            @if(session()->has('error'))
            <div class="alert alert-danger">
                {{ session()->get('error') }}
            </div>
            @endif


            @if(request()->has('clone'))
            <div class="alert alert-warning">
                Request has clone parameter, which means an exercise will be tried to clone using id on save, it will not effect any previous record.
            </div>
            @endif





            <div class="row">

                <div class="col-md-12 edit-form">
                    <div class="card">



                        <div class="card-body">
                            <div class="table-responsive">

                                <form method="post" action="/exercise-v2{{isset($exercise->id) ? '/' : ''}}{{$exercise->id}}">
                                    @csrf

                                    <div class="modal-body">

                                        <div class="form-group">

                                            <div class="marginb10">
                                                <div class="left">Sequence No:</div>
                                                <div class="right">

                                                    <input type="number" class="form-control" name="sequenceNo" value="{{ $exercise->sequenceNo ?? 0 }}">

                                                </div>
                                            </div>

                                            <div style="clear:both">&nbsp;</div>

                                            <div class="marginb10">
                                                <div class="left">Module No:</div>
                                                <div class="right">

                                                    <select name="moduleNo" class="form-control" onchange="changeRoutes(this.value);">
                                                        <option value="">Select</option>
                                                        <?php

                                                        foreach ($modules as $data) {  ?>

                                                            <option <?php if ($data->moduleno == $exercise->moduleNo  && strlen($exercise->moduleNo)) { ?> selected="selected" <?php } ?> value="<?php echo $data->moduleno; ?>"><?php echo $data->moduleno . "-" . $data->description; ?></option>

                                                        <?php } ?>

                                                    </select>

                                                </div>
                                            </div>


                                            <div style="clear:both">&nbsp;</div>

                                            <div class="left">Route No:</div>
                                            <div class="right">


                                                <div id="DivRouteNo" class="marginb10">

                                                    <select class="form-control" name="routeNo">
                                                        <option value="">Select</option>
                                                    </select>


                                                </div>

                                            </div>

                                            <div style="clear:both">&nbsp;</div>


                                            <div class="marginb10">
                                                <div class="left">Lesson No:</div>
                                                <div class="right">

                                                    <div id="DivLessonNo" class="marginb10">

                                                        <select class="form-control" name="lessonNo">
                                                            <option value="">Select</option>
                                                        </select>


                                                    </div>


                                                </div>
                                            </div>


                                            <div style="clear:both">&nbsp;</div>


                                            <div style="clear:both">&nbsp;</div>


                                            <div class="marginb10">
                                                <div class="left">Exercise Type:</div>
                                                <div class="right">
                                                    <select class="form-control" name="exerciseType">
                                                        <?php
                                                        foreach ($exercise_type as $data) {  ?>
                                                            <option value="<?php echo $data->type; ?>" <?php echo $exercise->exerciseType == $data->type ? 'selected="selected"' : ''; ?>><?php echo $data->title; ?></option>
                                                        <?php } ?>
                                                    </select>

                                                </div>
                                                <a href="Javascript:void(0)" class="text-sm pt-2" id="whatIsThis">What is this?</a>
                                            </div>
                                            <!-- this has the data about what different exercise type will do -->
                                            <!--  -->
                                            <div id="aboutExerciseType" style="display: none; border: 1px solid gray; padding: 5px;">
                                                <p>
                                                    Each one of the field below (question, options, answer) can have multiple questions per line and relative answers and options too. <br>
                                                    For eg if there are 5 questions, one in each line, they will have 5 options and 5 answers respectively. <br>
                                                    All options are Separated by <b>semicolon</b>. Delimiter is <b>;</b><br>
                                                </p>
                                                <br>
                                                For <b>translate_sentence -</b>
                                                <br>
                                                <p>
                                                    <b>Question</b> will have the sentence with word that is to be translated like, si ##este## sombrero. <br>
                                                    <b>options</b> will have an array of all the value that are to be shown. <br>
                                                    <b>answers</b> will have the actual translation that can be used for comparison
                                                </p>
                                                <br>
                                                For <b>tap_what_you_hear -</b>
                                                <p>
                                                    <b>Question</b> will have the word that is to be spoken. <br>
                                                    <b>options</b> will have an array of all the value that are to be shown. <br>
                                                    <b>answers</b> will have the actual translation that can be used for comparison
                                                </p>
                                                <br>
                                                For <b>multiple_choice -</b>
                                                <p>
                                                    <b>Question</b> will have the sentence with word that is to be translated. <br>
                                                    <b>options</b> will have an array of all the value that are to be shown. <br>
                                                    <b>answers</b> will have the actual translation that can be used for comparison
                                                </p>
                                                <br>
                                                For <b>voice_recognition -</b>
                                                <p>
                                                    <b>Question</b> will have the sentence that is to be recognised. <br>
                                                    <b>options</b> will be empty array. <br>
                                                    <b>answers</b> will be null.
                                                </p>
                                                <br>
                                                For <b>3_pair_of_words -</b>
                                                <p>
                                                    <b>Question</b> will be null. <br>
                                                    <b>options</b> will be array of all words. <br>
                                                    <b>answers</b> will be an array with 3 array that have one pair each. words in a pair will be separated by whitespace, while the pairs will be seperated from each other using semicolon like - <b>Red Green;Banana Apple;Pen Pencil</b>.
                                                </p>
                                                <br>
                                                For <b>tap_words_to_complete_dialogue -</b>
                                                <p>
                                                    <b>Question</b> will be the sentence with missing word like - <b>hey there, what is your ___</b>. <br>
                                                    <b>options</b> will be array of all words like, <b>name;age</b>. <br>
                                                    <b>answers</b> will be the word that is correct.
                                                </p>
                                                <br>
                                                For <b>tap_letter_to_complete_the_dialog-</b>
                                                <p>
                                                    <b>Question</b> will be the sentence with missing letters like - <b>hey th_re, what is your name</b>. <br>
                                                    <b>options</b> will be array of all letters like, <b>e;r;z</b>. <br>
                                                    <b>answers</b> will be the letter that is correct.
                                                </p>
                                            </div>


                                            <div style="clear:both">&nbsp;</div>


                                            <div class="marginb10">
                                                <div class="left">For Interactive Listen?:</div>
                                                <div class="right">
                                                    <select name="forInteractiveListen" class="form-control">
                                                        <option value="0" {{$exercise->forInteractiveListen === 0 ? "selected" : ""}}>No</option>
                                                        <option value="1" {{$exercise->forInteractiveListen === 1 ? "selected" : ""}}>Yes</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div style="clear:both">&nbsp;</div>


                                            <div class="marginb10">
                                                <div class="left">Question:</div>
                                                <div class="right"><textarea name="question" rows="10" cols="80" class="form-control">{{$exercise->question}}</textarea>
                                                </div>
                                            </div>

                                            <div style="clear:both">&nbsp;</div>

                                            <div class="marginb10">
                                                <div class="left">Options:</div>
                                                <div class="right"><textarea name="options" rows="10" cols="80" class="form-control">{{$exercise->options}}</textarea>
                                                </div>
                                            </div>


                                            <div style="clear:both">&nbsp;</div>


                                            <div class="marginb10">
                                                <div class="left">Answer:</div>
                                                <div class="right"><textarea name="answer" rows="10" cols="80" class="form-control">{{$exercise->answer}}</textarea>
                                                </div>
                                            </div>

                                            <div style="clear:both">&nbsp;</div>


                                            <div class="marginb10">
                                                <div class="left">Translation:</div>
                                                <div class="right"><textarea name="translation" rows="10" cols="80" class="form-control">{{$exercise->translation}}</textarea>
                                                </div>
                                            </div>

                                            <div style="clear:both">&nbsp;</div>


                                            <div class="marginb10">
                                                <div class="left">Is Hard:</div>
                                                <div class="right">
                                                    <select name="is_hard" class="form-control">
                                                        <option value="1" {{$exercise->is_hard == "1" ? "selected" : ""}}>Yes</option>
                                                        <option value="0" {{$exercise->is_hard == "0" ? "selected" : ""}}>No</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div style="clear:both">&nbsp;</div>


                                            <div class="marginb10">
                                                <div class="left">Status:</div>
                                                <div class="right">
                                                    <select name="status" class="form-control">
                                                        <option value="1" {{$exercise->status == "1" ? "selected" : ""}}>Active</option>
                                                        <option value="0" {{$exercise->status == "0" ? "selected" : ""}}>In-Active</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div style="clear:both">&nbsp;</div>

                                            <div class="modal-footer">
                                                <button type="submit" class="btn btn-primary">Save</button>
                                            </div>

                                        </div>
                                    </div>

                                </form>


                            </div>
                        </div>







                    </div>
                    <!-- /.card -->


                    <!-- /.card -->
                </div>


            </div>
            <!-- /.row -->


            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>




    <!-- /.content -->
</div>

@include('admin.layouts.partials.footer')


<script>
    function changeRoutes(m, r, cb = () => {}) {

        $('#DivRouteNo').html("loading...");

        $.ajax({
            type: "GET",
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            url: "/module-route?name=routeno",
            data: {
                moduleNo: m,
                routeNo: r
            }, // multiple data sent using ajax
            success: function(html) {

                //console.log( html ); 

                $('#DivRouteNo').html(html);

                cb();

            }
        });

    }

    function changeLessons(m, r, l) {

        $('#DivLessonNo').html("loading...");

        $.ajax({
            type: "GET",
            cache: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            url: "/module-route-lesson?name=lesson_no",
            data: {
                moduleNo: m,
                routeNo: r,
                lessonNo: l
            }, // multiple data sent using ajax
            success: function(html) {

                //console.log( html ); 

                $('#DivLessonNo').html(html);

            }
        });

    }


    $(document).ready(function() {

        $("#whatIsThis").click(function() {
            $("#aboutExerciseType").slideToggle();
        });



        <?php //if($lesson->moduleno!="") { 
        ?>
        changeRoutes('<?php echo $exercise->moduleNo; ?>', '<?php echo $exercise->routeNo; ?>', () => {
            changeLessons('<?php echo $exercise->moduleNo; ?>', '<?php echo $exercise->routeNo; ?>', '<?php echo $exercise->lessonNo; ?>');
        })
        <?php //} 
        ?>

        <?php //if($lesson->moduleno!="") { 
        ?>
        // changeLessons('<?php echo $exercise->moduleNo; ?>', '<?php echo $exercise->routeNo; ?>', '<?php echo $exercise->lessonNo; ?>')
        <?php //} 
        ?>

    });
</script>