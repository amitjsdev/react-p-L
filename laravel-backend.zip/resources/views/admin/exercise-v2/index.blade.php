@include('admin.layouts.mainlayout')

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Exercises</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Exercises</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            @if(session()->has('message'))
            <div class="alert alert-success">
                {{ session()->get('message') }}
            </div>
            @endif




            <div class="row">

                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <b>Show:</b>
                            <select name="pageSize" onchange="pageSizeChange(this);" class="form-control" style="width: 75px; display: inline-block;">
                                <option value="10" <?php if ($pageSize == 10) { ?> selected="selected" <?php } ?>>10</option>
                                <option value="25" <?php if ($pageSize == 25) { ?> selected="selected" <?php } ?>>25</option>
                                <option value="50" <?php if ($pageSize == 50) { ?> selected="selected" <?php } ?>>50</option>
                                <option value="100" <?php if ($pageSize == 100) { ?> selected="selected" <?php } ?>>100</option>
                            </select>
                            <div align="center">
                                <form class="">
                                    <input type="text" name="moduleNo" id="moduleNo" placeholder="moduleNo" style="width:80px;" value="{{ app('request')->input('moduleNo') }}" />
                                    <input type="text" name="routeNo" id="routeNo" placeholder="routeNo" style="width:80px;" value="{{ app('request')->input('routeNo') }}" />
                                    <input type="text" name="lessonNo" id="lessonNo" placeholder="lessonNo" style="width:80px;" value="{{ app('request')->input('lessonNo') }}" />
                                    <input type="text" name="search" placeholder="Search" value="{{ app('request')->input('query') }}" />
                                    <select name="exerciseType">
                                        <option value="">Any</option>
                                        @foreach ($exerciseType as $data)
                                        <option value="{{$data->code}}" {{ request()->get("exerciseType") === $data->code ? "selected" : "" }}>
                                            {{$data->name}}
                                        </option>
                                        @endforeach
                                    </select>
                                    <input type="hidden" name="pageSize" value="{{ app('request')->input('pageSize') }}" />
                                    <input type="submit" class="btn btn-primary btn-sm" value="Go" />
                                    <a href="/exercise-v2" type="reset" class="btn btn-danger btn-sm">Reset</a>
                                </form>
                            </div>
                            <a href="/exercise-v2/add"><button type="button" class="btn btn-primary" style="float: right;">Add Exercise</button></a>
                        </div>
                        <!-- /.card-header -->

                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered  tablesorter sortable">
                                    <thead>
                                        <tr>
                                            <th style="width: 10px">#</th>
                                            <th>Sequence Number</th>
                                            <th>Module Number</th>
                                            <th>Route Number</th>
                                            <th>Lesson Number</th>
                                            <th>Long Description</th>
                                            <th>Exercise Type</th>
                                            <th>For Interactive Listen?</th>
                                            <th>Question</th>
                                            <th>Answer</th>
                                            <th>Options</th>
                                            <th>translation</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>


                                        @foreach($exercises as $item => $value)
                                        <tr>
                                            <td>{{$value->id}}</td>
                                            <td>{{$value->sequenceNo}}</td>
                                            <td>{{$value->moduleNo}}</td>
                                            <td>{{$value->routeNo}}</td>
                                            <td>{{$value->lessonNo}}</td>
                                            <td>{{$value->lesson->long_description}}</td>
                                            <td>{{$value->exerciseType}}</td>
                                            <td>{{$value->forInteractiveListen ? "Yes" : "No"}}</td>
                                            <td><a href="/exercise-v2/{{$value->id}}">{{$value->question}}</a></td>
                                            <td>{{$value->answer ?? "-"}}</td>
                                            <td>{{$value->options ?? "-"}}</td>
                                            <td>{{$value->translation ?? "-"}}</td>
                                            <td>{{$value->status}}</td>
                                            <td width="100px">

                                                <a href="/exercise-v2/{{$value->id}}" title="Edit"><i class=" fas fa-edit" style="cursor: pointer;"></i></a>
                                                <a href="/exercise-v2/goto-forum/{{$value->id}}" title="Goto forum" class="{{ $value->forum ? 'text-primary' : 'text-warning' }}"><i class="fa fa-users" style="cursor: pointer;"></i></a>
                                                <a href="/exercise-v2/add?clone={{$value->id}}" title="Clone"><i class=" fas fa-copy" style="cursor: pointer;"></i></a>
                                                <form action="/exercise-v2/{{$value->id}}" method="post" class="d-inline" onsubmit="return confirm('Are you sure to delete the record?')">
                                                    @method("delete")
                                                    @csrf
                                                    <button class="btn text-primary btn-sm d-inline p-0" title="Delete"><i class="fas fa-trash" style="cursor: pointer;"></i></button>
                                                </form>

                                            </td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>


                        {{$exercises->appends(request()->query())->links()}}


                        <div style="padding-left: 20px; font-weight: bold;">Showing {{ $exercises->firstItem() }} to {{ $exercises->lastItem() }} of total {{$exercises->total()}} entries</div>
                        <div style="clear: both;">&nbsp;</div>



                    </div>
                    <!-- /.card -->


                    <!-- /.card -->
                </div>


            </div>
            <!-- /.row -->


            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>









    <!-- /.content -->
</div>

@include('admin.layouts.partials.footer')


<script>
    function pageSizeChange(v) {

        var val = $(v).val();

        location.href = "/exercises?pageSize=" + val;

    }
</script>