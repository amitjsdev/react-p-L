@include('admin.layouts.mainlayout')

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Forums</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Forums</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            @if(session()->has('message'))
            <div class="alert alert-success">
                {{ session()->get('message') }}
            </div>
            @endif
            @if(session()->has('error'))
            <div class="alert alert-danger">
                {{ session()->get('error') }}
            </div>
            @endif




            <div class="row">

                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <div align="center">
                                <form class="">
                                    <input type="text" name="moduleNo" id="moduleNo" placeholder="moduleNo" style="width:80px;" value="{{ app('request')->input('moduleNo') }}" />
                                    <input type="text" name="routeNo" id="routeNo" placeholder="routeNo" style="width:80px;" value="{{ app('request')->input('routeNo') }}" />
                                    <input type="text" name="lessonNo" id="lessonNo" placeholder="lessonNo" style="width:80px;" value="{{ app('request')->input('lessonNo') }}" />
                                    <input type="text" name="search" placeholder="Search" value="{{ app('request')->input('query') }}" />
                                    <select name="exerciseType">
                                        <option value="">Any</option>
                                        @foreach ([] as $data)
                                        <option value="{{$data->code}}" {{ request()->get("exerciseType") === $data->code ? "selected" : "" }}>
                                            {{$data->name}}
                                        </option>
                                        @endforeach
                                    </select>
                                    <input type="hidden" name="pageSize" value="{{ app('request')->input('pageSize') }}" />
                                    <input type="submit" class="btn btn-primary btn-sm" value="Go" />
                                    <a href="/exercise-v2" type="reset" class="btn btn-danger btn-sm">Reset</a>
                                </form>
                            </div>
                            <a href="/forums/add"><button type="button" class="btn btn-primary" style="float: right;">Add Forum</button></a>
                            <a href="/forums"><button type="button" class="btn btn-success" style="float: right;">All Forums</button></a>
                        </div>
                        <!-- /.card-header -->

                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered  tablesorter sortable">
                                    <thead>
                                        <tr>
                                            <th style="width: 10px">#</th>
                                            <th>Forum For</th>
                                            <th>Entity Id</th>
                                            <th>For</th>
                                            <th>Title</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>


                                        @foreach($forums as $item => $value)
                                        <tr>
                                            <td>{{$value->id}}</td>
                                            <td>{{substr($value->forumable_type, strrpos($value->forumable_type,"\\") + 1)}}</td>
                                            <td>{{$value->forumable_id}}</td>
                                            <td>{{$value->for}}</td>
                                            <td>{{$value->title}}</td>
                                            <td width="100px">
                                                <a href="/forums/{{$value->id}}"><i class=" fas fa-edit" style="cursor: pointer;"></i></a>
                                                <a target="_blank" href="/forums/open/{{$value->id}}" title="Go to forum" class="goto-link">
                                                    <span class="message-count {{ $value->new_messages > 0 ? 'has-new-messages' : '' }}">{{ $value->new_messages }}</span>
                                                    <i class=" fas fa-users" style="cursor: pointer;"></i>
                                                </a>
                                                <form action="/forums/{{$value->id}}" method="post" class="d-inline" onsubmit="return confirmDelete(this)">
                                                    @method("delete")
                                                    @csrf
                                                    <button class="btn text-primary btn-sm d-inline p-0"><i class="fas fa-trash" style="cursor: pointer;"></i></button>
                                                </form>

                                            </td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>


                    </div>
                    <!-- /.card -->


                    <!-- /.card -->
                </div>


            </div>
            <!-- /.row -->


            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>









    <!-- /.content -->
</div>

@include('admin.layouts.partials.footer')

<style>
    .goto-link {
        position: relative;
        padding-left: 5px;
    }

    .goto-link .message-count {
        position: absolute;
        width: 15px;
        height: 15px;
        line-height: 0;
        padding-top: 6px;
        background-color: white;
        font-size: 10px;
        font-weight: bold;
        border-radius: 50%;
        text-align: center;
        color: lightgray;
        border: 1px solid lightgray;
        left: -2px;
        bottom: -5px;
    }


    .goto-link .message-count.has-new-messages {
        color: dodgerblue;
        border: 1px solid dodgerblue;
    }
</style>

<script>
    function pageSizeChange(v) {

        var val = $(v).val();

        location.href = "/exercises?pageSize=" + val;

    }

    function confirmDelete(event) {
        return confirm("Are you sure?");
    }
</script>