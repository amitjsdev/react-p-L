<!DOCTYPE html>
<html lang="en">

<head>
  @include('admin.layouts.partials.head')
</head>

<body class="hold-transition sidebar-mini layout-fixed">
  @include('admin.layouts.partials.nav')
  @include(session('marketing') ? 'admin.layouts.partials.sidebar-marketing' : 'admin.layouts.partials.sidebar')
  @yield('content')

</body>

</html>