<aside class="main-sidebar sidebar-dark-primary elevation-4">
  <!-- Brand Logo -->
  <a href="/reports/main" class="brand-link">
    <img src="{{asset('dist/img/AdminLTELogo.png')}}" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
    <span class="brand-text font-weight-light">Admin</span>
  </a>

  <!-- Sidebar -->
  <div class="sidebar">
    <!-- Sidebar user panel (optional) -->


    <!-- Sidebar Menu -->
    <nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->


        <?php //echo request()->path(); 
        ?>

        <li class="nav-item has-treeview  <?php if (\Illuminate\Support\Str::startsWith(request()->path(), "reports")) echo ' menu-open'; ?>">
          <a href="#" class="nav-link">
            <i class="nav-icon fas fa-th"></i>
            <p>
              Reports
              <i class="fas fa-angle-left right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">

            <li class="nav-item">
              <a href="/reports/main" class="nav-link <?php if (request()->path() == "reports/main") echo ' active'; ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>
                  Main Report
                </p>
              </a>
            </li>

            @if(\Illuminate\Support\Str::startsWith(request()->path(), "reports"))
            <li class="nav-item">
              <a href="/reports/user-registration-loop" class="nav-link <?php if (request()->path() == "reports/user-registration-loop") echo ' active'; ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>
                  User Reg Loop
                </p>
              </a>
            </li>

            <!--<li class="nav-item">
              <a href="/reports/loop-one-details" class="nav-link <?php if (request()->path() == "reports/loop-one-details") echo ' active'; ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>
                  Loop One Details
                </p>
              </a>
            </li>-->


            <li class="nav-item">
              <a href="/reports/loop-one-details-dates" class="nav-link <?php if (request()->path() == "reports/loop-one-details-dates") echo ' active'; ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>
                  Loop One by Reg Date
                </p>
              </a>
            </li>

            <li class="nav-item">
              <a href="/reports/user-loops-by-module" class="nav-link <?php if (request()->path() == "reports/user-loops-by-module") echo ' active'; ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>
                  User Loops by Module
                </p>
              </a>
            </li>


            <li class="nav-item">
              <a href="/reports/employee-course-with-email" class="nav-link <?php if (request()->path() == "reports/employee-course-with-email") echo ' active'; ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>
                  Employee Course Email
                </p>
              </a>
            </li>


            <li class="nav-item">
              <a href="/reports/employee-retention" class="nav-link <?php if (request()->path() == "reports/employee-retention") echo ' active'; ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>
                  Employee Retention
                </p>
              </a>
            </li>


            <li class="nav-item">
              <a href="/reports/employee-composite-data" class="nav-link <?php if (request()->path() == "reports/employee-composite-data") echo ' active'; ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>
                  Employee Composite Data
                </p>
              </a>
            </li>


            <li class="nav-item">
              <a href="/reports/employee-goals-history" class="nav-link <?php if (request()->path() == "reports/employee-goals-history") echo ' active'; ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>
                  Employee Goals History
                </p>
              </a>
            </li>




            <li class="nav-item">
              <a href="/reports/user-time-logs" class="nav-link <?php if (request()->path() == "reports/user-time-logs") echo ' active'; ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>
                  User Time Logs
                </p>
              </a>
            </li>




            <li class="nav-item">
              <a href="/reports/push-logs" class="nav-link <?php if (request()->path() == "reports/push-logs") echo ' active'; ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>
                  Push Logs
                </p>
              </a>
            </li>

            <li class="nav-item">
              <a href="/reports/phased-users" class="nav-link <?php if (request()->path() == "reports/phased-users") echo ' active'; ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>
                  Phased Users
                </p>
              </a>
            </li>
        </li>

        <li class="nav-item">
          <a href="/reports/inactive-day-x-users" class="nav-link <?php if (request()->path() == "reports/inactive-day-x-users") echo ' active'; ?>">
            <i class="far fa-circle nav-icon"></i>
            <p>
              Inactive Day X Users
            </p>
          </a>
        </li>

        <li class="nav-item">
          <a href="/reports/additional-claimed-lives" class="nav-link <?php if (request()->path() == "reports/additional-claimed-lives") echo ' active'; ?>">
            <i class="far fa-circle nav-icon"></i>
            <p>
              Additional Lives Claimed
            </p>
          </a>
        </li>

        <li class="nav-item">
          <a href="/reports/users-that-have-made-3-or-more-mistakes-n-times" class="nav-link <?php if (request()->path() == "reports/users-that-have-made-3-or-more-mistakes-n-times") echo ' active'; ?>">
            <i class="far fa-circle nav-icon"></i>
            <p>
              User Failing Rounds
            </p>
          </a>
        </li>


        <li class="nav-item">
          <a href="/reports/email-template-performance" class="nav-link <?php if (request()->path() == "reports/email-template-performance") echo ' active'; ?>">
            <i class="far fa-circle nav-icon"></i>
            <p>
              Email Template Performance
            </p>
          </a>
        </li>


        <li class="nav-item">
          <a href="/reports/paused-users" class="nav-link <?php if (request()->path() == "reports/paused-users") echo ' active'; ?>">
            <i class="far fa-circle nav-icon"></i>
            <p>
              Paused Users
            </p>
          </a>
        </li>

        @endif
      </ul>
      </li>



      <li class="nav-item has-treeview  <?php if (
                                          request()->path() == "push-campaign-v2"
                                          || \Illuminate\Support\Str::startsWith(request()->path(), "forums")
                                          || \Illuminate\Support\Str::startsWith(request()->path(), "user-segment")
                                          || \Illuminate\Support\Str::startsWith(request()->path(), "email-templates")
                                        ) echo ' menu-open'; ?>">
        <a href="#" class="nav-link">
          <i class="nav-icon fas fa-th"></i>
          <p>
            Operations
            <i class="fas fa-angle-left right"></i>
          </p>
        </a>
        <ul class="nav nav-treeview">



          <li class="nav-item">
            <a href="/push-campaign-v2" class="nav-link <?php if (request()->path() == "push-campaign-v2") echo ' active'; ?>">
              <i class="far fa-circle nav-icon"></i>
              <p>
                Push Campaign V2
              </p>
            </a>
          </li>


          <li class="nav-item">
            <a href="/forums" class="nav-link <?php if (\Illuminate\Support\Str::startsWith(request()->path(), "forums")) echo ' active'; ?>">
              <i class="far fa-circle nav-icon"></i>
              <p>
                Forums
              </p>
            </a>
          </li>


          <li class="nav-item">
            <a href="/user-segment" class="nav-link <?php if (request()->path() == "user-segment") echo ' active'; ?>">
              <i class="far fa-circle nav-icon"></i>
              <p>
                User Segment
              </p>
            </a>
          </li>
      </li>


      <li class="nav-item">
        <a href="/user-segment/add/mix-panel" class="nav-link <?php if (request()->path() == "user-segment/add/mix-panel") echo ' active'; ?>">
          <i class="far fa-circle nav-icon"></i>
          <p>
            User Segment from Mix Panel
          </p>
        </a>
      </li>


      <li class="nav-item">
        <a href="/user-segment/add/using-rule" class="nav-link <?php if (request()->path() == "user-segment/add/using-rule") echo ' active'; ?>">
          <i class="far fa-circle nav-icon"></i>
          <p>
            User Segment using Rules
          </p>
        </a>
      </li>


      <li class="nav-item">
        <a href="/email-templates" class="nav-link <?php if (request()->path() == "email-templates") echo ' active'; ?>">
          <i class="far fa-circle nav-icon"></i>
          <p>
            Email Templates
          </p>
        </a>
      </li>


      <li class="nav-item">
        <a href="/email-templates/send-to-segment" class="nav-link <?php if (request()->path() == "email-templates/send-to-segment") echo ' active'; ?>">
          <i class="far fa-circle nav-icon"></i>
          <p>
            Send Email to Segment
          </p>
        </a>
      </li>

      <li class="nav-item">
        <a href="/cohorts" class="nav-link <?php if (\Illuminate\Support\Str::startsWith(request()->path(), "cohorts")) echo ' active'; ?>">
          <i class="far fa-circle nav-icon"></i>
          <p>
            Cohorts
          </p>
        </a>
      </li>

      <li class="nav-item">
        <a href="/programs" class="nav-link <?php if (\Illuminate\Support\Str::startsWith(request()->path(), "programs")) echo ' active'; ?>">
          <i class="far fa-circle nav-icon"></i>
          <p>
            Programs
          </p>
        </a>
      </li>

      <li class="nav-item">
        <a href="/practice-sets" class="nav-link <?php if (\Illuminate\Support\Str::startsWith(request()->path(), "practice-sets")) echo ' active'; ?>">
          <i class="far fa-circle nav-icon"></i>
          <p>
            Practice Sets
          </p>
        </a>
      </li>

      </ul>
      </li>

      <!--<li class="nav-item">
            <a href="/dashboard" class="nav-link">
              <i class="nav-icon fas fa-th"></i>
              <p>
                Manage Groups
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="/manage-user-permission" class="nav-link">
              <i class="nav-icon fas fa-th"></i>
              <p>
                Users Permission
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="/manage-api" class="nav-link">
              <i class="nav-icon fas fa-th"></i>
              <p>
                Manage Apis
              </p>
            </a>
          </li>-->


      </ul>
    </nav>
    <!-- /.sidebar-menu -->
  </div>
  <!-- /.sidebar -->
</aside>