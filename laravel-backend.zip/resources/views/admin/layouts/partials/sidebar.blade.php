<aside class="main-sidebar sidebar-dark-primary elevation-4">
  <!-- Brand Logo -->
  <a href="/dashboard" class="brand-link">
    <img src="{{asset('dist/img/AdminLTELogo.png')}}" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
    <span class="brand-text font-weight-light">Admin</span>
  </a>

  <!-- Sidebar -->
  <div class="sidebar">
    <!-- Sidebar user panel (optional) -->


    <!-- Sidebar Menu -->
    <nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->


        <?php //echo request()->path(); 
        ?>

        <li class="nav-item has-treeview  <?php if (\Illuminate\Support\Str::startsWith(request()->path(), "reports")) echo ' menu-open'; ?>">
          <a href="#" class="nav-link">
            <i class="nav-icon fas fa-th"></i>
            <p>
              Reports
              <i class="fas fa-angle-left right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">

            <li class="nav-item">
              <a href="/reports/main" class="nav-link <?php if (request()->path() == "reports/main") echo ' active'; ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>
                  Main Report
                </p>
              </a>
            </li>

            @if(\Illuminate\Support\Str::startsWith(request()->path(), "reports"))
            <li class="nav-item">
              <a href="/reports/user-registration-loop" class="nav-link <?php if (request()->path() == "reports/user-registration-loop") echo ' active'; ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>
                  User Reg Loop
                </p>
              </a>
            </li>

            <!--<li class="nav-item">
              <a href="/reports/loop-one-details" class="nav-link <?php if (request()->path() == "reports/loop-one-details") echo ' active'; ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>
                  Loop One Details
                </p>
              </a>
            </li>-->


            <li class="nav-item">
              <a href="/reports/loop-one-details-dates" class="nav-link <?php if (request()->path() == "reports/loop-one-details-dates") echo ' active'; ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>
                  Loop One by Reg Date
                </p>
              </a>
            </li>

            <li class="nav-item">
              <a href="/reports/user-loops-by-module" class="nav-link <?php if (request()->path() == "reports/user-loops-by-module") echo ' active'; ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>
                  User Loops by Module
                </p>
              </a>
            </li>


            <li class="nav-item">
              <a href="/reports/employee-course-with-email" class="nav-link <?php if (request()->path() == "reports/employee-course-with-email") echo ' active'; ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>
                  Employee Course Email
                </p>
              </a>
            </li>


            <li class="nav-item">
              <a href="/reports/employee-retention" class="nav-link <?php if (request()->path() == "reports/employee-retention") echo ' active'; ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>
                  Employee Retention
                </p>
              </a>
            </li>


            <li class="nav-item">
              <a href="/reports/employee-composite-data" class="nav-link <?php if (request()->path() == "reports/employee-composite-data") echo ' active'; ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>
                  Employee Composite Data
                </p>
              </a>
            </li>


            <li class="nav-item">
              <a href="/reports/employee-goals-history" class="nav-link <?php if (request()->path() == "reports/employee-goals-history") echo ' active'; ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>
                  Employee Goals History
                </p>
              </a>
            </li>




            <li class="nav-item">
              <a href="/reports/user-time-logs" class="nav-link <?php if (request()->path() == "reports/user-time-logs") echo ' active'; ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>
                  User Time Logs
                </p>
              </a>
            </li>




            <li class="nav-item">
              <a href="/reports/push-logs" class="nav-link <?php if (request()->path() == "reports/push-logs") echo ' active'; ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>
                  Push Logs
                </p>
              </a>
            </li>

            <li class="nav-item">
              <a href="/reports/phased-users" class="nav-link <?php if (request()->path() == "reports/phased-users") echo ' active'; ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>
                  Phased Users
                </p>
              </a>
            </li>
        </li>

        <li class="nav-item">
          <a href="/reports/inactive-day-x-users" class="nav-link <?php if (request()->path() == "reports/inactive-day-x-users") echo ' active'; ?>">
            <i class="far fa-circle nav-icon"></i>
            <p>
              Inactive Day X Users
            </p>
          </a>
        </li>

        <li class="nav-item">
          <a href="/reports/additional-claimed-lives" class="nav-link <?php if (request()->path() == "reports/additional-claimed-lives") echo ' active'; ?>">
            <i class="far fa-circle nav-icon"></i>
            <p>
              Additional Lives Claimed
            </p>
          </a>
        </li>

        <li class="nav-item">
          <a href="/reports/users-that-have-made-3-or-more-mistakes-n-times" class="nav-link <?php if (request()->path() == "reports/users-that-have-made-3-or-more-mistakes-n-times") echo ' active'; ?>">
            <i class="far fa-circle nav-icon"></i>
            <p>
              User Failing Rounds
            </p>
          </a>
        </li>


        @endif
      </ul>
      </li>



      <li class="nav-item has-treeview  <?php if (
                                          request()->path() == "push-campaign-v2"
                                          || \Illuminate\Support\Str::startsWith(request()->path(), "forums")
                                          || request()->path() == "user-segment"
                                        ) echo ' menu-open'; ?>">
        <a href="#" class="nav-link">
          <i class="nav-icon fas fa-th"></i>
          <p>
            Operations
            <i class="fas fa-angle-left right"></i>
          </p>
        </a>
        <ul class="nav nav-treeview">



          <li class="nav-item">
            <a href="/push-campaign-v2" class="nav-link <?php if (request()->path() == "push-campaign-v2") echo ' active'; ?>">
              <i class="far fa-circle nav-icon"></i>
              <p>
                Push Campaign V2
              </p>
            </a>
          </li>


          <li class="nav-item">
            <a href="/forums" class="nav-link <?php if (\Illuminate\Support\Str::startsWith(request()->path(), "forums")) echo ' active'; ?>">
              <i class="far fa-circle nav-icon"></i>
              <p>
                Forums
              </p>
            </a>
          </li>


          <li class="nav-item">
            <a href="/user-segment" class="nav-link <?php if (request()->path() == "user-segment") echo ' active'; ?>">
              <i class="far fa-circle nav-icon"></i>
              <p>
                User Segment
              </p>
            </a>
          </li>




        </ul>
      </li>

      @if(!(
      \Illuminate\Support\Str::startsWith(request()->path(), "reports") ||
      request()->path() == "push-campaign-v2"
      || \Illuminate\Support\Str::startsWith(request()->path(), "forums")
      || request()->path() == "user-segment"

      ))
      <li class="nav-item">
        <a href="/courses" class="nav-link <?php if (request()->path() == "courses" || request()->path() == "add-course" || request()->path() == "edit-course") echo ' active'; ?>">
          <i class="nav-icon fas fa-th"></i>
          <p>
            Courses
          </p>
        </a>
      </li>

      <li class="nav-item">
        <a href="/cards" class="nav-link <?php if (request()->path() == "cards" || request()->path() == "add-card" || request()->path() == "edit-card") echo ' active'; ?>">
          <i class="nav-icon fas fa-th"></i>
          <p>
            Cards
          </p>
        </a>
      </li>

      <li class="nav-item">
        <a href="/modules" class="nav-link <?php if (request()->path() == "modules" || request()->path() == "add-module" || request()->path() == "edit-module") echo ' active'; ?>">
          <i class="nav-icon fas fa-th"></i>
          <p>
            Modules
          </p>
        </a>
      </li>

      <li class="nav-item">
        <a href="/routes" class="nav-link <?php if (request()->path() == "routes" || request()->path() == "add-route" || request()->path() == "edit-route") echo ' active'; ?>">
          <i class="nav-icon fas fa-th"></i>
          <p>
            Routes
          </p>
        </a>
      </li>

      <li class="nav-item has-treeview  <?php if (request()->path() == "lessons" || request()->path() == "add-lesson" || request()->path() == "edit-lesson"  || request()->path() == "lessons-dialog-translation"  || request()->path() == "lessons-video-tldrs") echo ' menu-open'; ?>">
        <a href="/lessons" class="nav-link">
          <i class="nav-icon fas fa-th"></i>
          <p>
            Lessons
            <i class="fas fa-angle-left right"></i>
          </p>
        </a>

        <ul class="nav nav-treeview">

          <li class="nav-item">
            <a href="/lessons" class="nav-link <?php if (request()->path() == "lessons" || request()->path() == "add-lesson" || request()->path() == "edit-lesson") echo ' active'; ?>">
              <i class="far fa-circle nav-icon"></i>
              <p>
                Lessons
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="/lessons-dialog-translation" class="nav-link <?php if (request()->path() == "lessons-dialog-translation") echo ' active'; ?>">
              <i class="far fa-circle nav-icon"></i>
              <p>
                Dialog Translation
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="/lessons-video-tldrs" class="nav-link <?php if (request()->path() == "lessons-video-tldrs") echo ' active'; ?>">
              <i class="far fa-circle nav-icon"></i>
              <p>
                Video TLDRs
              </p>
            </a>
          </li>

        </ul>

      </li>





      <li class="nav-item has-treeview <?php if (request()->path() == "exercises" || request()->path() == "add-exercise" || request()->path() == "edit-exercise" || request()->path() == "exercises-description" || request()->path() == "exercises-media-alt3" || \Illuminate\Support\Str::startsWith(request()->path(), "exercise-v2")) echo ' menu-open'; ?>">
        <a href="/exercises" class="nav-link">
          <i class="nav-icon fas fa-th"></i>
          <p>
            Exercises
            <i class="fas fa-angle-left right"></i>
          </p>
        </a>

        <ul class="nav nav-treeview">

          <li class="nav-item">
            <a href="/exercises" class="nav-link <?php if (request()->path() == "exercises" || request()->path() == "add-exercise" || request()->path() == "edit-exercise") echo ' active'; ?>">
              <i class="far fa-circle nav-icon"></i>
              <p>
                Exercises
              </p>
            </a>
          </li>


          <li class="nav-item">
            <a href="/exercises-description" class="nav-link <?php if (request()->path() == "exercises-description") echo ' active'; ?>">
              <i class="far fa-circle nav-icon"></i>
              <p>
                Description
              </p>
            </a>
          </li>


          <li class="nav-item">
            <a href="/exercises-media-alt3" class="nav-link <?php if (request()->path() == "exercises-media-alt3") echo ' active'; ?>">
              <i class="far fa-circle nav-icon"></i>
              <p>
                Media Alt3
              </p>
            </a>
          </li>



          <li class="nav-item">
            <a href="/exercise-v2" class="nav-link <?php if (\Illuminate\Support\Str::startsWith(request()->path(), "exercise-v2")) echo ' active'; ?>">
              <i class="far fa-circle nav-icon"></i>
              <p>
                Exercises V2
              </p>
            </a>
          </li>

        </ul>


      </li>


      <li class="nav-item">
        <a href="/dialogs-polly" class="nav-link <?php if (request()->path() == "dialogs-polly" || request()->path() == "add-dialog-polly" || request()->path() == "edit-dialog-polly") echo ' active'; ?>">
          <i class="nav-icon fas fa-th"></i>
          <p>
            Polly Dialogs
          </p>
        </a>
      </li>


      <li class="nav-item">
        <a href="/exercises-polly" class="nav-link <?php if (request()->path() == "exercises-polly" || request()->path() == "add-exercise-polly" || request()->path() == "edit-exercise-polly") echo ' active'; ?>">
          <i class="nav-icon fas fa-th"></i>
          <p>
            Polly Exercises
          </p>
        </a>
      </li>



      <li class="nav-item">
        <a href="/transcribes" class="nav-link <?php if (request()->path() == "transcribes" || request()->path() == "add-transcribe" || request()->path() == "edit-transcribe") echo ' active'; ?>">
          <i class="nav-icon fas fa-th"></i>
          <p>
            Transcribe
          </p>
        </a>
      </li>



      <li class="nav-item">
        <a href="#" class="nav-link">
          <i class="nav-icon fas fa-th"></i>
          <p>
            Companies
          </p>
        </a>
      </li>

      <li class="nav-item">
        <a href="/access-levels" class="nav-link <?php if (request()->path() == "access-levels") echo ' active'; ?>">
          <i class="nav-icon fas fa-th"></i>
          <p>
            User Access Level
          </p>
        </a>
      </li>


      <li class="nav-item">
        <a href="#" class="nav-link">
          <i class="nav-icon fas fa-th"></i>
          <p>
            Batches
          </p>
        </a>
      </li>


      <li class="nav-item">
        <a href="/s3public" class="nav-link <?php if (request()->path() == "s3public") echo ' active'; ?>">
          <i class="nav-icon fas fa-th"></i>
          <p>
            S3 Permission
          </p>
        </a>
      </li>


      <li class="nav-item">
        <a href="/users" class="nav-link <?php if (request()->path() == "users") echo ' active'; ?>">
          <i class="nav-icon fas fa-th"></i>
          <p>
            Users
          </p>
        </a>
      </li>




      <li class="nav-item">
        <a href="/push-campaign" class="nav-link <?php if (request()->path() == "push-campaign") echo ' active'; ?>">
          <i class="nav-icon fas fa-th"></i>
          <p>
            Push Campaign
          </p>
        </a>
      </li>

      <li class="nav-item">
        <a href="/certificate" class="nav-link <?php if (request()->path() == "certificate") echo ' active'; ?>">
          <i class="nav-icon fas fa-th"></i>
          <p>
            Certificate
          </p>
        </a>
      </li>
      <li class="nav-item">
        <a href="/v2-exercise-type" class="nav-link <?php if (\Illuminate\Support\Str::startsWith(request()->path(), "v2-exercise-type")) echo ' active'; ?>">
          <i class="nav-icon fas fa-th"></i>
          <p>
            Exercise Types
          </p>
        </a>
      </li>
      <li class="nav-item">
        <a href="/faq" class="nav-link <?php if (request()->path() == "faq") echo ' active'; ?>">
          <i class="nav-icon fas fa-th"></i>
          <p>
            Faq
          </p>
        </a>
      </li>
      @endif

      <!--<li class="nav-item">
            <a href="/dashboard" class="nav-link">
              <i class="nav-icon fas fa-th"></i>
              <p>
                Manage Groups
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="/manage-user-permission" class="nav-link">
              <i class="nav-icon fas fa-th"></i>
              <p>
                Users Permission
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="/manage-api" class="nav-link">
              <i class="nav-icon fas fa-th"></i>
              <p>
                Manage Apis
              </p>
            </a>
          </li>-->


      </ul>
    </nav>
    <!-- /.sidebar-menu -->
  </div>
  <!-- /.sidebar -->
</aside>