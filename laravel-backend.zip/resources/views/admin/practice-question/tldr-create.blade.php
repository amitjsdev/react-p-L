@extends('admin.layouts.mainlayout')

@section('content')
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Video TLDRs</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active"><a href="/lessons-video-tldrs">Video TLDRs<a></li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>


    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            @if(session()->has('message'))
            <div class="alert alert-success">
                {{ session()->get('message') }}
            </div>
            @endif

            @if(session()->has('error'))
            <div class="alert alert-danger">
                {{ session()->get('error') }}
            </div>
            @endif

            <div class="row">
                <div class="col-md-12 edit-form">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">

                                <form method="post" enctype="multipart/form-data" action="/practice-sets/{{$videoTLDR->practiceSetId}}/questions/{{$videoTLDR->practiceQuestionId}}/tldr{{isset($videoTLDR->id) ? '/' : ''}}{{$videoTLDR->id}}">
                                    @csrf
                                    <input type="hidden" name="id" value="{{$videoTLDR->id}}">
                                    <div class="marginb10">
                                        <div class="left">Practice Set Id:</div>
                                        <div class="right">
                                            <div class="marginb10">
                                                <input class="form-control" name="practiceSetId" placeholder="Practice Set Id" value="{{ $videoTLDR->practiceSetId ?? old('practiceSetId')}}" />
                                            </div>
                                        </div>
                                    </div>
                                    <div style="clear:both">&nbsp;</div>

                                    <div class="marginb10">
                                        <div class="left">Practice Question Id:</div>
                                        <div class="right">
                                            <div class="marginb10">
                                                <input class="form-control" name="practiceQuestionId" placeholder="Practice Question Id" value="{{ $videoTLDR->practiceQuestionId ?? old('practiceQuestionId')}}" />
                                            </div>
                                        </div>
                                    </div>
                                    <div style="clear:both">&nbsp;</div>

                                    <!-- show data -->
                                    <h5>TLDR</h5>
                                    <div class="marginb10">
                                        <div class="left">Title:</div>
                                        <div class="right">
                                            <div class="marginb10">
                                                <input class="form-control" name="title" placeholder="Title" value="{{ $videoTLDR->title ?? old('title')}}" />
                                            </div>
                                        </div>
                                    </div>
                                    <div style="clear:both">&nbsp;</div>

                                    <div class="marginb10">
                                        <div class="left">Description:</div>
                                        <div class="right">
                                            <div class="marginb10">
                                                <textarea class="form-control" name="description" rows="5" placeholder="Description">{{ $videoTLDR->description ?? old('description')}}</textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div style="clear:both">&nbsp;</div>

                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-primary">Save</button>
                                    </div>
                            </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- /.card -->
            </div>


        </div>
        <!-- /.row -->


        <!-- /.row -->
</div><!-- /.container-fluid -->
</section>
</div>

@endsection