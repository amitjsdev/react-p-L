<!DOCTYPE html>
<html>

<head>
    <title>Career Launcher</title>
    <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://unpkg.com/vue"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        .text-taplingua {
            color: #7556D5;
        }

        .bg-taplingua {
            background-color: #7556D5;
            color: white;
        }

        .border-taplingua {
            border: 1px solid #7556D5;
        }

        .border-taplingua-b {
            border-bottom: 1px solid #7556D5;
        }

        .crossed {
            position: relative;
        }

        .crossed::after {
            position: absolute;
            bottom: 15px;
            display: block;
            content: "";
            height: 4px;
            width: 150px;
            left: calc(50% - 75px);
            margin: auto;
            background-color: #7556D5;
        }

        .enroll-button {
            color: white;
            font-weight: bold;
            padding: 8px 36px;
            border-radius: 5000000px;
            background-color: #7556D5;
        }

        table,
        td,
        th {
            border: 1px solid #707070;
        }

        td {
            padding: 4px 8px;
        }

        table {
            border-collapse: collapse;
            width: 100%;

        }

        .gray {
            background-color: #F4F4F4;
        }

        table>tbody>tr:nth-child(even)>td {
            background-color: #a3a3a344;
        }
    </style>
</head>

<body>
    <div id="app">
        <!-- section 1 -->
        <div class="p-6">
            <div class="text-center text-3xl font-bold mb-6 mt-20">Group Discussion in English</div>
            <div class="md:flex flex-row-reverse md:w-2/3 w-full lg:w-1/2 mx-auto items-center">
                <div class="md:w-1/2">
                    <img src="/career-site/image1.png" alt="Image 1">
                </div>
                <div class="md:w-1/2">
                    <div class="text-center text-lg font-bold">Practice Group Description <br> with Taplingua Mobile App
                    </div>
                    <div class="text-center py-6 text-lg">
                        <div class="text-taplingua font-bold text-xl mb-3">15 Days FREE trial</div>
                        <a v-bind:href="enrollLink" class="enroll-button">Enroll Now</a>
                    </div>
                </div>
            </div>
        </div><!-- section -->
        <div class="p-6">
            <div class="text-center text-3xl font-bold mt-20">Practice GD on Mobile App</div>
        </div>
        <!-- section 2 -->
        <div class="p-6 bg-gray-100">
            <div class="md:flex flex-row-reverse md:w-2/3 w-full lg:w-1/2 mx-auto items-center my-10">
                <div class="md:w-1/2 px-16">
                    <img src="/career-site/image2.png" width="240px" alt="Image 1">
                </div>
                <div class="md:w-1/2">
                    <div class="text-center py-6">
                        <div class="text-center text-2xl font-bold mb-5">Scenario based</div>
                        <div class="text-center text-gray-500">
                            Every lesson starts with a GD topic and a realistic scenario.
                            This helps you understand the context and how the
                            phrases and expressions
                            are used to participate effectively in GD.
                        </div>
                    </div>
                </div>
            </div>
            <div class="md:flex md:w-2/3 w-full lg:w-1/2 mx-auto items-center my-10">
                <div class="md:w-1/2 px-16">
                    <img src="/career-site/image3.png" width="240px" alt="Image 1">
                </div>
                <div class="md:w-1/2">
                    <div class="text-center py-6">
                        <div class="text-center text-2xl font-bold mb-5">In depth video tutorials</div>
                        <div class="text-center text-gray-500">
                            The app integrates short video tutorials in all the
                            lessons and have clear in-depth explanations so that
                            you can quickly
                            absorb new grammar and vocabulary
                            to be successful in a GD
                        </div>
                    </div>
                </div>
            </div>
            <div class="md:flex flex-row-reverse md:w-2/3 w-full lg:w-1/2 mx-auto items-center my-10">
                <div class="md:w-1/2 px-16">
                    <img src="/career-site/image4.png" width="240px" alt="Image 1">
                </div>
                <div class="md:w-1/2">
                    <div class="text-center py-6">
                        <div class="text-center text-2xl font-bold mb-5">Fun and Dynamic</div>
                        <div class="text-center text-gray-500">
                            Taplingua exercises are fun and makes you keep
                            coming back day after day. The games help you
                            create the habit that you really need to develop
                            your GD skills.
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- section -->
        <div class="p-6">
            <div class="text-center text-3xl font-bold mb-3">Group Discussion in English</div>
            <div class="text-center text-lg font-bold">Practice Group Description <br> with Taplingua Mobile App</div>
            <div class="text-center py-10 text-xl">
                <div class="text-taplingua font-bold text-xl mb-3">15 Days FREE trial</div>
                <a v-bind:href="enrollLink" class="enroll-button">Enroll Now</a>
            </div>
        </div>
        <!-- section -->
        <div class="p-6 bg-taplingua">
            <div class="text-center text-3xl font-bold mb-3">Watch the App in Action</div>
            <div class="md:flex justify-center mb-4 mt-10">
                <iframe height="240" src="https://www.youtube.com/embed/_dlpCYVbkmY" class="m-2 md:w-1/4">
                </iframe>
                <iframe height="240" src="https://www.youtube.com/embed/cT8E8sGcI6Y" class="m-2 md:w-1/4">
                </iframe>
                <iframe height="240" src="https://www.youtube.com/embed/V9AU3VZ9VAE" class="m-2 md:w-1/4">
                </iframe>
            </div>
        </div>
        <!-- section -->
        <div class="p-6">
            <div class="text-center text-3xl font-bold mb-3">Group Discussion in English</div>
            <div class="text-center text-lg font-bold">Course Plan</div>
        </div>

        <!-- section with table -->
        <div class="md:w-2/3 w-full lg:w-1/2 mx-auto">
            <div class="p-6" v-for="milestone in milestones">
                <div class="text-center font-semibold mb-3 text-taplingua uppercase">{{milestone.name}}</div>
                <table>
                    <tbody>
                        <tr v-for="lesson in milestone.data">
                            <td>{{lesson}}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- section -->
        <div class="p-6">
            <div class="text-center text-lg font-bold">Practice Group Description <br> with Taplingua Mobile App
            </div>
            <div class="text-center py-10 text-xl">
                <div class="text-taplingua font-bold text-xl mb-3">15 Days FREE trial</div>
                <a v-bind:href="enrollLink" class="enroll-button">Enroll Now</a>
            </div>
        </div>
        <!-- section - feedbacks -->
        <div class="p-6 gray">
            <div class="md:w-2/3 w-full lg:w-1/2 mx-auto">
                <div v-for="feedback in feedbacks" class="md:px-6 py-12 flex items-start">
                    <div class="feedback-image rounded-full w-20 h-20 flex-shrink-0" style="overflow: hidden;">
                        <img v-bind:src="feedback.image" alt="">
                    </div>
                    <div class="px-4 mt-2">
                        <div class="font-semibold">{{feedback.name}}</div>
                        <div class="font-semibold flex items-end">
                            <img src="/career-site/ratings.png" width="100px" v-bind:alt="feedback.rating" srcset="">
                            <span class="px-2">{{feedback.rating}}</span>
                        </div>

                        <div class="md:w-96 text-gray-500 text-sm">{{feedback.comment}}</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- section -->
        <div class="p-6">
            <div class="md:w-2/3 w-full lg:w-1/2 mx-auto border-taplingua">
                <div class="text-center text-3xl font-bold bg-taplingua p-4 pb-10">Practice Group Description <br> with Taplingua Mobile App
                </div>
                <div class="text-center py-10 text-xl border-taplingua-b">
                    <div class="text-taplingua font-bold text-3xl mb-5 crossed">Rs. 2000</div>
                    <div class="text-taplingua font-bold text-3xl mb-5">Rs. 1000</div>
                </div>
                <div class="text-center py-10 text-xl">
                    <div class="text-taplingua font-bold text-3xl mb-6">15 Days FREE trial</div>
                    <div class="text-taplingua text-2xl mb-10">To avail discount, you must <br> buy course before trail ends</div>
                    <a v-bind:href="enrollLink" class="enroll-button">Enroll Now</a>
                </div>
            </div>
        </div>

        <!-- section faq -->
        <div class="p-6">
            <div class="md:w-2/3 w-full lg:w-1/2 mx-auto">
                <div class="text-center text-3xl font-bold mb-3">Frequently asked questions?</div>
                <div class="my-5">
                    <div v-for="faq in faqs" class="my-10">
                        <div class="text-xl">{{faq.question}}</div>
                        <div class="text-sm text-gray-500">{{faq.answer}}</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- section -->
        <div class="p-6">
            <div class="text-center text-lg font-bold">Practice Group Description <br> with Taplingua Mobile App
            </div>
            <div class="text-center py-10 text-xl">
                <div class="text-taplingua font-bold text-xl mb-3">15 Days FREE trial</div>
                <a v-bind:href="enrollLink" class="enroll-button">Enroll Now</a>
            </div>
        </div>

    </div>

    <!-- scripts -->
    <script>
        var app = new Vue({
            el: '#app',
            data: {
                enrollLink: "https://api2.taplingua.com/app/employee-course-registration?courseNo=1532227012020",
                // milestones
                milestones: [{
                        name: "Milestone 1",
                        data: [
                            'Asking your opinions',
                            'Giving your opinion',
                            'Phrasal verbs 1',
                            'Responding to people\'s opinion',
                            'Modal verbs ‘shoud/could/would have’',
                            'Justifying your opinions and objectives',
                            'Present perfect continuous',
                        ]
                    },
                    {
                        name: "Milestone 2",
                        data: [
                            'Responding to people’s opinions (Agreeing and Disagreeing II) ',
                            'Responding to people’s opinions (Agreeing & Disagreeing III)',
                            'Clarifying something and understanding I',
                            'Clarifying something and understanding II',
                            'Clarifying something and understanding III',
                            'Dealing with interruptions',
                            'Responding to questions',
                        ]
                    },
                    {
                        name: "Milestone 3",
                        data: [
                            'Questioning and Clarifying. Connectors (Sequential order)',
                            'Talking about the future with ‘to be / be due to’ + infinitive',
                            'Responding to questions',
                            'Questioning and clarifying',
                            'Talking about the future with ‘to be/ be due to’ + infintive',
                            'Considering options',
                            'Phrasal verbs II (break in, set off, hold up, come up with, give away)',
                        ]
                    },
                    {
                        name: "Milestone 4",
                        data: [
                            'Summarizing  a Group discussion',
                            'Future continuous',
                            'Confirming agreements',
                            'Connectors (cause and consequence)',
                            'Outlining future goals and thanking everyone',
                            'Phrasal Verbs III',
                            'Review 7',
                        ]
                    },
                ],
                feedbacks: [{
                        image: "/career-site/arkya.png",
                        name: "Arkya Kumar",
                        rating: "4.8",
                        comment: "Taplingua is truly an amazing App that has helped me practice GD. The games are a lot of fun. and gets you addicted."
                    },
                    {
                        image: "/career-site/anjan.png",
                        name: "Anjan Jaiswal",
                        rating: "4.8",
                        comment: "Practice, practice practice. The games are really fun. Learnt a lot from completing the course."
                    },
                    {
                        image: "/career-site/minoti.png",
                        name: "Minoti Dubey",
                        rating: "4.8",
                        comment: "This is the best app I have found for self practice for GD. The videos are really helpful. And games are awesome. Very innovative app."
                    },
                ],
                faqs: [{
                        question: "Q. For whom is the course appropriate?",
                        answer: "The courses are appropriate for any student who is preparing for GD for CAT or GATE."
                    },
                    {
                        question: "Q. How long do I have access to the course",
                        answer: "You have access to this course for 1 year."
                    },
                    {
                        question: "Q. How long is the course?",
                        answer: "You are expected to complete the course in 5 weeks. However, if you feel more confident you can complete it sooner. We expect you to keep practicing the speaking exercises and role play to become more confident."
                    },
                    {
                        question: "Q. How will doubts be cleared",
                        answer: "You can send us a WhatsApp message with any questions and it will be answered within 4 hours. You can also ask questions in the Forum."
                    },
                ]
            }
        })
    </script>
</body>

</html>