<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="apple-touch-icon" sizes="180x180" href="https://www.taplingua.com/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="https://www.taplingua.com/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="https://www.taplingua.com/favicon-16x16.png">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Student Course Registration</title>
    <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
</head>

<body>
    <div class="mx-auto my-6 shadow p-3" style="max-width: 720px;">
        <div class="flex justify-center mb-5">
            <img src="/main-logo-alt.png" alt="" class="mx-auto w-48 mb-6">
        </div>
        <form action="/app/user-cohort-registration" method="post">
            @csrf
            <input type="hidden" name="cohort_id" value="{{$cohort->id}}">
            <div class="text-2xl font-medium">{{$cohort->name}}</div>
            <div class="mb-5">Use this form to register for Taplingua.</div>
            <!-- Email Address -->
            <label class="my-4 block">
                <div>Email Address <span class="text-red-500">*</span></div>
                <input type="email" class="block py-1 border-b md:w-1/2 w-full" placeholder="Valid Email Address" name="email" value="{{old('email')}}" required>
                @error('email')
                <span class="text-xs text-red-500">{{ $message }}</span>
                @enderror
            </label>
            <!-- First Name -->
            <label class="my-4 block">
                <div>What is your first name?</div>
                <input type="text" class="block py-1 border-b md:w-1/2 w-full" placeholder="First Name" value="{{old('FirstName')}}" name="FirstName">
                @error('FirstName')
                <span class="text-xs text-red-500">{{ $message }}</span>
                @enderror
            </label>
            <!-- Sur Name -->
            <label class="my-4 block">
                <div>What is your surname?</div>
                <input type="text" class="block py-1 border-b md:w-1/2 w-full" placeholder="Surname" value="{{old('LastName')}}" name="LastName">
                @error('LastName')
                <span class="text-xs text-red-500">{{ $message }}</span>
                @enderror
            </label>
            <!-- Whatsapp Number -->
            <label class="my-4 block">
                <div>What is your Whatsapp Number? (10 digit)</div>
                <input type="text" class="block py-1 border-b md:w-1/2 w-full" placeholder="Whatsapp Number" value="{{old('mobile')}}" name="mobile">
                @error('mobile')
                <span class="text-xs text-red-500">{{ $message }}</span>
                @enderror
            </label>
            <!-- Location -->
            <label class="my-4 block">
                <div>In which city do you live in?</div>
                <input type="text" class="block py-1 border-b md:w-1/2 w-full" placeholder="City" value="{{old('location')}}" name="location">
                @error('location')
                <span class="text-xs text-red-500">{{ $message }}</span>
                @enderror
                @error('courseNo')
                <span class="text-xs text-red-500">{{ $message }}</span>
                @enderror
                @if(session('error'))
                <span class="text-xs text-red-500">{{ session('error') }}</span>
                @endif
                @if(session('message'))
                <span class="text-xs text-green-500">{{ session('message') }}</span>
                @endif
               
            </label>
            <button class="bg-blue-500 text-white px-4 py-1 shadow rounded">Submit</button>
        </form>
        @if(session('debug'))
                <div id="lkmdebug" style="display:none">{{ session('debug') }}</div>
          @endif
    </div>
</body>

</html>