<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="apple-touch-icon" sizes="180x180" href="https://www.taplingua.com/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="https://www.taplingua.com/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="https://www.taplingua.com/favicon-16x16.png">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Employee Course Registration Success</title>
    <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
</head>

<body>
    <div class="mx-auto my-6 p-3 text-center" style="max-width: 720px;">
        <div class="flex justify-center mb-5">
            <img src="/main-logo-alt.png" alt="" class="mx-auto w-48 mb-6">
        </div>
        <div class="mb-10">
            @if(session('message'))
            {{session('message')}}
            @else
            Thanks for registering on Taplingua
            @endif
        </div>
        <div class="mb-10">Please check your email for further instructions. Please also check your spam folder if you don't see it in the inbox.</div>
        <!-- <div>https://play.google.com/store/apps/details?id=com.taplingua.languages</div> -->
        {{-- <div class="my-5 flex justify-center">
            <a href='https://play.google.com/store/apps/details?id=com.taplingua.languages&pcampaignid=pcampaignidMKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1'>
                <img alt='Get it on Google Play' src='https://play.google.com/intl/en_us/badges/static/images/badges/en_badge_web_generic.png' class="w-36 mx-auto" />
            </a>
        </div> --}}
    </div>
</body>

</html>
