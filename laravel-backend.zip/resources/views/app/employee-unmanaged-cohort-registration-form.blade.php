<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="apple-touch-icon" sizes="180x180" href="https://www.taplingua.com/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="https://www.taplingua.com/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="https://www.taplingua.com/favicon-16x16.png">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Employee Course Registration</title>
    <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
</head>

<body>
    <div class="mx-auto my-6 shadow p-3" style="max-width: 720px;">
        <div class="flex justify-center mb-5">
            <img src="/main-logo-alt.png" alt="" class="mx-auto w-48 mb-6">
        </div>
        <form action="{{ $program && $company ? "/app/user-cohort-registration/company/$company->Id/program/$program->id" : "/app/user-cohort-registration-dynamic" }}" method="post">
            @csrf
            @if($program)
            <div class="text-2xl font-medium">{{$program->name}}</div>
            <div class="mb-5">Use this form to register for Taplingua.</div>
            @error('program_id')
            <span class="text-xs text-red-500">{{ $message }}</span>
            @enderror
            <input type="hidden" name="program_id" value="{{$program->id}}">
            @else
            <!-- Program Id -->
            <label class="my-4 block">
                <div>Program Id <span class="text-red-500">*</span></div>
                <input type="text" class="block py-1 border-b md:w-1/2 w-full" placeholder="Program Id" name="program_id" value="{{old('program_id')}}" required>
                @error('program_id')
                <span class="text-xs text-red-500">{{ $message }}</span>
                @enderror
            </label>
            @endif
            @if($company)
            @error('company_code')
            <span class="text-xs text-red-500">{{ $message }}</span>
            @enderror
            <input type="hidden" name="company_code" value="{{$company->Id}}">
            @else
            <!-- Company Code -->
            <label class="my-4 block">
                <div>Company Code <span class="text-red-500">*</span></div>
                <input type="text" class="block py-1 border-b md:w-1/2 w-full" placeholder="Company Code" name="company_code" value="{{old('company_code')}}" required>
                @error('company_code')
                <span class="text-xs text-red-500">{{ $message }}</span>
                @enderror
            </label>
            @endif
            <!-- Email Address -->
            <label class="my-4 block">
                <div>Email Address <span class="text-red-500">*</span></div>
                <input type="email" class="block py-1 border-b md:w-1/2 w-full" placeholder="Valid Email Address" name="email" value="{{old('email')}}" required>
                @error('email')
                <span class="text-xs text-red-500">{{ $message }}</span>
                @enderror
            </label>
            <!-- First Name -->
            <label class="my-4 block">
                <div>What is your first name?</div>
                <input type="text" class="block py-1 border-b md:w-1/2 w-full" placeholder="First Name" value="{{old('FirstName')}}" name="FirstName">
                @error('FirstName')
                <span class="text-xs text-red-500">{{ $message }}</span>
                @enderror
            </label>
            <!-- Sur Name -->
            <label class="my-4 block">
                <div>What is your surname?</div>
                <input type="text" class="block py-1 border-b md:w-1/2 w-full" placeholder="Surname" value="{{old('LastName')}}" name="LastName">
                @error('LastName')
                <span class="text-xs text-red-500">{{ $message }}</span>
                @enderror
            </label>
            <!-- Whatsapp Number -->
            <label class="my-4 block">
                <div>What is your Whatsapp Number? (10 digit)</div>
                <input type="text" class="block py-1 border-b md:w-1/2 w-full" placeholder="Whatsapp Number" value="{{old('mobile')}}" name="mobile">
                @error('mobile')
                <span class="text-xs text-red-500">{{ $message }}</span>
                @enderror
            </label>
            <!-- Location -->
            <label class="my-4 block">
                <div>In which city do you live in?</div>
                <input type="text" class="block py-1 border-b md:w-1/2 w-full" placeholder="City" value="{{old('location')}}" name="location">
                @error('location')
                <span class="text-xs text-red-500">{{ $message }}</span>
                @enderror
                @error('courseNo')
                <span class="text-xs text-red-500">{{ $message }}</span>
                @enderror
                @if(session('error'))
                <span class="text-xs text-red-500">{{ session('error') }}</span>
                @endif
                @if(session('message'))
                <span class="text-xs text-green-500">{{ session('message') }}</span>
                @endif
            </label>
            <button class="bg-blue-500 text-white px-4 py-1 shadow rounded">Submit</button>
        </form>
    </div>
</body>

</html>