<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Taplingua Languages &#8211; Practical, job focused language learning skills</title>
    <meta name="description" content="">
    <meta name="keywords" content="">
    <link rel="icon" href="/favicon.ico?v=3" sizes="16x16" type="image/svg+xm" />
    <link rel="stylesheet" href="https://gateflix.in/taplingua/css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="https://gateflix.in/taplingua/css/product/category-testmonials.css">
    <link rel="stylesheet" href="https://gateflix.in/taplingua/css/tiny-slider.css" />
    <!-- tobii css -->
    <link href="https://gateflix.in/taplingua/css/tobii.min.css" rel="stylesheet" type="text/css" />
    <!-- Custom CSS -->
    <link rel="stylesheet" href="https://gateflix.in/taplingua/css/style.css" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.3/css/fontawesome.min.css">
    <!-- Start Recaptcha script -->
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        var SubmitButtonId = 'btn';
        var captchDivId = 'captchaId';
    </script>


    <style>
        .hide-new {
            display: none;
        }
    </style>

    <script>
        jQuery(document).on('click', 'a.smothscroll[href^="#"]', function(event) {
            event.preventDefault();

            jQuery('html, body').animate({
                scrollTop: jQuery($.attr(this, 'href')).offset().top - 70
            }, 500);
        });
    </script>

</head>

<body onLoad="showUrl();">
    <!-- <script src="/js/header-latest.js"></script> -->
    <!-- Google Tag Manager -->
    <noscript>
        <iframe src="//www.googletagmanager.com/ns.html?id=GTM-MG7FKN" height="0" width="0" style="display:none;visibility:hidden"></iframe>
    </noscript>


    <nav class="navbar navbar-default">
        <div class="container">
            <div class="navbar-header col-md-3">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#" style="display: flex;align-items: center;">
                    <img src="/taplingua-cohort-logo.png" height="40" class="logo-light-mode" alt="">
                    <span>&nbsp;</span>
                    <img src="https://langappnew.s3.amazonaws.com/logos/{{$company_code}}.jpeg" height="40" alt="" />
                    <span>&nbsp;</span>
                    <span style="flex-grow: 1; flex-shrink: 0;"> {{substr($company_name, 0, 15)}} </span>
                </a>
                <!--    <a class="logo" href="index.html">
                    <img src="images2/logo.png" height="40" class="logo-light-mode" alt="">
                </a> -->
            </div>
            <div id="navbar" class="navbar-collapse collapse" aria-expanded="false" style="height: 1px;">
                <ul class="nav navbar-nav">
                    <li class="active"><a href="#15_Days_Trial">15-Days Free Trial</a></li>
                    <li><a href="#Features">Features</a></li>
                    <li><a href="#Course_Plan">Course Plan</a></li>
                    <li><a href="#Testimonials">Testimonials</a></li>
                    <li><a href="#Faq">Faq</a></li>

                </ul>
            </div>
            <!--/.nav-collapse -->
        </div>
        <!--/.container-fluid -->
    </nav>


    <section class="baner-region" id="15_DaysS_Trial">

        <div class="bg-overlay"></div>
        <div class="container">
            <div class="row banner-row">
                <div class="col-md-7 col-xs-12">
                    <h1>Master the Group Discussion with Mobile App</h1>
                    <!--<h2>Practice Group Description with Taplingua</h2>-->
                    <p>Taplingua mobile App provides realistic scenarios, in-depth video tutorials and fun games to help you master the Group Discussion.</p>
                    <!-- <h3><span>15 Days</span> FREE trial</h3> -->

                </div>


                <div class="col-md-4 col-md-offset-1 col-xs-12">
                    <div class="form-box" id="frm">
                        <h4>Start here for 15-Days Free Trial </h4>
                        <form name="clForm" action="/app/user-cohort-registration/company/153/program/1" method="post" onSubmit="return validate();">
                            @csrf
                            <input type="hidden" name="utm_source" value='Website'>
                            <input type="hidden" name="utm_campaign" value='Taplingua'>
                            <input type="hidden" name="utm_term" value='https://www.careerlauncher.com/taplingua'>
                            <input type="hidden" name="utm_medium" value='SEO'>
                            <input type="hidden" name="cl_target_list" value='Taplingua'>
                            <input type="hidden" name="cl_prod_category" value='PG_ENGG'>
                            <input type="hidden" name="cl_prod_group" value='GD-PI'>
                            <input type="hidden" name="cl_campaign_name" value='Taplingua'>
                            <input type="hidden" id="url" name="url">
                            <input type="hidden" name="program_id" value="1">
                            <input type="hidden" name="company_code" value="{{$company_code}}">


                            <div class="row">
                                <div class="form-group col-md-12">
                                    <input type="text" class="form-control captialize" placeholder="First Name" id="name" name="FirstName" maxlength="50" required="" value="{{old('FirstName')}}">
                                    @error('FirstName')
                                    <span class="text-xs text-red-500">{{ $message }}</span>
                                    @enderror
                                </div>

                                <div class="form-group col-md-12">
                                    <input type="text" class="form-control captialize" placeholder="Last Name" id="lname" name="LastName" maxlength="50" required="" value="{{old('LastName')}}">
                                    @error('LastName')
                                    <span class="text-xs text-red-500">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="form-group col-md-12">
                                    <input type="email" class="form-control" placeholder="Email" name="email" id="email" maxlength="70" required="" value="{{old('email')}}">
                                    @error('email')
                                    <span class="text-xs text-red-500">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="form-group col-md-12">
                                    <input type="text" class="form-control" placeholder="Mobile Number" name="mobile" id="mobile" maxlength="10" required="" pattern="\d{10}" value="{{old('Mobile')}}">
                                    @error('mobile')
                                    <span class="text-xs text-red-500">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="form-group col-md-12">
                                    <input type="text" class="form-control captialize" placeholder="City" name="location" id="city" maxlength="70" required="" value="{{old('location')}}">
                                    @error('location')
                                    <span class="text-xs text-red-500">{{ $message }}</span>
                                    @enderror
                                    @error('program_id')
                                    <span class="text-xs text-red-500">{{ $message }}</span>
                                    @enderror
                                    @error('company_code')
                                    <span class="text-xs text-red-500">{{ $message }}</span>
                                    @enderror
                                    @error('courseNo')
                                    <span class="text-xs text-red-500">{{ $message }}</span>
                                    @enderror
                                    @if(session('error'))
                                    <span class="text-xs text-red-500">{{ session('error') }}</span>
                                    @endif
                                    @if(session('message'))
                                    <span class="text-xs text-green-500">{{ session('message') }}</span>
                                    @endif
                                </div>

                                <div class="form-group col-md-12">
                                    <div id="captchaId"></div>
                                </div>

                            </div>

                            <button class="btn theme-btn btn-arrow" type="submit" id="btn" value="submit">Submit</button>

                        </form>
                        <script src="https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit" async defer></script>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <section class="process" id="Features">
        <div class="container">
            <h2 class="sub-heading text-center">Practice GD on Mobile App</h2>
            <div class="row">
                <div class="col-md-8 top90">
                    <h3>Scenario based</h3>
                    <p>Every lesson starts with a GD topic and a realistic scenario. This helps you understand the context and how the phrases and expressions are used to participate effectively in GD.</p>
                </div>
                <div class="col-md-4 text-left">
                    <img src="https://gateflix.in/taplingua/images2/t-image1.png" class="img-responsive" width="300">
                </div>
            </div>

            <div class="row flexuse">
                <div class="col-md-4 top30 contedtop">
                    <img src="https://gateflix.in/taplingua/images2/t-image2.png" class="img-responsive" width="300">
                </div>
                <div class="col-md-8 top90 formcontfld">
                    <h3>In-depth video tutorials</h3>
                    <p>The app integrates short video tutorials in all the lessons and has clear in-depth explanations so that you can quickly absorb new grammar and vocabulary to be successful in a GD.</p>
                </div>
            </div>

            <div class="row">
                <div class="col-md-8 top90">
                    <h3>Fun and Dynamic</h3>
                    <p>Taplingua exercises are fun and makes you keep coming back day after day. The games help you create the habit that you really need to develop your GD skills.</p>
                </div>
                <div class="col-md-4 top30">
                    <img src="https://gateflix.in/taplingua/images2/t-image3.png" class="img-responsive" width="300">
                </div>
            </div>

        </div>
    </section>

    <section class="seven-part butns">
        <div class="container">
            <div class="msg-block">
                <div class="row">
                    <div class="col-md-9 msg-content">
                        <h3>Group Discussion in English</h3>
                        <p>Practice Group Discussion with Taplingua Mobile App</p>
                    </div>


                    <div class="col-md-3 text-center">
                        <p><span>15 Days FREE trial</span></p>
                        <a class="btn btn-warning smothscroll" href="#frm">Enroll Now</a>
                    </div>

                </div>
            </div>

        </div>
    </section>


    <section class="watch video-section testmonials-pull">
        <div class="container">
            <h2 class="sub-heading text-center white">Watch the App in Action</h2>
            <div class="mentors-details">
                <div class="row">
                    <div class="slider container d-flex">

                        <div class="col-md-4 col-sm-4 active">
                            <div class="wrap-small"></div>
                            <div class="video-player-wrap">
                                <div class="video-player d-table text-center">
                                    <div class="d-table-cell align-middle">
                                        <div class="play-icon">
                                            <a href="#!" data-type="youtube" data-id="_dlpCYVbkmY" class="play-btn lightbox">
                                                <i class="fa fa-play"></i><i class="mdi mdi-play text-primary rounded-circle bg-white shadow"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4 col-sm-4">
                            <div class="wrap-small"></div>
                            <div class="video-player-wrap wrap">
                                <div class="video-player d-table text-center">
                                    <div class="d-table-cell align-middle">
                                        <div class="play-icon">
                                            <a href="#!" data-type="youtube" data-id="cT8E8sGcI6Y" class="play-btn lightbox">
                                                <i class="fa fa-play"></i><i class="mdi mdi-play text-primary rounded-circle bg-white shadow"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4 col-sm-4">
                            <div class="wrap-small"></div>
                            <div class="video-player-wrap wrap1">
                                <div class="video-player d-table text-center">
                                    <div class="d-table-cell align-middle">
                                        <div class="play-icon">
                                            <a href="#!" data-type="youtube" data-id="V9AU3VZ9VAE" class="play-btn lightbox">
                                                <i class="fa fa-play"></i><i class="mdi mdi-play text-primary rounded-circle bg-white shadow"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
            </div>


        </div>
    </section>

    <section class="butns" id="Course_Plan">
        <div class="container">
            <h2 class="sub-heading text-center">Course Plan</h2>
            <div class="row">

                <div class="col-md-3">
                    <div class="tw-half">
                        <h5>Milestone 1</h5>
                        <ul>
                            <li>Asking for opinions</li>
                            <li>Giving your opinion</li>
                            <li>Phrasal verbs I</li>
                            <li>Responding to people's opinion</li>
                            <li>Modal verbs 'shoud/could/would have'</li>
                            <li>Justifying your opinions and objectives</li>
                            <li>Present perfect continuous</li>
                        </ul>
                        <a href="#frm" class="btn btn-primary smothscroll">Enroll Now</a>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="tw-half">
                        <h5>Milestone 2</h5>
                        <ul>
                            <li>Responding to people’s opinions (Agreeing and Disagreeing II) </li>
                            <li>Responding to people’s opinions (Agreeing &amp; Disagreeing III)</li>
                            <li>Clarifying something and understanding I</li>
                            <li>Clarifying something and understanding II</li>
                            <li>Clarifying something and understanding III</li>
                            <li>Dealing with interruptions</li>
                            <li>Responding to questions</li>
                        </ul>
                        <a href="#frm" class="btn btn-primary smothscroll">Enroll Now</a>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="tw-half">
                        <h5>Milestone 3</h5>
                        <ul>
                            <li>Questioning and Clarifying. Connectors (Sequential order)</li>
                            <li>Responding to questions</li>
                            <li>Questioning and clarifying</li>
                            <li>Talking about the future with ‘to be/ be due to’ + infintive</li>
                            <li>Considering options</li>
                            <li>Phrasal verbs II (break in, set off, hold up, come up with, give away)</li>
                        </ul>
                        <a href="#frm" class="btn btn-primary smothscroll">Enroll Now</a>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="tw-half">
                        <h5>Milestone 4</h5>
                        <ul>
                            <li>Summarizing a Group discussion</li>
                            <li>Future continuous</li>
                            <li>Confirming agreements</li>
                            <li>Connectors (cause and consequence)</li>
                            <li>Outlining future goals and thanking everyone</li>
                            <li>Phrasal Verbs III</li>
                        </ul>
                        <a href="#frm" class="btn btn-primary smothscroll">Enroll Now</a>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <section class="testmonials-pull" id="Testimonials">

        <div class="container">
            <h2 class="sub-heading white text-center">Our Testimonials</h2>

            <div class="mentors-details">
                <div class="row">
                    <div class="regular slider">

                        <div class="col-md-4 col-sm-4 col-xs-12">
                            <div class="mentor-profile">
                                <img src="https://gateflix.in/taplingua/images2/arkya.png">
                                <h5>Arkya Kumar</h5>
                                <div class="raiting">
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star-half-o" aria-hidden="true"></i> <span>4.8</span> </div>
                                <p>Taplingua is truly an amazing App that has helped me practice GD. The games are a lot of fun and the App gets you addicted.</p>
                            </div>
                        </div>

                        <div class="col-md-4 col-sm-4 col-xs-12">
                            <div class="mentor-profile">
                                <img src="https://gateflix.in/taplingua/images2/anjan.png">
                                <h5>Anjan Jaiswal</h5>
                                <div class="raiting">
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star-half-o" aria-hidden="true"></i> <span>4.8</span> </div>
                                <p>Practice, practice practice. The games are really fun. Learnt a lot from completing the course.</p>
                            </div>
                        </div>

                        <div class="col-md-4 col-sm-4 col-xs-12">
                            <div class="mentor-profile">
                                <img src="https://gateflix.in/taplingua/images2/minoti.png">
                                <h5>Minoti Dubey</h5>
                                <div class="raiting">
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star-half-o" aria-hidden="true"></i> <span>4.8</span> </div>
                                <p>This is the best app I have found for self practice for GD. The videos are really helpful. And games are awesome. Very innovative app.</p>
                            </div>
                        </div>

                    </div>
                </div>



            </div>


        </div>
    </section>




    <section class="same-block faq-block page-section" id="Faq">
        <div class="container">
            <h2 class="sub-heading text-center">Frequently Asked Questions</h2>
            <div class="panel-group accordion-panel collapse in" id="accordion2" role="tablist" aria-multiselectable="true" aria-expanded="true">
                <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="heading-1">
                        <h4 class="panel-title">
                            <a role="button" data-toggle="collapse" data-parent="#accordion2" href="#collapse-1" aria-expanded="true" aria-controls="collapseOne">
                                For whom is the course appropriate?
                            </a>
                        </h4>
                    </div>
                    <div id="collapse-1" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="heading-1">
                        <div class="panel-body">
                            <p>The courses are appropriate for any student who is preparing for GD for CAT or GATE.</p>

                        </div>
                    </div>
                </div>

                <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="heading-2">
                        <h4 class="panel-title">
                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion2" href="#collapse-2" aria-expanded="false" aria-controls="collapseTwo">How long do I have access to the course</a>
                        </h4>
                    </div>
                    <div id="collapse-2" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading-2">
                        <div class="panel-body">
                            <p>You have access to this course for 1 year.</p>
                        </div>
                    </div>
                </div>

                <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="heading-3">
                        <h4 class="panel-title">
                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion2" href="#collapse-3" aria-expanded="false" aria-controls="collapse-3">How long is the course?</a>
                        </h4>
                    </div>
                    <div id="collapse-3" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading-3">
                        <div class="panel-body">
                            <p>You are expected to complete the course in 5 weeks. However, if you feel more confident you can complete it sooner. We expect you to keep practicing the speaking exercises and role play to become more confident.</p>
                        </div>
                    </div>
                </div>

                <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="heading-4">
                        <h4 class="panel-title">
                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion2" href="#collapse-4" aria-expanded="false" aria-controls="collapse-4">How will doubts be cleared</a>
                        </h4>
                    </div>
                    <div id="collapse-4" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading-4">
                        <div class="panel-body">
                            <p>You can send us a WhatsApp message with any questions and it will be answered within 4 hours. You can also ask questions in the Forum.</p>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="course-title" style="padding-bottom: 0;">
        <div class="container">
            <div class="container">
                <h2 class="sub-heading text-center">Explore the Full Programme in Business English Communications</h2>
                <div class="">
                </div>
            </div>
        </div>
    </section>

    <section class="course" style="padding-top: 0;">
        <div class="container course-box">
            <div class="course-slide-wrape">
                <h2 class="sub-heading text-center">Foundation Programme for Business English (App based)</h2>
                <div class="course-slider">
                    <div class="course-content">
                        <div class="course-img">
                            <img src="https://gateflix.in/taplingua/img/icon_module_skype_and_telephone.png">
                        </div>
                        <div class="course-des" style="display: table; height: 150px; overflow: hidden;">
                            <div style="display: table-cell; vertical-align: middle;">
                                <div>
                                    <strong>English for Skype/Telephone Calls</strong>
                                    Objectives of the Course: Being able to communicate over the phone or Skype in English with clients, partners, colleagues and providers in a business-like and professional manner.
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="course-content">
                        <div class="course-img">
                            <img src="https://gateflix.in/taplingua/img/icon_module_meetings.png">
                        </div>
                        <div class="course-des" style="display: table; height: 150px; overflow: hidden;">
                            <div style="display: table-cell; vertical-align: middle;">
                                <div>
                                    <strong>English for Meetings</strong>
                                    Objectives of the Course: Being able to attend or conduct a meeting in English: set the agenda and objectives of the meeting, prioritize objectives, express opinions, justify opinions, etc
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="course-content">
                        <div class="course-img">
                            <img src="https://gateflix.in/taplingua/img/icon_module_negotiations.png">
                        </div>
                        <div class="course-des" style="display: table; height: 150px; overflow: hidden;">
                            <div style="display: table-cell; vertical-align: middle;">
                                <div>
                                    <strong>English for Negotiations</strong>
                                    Objectives of the Course: Being able to plan, lead and/or manage a negotiation in English with clients, partners and providers: Make, accept and reject proposals, offer counter proposals, etc
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="course-content">
                        <div class="course-img">
                            <img src="https://gateflix.in/taplingua/img/icon_module_presentations.png">
                        </div>
                        <div class="course-des" style="display: table; height: 150px; overflow: hidden;">
                            <div style="display: table-cell; vertical-align: middle;">
                                <div>
                                    <strong>Course Outline for Presentations</strong>
                                    Course objectives: Learn how to introduce yourself and the topic, justify the theme, present a plan or scheme, present a point of view, emphasize the main points, etc.
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="course-content">
                        <div class="course-img">
                            <img src="https://gateflix.in/taplingua/img/icon_module_networking.png">
                        </div>
                        <div class="course-des" style="display: table; height: 150px; overflow: hidden;">
                            <div style="display: table-cell; vertical-align: middle;">
                                <div>
                                    <strong>English for Networking</strong>
                                    Objectives of the Course: Being able to communicate with other business professionals in English: introduce yourself, your company and products/services, discuss main trends, etc
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="course-content">
                        <div class="course-img">
                            <img src="https://gateflix.in/taplingua/img/icon_module_email.png">
                        </div>
                        <div class="course-des" style="display: table; height: 150px; overflow: hidden;">
                            <div style="display: table-cell; vertical-align: middle;">
                                <div>
                                    <strong>English for Emails</strong>
                                    Objective of the Course: Being able to communicate over email in English with clients, partners, colleagues and providers in a business-like and professional manner.
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="course-content">
                        <div class="course-img">
                            <img src="https://gateflix.in/taplingua/img/icon_module_group_discussion.png">
                        </div>
                        <div class="course-des" style="display: table; height: 150px; overflow: hidden;">
                            <div style="display: table-cell; vertical-align: middle;">
                                <div>
                                    <strong>English for Group Discussion</strong>
                                    Objective of the Course: Being able to participate in a GD, provide effective arguments, ask and give opinions, clarify and question other participants and summarize the GD
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="course-content">
                        <div class="course-img">
                            <img src="https://gateflix.in/taplingua/img/icon_module_interview.png">
                        </div>
                        <div class="course-des" style="display: table; height: 150px; overflow: hidden;">
                            <div style="display: table-cell; vertical-align: middle;">
                                <div>
                                    <strong>English for Personal Interviews</strong>
                                    Objective of the Course: Being able to attend interviews with confidence. Able to handle a range of situations in interviews like strengths, weaknesses, educational qualifications, goals & plans
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="">
            </div>
        </div>
    </section>

    <section class="seven-part butns">
        <div class="container">
            <div class="msg-block">
                <div class="row">
                    <div class="col-md-9 msg-content">
                        <h3>Group Discussion in English</h3>
                        <p>Practice Group Discussion with Taplingua Mobile App</p>
                    </div>
                    <div class="col-md-3 text-center">
                        <p><span>15 Days FREE trial</span></p>
                        <a class="btn btn-warning smothscroll" href="#frm">Enroll Now</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="https://gateflix.in/taplingua/js/bootstrap.min.js"></script>
    <script src="https://gateflix.in/taplingua/js/fontawesome.js"></script>
    <style type="text/css">
        section#Features .row img {
            margin: 0 auto;
        }

        @media only screen and (max-width: 600px) {
            iframe {
                width: 100%;
                height: 100%;
            }
        }

        @media screen and (min-device-width: 801px) and (max-device-width: 991px) {
            .navbar-default .navbar-nav>li>a {
                padding-left: 12px;
            }
        }

        @media screen and (min-device-width: 769px) and (max-device-width: 991px) {
            .form-box {
                margin: 20px 0px;
            }
        }
    </style>
    <script type="text/javascript">
        $(document).ready(function() {
            //Examples of how to assign the Colorbox event to elements				
            $(".inline").colorbox({
                inline: true
            });

            /*$('.video').on('click', function(ev) { 
            $("#inline_content .play").click();
            ev.preventDefault();
            });*/

            $('.video1').on('click', function(ev) {
                $("#inline_content .play").click();
                ev.preventDefault();
            });

            $('.video2').on('click', function(ev) {
                $("#inline_content1 .play").click();
                ev.preventDefault();
            });

            $('.video3').on('click', function(ev) {
                $("#inline_content2 .play").click();
                ev.preventDefault();
            });

            $('.video4').on('click', function(ev) {
                $("#inline_content3 .play").click();
                ev.preventDefault();
            });

            $('.video5').on('click', function(ev) {
                $("#inline_content6 .play").click();
                ev.preventDefault();
            });


            $('.video6').on('click', function(ev) {
                $("#inline_content7 .play").click();
                ev.preventDefault();
            });

        });
        // Light YouTube Videos 
        document.addEventListener("DOMContentLoaded",
            function() {
                var div, n,
                    v = document.getElementsByClassName("youtube-player");
                for (n = 0; n < v.length; n++) {
                    div = document.createElement("div");
                    div.setAttribute("data-id", v[n].dataset.id);
                    div.innerHTML = labnolThumb(v[n].dataset.id);
                    div.onclick = labnolIframe;

                    v[n].appendChild(div);
                }
            });

        function labnolThumb(id) {
            var thumb = '<img src="https://i.ytimg.com/vi/ID/hqdefault.jpg">',
                play = '<div class="play"></div>';
            return thumb.replace("ID", id) + play;
        }

        function labnolIframe() {
            var iframe = document.createElement("iframe");
            var embed = "https://www.youtube.com/embed/ID?autoplay=1";
            iframe.setAttribute("src", embed.replace("ID", this.dataset.id));
            iframe.setAttribute("frameborder", "0");
            iframe.setAttribute("allowfullscreen", "1");
            iframe.setAttribute("allowfullscreen", "1");
            this.parentNode.replaceChild(iframe, this);
        }

        if (window.matchMedia('(max-width: 768px)').matches) {
            //$( "#offersregion" ).append( $( ".postionchngcon" ) );
        }
    </script>


    <div style='display:none'>
        <div id="inline_content" class="popup-outer">
            <div class="youtube-player" data-id="_dlpCYVbkmY"></div>
        </div>
        <div id="inline_content1" class="popup-outer">
            <div class="youtube-player" data-id="cT8E8sGcI6Y"></div>
        </div>

        <div id="inline_content2" class="popup-outer">
            <div class="youtube-player" data-id="V9AU3VZ9VAE"></div>
        </div>



    </div>

    <script src="https://gateflix.in/taplingua/js/product/slick.min.js"></script>
    <script src="https://gateflix.in/taplingua/js/plugins.init.js"></script>
    <!--Note: All init js like tiny slider, counter, countdown, maintenance, lightbox, gallery, swiper slider, aos animation etc.-->
    <script src="https://gateflix.in/taplingua/js/app.js"></script>
    <!-- <script>
$(document).ready(function(){
$( ".navbar-brand img" ).replaceWith( "<img src='https://clsite-file.s3.amazonaws.com/6858_cl-taplingua.png'>" );
});
</script> -->

    <script>
        $(document).ready(function() {

            $(".regular").slick({
                dots: true,
                infinite: true,
                slidesToShow: 3,
                slidesToScroll: 1,
                autoplay: true,
                pauseOnHover: true,
                autoplaySpeed: 2000,

                responsive: [{
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 2
                        }
                    },
                    {
                        breakpoint: 600,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 2
                        }
                    },
                    {
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1
                        }
                    }
                ]
            });
        });
    </script>


    <script type="text/javascript">
        $('.course-slider').slick({
            dots: true,
            infinite: true,
            arrows: true,
            autoplaySpeed: 2000,
            slidesToShow: 1,
            slidesToScroll: 1,
            autoplay: true,
        });
    </script>


    <script src="https://gateflix.in/taplingua/js/bootstrap.bundle.min.js"></script>
    <!-- SLIDER -->
    <script src="https://gateflix.in/taplingua/js/tiny-slider.js "></script>
    <!-- Icons -->
    <script src="https://gateflix.in/taplingua/js/feather.min.js"></script>
    <!-- tobii js -->
    <script src="https://gateflix.in/taplingua/js/tobii.min.js "></script>
    <!-- Main Js -->
    <script src="https://gateflix.in/taplingua/js/plugins.init.js"></script>
    <!--Note: All init js like tiny slider, counter, countdown, maintenance, lightbox, gallery, swiper slider, aos animation etc.-->
    <script src="https://gateflix.in/taplingua/js/app.js"></script>
    <!--Note: All important javascript like page loader, menu, sticky menu, menu-toggler, one page menu  -->
    <style>
        .text-xs {
            font-size: 12px;
        }

        .text-red-500 {
            color: red;
        }
    </style>

</body>

</html>