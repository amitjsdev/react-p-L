<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{$forum->title}}</title>
    <link href="https://fonts.googleapis.com/css2?family=Mallanna&family=Montserrat:wght@100;200;300;400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('/fonts/fonts.css') }}">
</head>

<body>
    <style>
        body {
            background-color: #eee;
            font-size: 0.9rem;
            font-family: 'SF Pro Display', Arial, Helvetica, sans-serif;
        }

        textarea,
        button {
            font-family: 'SF Pro Display', Arial, Helvetica, sans-serif;
        }

        .alert {
            display: inline-block;
            border-radius: 5px;
            padding: 0.5rem 0.75rem;
            font-size: 0.8rem;
            margin-bottom: 1rem;
            box-shadow: 0px 3px 5px 0px #0001;
        }

        .error {
            background-color: red;
            color: white;
        }

        .success {
            background-color: green;
            color: white;
        }

        .lonely {
            margin: 0;
        }

        .lonely .lonely-message {
            margin-bottom: 1rem;
        }


        .lonely .emoji-set {
            display: flex;
            height: 50px;
            align-items: center;
        }

        .lonely .emoji {
            font-size: 1.5rem;
            cursor: pointer;
            transition: all 0.4s;
        }


        .lonely .emoji:hover {
            font-size: 2rem;
        }

        .card,
        .comment-box {
            background-color: white;
            border-radius: 5px;
            padding: 1rem;
            margin-bottom: 0.5rem;
            box-shadow: 0px 3px 5px 0px #0001;
        }


        .reply-box:not(:last-of-type) {
            padding-bottom: 0.5rem;
            border-bottom: 1px solid lightgrey;
        }

        .comment-box .editable {
            display: none;
        }

        .forum-title {
            font-weight: bold;
            font-size: 1.1rem;
            color: #222;
            padding-bottom: 0.5rem;
            margin-bottom: 0.5rem;
            border-bottom: 1px solid #aaa;
        }

        .comment {
            margin: 0;
            margin-bottom: -15px;
            padding-bottom: 0.5rem;
        }

        .user {
            font-size: 0.8rem;
            padding-right: 5px;
            color: #444;
        }

        .time {
            font-size: 0.8rem;
            padding-right: 5px;
            color: #aaa;
        }

        a.upvote {
            color: grey;
            font-size: 0.8rem;
            padding-left: 5px;
            padding-right: 5px;
            text-decoration: none;
        }

        a.upvote.upvoted {
            color: #1E90FFaa;
        }

        a.edit {
            color: #1E90FFaa;
            font-size: 0.8rem;
            text-decoration: none;
        }

        a.delete {
            color: #f00a;
            font-size: 0.8rem;
            text-decoration: none;
        }

        .comment-box.editing .editable {
            display: initial;
        }


        .comment-box.editing .comment,
        .comment-box.editing .edit,
        .comment-box.editing .delete {
            display: none;
            box-sizing: border-box;
        }

        .comment-box.editing textarea.editable {
            display: block;
            border: 1px solid lightgray;
            box-sizing: border-box;
            background-color: #eee;
            border-radius: 5px;
            margin-bottom: 0.5rem;
            width: 100%;
        }

        .comment-box.editing button.editable {
            border: none;
            color: white;
            background-color: #00a730;
            box-shadow: 0px 0px 3px 0px #0001;
            margin-bottom: 0.5rem;
        }

        .comment-box.editing button.editable.cancel {
            background-color: red;
        }

        /* comment submission form */

        .comment-form {
            display: block;
            width: 100%;
            margin: 1rem 0;
            border-radius: 5px;
            padding: 0.5rem;
            box-sizing: border-box;
            background-color: #fff;
            box-shadow: 0px 3px 5px 0px #0001;
        }

        .comment-form textarea {
            display: block;
            border: 1px solid lightgray;
            box-sizing: border-box;
            background-color: #eee;
            border-radius: 5px;
            margin-bottom: 0.5rem;
            width: 100%;

        }

        .comment-replies {
            border-left: 1px solid lightgray;
            padding: 5px 5px 5px 10px;
        }

        button {
            border: none;
            padding: 8px 14px;
            color: white;
            font-weight: bold;
            text-transform: uppercase;
            background-color: #00a730;
            box-shadow: 0px 0px 3px 0px #0001;
            border-radius: 20px;
        }

        button:hover {
            background-color: #009620 !important;
            cursor: pointer;
        }

        img {
            max-width: 100%;
        }

        .larger {
            font-size: 2rem;
            margin-bottom: 1rem;
        }
    </style>
    <!-- show error -->
    @if(session()->has('error'))
    <div class="alert error">{{session()->get('error')}}</div>
    @endif

    <!-- show success -->
    @if(session()->has('success'))
    <div class="alert success">{{session()->get('success')}}</div>
    @endif

    <!-- show the question -->
    <div class="card">
        @if($moduleName)
        <h2>{{ $moduleName }}</h2>
        @endif
        @if($forum->title)
        <div class="forum-title">
            {{$forum->title}}
        </div>
        @endif
        {!!$forum->content!!}
    </div>

    <!-- show all the comments -->
    @forelse($forum->comments as $comment)

    <div class="comment-box" id="comment-{{$comment->id}}">
        <form action="{{url('/app/comments/edit/' . $comment->id)}}" method="POST">
            @csrf
            <input type="hidden" name="token" value="{{$token}}">
            <div class="comment">
                @if(strlen($comment->comment)===1)
                <div class="larger">{{ $comment->comment }}</div>
                @else
                @foreach(explode("\n", $comment->comment) as $line)
                <p>{{$line}}</p>
                @endforeach
                @endif
            </div>
            <textarea name="comment" class="editable" rows="10">{{$comment->comment}}</textarea>
            <button type="submit" class="editable">{{__("forum.exercise.save")}}</button>
            <button type="button" onclick="unEditComment({{$comment->id}})" class="editable cancel">{{__("forum.exercise.cancel")}}</button>
            <div>
                <span class="user">
                    {{
                        $comment->userId === $email 
                        ? __("forum.exercise.you")
                        : (
                            empty(trim($comment->employee->FirstName)) 
                            ? __("forum.exercise.new-user")
                            : $comment->employee->FirstName
                        )
                    }}
                </span>
                <span class="time">{{ $comment->created_at->diffForHumans() }}</span>
                @if($comment->upvotes()->where('userId', $email)->exists())
                <a href="{{ url('/app/comments/' . $comment->id . '/upvote/remove?token=' . $token) }}" title="Remove Upvote" class="upvote upvoted">
                    &#8686; {{ $comment->upvotes()->count() === 1 ? '1 '. __("forum.exercise.upvote") : $comment->upvotes()->count() . " ".__("forum.exercise.upvotes") }}
                </a>
                @else
                <a href="{{ url('/app/comments/' . $comment->id . '/upvote/add?token=' . $token) }}" title="Upvote" class="upvote">
                    &#8686; {{ $comment->upvotes()->count() === 1 ? '1 '. __("forum.exercise.upvote") : $comment->upvotes()->count() . " ".__("forum.exercise.upvotes") }}
                </a>
                @endif
                @if($comment->userId === $email)
                <a href="Javascript:void(0)" onClick="editComment({{$comment->id}})" class="edit">{{__("forum.exercise.edit")}}</a>
                <a href="Javascript:void(0)" onClick="deleteComment({{$comment->id}})" class="delete">{{__("forum.exercise.delete")}}</a>
                @endif
            </div>
        </form>
        <!-- comment replies and reply form -->
        <div class="comment-replies">
            @foreach($comment->comments as $reply)
            <!-- Comment body -->

            <div class="reply-box" id="comment-{{$reply->id}}">
                <form action="{{url('/app/comments/edit/' . $reply->id)}}" method="POST">
                    @csrf
                    <input type="hidden" name="token" value="{{$token}}">
                    <div class="comment">
                        @if(strlen($reply->comment)===1)
                        <div class="larger">{{ $reply->comment }}</div>
                        @else
                        @foreach(explode("\n", $reply->comment) as $line)
                        <p>{{$line}}</p>
                        @endforeach
                        @endif
                    </div>
                    <textarea name="comment" class="editable" rows="10">{{$reply->comment}}</textarea>
                    <button type="submit" class="editable">{{__("forum.exercise.save")}}</button>
                    <button type="button" onclick="unEditComment({{$reply->id}})" class="editable cancel">{{__("forum.exercise.cancel")}}</button>
                    <div>
                        <span class="user">
                            {{
                        $reply->userId === $email 
                        ? __("forum.exercise.you")
                        : (
                            empty(trim($reply->employee->FirstName)) 
                            ? __("forum.exercise.new-user")
                            : $reply->employee->FirstName
                        )
                    }}
                        </span>
                        <span class="time">{{ $reply->created_at->diffForHumans() }}</span>
                        @if($reply->upvotes()->where('userId', $email)->exists())
                        <a href="{{ url('/app/comments/' . $reply->id . '/upvote/remove?token=' . $token) }}" title="Remove Upvote" class="upvote upvoted">
                            &#8686; {{ $reply->upvotes()->count() === 1 ? '1 '. __("forum.exercise.upvote") : $reply->upvotes()->count() . " ".__("forum.exercise.upvotes") }}
                        </a>
                        @else
                        <a href="{{ url('/app/comments/' . $reply->id . '/upvote/add?token=' . $token) }}" title="Upvote" class="upvote">
                            &#8686; {{ $reply->upvotes()->count() === 1 ? '1 '. __("forum.exercise.upvote") : $reply->upvotes()->count() . " ".__("forum.exercise.upvotes") }}
                        </a>
                        @endif
                        @if($reply->userId === $email)
                        <a href="Javascript:void(0)" onClick="editComment({{$reply->id}})" class="edit">{{__("forum.exercise.edit")}}</a>
                        <a href="Javascript:void(0)" onClick="deleteComment({{$reply->id}})" class="delete">{{__("forum.exercise.delete")}}</a>
                        @endif
                    </div>
                </form>
            </div>
            <!-- Comment body end -->
            @endforeach
            <form action="{{url('/app/comments/add/' . $comment->id)}}" class="comment-form" method="POST" onsubmit="checkforusername()">
                @csrf
                <input type="hidden" name="token" value="{{$token}}">
                <textarea name="comment" placeholder="{{__('forum.exercise.add-comment')}}..." rows="5"></textarea>
                <button type="submit">{{__("forum.exercise.comment")}}</button>
            </form>
        </div>
        <!-- comment replies and reply form end -->
    </div>
    @empty
    <div class="lonely">
        <!-- show card for emoji reactions -->
        <div class="card">
            <div class="lonely-message">
                {{ __('forum.exercise.no-comments') }}
            </div>

            <form action="{{url()->current()}}" id="emojireactform" method="POST">
                @csrf
                <input type="hidden" name="token" value="{{$token}}">
                <input type="hidden" name="comment">
            </form>
            <div class="emoji-set">
                <span class="emoji" title="React" onclick="submitEmojiReactForm('👍')">👍</span>
                <span class="emoji" title="React" onclick="submitEmojiReactForm('👏')">👏</span>
                <span class="emoji" title="React" onclick="submitEmojiReactForm('😕')">😕</span>
            </div>
        </div>
        <!-- show card for emoji reactions end -->
    </div>
    <script>
        function submitEmojiReactForm(emoji = '👍') {
            const form = document.getElementById("emojireactform");
            form.comment.value = emoji;
            form.submit();
        }
    </script>
    @endforelse
    <!-- show comment form -->
    <form action="{{url()->current()}}" class="comment-form" method="POST">
        @csrf
        <input type="hidden" name="token" value="{{$token}}">
        <textarea name="comment" placeholder="{{__('forum.exercise.add-comment')}}..." rows="10"></textarea>
        <button type="submit">{{__("forum.exercise.comment")}}</button>
    </form>


    <!-- user name update model -->
    <div class="user-name-update-modal">
        <form class="user-name-update-form card" onsubmit="return updateUserName(event)">
            <div class="name-update-title">Wait!</div>
            <div class="name-update-subtitle">Looks like you have not told us your name yet!</div>
            <input type="text" name="FirstName" placeholder="First Name" value="{{$employee->FirstName}}" required>
            <input type="text" name="LastName" placeholder="Last Name" value="{{ $employee->LastName }}" required>
            <div class="error">Couldn't update!</div>
            <div class="success">Update successful!</div>
            <button type="submit" class="name-update-button">Save</button>
            <span class="close" onclick="closeusernameupdatemodal()">&times;</span>
        </form>
    </div>
    <style>
        input:focus,
        button:focus {
            outline: none;
        }

        .user-name-update-modal {
            position: fixed;
            display: none;
            top: 0px;
            left: 0px;
            right: 0px;
            bottom: 0px;
            z-index: 23;
            background-color: #0002;
            justify-content: center;
            align-items: center;
        }

        .user-name-update-form {
            position: relative;
            max-width: 100%;
        }


        .user-name-update-form .close {
            position: absolute;
            font-size: 1.3rem;
            right: 1rem;
            top: 8px;
            font-weight: bold;
            color: red;
            cursor: pointer;
            opacity: 0.8;
        }

        .user-name-update-form .close:hover {
            opacity: 1;
        }

        .name-update-title {
            font-weight: bold;
            font-size: 1.5rem;
            text-align: center;
            margin-bottom: 0.5rem;
        }

        .name-update-subtitle {
            font-size: 1.1rem;
            text-align: center;
            margin-bottom: 1rem;
        }

        .user-name-update-form input {
            width: calc(50% - 4px);
            box-sizing: border-box;
            padding: 7px 10px;
            font-size: 1.1rem;
            border-radius: 5px;
            border: 1px solid #aaa;
        }

        .user-name-update-form input:first-of-type {
            margin-right: 2px;
        }

        .user-name-update-form input:last-of-type {
            margin-left: 2px;
        }

        .user-name-update-form .error {
            display: none;
            margin-top: 0.5rem;
            text-align: center;
            color: red;
            background-color: white;
        }

        .user-name-update-form .success {
            display: none;
            margin-top: 0.5rem;
            text-align: center;
            color: green;
            background-color: white;
        }

        .user-name-update-form button {
            display: block;
            margin: 1rem auto 0;
            font-size: 1.1rem;
        }

        @media only screen and (max-width: 540px) {


            .user-name-update-form {
                margin: 1rem;
            }

            .user-name-update-form input:first-of-type {
                margin-right: 0px;
            }

            .user-name-update-form input:last-of-type {
                margin-left: 0px;
            }

            .user-name-update-form input {
                width: 100%;
                margin-bottom: 0.5rem;
            }
        }
    </style>
    <!-- user name update model end -->

    <script>
        var username = "{{ $employee->FirstName }}".trim();


        function deleteComment(id = null) {
            if (confirm("{{__('forum.exercise.delete-confirmation')}}")) {
                window.location = "{{url('/app/comments/delete')}}/" + id + "?token={{$token}}";
            }
        }

        function editComment(id = null) {
            const commentBox = document.getElementById("comment-" + id);
            commentBox.classList.add("editing");
        }

        function unEditComment(id = null) {
            const commentBox = document.getElementById("comment-" + id);
            commentBox.classList.remove("editing");
        }

        /**
         * Not username, but it checks for user's first name
         */
        function checkforusername() {
            if (username.length === 0) {
                event.preventDefault();
                // we have to show the update user firstName
                document.querySelector('.user-name-update-modal').style.display = "flex";
            }
        }

        function updateUserName(event) {
            event.preventDefault();
            // update username
            const payload = {
                FirstName: event.target.FirstName.value,
                LastName: event.target.LastName.value
            };

            fetch('/api/employee/{{ $email }}', {
                    method: "PUT",
                    headers: {
                        Authorization: "Bearer {{ $token }}",
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(payload)
                })
                .then(r => r.json())
                .then(response => {
                    username = payload.FirstName;
                    document.querySelector('.user-name-update-form .success').style.display = "block";
                    document.querySelector('.user-name-update-form .error').style.display = "none";
                })
                .catch(err => {
                    document.querySelector('.user-name-update-form .error').style.display = "block";
                    document.querySelector('.user-name-update-form .success').style.display = "none";
                });
        }

        function closeusernameupdatemodal() {
            document.querySelector('.user-name-update-modal').style.display = "none";
        }
    </script>
</body>

</html>