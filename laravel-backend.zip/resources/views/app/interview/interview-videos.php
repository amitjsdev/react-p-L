<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Interview Videos</title>
    <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.25.1/moment.min.js"></script>
    <script src="https://unpkg.com/vue"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
    <style>
        .main-content-box {
            display: none;
        }
    </style>
    <div id="app">
        <!-- check for fault -->
        <div v-if="appOnFault">
            <div class="flex bg-red-500 py-12 text-white justify-center items-center h-screen">
                {{faultReason}}
            </div>
        </div>
        <div v-if="!userToken" class="flex bg-red-500 py-12 text-white justify-center items-center h-screen">
            Token Missing, app wont work without a proper token!
        </div>
        <!-- else load the app -->
        <div class="main-content-box" v-bind:style="{display: appLoaded ? 'block' : 'none'}">
            <!-- taplingua header -->
            <div class="flex px-6 py-3 border-b justify-between items-center">
                <div class="flex items-center">
                    <img src="/main-logo-alt.png" style="height:51px; margin-right: 1rem;" alt="">
                    <div class="font-bold px-4 py-2 cursor-pointer rounded hover:bg-gray-50">Learn</div>
                    <a class="font-bold px-4 py-2 cursor-pointer rounded hover:bg-gray-50" v-bind:href="'/app/interview/92?token=' + userToken">Practice</a>
                    <div class="font-bold text-blue-500 px-4 py-2 cursor-pointer rounded hover:bg-gray-50">My Videos
                    </div>
                </div>
                <div class="user-img-holder">
                    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAABmJLR0QA/wD/AP+gvaeTAAADpklEQVR4nO3dy2tdVRTH8U8E26gx6qASH4gPkqJgqkKrUDuwQ50qCE50JP4NouDEQunYItipiDitI60vVHygVUdasFJRRCgkTfpIta2DnUCbQc0595y998ldX1hkcNmsvX7rnnPPXmvvE4IgCIIgCIIgCIIgCIJxYaL0BBowjaewFztwN25e/WwBv+EojuAwlgrMcVMyh0M4jUsbtNN4C7MF5rtpuA4H8I+NC7/ezmM/JjPPffDM4ifthV9vX+K2rBEMmIfxt+7EX7PfMZ8xjkEyqx/xL0/CTLZoBsak9BTTl/hr9q30+xKs44D+xV+z1zLFNBjmjPa009SWxK3oCg7JJ/6avZElsgEwrdkiqytbxo0Z4rsq15SegFReuL6A3xvwZAG/V1BDAvaOqW/UkYAdBX0XX5jVkIB7Cvq+t6Bv1FGOXsGWgr6LFupquALGmhoScKqg78WCvlFHAo4X9P1rQd+oIwFHC/r+oaBv1JGAIwV9f1jQdzVMSWWBEqWIqQzxXZUaroBlvFPA79urvgOpE3Zevm//igoWYbWxX74E7MsU06CYlHYv9C3+F9iaKabBMYMT+hP/D9yRLZqBMi/tXuha/BN4MGMcg2YbPtHtbSd6wA3ZKu1eGGWNsILXxT1/JGakBnqTRCzjTQN41KyhH7BRpqT+8RN4SGrkXL49/Ti+x0d4XyyygiAIgiAIgiAIgiAIgsqouRg3LTXrZ6UzZNulw9bTUhFuetVI2xtPSUW5RfyFn/ELjq3+rfLdEbUk4Fo8gt3Yg124vWMff+JrfIbP8Z10MLAopRIwgZ1SeXkPHpX/mNIZfCUl5DC+kXoJm5YJPI6D0rex790PbRr2B6WrsJY7Qyfcipele3FpkTdqx1bnvK0HPbLxgHT+96zygra1s9J7h+7vWJteuUvqx/6rvIBd2QW8i/s61KlztuBVnFNesL7sHF6RntqqYl63L1iq3X5U0SavZ5TZ31/alvB0B/qNxEu4qLwYpewiXhxZxZY8J/04lRahtF3AsyNq2Zg5aSVZOvha7IzMr8j8tIcghm4fj6RoA3ZnCmiI9lhTMdsc0nu+xZhx4YWmA9okYFeLMePCzqYD2lT9FnBTi3HjwAJuaTKgTQIutRgzTjTStIaD2mNNJKAwkYDCRAIKEwkoTJsEVLm/phIavwKtTQI+aDFmXMiizXacVL7uUpudlLEieqfUpF7sMaCh2CLeE/+xKQiCIAiCIAiCIAiCIPgf/gNsizrNlgE+xAAAAABJRU5ErkJggg==" alt="">
                </div>
            </div>
            <!-- main container -->
            <div class="main-container flex">
                <!-- sidebar -->
                <!-- <div class="sidebar">
                    <div class="text-center my-2 text-xl font-bold">{{moduleName}}</div>
                </div> -->
                <!-- content -->
                <div class="content">
                    <!-- no videos available -->
                    <div v-if="previousAttempts.length===0" class="m-5 border">
                        <div class="my-5 text-center">
                            No videos to review yet!
                        </div>
                    </div>
                    <div v-else class="m-5" v-if="previousAttempts.length > 0">
                        <!-- options -->
                        <div class="flex justify-end m-5">
                            <div class="px-4 py-2 cursor-pointer rounded hover:bg-gray-100 bg-gray-50 mx-2">Practice
                            </div>
                            <div class="px-4 py-2 cursor-pointer rounded hover:bg-red-500 hover:text-white bg-red-50 mx-2">
                                Delete
                            </div>
                        </div>
                        <!-- previous attempts -->
                        <div class=" border p-5">
                            <table class="w-full">
                                <thead>
                                    <tr>
                                        <th class="font-semibold">Attempt No</th>
                                        <th class="font-semibold">Video</th>
                                        <th class="font-semibold">Record Date</th>
                                        <th class="font-semibold">Self Rating</th>
                                        <th class="font-semibold">AI Rating</th>
                                        <th class="font-semibold">Instructor Rating</th>
                                        <th class="font-semibold">Share</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="(attempt, index) of previousAttempts">
                                        <td class="">
                                            <div class="w-10 h-10 flex items-center justify-center rounded hover:bg-gray-100 cursor-pointer">
                                                {{attempt.attemptNo}}</div>
                                        </td>
                                        <td>
                                            <div class="flex py-3">
                                                <video width="180" height="140" v-bind:src="'https://langappnew.s3.amazonaws.com/uploads/' + attempt.filePath"></video>
                                                <div class="flex-grow px-4">
                                                    <div class="font-semibold my-2">{{attempt.lessonName}}</div>
                                                    <div class="mt-5">Lesson {{attempt.lessonNo}}</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            {{getDateFormatted(attempt.created_at)}}
                                        </td>
                                        <td class="">
                                            <div class="w-10 h-10 flex items-center justify-center rounded hover:bg-gray-100 cursor-pointer" v-on:click="showRatingModel('Self')">
                                                4.2</div>
                                        </td>
                                        <td class="">
                                            <div class="w-10 h-10 flex items-center justify-center rounded hover:bg-gray-100 cursor-pointer" v-on:click='"ai_rating_average" in attempt ? showAIRatingModel(index) : () => {}'>
                                                {{"ai_rating_average" in attempt ? attempt.ai_rating_average : "Processing"}}</div>
                                        </td>
                                        <td class="">
                                            <div class="w-10 h-10 flex items-center justify-center rounded hover:bg-gray-100 cursor-pointer" v-on:click="showRatingModel('Instructor')">
                                                4.2</div>
                                        </td>
                                        <td>
                                            <div class="w-10 h-10 flex items-center justify-center rounded hover:bg-gray-100 cursor-pointer" v-on:click="showShareModel">
                                                <img height="21px" style="width: 21px;" src="/assets/share_button.png" />
                                            </div>
                                        </td>
                                    <tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- share model -->
                    <div class="model" style="display: none;">
                        <div class="modelCard" v-on:click="function(e) { e.preventDefault(); e.stopPropagation(); }">
                            <!-- header -->
                            <div class="flex justify-between">
                                <div class="font-semibold text-3xl">Share</div>
                                <div class="text-red-500 px-4 py-2 hover:bg-red-100 cursor-pointer rounded" v-on:click="hideShareModel">
                                    Close</div>
                            </div>
                            <!-- body -->
                            <div class="my-8">
                                <div class="flex items-center mb-8">
                                    <div class="font-semibold mr-3 w-36">Video Link</div>
                                    <input type="text" class="px-4 py-3 border rounded flex-grow" value="https://api2.taplingua.com/app/interview/1292/71/1/1/3">
                                </div>
                                <div class="flex items-center mb-4">
                                    <div class="w-36 mr-3">
                                        <div>&nbsp;</div>
                                        <div class="font-semibold">Email Address</div>
                                    </div>
                                    <div class="flex-grow">
                                        <div class="font-semibold mb-2">For multiple email addresses, seperate by commas
                                        </div>
                                        <input type="text" class="px-4 py-3 border rounded w-full" value="santanu@taplingua.com, rajeev.bajpai@taplingua.com">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- share model new -->
                    <div class="model" v-on:keyup.esc="hideShareModel" v-show="shareModelVisible" v-on:click="hideShareModel">
                        <div class="modelCard" v-on:click="function(e) { e.preventDefault(); e.stopPropagation(); }">
                            <!-- header -->
                            <div class="flex justify-end">
                                <div class="text-red-500 px-4 py-2 hover:bg-red-100 cursor-pointer rounded" v-on:click="hideShareModel">
                                    Close</div>
                            </div>
                            <!-- body -->
                            <div class="my-8 mx-8">
                                <div class="text-2xl font-bold text-center mb-5">A minimum AI Rating of 3.5 is required before requesting Instructor rating.</div>
                                <div class="text-2xl font-bold text-center mb-10">Current AI Rating for question: 4.2</div>
                                <div class="flex items-center flex-col">
                                    <div class="w-72 bg-green-600 text-2xl text-white rounded-full px-10 py-3 text-center cursor-pointer" v-on:click="requestRatingSuccess = true">Request Rating</div>
                                    <div class="text-green-600 my-3" v-if="requestRatingSuccess">Requested for rating!</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- rating model -->
                    <div class="model" v-on:keyup.esc="hideRatingModel" v-show="ratingModelVisible" v-on:click="hideRatingModel">
                        <div class="modelCard" v-on:click="function(e) { e.preventDefault(); e.stopPropagation(); }">
                            <!-- header -->
                            <div class="flex justify-between">
                                <div class="font-semibold text-3xl">{{ratingType}} Review</div>
                                <div class="text-red-500 px-4 py-2 hover:bg-red-100 cursor-pointer rounded" v-on:click="hideRatingModel">
                                    Close</div>
                            </div>
                            <!-- body -->
                            <div class="my-8">
                                <div class="flex items-center mb-4">
                                    <div class="w-1/2 font-semibold">Overall Answer</div>
                                    <div class="w-1/2 flex">
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/yellow_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/yellow_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/yellow_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/yellow_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/empty_star.png" />
                                    </div>
                                </div>
                                <div class="flex items-center mb-4">
                                    <div class="w-1/2 font-semibold">Conciseness of Answer</div>
                                    <div class="w-1/2 flex">
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/yellow_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/yellow_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/yellow_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/yellow_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/empty_star.png" />
                                    </div>
                                </div>
                                <div class="flex items-center mb-4">
                                    <div class="w-1/2 font-semibold">Confidence level</div>
                                    <div class="w-1/2 flex">
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/yellow_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/yellow_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/yellow_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/empty_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/empty_star.png" />
                                    </div>
                                </div>
                                <div class="flex items-center mb-4">
                                    <div class="w-1/2 font-semibold">Clarity of Speech</div>
                                    <div class="w-1/2 flex">
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/yellow_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/yellow_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/yellow_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/empty_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/empty_star.png" />
                                    </div>
                                </div>
                            </div>
                            <div class="text-2xl font-bold text-center">Overall {{previousAttempts[selectedAttemptIndex] ? previousAttempts[selectedAttemptIndex].ai_rating_average : null}}</div>
                        </div>
                    </div>
                    <!-- ai rating model -->
                    <div class="model" v-on:keyup.esc="hideAIRatingModel" v-show="ratingAIModelVisible" v-on:click="hideAIRatingModel">
                        <div class="modelCard" v-on:click="function(e) { e.preventDefault(); e.stopPropagation(); }">
                            <!-- header -->
                            <div class="flex justify-between">
                                <div class="font-semibold text-3xl">AI Review</div>
                                <div class="text-red-500 px-4 py-2 hover:bg-red-100 cursor-pointer rounded" v-on:click="hideAIRatingModel">
                                    Close</div>
                            </div>
                            <!-- body -->
                            <div class="my-8">
                                <div class="flex items-center mb-4">
                                    <div class="w-1/2 font-semibold">Fluency</div>
                                    <div class="w-1/2 flex">
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/yellow_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/yellow_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/yellow_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/yellow_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/empty_star.png" />
                                    </div>
                                </div>
                                <div class="flex items-center mb-4">
                                    <div class="w-1/2 font-semibold">Words per minute</div>
                                    <div class="w-1/2 flex">
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/yellow_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/yellow_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/yellow_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/yellow_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/empty_star.png" />
                                    </div>
                                </div>
                                <div class="flex items-center mb-4">
                                    <div class="w-1/2 font-semibold">Unnecessary Pauses</div>
                                    <div class="w-1/2 flex">
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/yellow_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/yellow_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/yellow_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/empty_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/empty_star.png" />
                                    </div>
                                </div>
                                <div class="flex items-center mb-4">
                                    <div class="w-1/2 font-semibold">Unnecessary Ums and Ahs</div>
                                    <div class="w-1/2 flex">
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/yellow_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/yellow_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/yellow_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/empty_star.png" />
                                        <img class="mx-2" height="21px" style="width: 21px;" src="/assets/empty_star.png" />
                                    </div>
                                </div>
                            </div>
                            <div class="text-2xl font-bold text-center">Overall 3.5</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- // the working script -->
    <script>
        var app = new Vue({
            el: "#app",
            data: {
                appLoaded: false,
                name: "Test Subscription Update",
                userToken: (new URLSearchParams(window.location.search)).get('token'),
                //module and lesson related
                moduleName: "",
                moduleNo: window.location.pathname.split("/").pop(),
                // media related
                previousAttempts: [],
                hasError: false,
                errors: undefined, // empty errors
                appOnFault: false,
                faultReason: "",
                message: "",
                shareModelVisible: false,
                ratingType: "Self",
                selectedAttemptIndex: null,
                ratingModelVisible: false,
                ratingAIModelVisible: false,
                requestRatingSuccess: false,
            },
            created: async function() {
                // validate the user first

                await fetch('/api/employee-cf?userId&FirstName', {
                        method: "GET",
                        headers: {
                            "Authorization": "Bearer " + this.userToken,
                            "Content-Type": "application/json",
                            "Accept": "application/json",
                        }
                    }).then(r => {
                        if (r.status != 200) {
                            this.appOnFault = true;
                            this.faultReason = "Cannot validate user!"
                            return;
                        } else {

                        }
                    })
                    .then(function() {
                        // all good
                    });

                // set app as loaded
                this.appLoaded = true;

                // load lessons for module
                fetch('/api/lesson-by-module-compact/' + this.moduleNo, {
                        method: "GET",
                        headers: {
                            "Authorization": "Bearer " + this.userToken,
                            "Content-Type": "application/json",
                            "Accept": "application/json",
                        }
                    })
                    .then(r => r.json())
                    .then(response => {
                        this.moduleName = response.module,
                            this.lessons = response.lessons
                    })
                    .catch(err => {
                        alert("Something went wrong, please refresh!");
                        console.log({
                            err
                        });
                    })

                // 
                this.loadPrevAttempts();
            },
            methods: {
                showShareModel: function() {
                    this.shareModelVisible = true;
                },
                hideShareModel: function() {
                    this.shareModelVisible = false;
                    this.requestRatingSuccess = false;
                },
                showRatingModel: function(type) {
                    this.ratingType = type;
                    this.ratingModelVisible = true;
                },
                hideRatingModel: function() {
                    this.ratingModelVisible = false;
                },
                showAIRatingModel: function(index) {
                    this.selectedAttemptIndex = index;
                    this.ratingAIModelVisible = true;
                },
                hideAIRatingModel: function() {
                    this.ratingAIModelVisible = false;
                },
                getDateFormatted: function(date) {
                    return moment(date).format("MMM DD YYYY");
                },
                loadPrevAttempts: function() {
                    // load previous attempts
                    fetch(`/api/interview/prev-attempts/all`, {
                            method: "GET",
                            headers: {
                                "Authorization": "Bearer " + this.userToken,
                                "Content-Type": "application/json",
                                "Accept": "application/json",
                            }
                        })
                        .then(r => {
                            if (r.status !== 200) {
                                throw new Error('something went wrong')
                            } else {
                                return r.json();
                            }
                        })
                        .then(response => {
                            this.previousAttempts = response.attempts
                        })
                        .catch(err => {
                            alert("Something went wrong, please refresh!");
                            console.log({
                                err
                            });
                        })
                }
            }
        })
    </script>

    <style>
        .user-img-holder {
            width: 48px;
            height: 48px;
            background-color: #543dff;
            border-radius: 50%;
            padding: 0.5rem;
        }

        .user-img-holder img {
            -webkit-filter: invert(1);
            filter: invert(1);
            width: 100%;
        }

        .sidebar {
            position: relative;
            width: 300px;
        }

        .content {
            flex-grow: 1;
        }

        .content .recorder {
            position: relative;
        }

        .content .recorder #start-record {
            position: absolute;
        }

        .content .recorder .time-elapsed {
            position: absolute;
            top: 10px;
            left: 10px;
            background-color: white;
            border-radius: 8px;
            padding: 3px 8px;
        }

        .content .recorder #redo-record,
        .content .recorder #stop-camera,
        .content .recorder #stop-record,
        .content .recorder #start-record {
            position: absolute;
            bottom: 10px;
            left: 10px;
            background-color: white;
            border-radius: 8px;
            padding: 3px 8px;
        }

        .content .recorder #stop-camera {
            left: auto;
            right: 10px;
        }

        .content .recorder #redo-record {
            left: auto;
            right: 10px;
            bottom: auto;
            top: 10px;
        }

        .lesson-completed-icon {
            display: inline-block;
            width: 24px;
            height: 24px;
            border-radius: 50%;
            border: 1px solid green;
            background-color: green;
        }

        .lesson-incomplete-icon {
            display: inline-block;
            width: 24px;
            height: 24px;
            border-radius: 50%;
            border: 1px solid gray;
        }

        video {
            width: auto;
            background-color: black;
            max-height: 100px;
        }

        th {
            text-align: left;
        }

        .model {
            position: fixed;
            bottom: 0;
            top: 0;
            left: 0;
            right: 0;
            background-color: #0003;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .modelCard {
            border-radius: 12px;
            padding: 3rem 2rem;
            min-width: 640px;
            max-width: 640px;
            background-color: white;
        }
    </style>
</body>

</html>