<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Subscription Update</title>
    <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://unpkg.com/vue"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body class="flex  flex-col items-center pt-24">

    <div id="app">
        <div class="font-bold text-2xl mb-5">{{name}}</div>
        <form action="" class="flex flex-col">
            <label>
                <span class="text-sm text-gray-500">Client ID</span>
                <input type="text" v-model="headers.ClientId" class="w-full border border-gray-600 px-4 py-1 m-1" placeholder="Client ID">
            </label>
            <label>
                <span class="text-sm text-gray-500">API KEY</span>
                <input type="text" v-model="headers.ApiKey" class="w-full border border-gray-600 px-4 py-1 m-1" placeholder="API KEY">
            </label>
            <div class="py-2"></div>
            <label>
                <span class="text-sm text-gray-500">Course No</span>
                <input type="text" v-model="payload.courseNo" class="w-full border border-gray-600 px-4 py-1 m-1" placeholder="Course No">
                <div class="text-red-500 text-xs">{{(errors && errors.courseNo && errors.courseNo[0]) ? errors.courseNo[0] : ""}}</div>
            </label>
            <label>
                <span class="text-sm text-gray-500">User Email</span>
                <input type="email" v-model="payload.email" class="w-full border border-gray-600 px-4 py-1 m-1" placeholder="User Email">
                <div class="text-red-500 text-xs">{{(errors && errors.email && errors.email[0]) ? errors.email[0] : ""}}</div>
            </label>
            <label>
                <span class="text-sm text-gray-500">MRP</span>
                <input type="text" v-model="payload.mrp" class="w-full border border-gray-600 px-4 py-1 m-1" placeholder="MRP">
                <div class="text-red-500 text-xs">{{(errors && errors.mrp && errors.mrp[0]) ? errors.mrp[0] : ""}}</div>
            </label>
            <label>
                <span class="text-sm text-gray-500">Actual Price</span>
                <input type="text" v-model="payload.actualPrice" class="w-full border border-gray-600 px-4 py-1 m-1" placeholder="Actual Price">
                <div class="text-red-500 text-xs">{{(errors && errors.actualPrice && errors.actualPrice[0]) ? errors.actualPrice[0] : ""}}</div>
            </label>
            <label>
                <span class="text-sm text-gray-500">Discount Code</span>
                <input type="text" v-model="payload.discountCode" class="w-full border border-gray-600 px-4 py-1 m-1" placeholder="Discount Code">
                <div class="text-red-500 text-xs">{{(errors && errors.discountCode && errors.discountCode[0]) ? errors.discountCode[0] : ""}}</div>
            </label>
            <label>
                <span class="text-sm text-gray-500">Duration in Months (Number)</span>
                <input type="text" v-model="payload.durationInMonth" class="w-full border border-gray-600 px-4 py-1 m-1" placeholder="Duration in Months (Number)">
                <div class="text-red-500 text-xs">{{(errors && errors.durationInMonth && errors.durationInMonth[0]) ? errors.durationInMonth[0] : ""}}</div>
            </label>
            <label>
                <span class="text-sm text-gray-500">Subscription End Date (YYYY-MM-DD)</span>
                <input type="text" v-model="payload.subscriptionEndDate" class="w-full border border-gray-600 px-4 py-1 m-1" placeholder="Subscription Expires Date (YYYY-MM-DD)">
                <div class="text-red-500 text-xs">{{(errors && errors.subscriptionEndDate && errors.subscriptionEndDate[0]) ? errors.subscriptionEndDate[0] : ""}}</div>
            </label>
            <div class="text-red-500 text-xs" v-if="hasError">{{message}}</div>
            <div class="text-green-500 text-xs" v-if="!hasError">{{message}}</div>
            <div class="p-1 text-center">
                <button v-on:click="submit" class="bg-green-500 text-white px-4 py-2 rounded">Submit</button>
            </div>
        </form>
    </div>
    <script>
        var app = new Vue({
            el: "#app",
            data: {
                name: "Test Subscription Update",
                headers: {
                    ClientId: "d977e1fbc6adfcd66a8a52e622",
                    ApiKey: "ef0365c0797daf1405b5a.ea0da037dfe5ca64a6e0e8b345a638aa0b33a8fa529",
                    Accept: "application/json",
                    "Content-Type": "application/json"
                },
                payload: {
                    courseNo: "",
                    email: "",
                    mrp: "",
                    actualPrice: "",
                    discountCode: "",
                    durationInMonth: "",
                    subscriptionEndDate: "",
                },
                hasError: false,
                errors: undefined, // empty errors
                message: "",
            },
            methods: {
                submit: function(e) {
                    e.preventDefault();
                    // call api
                    fetch("https://api2.taplingua.com/api/3p/update-subscription", {
                            body: JSON.stringify(this.payload),
                            method: "POST",
                            headers: {
                                "ClientId": this.headers.ClientId,
                                "ApiKey": this.headers.ApiKey,
                                "Accept": this.headers.Accept,
                                "Content-Type": "application/json"
                            }
                        })
                        .then(r => {
                            this.hasError = r.status !== 200;
                            this.message = r.statusText;
                            return r.json();
                        })
                        .then(response => {
                            // set errors
                            this.errors = response.errors;
                            this.message = response.message;
                            console.log({
                                response
                            })
                        })
                        .catch(err => {
                            console.log({
                                err
                            })
                        })
                }
            }
        })
    </script>
</body>

</html>