<table border="1">
    <?php
    $rc =["Jee Rank","Location","Company Name","State Exam Rank","Current Address","Whatsapp Number","Work Experience","Are You Working YN","Branch Or Department","Class10GPAor Percent","College Entrance Name","Plans To Work Full Time","Graduation College Name","Graduation GPAor Percent","Final Exam Start If Student","Graduation Date If Student"]; ?>
   @if($cohort == 'Summary')
   <thead>
      <tr >
        <th style="font-weight: bold; background-color:gray;width:200px"></th> 
        <th  style="font-weight: bold; background-color:gray;width:200px"> </th>
        <th  style="font-weight: bold; background-color:gray;width:200px"></th>
        <th  style="font-weight: bold; background-color:gray;width:200px"></th>
        <th  colSpan="3" style="text-align:center;font-weight: bold; background-color:gray;width:200px">% Answered Distribution</th>

      </tr>
    </thead>
   <thead>
      <tr >
        <th style="font-weight: bold; background-color:gray;width:200px">Cohort Name</th> 
        <th  style="font-weight: bold; background-color:gray;width:200px">Cohort Start Date </th>
        <th  style="font-weight: bold; background-color:gray;width:200px">Total Number Of Questions</th>
        <th  style="font-weight: bold; background-color:gray;width:200px">Total Number Of Students</th>
        <th  style="font-weight: bold; background-color:gray;width:200px">% Answered less than 50%</th>
        <th  style="font-weight: bold; background-color:gray;width:200px">% Answered 50 to 80%</th>
        <th  style="font-weight: bold; background-color:gray;width:200px">% Answered greater than 80%</th>

      </tr>
    </thead>
   @else
    <thead>
      <tr >
        <th style="font-weight: bold; background-color:gray;width:200px">EMAIL</th>
        <th style="font-weight: bold; background-color:gray;width:200px">FIRST NAME</th>
        <th  style="font-weight: bold; background-color:gray;width:200px">LAST NAME	</th>
        <th  style="font-weight: bold; background-color:gray;width:200px">QUESTIONS ANSWERED	</th>
        <th  style="font-weight: bold; background-color:gray;width:200px">% OF QUESTIONS ANSWERED	</th>
        <th  style="font-weight: bold; background-color:gray;width:200px">ATTEMPTS</th>
        <th  style="font-weight: bold; background-color:gray;width:200px">ATTEMPTS PER QUESTION	</th>
        <th  style="font-weight: bold; background-color:gray;width:200px">ASKED FOR REVIEW	</th>
        <th  style="font-weight: bold; background-color:gray;width:200px">REVIEWS REQUESTED	PER QUESTION</th>
        <th  style="font-weight: bold; background-color:gray;width:200px">REVIEWS COMPLETED	</th>
        <th  style="font-weight: bold; background-color:gray;width:200px">%REVIEWS COMPLETED	</th>
        <th  style="font-weight: bold; background-color:gray;width:200px">NOTES</th>
        <th  style="font-weight: bold; background-color:gray;width:200px">% QUESTIONS WITH NOTES</th>
        <th  style="font-weight: bold; background-color:gray;width:200px">Manual Rating</th>
        <th  style="font-weight: bold; background-color:gray;width:200px">Vpi Score(Max-Min value)</th>
      </tr>
    </thead>
    @endif
    <tbody>
    @if($cohort == 'Summary')
    @foreach ($users as $u)
    @foreach ($u as $val)
    <tr>
        <td > {{$val->name}}</td>
        <td >{{$val->start_date}}</td>
        <td >{{$val->quesionCount}}</td>
        <td >{{$val->allIds}}</td>
        @if($val->userLessPecentage != '')
        <td >{{$val->userLessPecentage}}%</td>
        @else
        <td ></td>
        @endif
        @if($val->userBetweenPecentage != '')
        <td >{{$val->userBetweenPecentage}}%</td>
        @else
        <td ></td>
        @endif
        @if($val->userGreaterPecentage != '')
        <td >{{$val->userGreaterPecentage}}%</td>
        @else
        <td ></td>
        @endif
        </tr>
        @endforeach 
        @endforeach 
    @else
      @foreach ($users as $u)
      @foreach ($u as $i=>$datum)
      <tr>
        <td > {{$datum->email}}</td>
        <td >{{$datum->FirstName}}</td>
        <td >{{$datum->LastName}}</td>
        <td >{{$datum->distinctAttempts}}</td>
        @if($datum->distinctAttemptsCount != '')
        <td >{{$datum->distinctAttemptsCount}}%</td>
        @else
        <td ></td>
        @endif
        <td >{{$datum->totalAttempts}}</td>
        <td >{{$datum->attemptsPerQuestion}}</td>
        <td >{{$datum->Asked_for_Review}}</td>

        @if($datum->reviewsRequested != '')
        <td >{{$datum->reviewsRequested}}</td>
        @else
        <td ></td>
        @endif

        <td >{{$datum->Reviews_Completed}}</td>

        @if($datum->percentage_reviews_completed != '')
        <td >{{$datum->percentage_reviews_completed}}%</td>
        @else
        <td ></td>
        @endif

        <td >{{$datum->notes}}</td>

        @if($datum->percentageNotes != '')
        <td >{{$datum->percentageNotes}}%</td>
        @else
        <td ></td>
        @endif
        <td >{{$datum->manual_rating}}</td>
        <td >{{$datum->vpi_scores_fluency_score}}</td>
        </tr>
        @endforeach 
        @endforeach 
        @endif
    </tbody>
  </table>
