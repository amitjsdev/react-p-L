<div style="margin: 24px 0;">
    <div style="border-radius: 6px; padding: 0px; margin: 12px 0 0; text-align: center;">
        <div style="margin: 12px 0;">{{ $subMessage }}</div>
        <div style="font-size: 22px; font-weight: bold; margin-bottom: 24px;">{{ $message }}</div>
        <span style="position: relative;">
            <img src='{{ url($imageSrc) }}' style="position: absolute; left: -31.5px;" />
        </span>
    </div>
    <div style="text-align: center; padding: 24px 0; margin: 24px 0;">
        <a style="border-radius: 8px; background-color: #7066EF; color: white; padding: 12px 46px; text-decoration: none; font-weight: bold; display: inline-block;" href="{{ $buttonLink }}">{{$buttonLabel}}</a>
    </div>
</div>