@php
$title = "";
$userId = "";
@endphp
@extends('emails.layouts.skeleton')

@section('content')
<p>
    Hi,
</p>
<p>
    A Server Error is Detected!
</p>
<p>
    {{ $description }}
</p>
<pre style="background-color: #ddd; padding: 10px; overflow: scroll; width: 100%;"><code>{{json_encode($data, JSON_PRETTY_PRINT)}}</code></pre>
<p>
    Thanks<br />
    Taplingua Team.
</p>
@endsection