@php
$title = "Check Your Progress!";
$userId = $employee->userId;
@endphp
@extends('emails.layouts.skeleton')

@section('content')
<div style="background-color: #F1EFFF; padding: 14px;">
    <img src="{{url('/images/emailers/taplingua-icon.png')}}" />
    <div style="padding: 40px;">
        <h2 style="font-size: 35px; margin-bottom: 36px; text-align: center;">You got your first badge -<br /> Paycheck!!</h2>
        <div style="text-align: center; margin: 24px 0 48px;">
            <img src="{{url('/images/emailers/points-gain-icon.png')}}" style="width: 250px;" />
        </div>
        <p>Congrats {{$employee->FirstName}}!</p>
        <p>Nice work and keep it up.</p>
        <p>We have a lot of work ahead! Let’s stay the course and keep moving quickly.</p>
        <br />
        <p>See you in class,</p>
        <p>
            <b>Polly</b><br />
            Head Student Coach, Taplingua
        </p>
    </div>
</div>
@endsection