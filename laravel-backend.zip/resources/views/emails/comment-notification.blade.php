@php
$title = $notificationTitle;
$userId = $employee->userId;
@endphp
@extends('emails.layouts.skeleton')

@section('content')
<p>
    Hi {{$employee->FirstName}},
</p>
<p>
    {!!str_replace('comment!', ' <br /> comment in the Taplingua Forum.', $notificationTitle)!!}
</p>
<p>
    To check it out, click the Continue <br />
    button below.
</p>
<p>
    Thanks<br />
    Taplingua Team.
</p>
<img src="{{ url('/images/polly_email.gif') }}" width="200px" />
<p style="margin-top: 35px; margin-bottom: 40px;">
    <a href="{{$branchURL}}" style="font-weight: bold; background-color: #6834FF; color: white; padding: 15px 30px; border-radius: 25px; text-decoration: none;">
        Go to Comment
    </a>
</p>
@if($webAppLink)
<p style="margin-top: 35px; margin-bottom: 40px;">
    <a href="{{$webAppLink}}" style="font-weight: bold; background-color: #6834FF; color: white; padding: 15px 30px; border-radius: 25px; text-decoration: none;">
        Go to Comment [Web]
    </a>
</p>
@endif
@endsection