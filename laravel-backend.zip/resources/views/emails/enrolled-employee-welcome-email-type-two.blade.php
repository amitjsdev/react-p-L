@php
$userId = $email;
@endphp
@extends('emails.layouts.skeletonTypeTwo')

@section('content')
<div>
{{-- <div style="background-color: white; display: flex; align-items: center; padding: 5px 5px 15px; border-bottom: 1px solid #aaa;">
        <img src="{{ url('/images/emailers/taplingua-header.png') }}" style="height: 40px;" />
        <span style="padding: 0 12px; font-weight: bold;">for</span>
        <img src="https://langappnew.s3.amazonaws.com/logos/{{$companyCode}}.jpeg" style="height: 40px;" />
    </div> --}}
    {{-- <div style="font-weight: 700; margin-top: 15px;">
        Welcome to {{$companyName}} / {{$cohortName}}
    </div> --}}
    <div style="padding: 12px;">
        <p>
            Dear {{$name}}!<br><br>

            Thank you for registering for the {{$cohortName}}. We really appreciate your effort in <br>
            building a new and better career as a full-stack developer.<br><br>

            This is a proctored test, meaning invigilators from our team will be constantly watching you<br>
            throughout the test. So it is mandatory that you:<br><br>

               - Do not seek help from anyone else during the test<br>
               - Do not use Google or any other means to cheat the test<br><br>

            If you’re spotted cheating the test, we will have all rights to cancel your application. So make<br>
            sure that you come prepared and prevent any means of cheating. <br><br>


            Also, please make sure to take the test with a working laptop and stable internet connection,<br>
            and from a quiet environment. Try to avoid any background distractions. <br><br>

            To attend the test, kindly follow this link: <a href="https://app.taplingua.com">https://app.taplingua.com</a><br><br>



               - Click on the Google login button<br><br>
               - Use the email you’ve registered with The {{$companyName}} to login<br><br>


            <img src="https://langappnew.s3.amazonaws.com/logos/googlelogin.png" style="height: 300px;width:500px; margin:30px" /><br><br>

            {{-- The camera will record you while you take the test. You should not receive any help from anyone nor use Google to find the answer as your application will be cancelled if it is found that you have cheated in the exam. <br>

            Please proceed to https://app.taplingua.com and log in with your registered email address.<br> --}}
            {{-- @if(!empty($password))

                          <div style="border: 1px solid black; padding: 2px 16px; margin-bottom: 16px;">
                <p>LOGIN</b> using your email and password below</p>
                <p>
                    email: <b>{{$email}}</b> <br>
                    password: <b>{{$password}}</b>
                </p>
            </div>
            <p style="text-align: center; margin-bottom: 54px;">
                Your password will be valid for 24 hours. Please change your password from
                profile section once you have logged in.
            </p>

        @endif --}}



Sincerely,<br>
{{$companyName}} / {{$cohortName}} Team<br>
<img src="https://langappnew.s3.amazonaws.com/logos/{{$companyCode}}.jpeg" style="height: 40px;" />

        </p>


    </div>
</div>
@endsection
