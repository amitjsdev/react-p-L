@php
$userId = $email;
@endphp
@extends('emails.layouts.skeleton')

@section('content')
<div>
    <div style="background-color: white; display: flex; align-items: center; padding: 5px 5px 15px; border-bottom: 1px solid #aaa;">
        <img src="{{ url('/images/emailers/taplingua-header.png') }}" style="height: 40px;" />
        <span style="padding: 0 12px; font-weight: bold;">for</span>
        <img src="https://langappnew.s3.amazonaws.com/logos/{{$companyCode}}.jpeg" style="height: 40px;" />
    </div>
    <div style="font-weight: 700; margin-top: 15px;">
        Welcome to {{$companyName}} / {{$cohortName}}
    </div>
    <div style="padding: 12px;">
        <p>
            Hi {{$name}}!<br>
            Welcome to the <b>Taplingua {{$moduleName}} Course</b>.<br>
            @if(!empty($password))
            Your account has been successfully created.
            @else
            Your account has been successfully registered for the course.
            @endif
        </p>
        <p>To get started:</p>
        <div style="border: 1px solid black; padding: 2px 16px; margin-bottom: 16px;">
            <!-- <p>1. <b>CLICK</b> on the link to go to this URL</p> -->
            <p>1. <b>DOWNLOAD</b> the App in Google Play</p>
            <div style="text-align: left;">
                <!-- <a href='http://app.taplingua.com'>
                   <b>http://app.taplingua.com</b>
                   </a> -->
                <a href='https://play.google.com/store/apps/details?id=com.taplingua.languages&pcampaignid=pcampaignidMKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1'>
                    <img alt='Get it on Google Play' width="150px" src='https://play.google.com/intl/en_us/badges/static/images/badges/en_badge_web_generic.png' class="w-36 mx-auto" />
                </a>
            </div>
        </div>
        @if(!empty($password))

        <div style="border: 1px solid black; padding: 2px 16px; margin-bottom: 16px;">
            <p>2. <b>LOGIN</b> using your email and password below</p>
            <p>
                email: <b>{{$email}}</b> <br>
                password: <b>{{$password}}</b>
            </p>
        </div>
        <p style="text-align: center; margin-bottom: 54px;">
            Your password will be valid for 24 hours. Please change your password from
            profile section once you have logged in.
        </p>
        @else
        <div style="border: 1px solid black; padding: 2px 16px; margin-bottom: 16px;">
            <p>2. <b>LOGIN</b> to the App using you email and password. If you have forgotten
                your password, you can reset the password by clicking
                <a href="{{ url('/password-reset') }}" style="font-weight: 700;">Reset password.</a>
            </p>
        </div>
        @endif
    </div>
</div>
@endsection