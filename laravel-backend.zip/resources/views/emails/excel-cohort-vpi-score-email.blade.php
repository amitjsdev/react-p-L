@php
// $userId = $email;
@endphp
@extends('emails.layouts.skeletonTypeTwo')

@section('content')
<div>
    <div style="background-color: white; display: flex; align-items: center; padding: 5px 5px 15px; border-bottom: 1px solid #aaa;">
        <div style="font-weight: 700; margin-top: 15px;">
            Dear {{$companyName}} team, Please find the Cohort vpi score report"
        </div>
    </div>

    <div style="padding: 12px;">



    Sincerely,<br>
{{$companyName}} Team<br>
<img src="https://langappnew.s3.amazonaws.com/logos/{{$companyCode}}.jpeg" style="height: 40px;" />


    </div>
</div>
@endsection
