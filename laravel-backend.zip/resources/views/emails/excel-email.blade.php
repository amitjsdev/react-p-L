@php
// $userId = $email;
@endphp
@extends('emails.layouts.skeletonTypeTwo')

@section('content')
<div>
    <div style="background-color: white; display: flex; align-items: center; padding: 5px 5px 15px; border-bottom: 1px solid #aaa;">
        <div style="font-weight: 700; margin-top: 15px;">
            Hi: Please find attached the quiz attempt report for the cohort {{$cohortName}} Quiz set {{$quizName}}
        </div>
    </div>

    <div style="padding: 12px;">



Regards,<br>
Taplingua Team<br>
<img src="{{ url('/images/emailers/taplingua-header.png') }}" style="height: 40px;" />


    </div>
</div>
@endsection
