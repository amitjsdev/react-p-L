<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{"Error"}}</title>

</head>

<body style="font-family: Verdana, Geneva, Tahoma, sans-serif; color: #421C40; max-width: 640px; background-color: #F8F8F8;">
    <div style="padding: 54px;">
        <div style="color: #421C40;">
            <h2 style="font-size: 28px; margin-bottom: 36px; color: red;">Unhandled Exception Logged!</h2>
            <p>Project: <b>Taplingua</b></p>
            <p>Exception message: <code>{{$text}}</code></p>
            <p>Exception log id: <code style="padding: 10px; margin: 0 10px; background-color: #ddd; border-radius: 5px;">{{$exceptionLogId}}</code></p>
            <p style="font-size: 10px; color: #aaa;">Copy the log id for reference in db.</p>
            <p style="margin-top: 2rem;">
                <a target="_blank" style="padding: 5px 10px; border-radius: 5px; background-color: dodgerblue; color: white; text-decoration: none;" href="https://api2.taplingua.com/phpmyadmin/sql.php?db=prodapi&table=exception_logs&pos=0">GOTO PHPMYADMIN</a>
            </p>
        </div>
    </div>
</body>

</html>