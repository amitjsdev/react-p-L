@extends('emails.partials.structure')

@section('content')
<div style="padding: 24px 18px;">
    <div>
        <p>Hi {{ $user }},</p>
        <br>
        <p>You have received feedback for your videos.</p>
        <p>You can access the reviews by clicking <a href="https://app.taplingua.com/myvideos?videoId={{ $interviewVideoId }}">here</a></p>
        <br>
    </div>
    <p>Thanks</p>
    <p>Taplingua Team</p>
</div>
@endsection