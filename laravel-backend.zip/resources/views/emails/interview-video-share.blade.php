@extends('emails.partials.structure')

@section('content')
<div style="padding: 24px 18px;">
    <div>
        <p>Hi,</p>
        <br>
        <p>You are requested to review the interview prep videos for {{ $user }}.</p>
        <p>You can access the videos at <a href="{{ $link }}">{{ $link }}</a></p>
        <br>
    </div>
    <p>Thanks</p>
    <p>Taplingua Team</p>
</div>
@endsection