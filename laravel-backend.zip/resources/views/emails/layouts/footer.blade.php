<div style="background-color: #D6D6D6; padding: 2rem 1rem; text-align: center; font-size: 14px;">
    Need help?
    <abr />
    <!-- <a href="mailto:cristina@taplingua.com">cristina@taplingua.com</a> | -->
    <a href="mailto:support@taplingua.com">support@taplingua.com</a>
    <!-- <div style="margin-top: 5px; margin-bottom: 2rem;">
        Forgot your password? <a href="/">Reset it here</a>
    </div> -->
    <!-- <div style="font-size: 17px; font-weight: bold; margin: 1rem 0;">CLICK on the link to go to this URL</div> -->
    <div style="font-size: 17px; font-weight: bold; margin: 1rem 0;">Download the Taplingua App</div>
    <div style="margin-bottom: 1rem;">
        <!-- <a href=""><img src='{{asset("images/emailers/appstore-0.png")}}' style="max-width: 50%; margin: 0 3px;" /></a> -->
        <a href="https://play.google.com/store/apps/details?id=com.taplingua.languages&hl=en_IN&gl=US"><img src='{{asset("images/emailers/playstore-0.png")}}' style="max-width: 50%; margin: 0 3px;" /></a>
        <!-- <a href="http://app.taplingua.com"> http://app.taplingua.com</a> -->
    </div>
    <!-- <div style="margin-bottom: 1rem;">
        <a href=""><img src='{{asset("images/emailers/facebook.png")}}' style="max-width: 50%; margin: 0 3px;" /></a>
        <a href=""><img src='{{asset("images/emailers/whatsapp.png")}}' style="max-width: 50%; margin: 0 3px;" /></a>
    </div> -->
    <div style="font-size: 12px; margin-bottom: 1rem;">
        You may <a href='{{ getUnsubscribeLink($userId ?? "") }}'>unsubscribe</a> if you prefer not to receive messages like these. <br />
        If something isn’t right, please <a href="">report abuse</a> <br />
        @if(isset($pixelUrl))
        <img alt="" src="{{$pixelUrl}}" />
        @endif
    </div>
</div>
