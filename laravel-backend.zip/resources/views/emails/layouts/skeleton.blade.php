<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{$title ?? "Email"}}</title>

</head>

<body style="font-family: Verdana, Geneva, Tahoma, sans-serif; color: #421C40; max-width: 640px; background-color: #F8F8F8;">
    @yield('content')
    @include('emails.layouts.footer')
</body>

</html>