<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{$notificationTitle}}</title>
</head>

<body>
    <p>
        Hi {{$employee->FirstName}},
    </p>
    <p>
        {{$notificationTitle}}
    </p>
    <p>
        {{$notificationBody}}
    </p>
    <p>
        <a href="{{$branchURL}}">Check it out</a>
    </p>
    <img alt="" src="{{$pixelUrl}}" />
</body>

</html>