@php
$userId = $employee->userId;
@endphp
@extends('emails.layouts.skeleton')

@section('content')
<div style="padding: 54px;">
    <div style="color: #421C40;">
        <p>
            <h2 style="font-size: 35px; margin-bottom: 36px;">Placement Test Results</h2>
        </p>
        <p>Dear {{$employee->FirstName}},</p>
        <p>Please find below the results of your placement test</p>
        <p><b>MODULE: {{$module->description}}</b></p>
        <p>
            <h2 style="font-size: 35px; margin-bottom: 36px;">Total Score: {{ $correctPercentage["Total"] }}%</h2>
        </p>
        <table class="border-collapse: collapse; border: 1px solid gray;">
            <thead>
                <tr>
                    <th style="padding: 10px 24px; border: 1px solid gray; color: white; background-color: #0D1853;">Skill Area</th>
                    <th style="padding: 10px 48px; border: 1px solid gray; color: white; background-color: #0D1853;">Score</th>
                    <th style="border: 1px solid gray; color: white; background-color: #0D1853; width: 200px;">Score</th>
                </tr>
            </thead>
            <tbody>
                @foreach($correctPercentage as $key => $percentage)
                <tr>
                    <th style="padding: 10px 24px; border: 1px solid gray; text-align: left;">{{$key === "Total" ? "Overall" : $key}}</th>
                    <th style="padding: 10px 48px; border: 1px solid gray;">{{$percentage}}%</th>
                    <th style="width: 200px; text-align: left;"><span style="background-color: {{$key === 'Total' ? '#3036D6' : '#7F82E3' }}; height: 24px; width: {{$percentage*2}}px; display: inline-block;">&nbsp;</span></th>
                </tr>
                @endforeach
            </tbody>
        </table>
        <!-- <x-email-sequence-action-button sub-message="NEXT STEPS" message="Get 100 points today" image-src="images/beginner.png" button-label="Start Learning" button-link="{{$link}}" /> -->
        <img alt="" src="{{$pixelUrl}}" />
    </div>
</div>
@endsection