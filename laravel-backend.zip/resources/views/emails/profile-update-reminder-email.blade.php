@php
$userId = $employee->userId;
@endphp
@extends('emails.layouts.skeleton')

@section('content')
<div style="padding: 54px;">
    <div style="color: #421C40;">
        <p>
            <h2 style="font-size: 35px; margin-bottom: 36px;">Placement Test Results</h2>
        </p>
        <p>Hi {{$employee->FirstName}},</p>
        <p>We noticed that you haven't completed your profile for your application to {{$companyName}}.
            .We cannot make a decision unless you finish the Profile. Please do so immediately.</p>
        <p>{{$companyName}} Team</p>
        <!-- <x-email-sequence-action-button sub-message="NEXT STEPS" message="Get 100 points today" image-src="images/beginner.png" button-label="Start Learning" button-link="{{$link}}" /> -->
        <img alt="" src="{{$pixelUrl}}" />
    </div>
</div>
@endsection