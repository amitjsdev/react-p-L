<body style=" margin: 0 auto; max-width: 700px;">

    <div style="text-align: center;">
        <div style="padding-top: 3rem;">
            <img src="{{ url('/images/beginner.png') }}" />
        </div>
        <div style="padding: 2rem 0;">
            <img src="{{ url('/images/emailers/taplingua-header-only.png') }}" />
        </div>
        <div style="padding-bottom: 3rem;">
            <span style="font-size: 32px; font-weight: bold;">Daily Taplingua Reminder</span>
        </div>
        <div style="padding-bottom: 1rem; max-width: 320px; margin: auto;">
            <span style="font-size: 14px; font-weight: bold;">
                Hi {{$username}}! {{$text}}
            </span>
        </div>
        @if(isset($label))
        <div style="text-align: center; padding: 0 0 36px; margin: 6px 0 36px;">
            <a style="border-radius: 19px; background-color: #7066EF; color: white; padding: 12px 56px; text-decoration: none; font-weight: bold; display: inline-block;" href="{{ $link }}">{{$label}}</a>
        </div>
        @endif
    </div>

    @include('emails.layouts.footer')

</body>