<body style=" margin: 0 auto; max-width: 700px;">

    <div style="margin: 20px 0;">

        <p>
            Hi, <br />
            Below is the summary report for email and push for <b>{{$today->format('d M Y')}}</b>
        </p>
        <table style="margin-bottom: 20px;">
            <tbody>
                <tr>
                    <th style="text-align: left;">Email Bounce Count</th>
                    <td>{{$emailBounceCount}}</td>
                </tr>
                <tr>
                    <th style="text-align: left;">Email Unsubscribe Count</th>
                    <td>{{$emailUnsubscribeCount}}</td>
                </tr>
            </tbody>
        </table>
        <!-- Email Log -->
        <hr>
        <h4>Email Report</h4>
        <table style="width: 100%;">
            <thead>
                <tr>
                    <th style="text-align: left;">Campaign Id</th>
                    <th style="text-align: left;">Email Sent</th>
                    <th style="text-align: left;">Email Opened</th>
                    <th style="text-align: left;">CTA Clicked</th>
                </tr>
            </thead>
            <tbody>
                @forelse($elogByCampaign as $elog)
                <tr>
                    <td>{{$elog->type}}</td>
                    <td>{{$elog->emailSent}}</td>
                    <td>{{$elog->emailOpened}}</td>
                    <td>{{$elog->ctaClicked}}</td>
                </tr>
                @empty
                <tr>
                    <td colspan="4">No records</td>
                </tr>
                @endforelse
            </tbody>
        </table>
        <!-- Push Log -->
        <hr>
        <h4>Push Report</h4>
        <table style="margin-bottom: 20px;" class="table">
            <tbody>
                <tr>
                    <th style="text-align: left; padding-right: 10px;">Total Users that we are aiming </th>
                    <td>{{$totalUserCount}}</td>
                </tr>
                <tr>
                    <th style="text-align: left; padding-right: 10px;">Users that we have lost (Deleted the app) </th>
                    <td>{{$lostUserCount}}</td>
                </tr>
                <tr>
                    <th style="text-align: left; padding-right: 10px;">Users that turned Notification Off (Exclusive from lost users)</th>
                    <td>{{$userCountWithNotificationOff}}</td>
                </tr>
                <tr>
                    <th style="text-align: left; padding-right: 10px;">Potential Users Count</th>
                    <td>{{$potentialUserCount}}</td>
                </tr>
                <tr>
                    <th style="text-align: left; padding-right: 10px;">-</th>
                    <td>-</td>
                </tr>
                <tr>
                    <th style="text-align: left; padding-right: 10px;">Failed Push Count </th>
                    <td>{{$failedPushes}}</td>
                </tr>
            </tbody>
        </table>
        <table style="width: 100%;">
            <thead>
                <tr>
                    <th style="text-align: left;">Campaign Id</th>
                    <th style="text-align: left;">Push Sent</th>
                    <th style="text-align: left;">Push Received</th>
                    <th style="text-align: left;">Push Opened</th>
                </tr>
            </thead>
            <tbody>
                @forelse($plogByCampaign as $elog)
                <tr>
                    <td>{{$elog->type}}</td>
                    <td>{{$elog->pushSent}}</td>
                    <td>{{$elog->pushReceived}}</td>
                    <td>{{$elog->pushOpened}}</td>
                </tr>
                @empty
                <tr>
                    <td colspan="4">No records</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</body>