@php
$title = "Check Your Progress!";
$userId = $employee->userId;
@endphp
@extends('emails.layouts.skeleton')

@section('content')
<p>Hi {{$employee->FirstName}},</p>
<p>Here is your goal history</p>
<img src="{{$chartURL}}" />
@endsection