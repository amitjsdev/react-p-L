@php
$userId = $employee->userId;
@endphp
@extends('emails.layouts.skeleton')

@section('content')
<img src="{{ url('/images/emailers/email-from-founder.png') }}" style="max-width: 100%;" />

<div style="padding: 54px;">
    <div style="font-weight: bold; color: #421C40; font-size: 35px; letter-spacing: -1px; text-align: center; padding: 24px 0;">
        How Taplingua helps you learn
    </div>
    Hi {{$employee->FirstName}},<br />
    <p>This is Cristina. Co-founder of Taplingua and VP of Learning. I hope Polly (the friendly Taplingua language learning coach) has been taking good care of you.</p>
    <p>I wanted to take a minute to introduce you to how Taplingua can help you. As an expat, you want to experience your life in Spain. Make friends with the locals, order the best Paella in town, explore quaint cities and all that Spain has to offer. If you spoke some Spanish, it would go a long way in your adopted homeland!</p>
    <p>So, why not start with that goal in mind? </p>
    <p><b>Taplingua teaches you in a way that you can start using Spanish Day 1 of the course.</b> .e.g the first lesson starts with what you need to know to order a drink in Spanish. Yeah...you will soon be able to order your own vino tinto at your favorite terraza!</p>
    <p><b>We use such everyday situations throughout the course to gently introduce new words and vocabulary.</b> Unlike some of our competitors (the green bird one - you know what I mean), we don’t overwhelm you with rote vocabulary and mindless practice.</p>
    <p>Whether you want to learn some quick Spanish vocabulary or you want to reach fluency in Spanish. We will take you all the way. From the most basic vocabulary to the most advanced grammar concepts (the subjunctive can be hard even for the students studying for years), I will progressively introduce you to the Spanish language. If you are more advanced</p>
    <br />
    <p>Happy Learning,</p>
    <p>
        <div style="padding: 12px 0; overflow: none;">
            <img src="{{ url('images/cristina.png') }}" style="width: 80px; border-radius: 50%; height: 80px;" />
        </div>
        <b>Dr. Cristina Guijarro</b><br />
        VP Learning, Taplingua
    </p>
    <x-email-sequence-action-button sub-message="NEXT STEPS" message="Get 100 points today" image-src="images/beginner.png" button-label="Learn Now" />
</div>
@endsection