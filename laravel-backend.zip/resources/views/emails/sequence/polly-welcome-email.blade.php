@php
$userId = $employee->userId;
@endphp
@extends('emails.layouts.skeleton')

@section('content')
<img src="{{ url('/images/emailers/mail_header.png') }}" style="max-width: 100%;" />
<div style="padding: 54px;">
    <div style="color: #421C40;">
        <h2 style="font-size: 35px; margin-bottom: 36px;">Welcome to Taplingua!</h2>
        <p>Hi {{$employee->FirstName}},</p>
        <p>Welcome to <b>Taplingua</b> - the language App that <b>helps you learn everyday conversations in {{$moduleName}}.</b></p>
        <p>Many of you are probably struggling with learning {{$moduleName}} in these difficult times of Covid. But it shouldn't be so.</p>
        <p>
            Taplingua gives you all the resources to learn {{$moduleName}} at your own pace. We make difficult language concepts easy to understand and practice in a fun way.
        </p>
        <p>Hang tight and enjoy the ride. We will do it together.</p>
        <p>In the meantime, hit the gas and <b>get your 1st 100 points today and a special prize awaits you!</b></p>
        <br />
        <p>Your friendly language learning coach!</p>
        <b>Polly</b>
        <x-email-sequence-action-button sub-message="NEXT STEPS" message="Get 100 points today" image-src="images/beginner.png" button-label="Start Learning" button-link="{{$link}}" />
        <img alt="" src="{{$pixelUrl}}" />
    </div>
</div>
@endsection