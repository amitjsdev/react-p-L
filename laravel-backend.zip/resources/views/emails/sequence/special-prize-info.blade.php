@php
$userId = $employee->userId;
@endphp
@extends('emails.layouts.skeleton')

@section('content')
<div style="background-color: #F1EFFF; padding: 14px;">
    <img src="{{url('/images/emailers/taplingua-icon.png')}}" />
    <div style="padding: 40px;">
        <div style="font-weight: bold; color: #421C40; font-size: 35px; letter-spacing: -3px; text-align: center; padding: 24px 0;">
            Unlock your 1st Taplingua prize
        </div>
        <div style="text-align: center; padding: 32px 0;">
            <img src="{{url('/images/emailers/gift.png')}}" width="200px" />
        </div>
        Hi there,<br />
        <p>
            It’s your first day at <b>Taplingua School of Most Practical Language Skills!</b> Rev your
            engines..vrroom, vroom and let’s step on it!
        </p>
        <p>Score <b>100 points on your first day and get your surprise gift.</b></p>
        <br />
        <p>See you in class,</p>
        <p><b>Polly</b><br />Head Student Coach, Taplingua</p>
        <x-email-sequence-action-button sub-message="what to do now" message="Get 100 points today" image-src="images/beginner.png" button-label="Yeah! I want to get my prize!" />
    </div>
</div>
@endsection