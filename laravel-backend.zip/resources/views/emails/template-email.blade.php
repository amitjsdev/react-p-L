@php
$title = $subject;
$userId = $email;
@endphp
@extends('emails.layouts.skeleton')

@section('content')
<div style="margin: 2rem 1rem;">
    {!!$content!!}
</div>
@if($label)
<x-email-sequence-action-button sub-message="" message="" image-src="images/beginner.png" button-label="{{ $label }}" button-link="{{$link}}" />
@endif
<img alt="" src="{{$pixelUrl}}" />
@endsection