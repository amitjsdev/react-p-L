
@extends('emails.layouts.skeletonTypeTwo')

@section('content')
<div>
    <div style="background-color: white; display: flex; align-items: center; padding: 5px 5px 15px; border-bottom: 1px solid #aaa;">
       @if(empty($companyId))
        <img src="{{ url('/images/emailers/taplingua-header.png') }}" style="height: 40px;" />
        @else
        <span style="padding: 0 12px; font-weight: bold;">for</span>
        <img src="https://langappnew.s3.amazonaws.com/logos/{{$companyId}}.jpeg" style="height: 40px;" />
        @endif
    </div>

    <div style="padding: 12px;">
        <p>
            Dear {{$name}}!<br>
            Thank you for successfully attempting the test for {{$cohortName}}. Your test has been successfully recorded.
Someone from the {{$companyTeam}} will contact you shortly.
</p>

<p>
Regards,<br/>
{{$companyTeam}} Team<br>
<img src="https://langappnew.s3.amazonaws.com/logos/{{$companyId}}.jpeg" style="height: 40px;" />

        </p >


    </div>
</div>
@endsection
