@php
$title = "Taplingua language learning App";
$userId = $employee->userId;
@endphp
@extends('emails.layouts.skeleton')

@section('content')
<br />
<p>Hi {{$employee->FirstName}},</p>
<br />
<p>
    Thanks for downloading the Taplingua App recently. I noticed that you didn't really use the App?
</p>
<p>
    I am curious what stopped you from using the Taplingua App.
</p>
<p>
    Was it to difficult, too easy, couldn't find what you were look for or was it some other reason?
</p>
<br />
<p>
    Any feedback is much appreciated?
</p>
<p>
    Thanks
</p>
<p>
    Santanu
</p>
<br />
<p>
    santanu@taplingua.com
</p>
<br />
<p>
    Taplingua
</p>
<br />
@endsection