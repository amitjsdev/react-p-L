@extends('emails.layouts.skeleton')

@section('content')
<br />
<p>
    Hi,<br />
    You are unsubscribed from taplingua emails!
</p>
<br />
@endsection