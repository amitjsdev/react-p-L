Hi,<br>
<br>
<p>Exercise ID: {{ $exercise ? $exercise->id : "Forum Not for Exercise" }}</p>
<p>Lesson No: {{ $exercise ? $exercise->lessonNo : "Forum Not for Exercise" }}</p>
{{$employee->FirstName}} ({{$userId}}) just posted a new comment. Check it out: {{$url}}