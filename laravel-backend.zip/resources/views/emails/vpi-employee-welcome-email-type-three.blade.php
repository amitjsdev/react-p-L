@php
$userId = $email;
@endphp
@extends('emails.layouts.skeletonTypeTwo')

@section('content')
<div>
    <div style="background-color: white; display: flex; align-items: center; padding: 5px 5px 15px; border-bottom: 1px solid #aaa;">
        <img src="{{ url('/images/emailers/taplingua-header.png') }}" style="height: 40px;" />
        <span style="padding: 0 12px; font-weight: bold;">for</span>
        <img src="https://langappnew.s3.amazonaws.com/logos/{{$companyId}}.jpeg" style="height: 40px;" />
    </div>
    <div style="font-weight: 700; margin-top: 15px;">
        Taplingua for {{$companyName}} / {{$cohortName}}
    </div>
    <div style="padding: 12px;">
        <p>
            Dear {{$name}}!<br>
            <p>Thanks for signing up for the Communications Assessment for {{$companyName}} / {{$cohortName}}</p><br>

            <p>The communication Assessment test asks you several questions and you are required to answer the questions using your camera. </p>
            <br>
            <p>Please go to https://app.taplingua.com and enter your email and password below:</p>
            <br>

            @if(!empty($password))

            <div style="border: 1px solid black; padding: 2px 16px; margin-bottom: 16px;">
                <p>LOGIN</b> using your email and password below</p>
                <p>
                    email: <b>{{$email}}</b> <br>
                    password: <b>{{$password}}</b>
                </p>
            </div>
            @else
            <div style="border: 1px solid black; padding: 2px 16px; margin-bottom: 16px;">
                <p>You can login with your email and password. In case you have forgotten your password, 
                    please reset it using the forget password link in the login page.
                </p>
            </div>
        @endif
        <br/>
        <br/>


Regards,<br/>
{{$companyName}} / {{$cohortName}} Team<br>
<img src="https://langappnew.s3.amazonaws.com/logos/{{$companyId}}.jpeg" style="height: 40px;" />

        </p>


    </div>
</div>
@endsection
