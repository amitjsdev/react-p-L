@extends('emails.partials.structure')

@section('content')
<div style="padding: 24px 18px;">
    <div>
        <p> Dear {{$name}}!</p>
        <br>
        <p>Thank you for submitting your answers for {{$cohortName}}</p>
        <br>
    </div> 
    <p>Thanks</p>
    <p>Taplingua Team</p>
</div>
@endsection