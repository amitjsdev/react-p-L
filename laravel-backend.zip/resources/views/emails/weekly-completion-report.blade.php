@extends('emails.partials.structure')

@section('content')
<div style="padding: 2rem">
    <div style="display: flex; justify-content: space-between;">
        <div style="font-size: 24px; margin-bottom: 1rem; font-weight: 500; padding: 1rem;">{{ $data["moduleName"] }}</div>
        <img src='{{asset("/images/emailers/line1.png")}}' />
    </div>
    <div style="font-size: 17px; padding: 1rem;">
        <div style="margin-bottom: 0.5rem;">{{ __("email.completion-report.greeting", ["name" => $data["Name"]]) }}</div>
        {{ __("email.completion-report.line1", ["moduleName" => $data["moduleName"], "companyName" => $data["companyName"]]) }}
    </div>
    <div style="background-color: white; padding: 2rem; border: 1px solid #F2F2F2; margin-bottom: 2rem; border-radius: 8px;">
        <div style="color: #EE8538; font-size: 25px; font-weight: 500;">{{$data['moduleName']}}</div>
        <div style="color: #939393; font-size: 12px; margin-top: 0.5rem; font-family: 'SF Pro Text';">
            <span>{{__("email.completion-report.duration")}}: {{$data['courseDuration']}}</span>
            <span style="text-decoration: underline; padding: 0 8px;">{{$data['courseStartDate']}} - {{$data['courseEndDate']}}</span>
        </div>
        <table style="text-align: center; margin: 2rem 0; width: 100%;">
            <tbody style="width: 100%">
                <tr style="width: 100%">
                    @foreach($data['Routes'] as $key => $route)
                    <td>
                        <div style="font-size: 25px; padding: 0.5rem; color: #F6936F; font-weight: bold;">
                            <img style="max-width: 100%" src='{{asset("/images/emailers/progress/email-progress-".str_pad($route["routePercent"], 3, 0, STR_PAD_LEFT).".png")}}' alt='{{ $route["routePercent"] }}%' />
                        </div>
                        <div style="font-size: 14px;">{{$key}}</div>
                    </td>
                    @endforeach
                </tr>
            </tbody>

        </table>
        <div style="font-family: 'SF Pro Text'; font-size: 14px; padding-top: 2rem;">
            {!!__('email.completion-report.trivia', ['moduleName' => $data['moduleName']])!!}
        </div>
    </div>
    <div style="background-color: white; padding: 2rem; border: 1px solid #F2F2F2; margin-bottom: 2rem; border-radius: 8px;">
        <div style="color: #EE8538; font-size: 25px;">{!!__('email.completion-report.motivation')!!}</div>
        <div style="font-family: 'SF Pro Text'; font-size: 14px; padding-top: 1rem;">
            {!!__('email.completion-report.motivation2', ['coursePercent' => $data['coursePercent']])!!}
        </div>
        <table>
            <tbody>
                <tr>
                    <td style="width: 50%; text-align: center;">
                        <img style="max-width: 100%; height: auto;" src='{{ $data["certificateImg"] }}' />
                    </td>
                    <td style="width: 50%; text-align: center;">
                        <img style="max-width: 100%; height: auto;display: inline-block; max-width: 100%; height: auto; font-size: 42px; padding: 0.5rem; color: #F6936F; font-weight: bold; box-sizing: border-box; text-align: center;" src='{{asset("/images/emailers/progress/email-progress-".str_pad($data["coursePercent"], 3, 0, STR_PAD_LEFT).".png")}}' alt='{{ $data["coursePercent"] }}%' />
                    </td>
                </tr>
            </tbody>
        </table>
        <div style="text-align: center; padding-top: 1.5rem;">
            <a href="{{ $branchLink }}" style="color: white; font-size: 16px; display: inline-block; text-decoration: none; padding: 1rem 2rem; border-radius: 8px; background-image: linear-gradient(90deg, #EC5551, #FDC285)">
                {{__('email.completion-report.resume-button')}}
            </a>
        </div>
    </div>
</div>
@endsection