@extends('emails.partials.structure')

@section('content')
<div style="padding: 2rem">
    <!-- greeting -->
    <div style="font-size: 24px; margin-bottom: 1rem; font-weight: 500; padding: 1rem;">
        {{__('email.weekly.subject', ['moduleName' => $data['moduleName']])}}
    </div>
    <div style="font-size: 17px; padding: 1rem;">
        <div style="margin-bottom: 0.5rem;">{{ __("email.welcome.greeting", ["name" => $data["Name"]]) }}</div>
        {{ __("email.weekly.line1", ["moduleName" => $data["moduleName"], "companyName" => $data["companyName"]]) }}
    </div>
    <!-- all weeks -->
    <div style="background-color: white; padding: 2rem; border: 1px solid #F2F2F2; margin-bottom: 2rem; border-radius: 8px;">
        <div style="color: #EE8538; font-size: 25px;">{!!__('email.welcome.schedule-title', ['moduleName' => $data["moduleName"]])!!}</div>
        <div style="color: #939393; font-size: 12px; margin-top: 0.5rem; font-family: 'SF Pro Text';">
            <span>{{__("email.completion-report.duration")}}: {{$data['courseDuration']}}</span>
            <span style="text-decoration: underline; padding: 0 8px;">{{$data['courseStartDate']}} - {{$data['courseEndDate']}}</span>
        </div>
        <table style="margin-top: 2rem;">
            <tbody>
                <tr>
                    <td style="width: 75px; height: auto;">
                        <img alt="{{$data['moduleName']}}" style="width: 64px;" src='{{"https://app.taplingua.com/_assets/module_icons/icon_module_" . $data["moduleNumber"] . ".png"}}' /> </td>
                    <td>
                        <div style="font-size: 20px; font-weight: bold;">{{ $data['moduleName'] }} - {{ $data['description'] }}</div>
                        <span style="color: #939393; font-size: 12px; margin-top: 0.5rem; font-family: 'SF Pro Text'; text-decoration: underline;">
                            {{
                                \Carbon\Carbon::parse($data['courseStartDate'])->addDays(($data['routeno'] - 1) * 7)->format('d, M Y')
                            }} - {{
                                \Carbon\Carbon::parse($data['courseStartDate'])->addDays(($data['routeno']) * 7)->format('d, M Y')
                            }}
                        </span>
                    </td>
                </tr>
            </tbody>
        </table>
        <table style="margin-bottom: 2rem;">
            <tbody>
                @foreach($data['routeLevels'] as $route)
                <tr>
                    <td>
                        <img style="margin-top: 0.75rem; margin-bottom: 0.75rem;" src='{{asset("/images/emailers/count/email-lesson-".str_pad($route["levelno"], 3, 0, STR_PAD_LEFT).".png")}}' alt='{{ $route["levelno"] }}' />
                    </td>
                    <td style="font-family:SF Pro Text;font-size: 14px;text-align: left;">
                        {{str_replace('=>', ':', $route['description'])}}
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
        <div>
            {{__('email.weekly.message')}}
        </div>
        <div style="text-align: center; padding-top: 1.5rem;">
            <a href="{{ $branchLink }}" style="color: white; font-size: 16px; display: inline-block; text-decoration: none; padding: 1rem 2rem; border-radius: 8px; background-image: linear-gradient(90deg, #EC5551, #FDC285)">
                {{__('email.weekly.resume', ['weekNo'=> $data['routeno']])}}
            </a>
        </div>
    </div>
</div>
@endsection