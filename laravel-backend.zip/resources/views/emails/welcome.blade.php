@extends('emails.partials.structure')

@section('content')
<div style="padding: 2rem">
    <!-- greeting -->
    <div style="font-size: 24px; margin-bottom: 1rem; font-weight: 500; padding: 1rem;">
        Welcome to the {{ $data["moduleName"] }} course
    </div>
    <div style="font-size: 17px; padding: 1rem;">
        <div style="margin-bottom: 0.5rem;">{{ __("email.welcome.greeting", ["name" => $data["Name"]]) }}</div>
        {{ __("email.welcome.line1", ["moduleName" => $data["moduleName"], "companyName" => $data["companyName"]]) }}
    </div>
    <!-- all weeks -->
    <div style="background-color: white; padding: 2rem; border: 1px solid #F2F2F2; margin-bottom: 2rem; border-radius: 8px;">
        <div style="color: #EE8538; font-size: 25px;">{!!__('email.welcome.schedule-title', ['moduleName' => $data["moduleName"]])!!}</div>
        <div style="color: #939393; font-size: 12px; margin-top: 0.5rem; font-family: 'SF Pro Text';">
            <span>{{__("email.completion-report.duration")}}: {{$data['courseDuration']}}</span>
            <span style="text-decoration: underline; padding: 0 8px;">{{$data['courseStartDate']}} - {{$data['courseEndDate']}}</span>
        </div>
        <table style="margin: 2rem 0;">
            <tbody>

                @foreach($data['Routes'] as $route)
                <tr>
                    <td width="33" align="left" valign="top" style="width:33px;">
                        <img src="{{asset('/images/emailers/progress-point' . ($loop->first ? '-checked' : '') . '.png')}}" width="33" height="33" />
                        @if(!$loop->last)
                        <img src="{{asset('/images/emailers/progress-line.png')}}" width="33" height="33" />
                        @endif
                    </td>
                    <td style="padding:0px 0px 0px 10px; vertical-align:top; ">
                        <div style="margin: 5px 0; font-weight:bold; color: {{$loop->first ? '#EE8538' : '#000000'}}; text-align:left; font-size:18px;">
                            {{$route['description']}}
                        </div>
                        <div style="margin-top: 0px; font-weight:normal; height:23px; color:#939393; text-align:left; vertical-align:middle; font-size:12px;">
                            <div style="color: #939393; font-size: 12px; font-family: 'SF Pro Text';">
                                <u>{{$route['courseStartDate']}}</u> - <u>{{$route['courseEndDate']}}</u>
                            </div>
                            @if(!empty($route['long_description']))
                            <div style="font-family: 'SF Pro Text'; font-size: 14px; padding-top: 1rem; color: black;">
                                {{$route['long_description']}}
                            </div>
                            @endif
                        </div>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    <!-- certificate and motivation -->
    <div style="background-color: white; padding: 2rem; border: 1px solid #F2F2F2; margin-bottom: 2rem; border-radius: 8px;">
        <div style="color: #EE8538; font-size: 25px;">{!!__('email.welcome.motivation')!!}</div>
        <div style="font-family: 'SF Pro Text'; font-size: 14px; padding-top: 1rem;">
            {!!__('email.welcome.motivation2')!!}
        </div>
        <img style="max-width: 100%; height: auto; margin-top: 2rem;" src='{{ $data["certificateImg"] }}' />
    </div>
</div>
@endsection