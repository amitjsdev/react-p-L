<table border="1">
    <?php
    $rc =["Jee Rank","Location","Company Name","State Exam Rank","Current Address","Whatsapp Number","Work Experience","Are You Working YN","Branch Or Department","Class10GPAor Percent","College Entrance Name","Plans To Work Full Time","Graduation College Name","Graduation GPAor Percent","Final Exam Start If Student","Graduation Date If Student"]; ?>
    <thead>
      <tr >
        <th style="font-weight: bold; background-color:gray">Response</th>
        <th style="font-weight: bold; background-color:gray;width:200px">Name</th>
        <th style="font-weight: bold; background-color:gray;width:200px">Email</th>
        <th  style="font-weight: bold; background-color:gray;width:200px">Phone</th>
        <th  style="font-weight: bold; background-color:gray;width:200px">Exam Start Date</th>
        <th  style="font-weight: bold; background-color:gray;width:120px">Video</th>
        <th  style="font-weight: bold; background-color:gray;width:120px">UFM %</th>
        <th  style="font-weight: bold; background-color:gray;width:120px">Looking Sideways</th>
        <th  style="font-weight: bold; background-color:gray;width:120px">Looking  Up/Down</th>
        <th  style="font-weight: bold; background-color:gray;width:120px">Total time of test</th>
        <th  style="font-weight: bold; background-color:gray;width:120px">Time stepped away </th>
        <th  style="font-weight: bold; background-color:gray;width:120px">> 1 person</th>

        <th  style="font-weight: bold; background-color:gray;width:120px">Complete</th>
        <th  style="font-weight: bold; background-color:gray;width:120px">Attempt Number</th>
        <th  style="font-weight: bold; background-color:gray;width:120px">Reason Incomplete</th>
        <th  style="font-weight: bold; background-color:gray;width:120px">Percent</th>

        <th  style="font-weight: bold; background-color:gray;width:120px">Right</th>
        <th  style="font-weight: bold; background-color:gray;width:120px">Wrong</th>
        <th  style="font-weight: bold; background-color:gray;width:120px">Not Attempted</th>

        @foreach ($questions as $q)
        <th colspan="2" style="font-weight: bold; background-color:gray;width:200px">{{$q}}</th>
        @endforeach
        @foreach ($rc as $r)
        <th  style="font-weight: bold; background-color:gray;width:200px">{{$r}}</th>
        @endforeach

      </tr>
      <tr>
        <th style="font-weight: bold; background-color:gray"></th>
        <th style="font-weight: bold; background-color:gray"></th>
        <th style="font-weight: bold; background-color:gray"></th>

        <th style="font-weight: bold; background-color:gray"></th>
        <th style="font-weight: bold; background-color:gray"></th>
        <th style="font-weight: bold; background-color:gray"></th>

        <th style="font-weight: bold; background-color:gray"></th>
        <th style="font-weight: bold; background-color:gray"></th>
        <th style="font-weight: bold; background-color:gray"></th>

        <th style="font-weight: bold; background-color:gray"></th>
        <th style="font-weight: bold; background-color:gray"></th>
        <th style="font-weight: bold; background-color:gray"></th>

        <th style="font-weight: bold; background-color:gray"></th>
        <th style="font-weight: bold; background-color:gray"></th>
        <th style="font-weight: bold; background-color:gray"></th>

        <th style="font-weight: bold; background-color:gray"></th>
        <th style="font-weight: bold; background-color:gray"></th>


        @foreach ($questions as $q)
        <th style="font-weight: bold; background-color:gray">Answer</th>
        <th style="font-weight: bold; background-color:gray"> Score</th>
        @endforeach

      </tr>
    </thead>
    <tbody>
        @foreach ($users as $u)
        <tr>
            @foreach ($u as $i=>$datum)
            {{-- @if($i==5 || $i==6)
            <td ><a href="{{$datum}}" target="_blank">Video V1</a></td>
            @else --}}
            <td >{{$datum}}</td>
            {{-- @endif --}}
            @endforeach
        </tr>
        @endforeach

    </tbody>
  </table>
