<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Taplingua - Forum</title>
    <link href="https://fonts.googleapis.com/css2?family=Mallanna&family=Montserrat:wght@100;200;300;400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('/fonts/fonts.css') }}">
    <link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
</head>

<body>
    <div id="root"></div>
    <script src="{{ asset('js/forum.js') }}"></script>
</body>

</html>