<table border="1">
    <?php
    $rc =["Jee Rank","Location","Company Name","State Exam Rank","Current Address","Whatsapp Number","Work Experience","Are You Working YN","Branch Or Department","Class10GPAor Percent","College Entrance Name","Plans To Work Full Time","Graduation College Name","Graduation GPAor Percent","Final Exam Start If Student","Graduation Date If Student"]; ?>
   <thead>
      <tr >
        <th style="font-weight: bold; background-color:gray;width:200px">Email</th> 
        <th  style="font-weight: bold; background-color:gray;width:200px">Name </th>
        @if(isset($questions))
        @foreach ($questions as $val)
        <th  style="font-weight: bold; background-color:gray;width:200px">{{$val->practiceSetQuestion}} </th>
        <th  style="font-weight: bold; background-color:gray;width:200px">Vpi Score</th>
        @endforeach 
        @endif
      </tr>
    </thead>
    <tbody>
    @foreach ($users as $u)
    <tr>
    <td >{{$u->email}}</td>
    <td >{{$u->FirstName}} {{$u->LastName}}</td>
    @if(isset($u->userAnswered))
    @foreach ($u->userAnswered as $val)
    @if(isset($val->reviewFileLocation))
    <td >{{$val->reviewFileLocation}}</td>
    @else
    <td ></td>
    @endif
    @if(isset($val->vpi_score))
    <td >{{number_format((json_decode($val->vpi_score))->fluency_score,2,'.','')}}</td>
    @else
    <td ></td>
    @endif
        @endforeach 
        @endif
        </tr>
        @endforeach 
    
    </tbody>
  </table>
