import React from 'react';
import './input.css';
const Input = (props:Props) => {
    let {
        label,
        name,
        className,
        placeholder,
        classNameInput,
        onChange,
        required, type, disabled, value
    } = props;
    className = className ? className : ' col-xs-12 col-sm-6 ';
    classNameInput = classNameInput ? `tp-input form-control ${classNameInput}` : 'tp-input form-control';
    disabled = disabled ? disabled : false;
    type = type ? type : 'text';



    return (
        <div className={'relative ' + className}>
            <label className="form-label" >{label}</label>
            <div className="input-div">
            <input
             value={value} 
             disabled={disabled} 
             placeholder={placeholder} 
             className={classNameInput} 
            //  onChange={onChange} 
             name={name} 
             type={type}
              />
            </div>

            {props.children}
        </div>)
}
export default Input;
interface Props {
    label: string;
    name: string;
    className?: string;
    placeholder?: string;
    classNameInput?: string;
    required?: boolean;
    disabled?: boolean;
    type?: string;
    value?: string;
    onChange?: React.ChangeEvent<HTMLInputElement>; 
    children?:React.ReactChildren  
  }