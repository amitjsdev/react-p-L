import React from 'react';
import MicRecorder from 'mic-recorder-to-mp3';
import { Col } from 'react-bootstrap'
const Mp3Recorder = new MicRecorder({ bitRate: 128 });
class Mp3 extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isRecording: false,
            blobURL: this.props.audio ? this.props.audio : '',
            isBlocked: false,
            audio: this.p,
        }

    }

    componentDidMount() {
        this.initRecording();
    }
    initRecording = () => {
        navigator.getUserMedia = (navigator.getUserMedia ||
            navigator.webkitGetUserMedia ||
            navigator.mozGetUserMedia ||
            navigator.msGetUserMedia);
        navigator.getUserMedia({ audio: true },
            () => {
                console.log('Permission Granted');
                this.setState({ isBlocked: false });
            },
            () => {
                console.log('Permission Denied');
                this.setState({ isBlocked: true })
            },
        );
    }
    start = () => {
        if (this.state.isBlocked) {
            console.log('Permission Denied');
        } else {
            Mp3Recorder
                .start()
                .then(() => {
                    this.setState({ isRecording: true });
                }).catch((e) => console.error(e));
        }
    };
    audioToBase64 = async (audioFile) => {
        return new Promise((resolve, reject) => {
            let reader = new FileReader();
            reader.onerror = reject;
            reader.onload = (e) => resolve(e.target.result);
            reader.readAsDataURL(audioFile);
        });
    }
    stop = () => {
        console.log('stop');
        Mp3Recorder
            .stop()
            .getMp3()
            .then(async ([buffer, blob]) => {
                const blobURL = URL.createObjectURL(blob)
                this.setState({ blobURL, isRecording: false });
                const file = new File(buffer, 'me-at-thevoice.mp3', {
                    type: blob.type,
                    lastModified: Date.now()
                });
                this.props.setAudio(file)
            }).catch((e) => console.log(e));
    };

    deleteRecording = () => {
        this.setState({ blobURL: '', audio: null })
        this.props.setAudio(undefined)
    }


    render() {
        return (
            <Col sm={12} md={12}>
                <div style={{
                    marginTop:10,
                    padding: '1rem 0',
                    backgroundColor: 'white',
                    borderRadius: '16px',
                    border: '1px solid #0007',
                    boxShadow: '0px 0px 24px 0px #0003'
                }}>


                    <Col sm={12} md={12}> New Audio Feedback </Col>
                    <Col sm={12} md={12}>
                        <div className="border" style={{ display: 'inline-flex' }}>
                            <div>
                                {
                                    this.state.isRecording ? (
                                        <button onClick={this.stop}
                                            style={{ backgroundColor: 'red', color: 'white', display: 'inline-flex' }}
                                            className='btn btn-danger btn-xs'>
                                            <img src='/_assets/mic.png' alt="record" style={{ height: '25px', display: 'inline-flex' }} />
                                            Stop Recording
                                        </button>
                                    ) : (
                                        <button onClick={this.start}
                                            style={{ backgroundColor: '#31C072', color: 'white', display: 'inline-flex', margin: '0 5px 0 0' }}
                                            className='btn btn-primary btn-xs'>
                                            <img src='/_assets/mic.png' alt="record" style={{ height: '25px', display: 'inline-flex' }} />
                                            Record Audio feedback
                                        </button>

                                    )
                                }
                            </div>
                            {!!this.state.blobURL && <div><audio src={this.state.blobURL} controls="controls" /></div>}
                            {!!this.state.blobURL && <div>

                                <button onClick={this.deleteRecording} disabled={this.state.isRecording}
                                    style={{ margin: '0 3px' }}
                                    className='btn btn-danger btn-xs'>
                                    <img src='/_assets/trash-bin.png' alt="record" style={{ height: '25px', display: 'inline-flex' }} />
                                    Delete Recording
                                </button>

                            </div>
                            }
                        </div>
                    </Col>
                </div>
            </Col>
        )
    }

}
export default Mp3;
