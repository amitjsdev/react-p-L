import React, { useState, useEffect } from 'react';
import { history } from '../_config';
import { MainService } from '../_services/main.service'
import { Router, Switch, Route } from 'react-router-dom';
import QuizSetPage, { QUIZ_SET_ROUTE } from '../_pages/quiz-sets/quiz-set.page';
import QuizAttemptPage, { QUIZ_ATTEMPT_ROUTE } from '../_pages/quiz-sets/quiz-attempt.page';
import { processAITimerhandler } from '../_pages/quiz-sets/AIHOC'
import { baseUrl } from "../_config/endpoints.config"
import { LottieLoader } from '../_components/lottie-loader.component'
import axios from 'axios';
import NetworkSpeed from './NetworkSpeedCheck'; // ES6

// import { setQuizSetId } from '../store/action-creator';
const main = new MainService()

const Quiz = (props) => {
    const { user } = props;
    const [cameraActive, setCameraActive] = useState(false);
    const [cameraError, setCameraError] = useState(false);
    const [isAlignConfirmed, setAlginConfirm] = useState(false);
    const [cameraEnabledAgree, setCameraEnabledAgree] = useState(false)
    const [isRecording, setIsRecording] = useState(false);
    const [percent, setPercent] = useState(0); // how many questions to display
    const [showUpload, setShowUpload] = useState(false);
    const [showResults, setShowResults] = useState(false);
    const [attemptNumber, setAttemptNumber] = useState();
    const [quizAttemptLogId, setquizAttemptLogId] = useState();
    const [quizSetId, setQuizSetId] = useState(0);
    const [startCamera, setstartCamera] = useState(false);
    const [stopCamera, setstopCamera] = useState(false);
    const [startRecording, setstartRecording] = useState(false);
    const [stopRecording, setstopRecording] = useState(false);
    const [multipartData, setMultiPartData] = useState({});
    const [stream, setStream] = useState([]);
    const [size, setSize] = useState(0);
    const [index, setIndex] = useState(0);
    const [time, setTime] = useState(new Date());
    const [keyForPage, setKeyForPage] = useState(new Date());
    const [blobsRecorded, setblobsRecorded] = useState([]);
    const [uploadingToS3, setuploadingToS3] = useState({});
    const [checkMultiDevice, setcheckMultiDevice] = useState(false);
    const [checkMultiDeviceLoading, setcheckMultiDeviceLoading] = useState(false);
    const [uploaded, setUploaded] = useState({});
    const [NetSpeed, setNetSpeed] = useState(undefined);
    const [EstimateTime, setEstimateTime] = useState('');
    const [netSpeedTesting, setnetSpeedTesting] = useState(false);

    const startTest = async (id) => {
        setQuizSetId(id);
        setnetSpeedTesting(true)
        const getSpeed = await getNetworkUploadSpeed();
        if (getSpeed && getSpeed.mbps && getSpeed.mbps > 1) {
            setnetSpeedTesting(false)
            checkMultiDeviceAPI(id)
        } else {
            setnetSpeedTesting(false);
            alert('Your internet speed too slow to take exam')

        }


    }
    const checkMultiDeviceAPI = (id) => {
        setcheckMultiDeviceLoading(true);
        axios.post(`${baseUrl}checkMultiDevice`, { id }, {
            headers: {
                "Authorization": "Bearer " + user.token,
            }
        }).then((res) => {
            setcheckMultiDeviceLoading(false)
            if (res && res.data && res.data.status) {
                setIsRecording(true);
                setstartRecording(true);
                history.push(`/quiz/${id}`);
                setTimeout(() => {
                    startRecordingHandler()
                }, 1000)
            } else {
                alert('Please contact your admin to continue with the exam.');
                window.location.reload()
            }
        }).catch((e) => {
            console.log({ e });
        });
    }
    const setCameraActiveHandler = () => {
        setCameraActive(true)
        setstartCamera(true)
    }

    const onUploadProgress = (e, payloadId, isLast) => {
        const { loaded, total } = e;


        let obj = uploaded;
        obj[payloadId] = { loaded, total }
        if (obj && Object.keys(obj) && Object.keys(obj).length > 0) {
            Object.keys(obj).map((idd) => {
                if (obj && obj[idd] && obj[idd].loaded === obj[idd].total) {
                    delete obj[idd];
                }
            })
        }
        let up = 0;
        let totalSize = 0;
        if (obj && Object.keys(obj) && Object.keys(obj).length > 0) {

            Object.keys(obj).map((obId) => {
                if (obj[obId]) {
                    up = up + obj[obId].loaded
                    totalSize = totalSize + obj[obId].total;
                }
            })
        }
        if (totalSize > 0) {
            setPercent((up / totalSize) * 100)
            console.log(up, totalSize);
            let left = NetSpeed > 0 ? ((totalSize - up) / (NetSpeed * 1000 * 1000)) : 0;
            console.log(left);
            if(isLast && left < 1){
                setShowUpload(false)
                setShowResults(true)
            }
            left = left > 0 ? (left / 60).toFixed(2) : ''
            setEstimateTime(`Your upload speed ${NetSpeed}Mbps, Estimated time to complete ${left} Minutes`);
            
        }

        setUploaded(obj ? obj : {});

    }

    const startRecordingHandler = () => {
        const v = document.getElementById('square1');
        if (v && v.childNodes && v.childNodes[0] && v.childNodes[0].srcObject) {
            const stream = v.childNodes[0].srcObject;
            const mediaRecorder2 = new MediaRecorder(stream, {
                mimeType: "video/webm"
            });
            const recorded_blobs = [];
            // reset the blobs
            setblobsRecorded([]);
            mediaRecorder2.addEventListener('dataavailable', (e) => {
                recorded_blobs.push(e.data);
                setblobsRecorded(recorded_blobs);
                setTime(new Date())

            });
            // start recording with each recorded blob having 1 second video
            mediaRecorder2.start(1000);
        }
    }

    const checkVideoSizeAndUpload = (isLast = false) => {
        let st = blobsRecorded;
        if (stopRecording || !st.length) return;
        const lastItem = st[st.length - 1];
        const currentChunckSize = lastItem.size;
        const totalChunckSize = size + currentChunckSize;
        setSize(totalChunckSize);
        if (isLast || totalChunckSize > 6000000) {
            const thisBlob = st.slice(index, st.length);
            setIndex(st.length);
            setSize(0);
            s3UploadChunk(thisBlob, isLast);

        }
        st = null;
    }
    useEffect(() => {
        checkVideoSizeAndUpload()
    }, [time]);

    useEffect(() => {
        let pending = Object.values(uploadingToS3);
        pending = pending && pending.length > 0 ? pending : [];
        const isanyUploading = pending.find((element) => !element.status)
        if (isanyUploading === undefined && !showResults && showUpload) {
            setShowUpload(false)
            setShowResults(true)

        }
    }, [uploadingToS3])
    const s3UploadChunk = (file, isLast) => {
        s3UploadChunkAPI(file, isLast);
    }


    const s3UploadChunkAPI = (videoData, islast) => {
        const ext = 'webm';

        if (attemptNumber) {
            const payload = {
                quizAttemptLogId,
                ext
            }
            axios.post(baseUrl + 'signed-url', payload, {
                headers: {
                    "Authorization": "Bearer " + user.token,
                }
            }).then((res) => {

                if (res && res.data && res.data.id) {
                    setMultiPartData({ ...multipartData, [res.part_no]: res.data })
                    directS3(res.data, videoData, islast);
                }
            }).catch((e) => {
                console.log({ e });
            });
        }

    }

    const directS3 = (payload, videoData, isLast, retry = 0) => {
        const file = new File(videoData, payload.name);
        const obj = { status: false, data: { payload, videoData, isLast, retry } }
        setuploadingToS3({ ...uploadingToS3, [payload.id]: obj });
        // console.log('payload.id',payload.id);
        if (isLast) {
            setIsRecording(false);
            setShowUpload(true)
        }
        axios.put(payload.presignedUrl,
            file, {
            headers: {
                "Content-Type": "video/webm"
            },
            onUploadProgress: (e) => onUploadProgress(e, payload.id, isLast)
        }).then(() => {
            setuploadingToS3({ ...uploadingToS3, [payload.id]: { status: true, data: null } })
        }).catch((e) => {
            const p = obj;
            p.data.retry = p.data.retry + 1;
            setuploadingToS3({ ...uploadingToS3, [payload.id]: p });
            if (p.data.retry < 3) {
                directS3(p.data)
            }

        })



    }
    const markUploadComplete = (id) => {
        let aiTimer = processAITimerhandler(window.aiTimer);
        axios.post(baseUrl + 'signed-url/complete', { quizAttemptLogId: id, aiTimer }, {
            headers: {
                "Authorization": "Bearer " + user.token,
            }
        }).then((res) => { })
            .catch((e) => { });
    }


    const setShowResultsHandler = () => {
        setstopRecording(true);


        checkVideoSizeAndUpload(true)
        markUploadComplete(quizAttemptLogId)

    }
    const handleAbruptMediaClose = () => {
        console.log('handleAbruptMediaClose');
        alert('We need access to your camera for the test to proceed but were not able to get it. Please reload the screen and enable. camera access.');
        window.location.reload()

    }
    const setStreamHandler = () => {
        const stream = window.aiStream;
        const tracks = stream.getTracks();
        tracks.forEach((track) => {
            track.onended = handleAbruptMediaClose;
        });
    }

    useEffect(() => {
        if (isRecording) {
            setStreamHandler()
        }
    }, [isRecording])

    useEffect(() => {
        (function () {
            const log = console.log;
            console.log = function (str) {
                const s = JSON.stringify(str);
                const isError =s.includes('The request is not allowed by the user agent or the platform in the current context');
               if(isError){
                alert('Camera Error');
                window.location.reload()
               }
              log.call(this, ...arguments);
            };
          }());
    },[])


    const callbackTimerForTimeLeft = (startTime) => {
        setKeyForPage(startTime)
    }

    async function getNetworkUploadSpeed() {
        const testNetworkSpeed = new NetworkSpeed();
        const hostname = baseUrl.replace('https://', '').replace('http://', '');
        const options = {
            hostname,
            //   port:,
            path: 'speedtest',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
        };
        const fileSizeInBytes = 500000
        const speed = await testNetworkSpeed.checkUploadSpeed(options, fileSizeInBytes);
        console.log(speed);
        if (speed) {
            setNetSpeed(speed.mbps)

            return speed;
        } else {
            setNetSpeed(null)
        }
        return null;
    }
    // useEffect(() => {
    //     // getNetworkDownloadSpeed()
    //     getNetworkUploadSpeed()
    // },[])

    return (
        <div id="quiz-window">
            <div id="square1"
                style={{ display: isRecording ? 'block' : 'none', position: 'absolute', marginTop: 5, marginLeft: 5 }}
            ></div>
            {checkMultiDeviceLoading && <div className="d-flex justify-content-center mt-5 pt-5">
                <LottieLoader />
            </div>
            }
            {netSpeedTesting && <div className="d-flex justify-content-center mt-5 pt-5">
                <LottieLoader />
            </div>
            }



            <Router history={history}>
                <Switch>
                    <Route path={QUIZ_SET_ROUTE} exact render={props => <QuizSetPage user={user}
                        cameraActive={cameraActive}
                        key={keyForPage}
                        setCameraActive={setCameraActiveHandler}
                        cameraError={cameraError}
                        setCameraError={setCameraError}
                        isAlignConfirmed={isAlignConfirmed}
                        setAlginConfirm={setAlginConfirm}
                        cameraEnabledAgree={cameraEnabledAgree}
                        setCameraEnabledAgree={setCameraEnabledAgree}
                        startTest={startTest}
                        callbackTimerForTimeLeft={callbackTimerForTimeLeft}
                    />} />
                    <Route path={QUIZ_ATTEMPT_ROUTE} exact render={props => <QuizAttemptPage user={user}
                        cameraActive={cameraActive}
                        setCameraActive={setCameraActiveHandler}
                        cameraError={cameraError}
                        setCameraError={setCameraError}
                        isAlignConfirmed={isAlignConfirmed}
                        setAlginConfirm={setAlginConfirm}
                        cameraEnabledAgree={cameraEnabledAgree}
                        setCameraEnabledAgree={setCameraEnabledAgree}
                        percent={percent}
                        showUpload={showUpload}
                        NetSpeed={NetSpeed}
                        uploaded={uploaded}
                        EstimateTime={EstimateTime}
                        showResults={showResults}
                        setShowResults={setShowResultsHandler}
                        attemptNumber={attemptNumber}
                        setAttemptNumber={setAttemptNumber}
                        quizAttemptLogId={quizAttemptLogId}
                        setquizAttemptLogId={setquizAttemptLogId}
                        quizSetId={quizSetId}
                        setIsRecording={setIsRecording}
                    />} />
                </Switch>
            </Router>

        </div>
    )
}
export default Quiz;