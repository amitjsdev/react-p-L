import React from 'react';
import Rating from '@material-ui/lab/Rating';

interface Props {
    value?: number;
    name: string;
    setRating: Function;
    reviewParameter?: string;
    id: number;
    defaultValue?: any
}

const RatingComponent:React.FC<Props> =({ value, name, setRating, reviewParameter, id,defaultValue })=> {

    const handleChange = (event: any, newValue: React.SetStateAction<number | null>) => {

        if(newValue == null){
            setRating(0);
        }else{
            setRating(newValue);
        }
    }
    return (
        <Rating
            // defaultValue={3}
            name={name}
            value={value ? value : 0}
            onChange={handleChange}
        />
    );
}
export default RatingComponent