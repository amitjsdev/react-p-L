import React, { useState } from 'react'
import { Button, Modal } from 'react-bootstrap';

interface Props {
  tldrs: []
}
export const Tips: React.FC<Props> = ({ tldrs }) => {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  if (tldrs && tldrs.length > 0) {
    return (
      <>

        <div style={{ color: 'blue' }} onClick={handleShow}>
          Show Tips
        </div>

        <Modal scrollable show={show} onHide={handleClose}>
          <Modal.Header closeButton>
            <Modal.Title>Tips & Best Practices</Modal.Title>
          </Modal.Header>
          <Modal.Body style={{ height: '500px' }}>
            {tldrs && tldrs.length > 0 ? tldrs.map((tldr: any, index: number) => {
              return (
                <div className="row" key={index}>
                  <div className="col-md-12">
                    <h5 className="font-bold">{tldr.title}</h5>
                  </div>
                  <div className="col-md-12 mt-3 mb-3">
                    <div>{tldr.description}</div>
                  </div>
                </div>
              )
            }) : null}
          </Modal.Body>

        </Modal>
      </>
    );
  } else return null;
}
