import React, { useRef, useEffect, useState } from 'react'
import { ProgressBar } from 'react-bootstrap';
import { useToasts } from 'react-toast-notifications';
import { CDN_URL } from '../constant';
import "./VideoReview.scss";
const s3Url = CDN_URL+'/uploads/';
const Recorder = (
  {
    setVideo,
    video,
    videoDb = false,
    canRecord = false,
    id = ''
  }
) => {

  const { addToast } = useToasts();

  const [counterVisible, setCounterVisible] = useState(false);
  const [counterCount, setCounterCount] = useState(3);

  const [progress, setProgress] = useState();

  const [previousAttempts, setPreviousAttempts] = useState([]);
  const [isLoadingPreviousAttempt, setIsLoadingPreviousAttempt] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const [moduleNo, setmoduleNo] = useState(module.moduleNumber);
  const [AddTipsModal, setAddTipsModal] = useState(false)
  // recording related
  const [stream, setstream] = useState();
  const [mediaRecorder, setmediaRecorder] = useState();
  const [isRecording, setisRecording] = useState();
  const [downloadLink, setdownloadLink] = useState(null);
  const [videoObj, setvideoObj] = useState();
  const [blobsRecorded, setblobsRecorded] = useState([]);

  // Video ref
  const videoRef = useRef(null);

  const stopCamera = (discardFootage = false) => {
    const vid = document.getElementById("video");
    if (vid) {
      vid.pause();
      vid.src = "";
    }
    if (!stream) return;
    stream.getTracks().forEach(function (track) {
      track.stop();
    });
    if (stream) {
      setstream(null);
    }
  }


  const resetCameraAndMedia = () => {
    return new Promise((res, rej) => {
      stopCamera(true);
      clearRecording();
      return res(true);
    });
  }

  const clearRecording = () => {
    setblobsRecorded([])
    setisRecording(false);
    setdownloadLink(null);
    setvideoObj(null);
  }
  useEffect(() => {
    if (counterCount === 0) {
      setCounterVisible(false);
      setCounterCount(3); // reset the count
      // start recording
      startRecording(null);
    }
  }, [counterCount]);


  

  const startCamera = async () => {
    setblobsRecorded([])
    setdownloadLink(null)
    setvideoObj(null)
    let stream = await navigator.mediaDevices.getUserMedia({
      video: true,
      audio: true
    });
    var video = document.getElementById('video');
    video.srcObject = stream;
    video.volume = 0;
    if (videoRef.current) {
      videoRef.current.srcObject = stream;
      setstream(stream)
      video.srcObject = stream;
      video.volume = 0;
    }
    return;
  }

  // start recording
  const startRecording = async () => {
    var mediaRecorder2 = new MediaRecorder(stream, {
      mimeType: "video/webm"
    });
    const recorded_blobs = [];
    // reset the blobs
    setblobsRecorded([]);
    // reset the download link
    setdownloadLink(null)
    setvideoObj(null);

    // event : new recorded video blob available 
    mediaRecorder2.addEventListener('dataavailable', (e) => {
      recorded_blobs.push(e.data);
      // hacking in through to show the recorded time data, due to insufficient time
      const recordedTimeDiv = document.getElementById('recording-time');
      if (recordedTimeDiv) {
        recordedTimeDiv.innerText = ((Math.floor(recorded_blobs.length / 60) + "").padStart(2, "0") + ":" + (Math.floor(recorded_blobs.length % 60) + "").padStart(2, "0"));
      }

      setblobsRecorded(recorded_blobs);
    });
    // start recording with each recorded blob having 1 second video
    mediaRecorder2.start(1000);
    setmediaRecorder(mediaRecorder2)
    // set state to recording
    setisRecording(true);

  }

  const stopRecording = (e) => {
    if (isRecording) {
      //this.mediaRecorder.stop();
      mediaRecorder.stop()
      setisRecording(false);
      setmediaRecorder(undefined);
      console.log("here2", {
        isRecording: JSON.stringify(isRecording)
      });
      // stop all tracks
      stream.getTracks().forEach((track) => {
        if (track.readyState == "live") {
          track.stop();
        }
      });

      // save the blob as video
      let video_local = new Blob(blobsRecorded, {
        type: 'video/webm'
      });
      setdownloadLink(video_local);
      setvideoObj(URL.createObjectURL(video_local));
      saveAttempt()
    }
  }

  // triggers pre recording 
  const preStartRecording = (e) => {
    // start the 3 sec counter
    setCounterVisible(true);
    setTimeout(() => {
      setCounterCount(2);
    }, 1000);
    setTimeout(() => {
      setCounterCount(1);
    }, 2000);
    setTimeout(() => {
      setCounterCount(0);
    }, 3000);
  }
  const saveAttempt = async (e) => {
    let video_local = new Blob(blobsRecorded, {
      type: 'video/webm'
    });

    setIsCompleted(true);
    setVideo(video_local);
  }

  const both = canRecord && videoDb;
  const single = !canRecord && videoDb;

  return (
    <div className="recorder">
      {canRecord && <div>
        {counterVisible ? <div className="countdown-counter">{counterCount}</div> : <></>}
        {progress && <div className="progressBar"><ProgressBar variant="success" now={progress} label={`${progress}%`} /></div>}

        {!downloadLink ?
          !stream ? <video id="video" style={{ display: 'none' }} className="record-video c1234" ref={videoRef} autoPlay></video> : <video id="video" className="record-video c12345" ref={videoRef} autoPlay></video>
          : <video id="video" style={{ display: 'none' }} className="record-video c2134567" ref={videoRef} autoPlay></video>
        }


        {downloadLink ? <video className="record-video c212121" src={videoObj} autoPlay controls></video> : null}
        {!stream ? <video src={s3Url + previousAttempts[0]?.filePath} className="record-video c111111" style={{ backgroundColor: 'black' }}>
        </video> : null}
        {stream && !counterVisible && !isRecording && !downloadLink ? <button id="start-record" onClick={(e) => preStartRecording(e)}>Start
          Recording</button> : null}
        {stream && !isRecording && !downloadLink ? <button id="stop-camera" onClick={() => stopCamera()}><span>&times;</span></button> : null}
        {previousAttempts.length === 0 && !stream ? <button id="start-record" onClick={() => startCamera()}>Start Camera</button> : null}

        {!isRecording && downloadLink ? <button className="re-record" onClick={() => startCamera()}>Re-record</button> : null}
        {previousAttempts.length > 0 && !stream ? <button className="re-record2" onClick={() => startCamera()}>Re-record</button> : null}

        {/* the recording timer */}
        {isRecording ? <button id="recording-time" onClick={() => stopCamera()}><span>
        </span></button> : null}
        {isRecording ? <button id="stop-record" onClick={(e) => stopRecording(e)}>Stop
          Recording</button> : null}

      </div>}
    </div>
  );
}


const OldVideo = ({ videoLink }) => <video className={"question-video"} autoPlay={false} src={videoLink} controls ></video>

const VideoReview = ({
  setVideo,
  video,
  videoDb = false,
  canRecord = false,
  id = ''
}) =>{
  const both = canRecord && videoDb && id;
  const single = !canRecord && videoDb;
  const onlyRecord =canRecord && !videoDb;
  const videoLink = `${CDN_URL}/reviews/video/${id}/${videoDb}`;
  return(
  <div className='col-md-12 d-flex justify-content-center py-2'>
    <div className="videoReview">
      <div className="content-holder">
        <div className="content-holder-content">
          <h5 className='video-heading'>Video Feedback</h5>
          <div className="video-box flex items-left justify-around" style={{marginBottom:'1rem'}}>
            {both && <>
              <div style={{width:'50%'}}>
              <OldVideo videoLink={videoLink} />
              </div>
            <Recorder 
             setVideo={setVideo}
             video={video}
             videoDb = {videoDb}
             canRecord = {canRecord}
            />

            </>}
            {single && <>
              <div style={{width:'50%'}}>
              <OldVideo videoLink={videoLink} />
              </div>
              <div style={{width:'50%'}}> </div>
            </>}
            {onlyRecord && <>
              <Recorder 
             setVideo={setVideo}
             video={video}
             videoDb = {videoDb}
             canRecord = {canRecord}
            />
              <div style={{width:'50%'}}> </div>
            </>}
          </div>
        </div>
      </div>
    </div>
  </div>
  )
}
export default VideoReview;
