import React, { useState, useEffect } from 'react';
import { Router, Switch, Route, Redirect } from 'react-router-dom';
import { LOGIN_ROUTE, HOME_ROUTE, HomePage, PROFILE_ROUTE,ProfilePage, MODULE_ROUTE, ModulePage, LLP_ROUTE, LLPPage, LISTEN_ROUTE, ListenPage, LearnPage, LEARN_ROUTE, EXERCISE_ROUTE, ExercisePage, ONBOARDING_ROUTE, OnboardingPage, ABOUT_ROUTE, AboutPage, Profile } from '../_pages';
import LoginPage from '../_pages/login.page';
import { GuestPage, GUEST_ROUTE } from '../_pages';
import { history } from '../_config';
import { AuthRoute } from './protected-route.component';
import { MainService } from '../_services/main.service';
import { AuthService } from '../_services';
import { Employee, RecentModule } from '../_types';
import { PLAY_ROUTE, PlayPage } from '../_pages/play.page';
import RegisterPage, { REGISTER_ROUTE } from '../_pages/register.page';
import { PRATICE_ROUTE } from '../_pages/InterviewPrep/PracticePage';
import PracticePage from '../_pages/InterviewPrep/PracticePage';
import ResumeBuilder from '../_pages/ResumeBuilder/ResumeBuilder';
import SingleResume from '../_pages/ResumeBuilder/SingleResume';
import MyVideosPage, { MYVIDEOS_ROUTE } from '../_pages/MyVideos/MyVideosPage';
import UserVideosPage  from '../_pages/MyVideos/UserVideosPage';
import PracticeSetPage, { PRACTICE_SET } from '../_pages/PracticeSet/PracticeSetPage';

import InstructionModal, { INSTRUCTION_MODAL } from '../_pages/PracticeSet/InstrunctionModal';

import AiFeedbackPage, { AI_FEEDBACK_ROUTE } from '../_pages/AI/aiFeedback.page';
import ExternalReviewPage, { EXTERNAL_REVIEW_ROUTE } from '../_pages/ExternalReview';
import { ToastProvider } from 'react-toast-notifications';
import { PROFILE_PAGE_ROUTE } from '../_pages/Profile/profile.page';
import { mixPanel } from '../_config/mixpanel.config';
import GettingStartedPage from '../_pages/getting-started/getting-started.page';
import MentorQPage, { MENTORQ_ROUTE } from '../_pages/MentorQ/mentor-q.page';
import Quiz from './Quiz';
import QuizSetProgressionPage, { QUIZ_PROGRESSION_ROUTE } from '../_pages/quiz-sets/quiz-progression.page';
import ProctoredQuestionnairePage, { PROCTORED_QUESTIONNAIRE_ROUTE } from '../_pages/quiz-sets/proctored-questionnaire.page';

function getUser() {
    try {
        return JSON.parse(localStorage.getItem('user') ?? '');
    } catch (e) {
        return null;
    }
}

const main = new MainService();
const auth = new AuthService();

export function App() {

    const [user, setUser] = useState(getUser());
    const [myRank, setMyRank] = useState(0);
    const [myStreak, setMyStreak] = useState({ currentStreak: 0 });
    const [lastLesson, setLastLesson] = useState(0);
    const [userActivity, setUserActivity] = useState([] as Array<any>);
    const [mostRecent, setMostRecent] = useState(null as RecentModule | null);
    const [coursesRegistered, setCoursesRegistered] = useState([] as Array<RecentModule>);

    // for onboarding flow
    const [preferredCourse, setPreferredCourse] = useState<number | undefined>(undefined);
    const [preferredLevel, setPreferredLevel] = useState<string>("");

    const [employee, setEmployee] = useState<Employee | undefined>();

    const [gettingStartedDone, setGettingStartedDone] = useState(localStorage.getItem('getting-started-done') ? true : false);

    // get user profile and user courses
    useEffect(() => {
        // get user courses
        if (user) {
            auth.profile(user).then(r1 => {
                // we have the user
                // mixpanel start
                mixPanel.identify(user.email);
                // mixpanel end

                // get the courses
                const { courseRegistered, currentCourse } = r1.data;
                setCoursesRegistered(courseRegistered as Array<RecentModule>);

                // get module number for most recent module and recent module
                // const recentModule = courseRegistered.find((course: any) => course.courseNumber === currentCourse);
                const recentModule = courseRegistered.find((course: any) => course.moduleNumber === 150); // show only module 150
                const moduleNo = 150;

                // save the employee
                setEmployee(r1.data as Employee);

                // get most recent course
                // get the activity log
                auth.getActivityLog(user)
                    .then(r => {
                        // get all the logs and select top most as it is the most recent
                        const logs = r.data as Array<any>;
                        if (logs.length) {
                            // set logs in app state
                            setUserActivity(logs);

                            // if we have the recent module, add the long description to it
                            if (recentModule) {
                                setMostRecent(recentModule);
                                // get module description for recent module
                                if (moduleNo || moduleNo === 150) {
                                    console.log({ moduleNo })
                                    main.getModules(user, moduleNo)
                                        .then(r2 => {
                                            const module = r2.data[0] as any;

                                            if (recentModule) {
                                                recentModule.long_description = module.long_description;
                                                setMostRecent(recentModule);

                                                // get the last done lesson of current module
                                                let lastLessonDone = 0;
                                                logs.forEach(log => {
                                                    if (log.moduleNo === recentModule?.moduleNumber && log.activityType == 3 && log.lessonNo > lastLessonDone) {
                                                        lastLessonDone = log.lessonNo;
                                                    }
                                                });

                                                // last lesson
                                                setLastLesson(lastLessonDone);
                                            }
                                        });
                                }
                            }
                        }
                    });

                // get the user rank
                main.getMyRank(user).then(rank => {
                    setMyRank(rank);
                });

                // get the user streak
                main.getMyStreak(user).then(streak => {
                    setMyStreak(streak);
                });
            });
        }
    }, [user]);

    // getting started related

    return (
        <ToastProvider>
            <div className="App">

                <Router history={history}>
                    <Switch>
                        <AuthRoute path="/" exact user={user} render={
                            (props: any) => gettingStartedDone ? <Redirect to="/practice-set" /> : <GettingStartedPage setGettingStartedDone={setGettingStartedDone} />
                        } />
                        <AuthRoute path={HOME_ROUTE} exact user={user} render={
                            (props: any) => <HomePage {...props} user={user} mostRecent={mostRecent} coursesRegistered={coursesRegistered} myRank={myRank} myStreak={myStreak ? myStreak.currentStreak : 0} lastLesson={lastLesson} userActivity={userActivity} />
                        } />
                        <AuthRoute path={PROFILE_PAGE_ROUTE} user={user} render={(props: any) => <Profile {...props} />} />
                        <AuthRoute path={AI_FEEDBACK_ROUTE} user={user} render={(props: any) => <AiFeedbackPage  {...props} user={user} />} />
                       
                        <AuthRoute path={INSTRUCTION_MODAL} exact user={user} render={
                            (props: any) => <InstructionModal {...props} user={user} />
                        } />

                        <AuthRoute path={PRATICE_ROUTE} exact user={user} render={
                            (props: any) => <PracticePage {...props} user={user} />
                        } />
                        <AuthRoute path={PROFILE_ROUTE} exact user={user} render={
                            (props: any) => <ProfilePage {...props} user={user} employee={employee} />
                        } />
                        <AuthRoute path={MODULE_ROUTE} exact user={user} render={
                            (props: any) => <ModulePage {...props} user={user} userActivity={userActivity} />
                        } />
                        <AuthRoute path={LLP_ROUTE} exact user={user} render={
                            (props: any) => <LLPPage {...props} user={user} userActivity={userActivity} />
                        } />
                        <AuthRoute path={LISTEN_ROUTE} exact user={user} render={
                            (props: any) => <ListenPage {...props} user={user} userActivity={userActivity} coursesRegistered={coursesRegistered} />
                        } />
                        {/* <AuthRoute path={LEARN_ROUTE} exact user={user} render={
                            (props: any) => <LearnPage {...props} user={user} userActivity={userActivity} coursesRegistered={coursesRegistered} />
                        } /> */}
                        <AuthRoute path={PLAY_ROUTE} exact user={user} render={
                            (props: any) => <PlayPage {...props} user={user} userActivity={userActivity} coursesRegistered={coursesRegistered} />
                        } />
                        <AuthRoute path={EXERCISE_ROUTE} exact user={user} render={
                            (props: any) => <ExercisePage {...props} user={user} userActivity={userActivity} coursesRegistered={coursesRegistered} myStreak={myStreak} />
                        } />
                        <AuthRoute path="/practice/:id" exact user={user} render={
                            (props: any) => <PracticePage {...props} user={user} />
                        } />
                        <AuthRoute path={PRATICE_ROUTE} exact user={user} render={
                            (props: any) => <PracticePage {...props} user={user} />
                        } />
                       <AuthRoute path="/external-review-user/:email" exact user={user} render={
                            (props: any) => <UserVideosPage {...props}/>
                        }/>
                        <AuthRoute path={MYVIDEOS_ROUTE} exact user={user} render={
                            (props: any) => <MyVideosPage />
                        }
                        />
                        <AuthRoute path={MENTORQ_ROUTE} exact user={user} render={
                            (props: any) => <MentorQPage user={user} />
                        } />
                        <AuthRoute path={PRACTICE_SET} exact user={user} render={
                            (props: any) => <PracticeSetPage />
                        }
                        />
                        <AuthRoute path='/quiz-sets' exact user={user} render={
                            (props: any) => <Quiz user={user} />
                        }
                        />
                         <AuthRoute path='/quiz/:quizSetId' exact user={user} render={
                            (props: any) => <Quiz user={user} />
                        }
                        />
                        <AuthRoute path={PROCTORED_QUESTIONNAIRE_ROUTE} exact user={user} render={
                            (props: any) => <ProctoredQuestionnairePage user={user} />
                        } /> 
                       
                       
                        <AuthRoute path={QUIZ_PROGRESSION_ROUTE} exact user={user} render={
                            (props: any) => <QuizSetProgressionPage user={user} />
                        }
                        />
                        <AuthRoute path="/resume-builder/new" exact user={user} render={(props: any) => <SingleResume />} />
                        <AuthRoute path="/resume-builder/:id" exact user={user} render={(props: any) => <SingleResume />} />
                        <AuthRoute path="/resume-builder" exact user={user} render={(props: any) => <ResumeBuilder />} />
                        <Route path={EXTERNAL_REVIEW_ROUTE} exact render={props => <ExternalReviewPage />} />
                        <Route path={GUEST_ROUTE} exact render={props => <GuestPage setPreferredCourse={setPreferredCourse} />} />
                        <Route path={ONBOARDING_ROUTE} exact render={props => <OnboardingPage setPreferredCourse={setPreferredCourse} preferredCourse={preferredCourse} preferredLevel={preferredLevel} setPreferredLevel={setPreferredLevel} />} />
                        <Route path={LOGIN_ROUTE} exact render={props => <LoginPage setUser={setUser} preferredCourse={preferredCourse} preferredLevel={preferredLevel} />} />
                        <Route path={REGISTER_ROUTE} exact render={props => <RegisterPage setUser={setUser} preferredCourse={preferredCourse} preferredLevel={preferredLevel} />} />
                        <Route path={ABOUT_ROUTE} exact render={props => <AboutPage />} />
                    </Switch>
                </Router>
            </div>
        </ToastProvider>
    );
}
