import React, { SyntheticEvent, useRef, useState } from 'react'

import play_button from '../_assets/_learn/play-2x.png';
import pause_button from '../_assets/_learn/pause-2x.png';


type P = {
    src: string,
    autoPlay?: true,
    onCanPlay?: (event: SyntheticEvent<HTMLAudioElement, Event>) => void
};

export default function Audio(props: P) {
    const ref = useRef<HTMLAudioElement>(null);
    const [paused, setPaused] = useState(props.autoPlay ? false : true);

    return (
        <div className="Audio">
            <div className="controls">
                {
                    paused ?
                        <img src={play_button} alt='' className="center" onClick={() => {
                            ref.current?.play();
                            setPaused(false);
                            console.log(ref.current);
                        }} /> :
                        <img src={pause_button} alt='' className="center" onClick={() => {
                            ref.current?.pause();
                            setPaused(true);
                        }} />
                }
            </div>
            <audio {...props} ref={ref} onEnded={() => {
                if (ref.current) {
                    ref.current.currentTime = 0;
                    setPaused(true);
                }
            }} />
        </div>
    )
}
