import React from 'react';
import backArrow from '../_assets/back-arrow.png';
import { history } from '../_config';

export function BackArrow(props: { onClick?: Function, alt?: true }) {
    const handleClick = (event: any) => {
        if ("onClick" in props && props.onClick) {
            props.onClick();
        } else {
            history.goBack();
        }
    }
    return (
        <span className="BackArrow" onClick={handleClick}>
            <img src={backArrow} alt="Back" style={props.alt ? { "filter": "invert(1)" } : {}} />
        </span>
    )
}