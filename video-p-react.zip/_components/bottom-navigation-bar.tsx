import React from 'react';
import { Link } from 'react-router-dom';
import { HOME_ROUTE } from '../_pages';
import { withI18 } from '../_context';
import { lang } from 'moment';

type P = {
    lang: any
}

function BottomNavigationBarComponent(props: P) {

    const tabs = [
        { title: props.lang.handle('home'), icon: '/_assets/navigation-icon-home.png', to: HOME_ROUTE },
        { title: props.lang.handle('courses'), icon: '/_assets/navigation-icon-courses.png', to: "/courses" },
        { title: props.lang.handle('profile'), icon: '/_assets/navigation-icon-user.png', to: "/profile" },
    ]

    return (
        <div className="BottomNavigationBar">
            {
                tabs.map((tab, i) => {
                    return (
                        <Link
                            key={i}
                            to={tab.to}
                            className={
                                "tab-tile" + (
                                    window.location.pathname.startsWith(tab.to) ?
                                        " active" : ""
                                )
                            }>
                            <img src={tab.icon} alt="Home" /> {tab.title}
                        </Link>
                    )
                })
            }
        </div>
    )
}

export const BottomNavigationBar = withI18(BottomNavigationBarComponent);