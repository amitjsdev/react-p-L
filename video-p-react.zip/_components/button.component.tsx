import React from 'react'

interface Props {
    text: string;
    color: string;
    disabled?: boolean;
    handleClick?: ()=> void
}
const Button: React.FC<Props> = ({ text, color, handleClick, disabled=false }) => {
    return <button disabled={disabled} onClick={handleClick} className={`button-custom button-custom-${color}`}>{text}</button>
}

export default Button
