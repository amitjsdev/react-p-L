import React from 'react';
import Rating from '@material-ui/lab/Rating';

interface Props {
    value: number;
    name: string;
    readOnly?: boolean;
    setRating: Function;
    reviewParameter?: string;
    id: number;
    defaultValue?: any
}

const ExternalRatingComponent: React.FC<Props> = ({ value, readOnly = false, name,setRating: setRating, reviewParameter, id,defaultValue })=> {

    const handleChange = (event: any, newValue: React.SetStateAction<number | null>) => {
        setRating(newValue);
    }
    return (
        <Rating
            // defaultValue={3}
            readOnly={readOnly}
            name={name}
            value={value}
            onChange={handleChange}
        />
    );
}
export default ExternalRatingComponent