import React from 'react';
import { I18Context } from '../_context';
import { es, en } from '../_locales';

const translations = {
    en,
    es
};

type P = {}

type S = {
    current: string
}

class I18 extends React.Component<P, S> {
    constructor(props: any) {
        super(props);
        // get saved langcode from localstorage
        let langCode = localStorage.getItem('langCode') ?? 'en';

        // validate the langcode with available languages
        if (!Object.keys(translations).includes(langCode)) {
            langCode = 'en';
        }

        this.state = {
            current: langCode
        };
        this.handle = this.handle.bind(this)
    }

    handle(s: string) {
        return (translations as any)[this.state.current][s.toLowerCase()] || s;
    }

    render() {
        return (
            <I18Context.Provider value={{
                current: this.state.current,
                handle: this.handle
            }}>
                <div className="I18Selector" style={{ display: "none" }}>
                    <select
                        defaultValue={this.state.current}
                        onChange={event => {
                            const langCode = event.target.value;
                            this.setState({ current: langCode }, () => {
                                localStorage.setItem('langCode', langCode);
                            });
                        }}>
                        {
                            Object.keys(translations).map(lang => (
                                <option key={lang} value={lang}>{lang.toUpperCase()}</option>
                            ))
                        }
                    </select>
                </div>
                {this.props.children}
            </I18Context.Provider>
        )
    }
}

export { I18 };