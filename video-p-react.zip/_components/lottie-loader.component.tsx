import React from 'react';
import Lottie from 'react-lottie';
import loaderAnimation from '../_assets/lottie/loader.json';

export function LottieLoader({ size = 200 }) {
    return (
        <Lottie options={{
            loop: true,
            autoplay: true,
            animationData: loaderAnimation,
            rendererSettings: {
                preserveAspectRatio: "xMidYMid slice"
            }
        }}
            width={size}
            height={size} />
    )
}