import React from 'react';

export function Nl2br(props: { text: string }) {
    return (
        <span>
            {
                props.text.split("\n").map((e, i) => {
                    return <span key={i}>
                        {e} <br />
                    </span>;
                })
            }
        </span>
    )
}