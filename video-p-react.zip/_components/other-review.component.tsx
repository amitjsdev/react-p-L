import React from 'react'
import { Col, Row } from 'react-bootstrap'

const OtherReview = ({}) => {
    return (
        <>
            {/* <Row> */}
                {/* <Col sm={8} className="font-bold">{reviewerName}</Col>
                <Col sm={4}>{showDetails ? <div onClick={() => handleShow(index)} style={{ cursor: 'pointer', color: 'blue' }}>Show Details</div> :
                    <div onClick={() => setshowDetails(true)} style={{ color: 'blue', cursor: 'pointer' }}>Hide Details</div>}
                </Col>
                <Col sm={12} md={12}>
                    <div className="comment-box">{comment}</div>
                </Col>
                {!showDetails ? Object.keys(reviewJSON).map((reviewParameter: any) => {
                    return (
                        <Col>
                            <div className="d-flex flex-wrap justify-content-center text-center px-5" onClick={() => console.log('rating index', index)} key={index}>
                                <div>{reviewParameter}</div>
                                <ExternalRatingComponent
                                    id={index}
                                    name={"rating" + index}
                                    value={reviewJSON[reviewParameter]}
                                    setRating={(r: number) => {
                                        let newRating = ratingExternal
                                        newRating[reviewJSON] = r;
                                        setRatingExternal(newRating)
                                    }}
                                />
                            </div>
                        </Col>
                    )
                }) : null} */}
            {/* </Row> */}
        </>
    )
}

export default OtherReview
