import React, { useState } from 'react';

import preReg1 from '../_assets/pre-reg/pre-reg-1.png';


export function PreRegPage() {

    const data = [
        {
            imgSrc: preReg1,
            title: "Learn everyday conversations",
            description: "Word and phrases you can really user."
        },
        {
            imgSrc: preReg1,
            title: "From an expert instructor",
            description: "Like a class that's just for you."
        },
        {
            imgSrc: preReg1,
            title: "Wherever and Whenever",
            description: "3 seconds or 30 minutes, coffee or commute."
        },
        {
            imgSrc: preReg1,
            title: "Practice makes Perfect",
            description: "Fun and games to help you along with."
        },
    ]

    const [currentPage, setCurrentPage] = useState(0);

    const nextPage = () => {
        if (currentPage + 1 >= data.length) {
            setCurrentPage(0);
        } else {
            setCurrentPage(currentPage + 1);
        }
    }

    const prevPage = () => {
        if (currentPage - 1 < 0) {
            setCurrentPage(data.length - 1);
        } else {
            setCurrentPage(currentPage - 1);
        }

    }

    return (
        <div className="PreRegPageHolder">
            <div className="page-view">
                <div className="page-holder">
                    {
                        data.map((page, index) => (
                            <div className={"page " + (index === currentPage ? "active" : "")}>
                                <img src={page.imgSrc} alt="Pre Reg" />
                                <div className="title">{page.title}</div>
                                <div className="description">{page.description}</div>
                            </div>
                        ))
                    }
                </div>
                <div className="bullet-holder">
                    {
                        data.map((page, index) => (
                            <div
                                onClick={() => {
                                    setCurrentPage(index);
                                }}
                                className={"bullet " + (index === currentPage ? "active" : "")}>
                            </div>
                        ))
                    }
                </div>
                <div className="page-button left" onClick={prevPage}>
                    <span>&lt;</span>
                </div>
                <div className="page-button right" onClick={nextPage}>
                    <span>&gt;</span>
                </div>
                <button className="button">Continue</button>
            </div>
        </div>
    )
}