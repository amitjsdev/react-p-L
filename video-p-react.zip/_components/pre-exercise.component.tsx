import React from 'react'
import { Lesson, ModuleRoute, ExerciseType } from '../_types'
import { Nl2br } from './nl2br.component'



type S = {
    lesson: Lesson | null,
    route: ModuleRoute | null
}

    // pre exercise form
export function PreExercise(props: { state: S, preExerciseDone: any, type: string }) {
    return (
        <div className="PreExercise">
            <div className="bg" style={{ backgroundImage: 'url("/_assets/listenpage-bg.png")' }}></div>
            <div className="intersection" style={{ backgroundImage: 'url("/_assets/listenpage-intersection.png")' }}></div>
            <div className="route-description">
                <Nl2br text={props.state.route?.description ?? ''} />
            </div>
            <div className="lesson-title">
                <span>Level {props.state.lesson?.title}</span>
            </div>
            <div className="lesson-description">
                <Nl2br text={props.state.lesson?.description ?? ''} />
            </div>
            <div className="decoration-star">
                <img src="/_assets/spectacle-star.png" alt="" />
            </div>
            <div className="pre-lesson">
                {
                    props.type === 'listen' ?
                    props.state.lesson?.pre_dialog_msg :
                    props.type === 'learn' ? 
                    props.state.lesson?.pre_video_msg :
                    props.state.lesson?.pre_exercise
                }
            </div>
            <button className="continue-button" onClick={props.preExerciseDone}>
                Continue
            </button>
        </div>
    )
}
