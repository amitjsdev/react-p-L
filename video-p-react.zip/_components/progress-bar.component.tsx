import React, { CSSProperties } from 'react';

const style: CSSProperties = {
}

export function ProgressBar(props: { percent: number, withText?: true }) {
    return (
        <div className="ProgressBar">
            <div className="total" style={style}></div>
            <div className="progress" style={{ width: props.percent + "%"}}></div>
            {props.withText ? <div className="percentage">{props.percent + "%"}</div> : ""}
        </div>
    )
}