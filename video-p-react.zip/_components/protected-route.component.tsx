import React, { ReactNode } from 'react';
import { Route, Redirect, RouteComponentProps } from 'react-router-dom';
import { LOGIN_ROUTE } from '../_pages';


export function AuthRoute(props: {
    path: string,
    user?: Object,
    exact?: boolean,
    component?: any,
    render?: ((props: RouteComponentProps<any>) => ReactNode)
}) {
    return (
        props.user ?
            <Route path={props.path} exact={props.exact} component={props.component} render={props.render} /> :
            <Redirect to={LOGIN_ROUTE} />
    )
}