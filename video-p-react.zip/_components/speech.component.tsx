import React, { useState } from 'react'
import speak_image from '../_assets/speak-1x.png';

let sr = {} as any;

try {

    sr = new (window as any).webkitSpeechRecognition();

} catch (error) {
    console.error("Speech recog not supported natively");
}

export default function SpeechRecognition(props: { onComplete?: any}) {

    const [isListening, setIsListening] = useState(false);
    const [result, setResult] = useState('');

    sr.onspeechstart = () => {
        // TODO
    }

    sr.onspeechend = () => {
        // TODO
    }

    sr.onresult = (response: any) => {
        try {
            setResult(response.results[0][0].transcript);
        } catch (err) { 
            // Failed silently
        } finally {
            setIsListening(false);
            props.onComplete();
        }
    }

    const startListening = () => {
        sr.start();
        setIsListening(true);
    }

    return (
        <div className="SpeechRecognition">
            <img src={speak_image} alt="Speak" onClick={startListening} />
            <div className="result">
                {
                    isListening ?
                        <span className="Spinner"></span> :
                        result
                }
            </div>
        </div>
    )
}
