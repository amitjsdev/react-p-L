import React from 'react';

type styleType = {
    borderColor?: string,
    width?: string,
    height?: string
}

export const Spinner = (props: { alt?: true, color?: string, larger?: true }) => {
    const style: styleType = {};
    if(props.alt) {
        style.borderColor = '#232323 transparent';
    }
    if(props.color) {
        style.borderColor = props.color + ' transparent';
    }
    if(props.larger) {
        style.width = '35px';
        style.height = '35px';
    }
    return (
        <div
            className="Spinner"
            style={style}>

            </div>
    )
}