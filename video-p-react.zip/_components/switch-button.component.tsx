import React from 'react';

export function SwitchButton(props: {on: boolean, onClick: any}) {
    return (
        <div className={"SwitchButton" + (props.on ? " enabled" : "")} onClick={props.onClick}>
            <span className="head"></span>
        </div>
    )
}