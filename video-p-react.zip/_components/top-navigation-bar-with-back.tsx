import React, { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { HOME_ROUTE } from '../_pages';
import { withI18 } from '../_context';
import { lang } from 'moment';
import backArrow from '../_assets/back-arrow-3x.png';
import { RecentModule } from '../_types';
import { history } from '../_config';
import taplinguaLogo from '../_assets/main-logo-alt.png';

type P = {
    onClick?: Function,
    alt?: true,
    title: string,
    buttonTwoLabel: string,
    buttonTwoOnClick: Function,
    buttonTwoComponent: ReactNode
}

function TopNavigationBarWithBackComponent(props: P) {

    const handleClick = (event: any) => {
        if ("onClick" in props && props.onClick) {
            props.onClick();
        } else {
            history.replace(HOME_ROUTE);
        }
    }

    return (
        <div className="TopNavigationBar" style={{
            display: "flex",
            width: "100%",
            justifyContent: "space-between",
            alignItems: "center"
        }}>
            <span style={{
                display: "flex",
                justifyContent: "start",
                alignItems: "center"
            }}>
                <img className="taplingua-logo" src={taplinguaLogo} alt="Taplingua Logo" onClick={() => {
                    history.replace(HOME_ROUTE);
                    // window.location.href = window.location.origin;
                }} />

                <span className="TopNavTitle">{props.title}</span>
            </span>
            <div style={{ display: "flex", justifyContent: "center", alignItems: "center" }}>
                {
                    props.buttonTwoComponent ?
                        props.buttonTwoComponent :
                        (
                            <span className="TopNavButtonTwo" onClick={event => {
                                if (props.buttonTwoOnClick) {
                                    props.buttonTwoOnClick(event);
                                }
                            }}>{props.buttonTwoLabel}</span>
                        )
                }
                {!props.buttonTwoLabel ? (
                    <span className="TopNavBack" onClick={handleClick}>&times;</span>
                ) : <></>}

            </div>
        </div>
    )
}

export const TopNavigationBarWithBack = withI18(TopNavigationBarWithBackComponent);