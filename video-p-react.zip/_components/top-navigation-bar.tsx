import React, { useEffect, useState } from 'react';
import { Nav, Navbar } from "react-bootstrap";
import { Link, useLocation } from 'react-router-dom';
import { HOME_ROUTE } from '../_pages';
import { withI18 } from '../_context';
import { lang } from 'moment';
import { RecentModule } from '../_types';
import { history } from '../_config';
import taplinguaLogo from '../_assets/main-logo-alt.png';
import taplinguaMainLogo from '../_assets/main-logo.png';
import { PRATICE_ROUTE } from '../_pages/InterviewPrep/PracticePage';
import { NavLink } from 'react-router-dom';
import { PRACTICE_SET } from '../_pages/PracticeSet/PracticeSetPage';
import { MainService } from '../_services/main.service';
import './top-nav.css';


const main = new MainService();

type P = {
    lang: any,
    myRank: number,
    myStreak: number,
    recentModule: RecentModule,
}

function TopNavigationBarComponent(props: P) {
    const [token, setToken] = useState<string>();
    const [user, setUser] = useState<any>(null);
    const [cohort, setCohort] = useState<any>(null);
    const [checkLoading, setCheckLoading] = useState<boolean>(false);

    
    const [showMentorQ, setShowMentorQ] = useState(false);


    useEffect(() => {
        const user = JSON.parse(localStorage.getItem('user') || '{}')
        setToken(user.token)
         setCohort(user.cohort);
        setUser(user);
    }, [])

    const checkUserDetails = () =>{
        main.checkUserDetails(token as any).then(response => {
            localStorage.setItem('user', JSON.stringify(response));
            setCohort(user.cohort);
        }).catch(error => {
        });
    }
    // get mentor cohorts
    useEffect(() => {
        if (token) {
            main.getMentorCohorts(token)
                .then(({ cohorts: c }) => {
                    if (Array.isArray(c) && c.length > 0) {
                        setShowMentorQ(true);
                    }
                });
               checkUserDetails()
        }
    }, [token]);

    const { recentModule } = props;

    const l = useLocation();

    const [showLiveTourButton, SetshowLiveTourButton] = useState(true);


    useEffect(() => {
        SetshowLiveTourButton(
            (() => {
                let shouldShowButton = true;

                // if on tour page
                if (l.pathname as any === "/") {
                    return false;
                }

                // if on practice page and joyride completed, return false
                if ((l.pathname as any === "/practice") && !localStorage.getItem('joyride-show.practicepage')) {
                    return false;
                }

                // if on practice set page and joyride completed, return false
                if (l.pathname as any === "/practice-set" && !localStorage.getItem('joyride-show.practicesetpage')) {
                    return false;
                }

                // if on practice page and joyride completed, return false
                if (l.pathname as any === "/myvideos" && !localStorage.getItem('joyride-show.myvideopage')) {
                    return false;
                }



                return shouldShowButton;
            })());
    }, [l.pathname]);

    const tabs = [
        { title: props.lang.handle(recentModule && recentModule.courseName ? recentModule.courseName : ''), icon: '/_assets/navigation-icon-home.png', to: HOME_ROUTE },
        { title: props.lang.handle('Streaks: ' + props.myStreak), icon: '/_assets/navigation-icon-courses.png', to: "" },
        { title: props.lang.handle('profile'), icon: '/_assets/navigation-icon-user.png', to: "/profile" },
    ]
    
    let vpiData:any = [];
    let checkForType:any = [];
    if(cohort && cohort.length > 0){

       let checkType = cohort && cohort.length > 0 && cohort.find((item:any)=> item.type_id == 2);
        if(checkType?.type_id == 2){
            vpiData = checkType;

            checkForType = cohort && cohort.length > 0 && cohort.find((item:any)=> item.type_id == 3 && item.vpi_value == 0);

      if(Object.keys(checkForType).length){
                checkForType = [];
            }else{
                checkForType = cohort && cohort.length > 0 && cohort.find((item:any)=> item.type_id == 3 && item.vpi_value == '1');
            }
        }else{

            // vpiData = cohort && cohort.length > 0 && cohort.find((item:any)=> item.vpi_value == '1');
            vpiData = cohort && cohort.length > 0 && cohort.find((item:any)=> item.type_id == 3 && item.vpi_value == 0);

            if(Object.keys(vpiData).length){
                vpiData = [];
            }else{
                vpiData = cohort && cohort.length > 0 && cohort.find((item:any)=> item.type_id == 3 && item.vpi_value == '1');
            }

        }

    }else{

        if(user?.cohort && user?.cohort.length > 0){
            let checkType = user?.cohort && user?.cohort.length > 0 && user?.cohort.find((item:any)=> item.type_id == 2);
            if(checkType?.type_id == 2){
                vpiData = checkType;

                checkForType = user?.cohort && user?.cohort.length > 0 && user?.cohort.find((item:any)=> item.type_id == 3 && item.vpi_value == 0);
                if(checkForType && Object.keys(checkForType).length){
                    checkForType = [];
                }else{
                    checkForType = user?.cohort && user?.cohort.length > 0 && user?.cohort.find((item:any)=> item.type_id == 3 && item.vpi_value == 1);
                }
            }else{

                let checkData = cohort && cohort.length > 0 && cohort.find((item:any)=> item.vpi_value == 0);
                if(checkData && Object.keys(checkData).length){
                    vpiData = [];
                }else{
                    vpiData = cohort && cohort.length > 0 && cohort.find((item:any)=> item.vpi_value == '1');
                }
            }    
        }
    }
    
   
    // if(vpiData){
    //     vpiData = cohort && cohort.length > 0 && cohort.find((item:any)=> item.vpi_value == '1');
    // }else{

    // }
    
    // const typeid = user && user.cohort && user.cohort.type_id ? user.cohort.type_id :'';

    if(vpiData?.type_id == 2) { 
        return ( 

            <div className="TopNavigationBarHome">
                {/* {console.log('from navbar',userDetails)} */}
                <img className="taplingua-logo" src={user ? `https://langappnew.s3.amazonaws.com/logos/${user.CompanyCode}.jpeg` : taplinguaMainLogo} alt="Taplingua Logo" onClick={() => {
                    history.replace(PRACTICE_SET);
                    // window.location.href = window.location.origin;
                }} />

                 
                {token ?
                    <>
                    <div className="mobileMenu">
                  <img className="taplingua-logo" src={user ? `https://langappnew.s3.amazonaws.com/logos/${user.CompanyCode}.jpeg` : taplinguaMainLogo} alt="Taplingua Logo" onClick={() => {
                    history.replace(PRACTICE_SET);
                    // window.location.href = window.location.origin;
                }} />
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar expand="lg" className="topBar TopNavigationBarHome">
                    <Navbar.Brand href="/">
                    <img className="taplingua-logo" src={user ? `https://langappnew.s3.amazonaws.com/logos/${user.CompanyCode}.jpeg` : taplinguaMainLogo} alt="Taplingua Logo" onClick={() => {
                    history.replace(PRACTICE_SET);
                    // window.location.href = window.location.origin;
                }} />
                    </Navbar.Brand>

                    <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar.Collapse id="basic-navbar-nav" className="navbarLeft">
                    <Nav>
                    {checkForType?.type_id == 3 && checkForType?.vpi_value == 1 &&
                    <>
                     <NavLink exact to="/practice-set" activeClassName="active" className="home-link">Home</NavLink>
                      <NavLink to="/practice" exact activeClassName="active" className="inactive">English Test</NavLink>
                    </>
                     }
                    
                        <NavLink exact to="/quiz-sets" activeClassName="active" className="inactive">Quiz</NavLink>
                        {checkForType?.type_id == 3 && checkForType?.vpi_value != 1 &&
                          <NavLink to="/myvideos" exact activeClassName="active" className="inactive myvideo-link">Reviews</NavLink>
                        }
                        {/* <NavLink to="/resume-builder" exact activeClassName="active" className="inactive">Resume</NavLink> */}
                      
                        {
                            showMentorQ ? (
                                <NavLink to="/mentor-q" exact activeClassName="active" className="inactive">Mentor Q</NavLink>
                            ) : <></>
                        }
                        {/* <div className="topbar-button" onClick={() => {
                            localStorage.removeItem('user');
                            history.replace('/login');
                            window.location.reload();
                        }}>Logout</div> */}
                        <NavLink to="/profile" exact activeClassName="active" className="inactive">Profile</NavLink>
                        {
                            showLiveTourButton ? (
                                <>
                                <div className="tour-button" onClick={e => {
                                    e.preventDefault();
                                    localStorage.removeItem('getting-started-done');
                                    window.location.href = window.location.origin;
                                }}>
                                    <img src="/_assets/tour-button.png" />
                                    <span>Live Tour</span>
                                </div>
                                {checkForType?.type_id == 3 && checkForType?.vpi_value == 1 &&
                                <div onClick={()=>{
                                    history.push('/test-instruction');
                                }} 
                                className="insButton"><span>Instructions</span>
                                </div>
                                 }
                                </>
                            ) : <></>
                        }
                    </Nav>
                    </Navbar.Collapse>
                    </Navbar>

      </div>

                       <div className="desktopMenu">
                         <img className="taplingua-logo" src={user ? `https://langappnew.s3.amazonaws.com/logos/${user.CompanyCode}.jpeg` : taplinguaMainLogo} alt="Taplingua Logo" onClick={() => {
                    history.replace(PRACTICE_SET);
                    // window.location.href = window.location.origin;
                }} />


                    {checkForType?.type_id == 3 && checkForType?.vpi_value == 1 &&
                    <>
                     <NavLink exact to="/practice-set" activeClassName="active" className="home-link">Home</NavLink>
                      <NavLink to="/practice" exact activeClassName="active" className="inactive">English Test</NavLink>
                    </>
                     }
                    
                        <NavLink exact to="/quiz-sets" activeClassName="active" className="inactive">Quiz</NavLink>
                        {checkForType?.type_id == 3 && checkForType?.vpi_value != 1 &&
                          <NavLink to="/myvideos" exact activeClassName="active" className="inactive myvideo-link">Reviews</NavLink>
                        }
                        {/* <NavLink to="/resume-builder" exact activeClassName="active" className="inactive">Resume</NavLink> */}
                      
                        {
                            showMentorQ ? (
                                <NavLink to="/mentor-q" exact activeClassName="active" className="inactive">Mentor Q</NavLink>
                            ) : <></>
                        }
                        {/* <div className="topbar-button" onClick={() => {
                            localStorage.removeItem('user');
                            history.replace('/login');
                            window.location.reload();
                        }}>Logout</div> */}
                        <NavLink to="/profile" exact activeClassName="active" className="inactive">Profile</NavLink>
                        {
                            showLiveTourButton ? (
                                <>
                                <div className="tour-button" onClick={e => {
                                    e.preventDefault();
                                    localStorage.removeItem('getting-started-done');
                                    window.location.href = window.location.origin;
                                }}>
                                    <img src="/_assets/tour-button.png" />
                                    <span>Live Tour</span>
                                </div>
                                {checkForType?.type_id == 3 && checkForType?.vpi_value == 1 &&
                                <div onClick={()=>{
                                    history.push('/test-instruction');
                                }} 
                                className="insButton"><span>Instructions</span>
                                </div>
                                 }
                                </>
                            ) : <></>
                        }
                        </div>
                    </>
                    :
                    <div className="topbar-button" onClick={() => {
                        localStorage.removeItem('user');
                        history.replace('/login');
                        window.location.reload();
                    }}>Login</div>}
    
            </div>
        )

    } else {

        return (

            <div className="TopNavigationBarHome">


                {token ?
<>
                <div className="mobileMenu">
                  <img className="taplingua-logo" src={user ? `https://langappnew.s3.amazonaws.com/logos/${user.CompanyCode}.jpeg` : taplinguaMainLogo} alt="Taplingua Logo" onClick={() => {
                    history.replace(PRACTICE_SET);
                    // window.location.href = window.location.origin;
                }} />
                {/* {console.log('from navbar',userDetails)} */}

               
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar expand="lg" className="topBar TopNavigationBarHome navbar-dark">
                    <Navbar.Brand href="/">
                    <img className="taplingua-logo" src={user ? `https://langappnew.s3.amazonaws.com/logos/${user.CompanyCode}.jpeg` : taplinguaMainLogo} alt="Taplingua Logo" onClick={() => {
                    history.replace(PRACTICE_SET);
                    // window.location.href = window.location.origin;
                }} />
                <span className="homeTop">Home</span>
                
                    </Navbar.Brand>

                    <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar.Collapse id="basic-navbar-nav" className="navbarLeft">
                    <Nav>
                    <NavLink exact to="/practice-set" activeClassName="active" className="home-link">Home</NavLink>
                     {/* <NavLink exact to="/learn" activeClassName="active" className="inactive">Learn</NavLink> */}
                        <NavLink to="/practice" exact activeClassName="active" className="inactive">{vpiData?.type_id == 3 && vpiData?.vpi_value == 1 ? `English Test` : `Practice`}</NavLink>
                        {vpiData?.type_id == 3 && vpiData?.vpi_value != 1 ? '':
                        <NavLink exact to="/quiz-sets" activeClassName="active" className="inactive">Quiz</NavLink>
                        }
                        {/* <NavLink to="/resume-builder" exact activeClassName="active" className="inactive">Resume</NavLink> */}
                        {vpiData?.type_id == 3 && vpiData?.vpi_value == 1 ? '':
                         <NavLink to="/myvideos" exact activeClassName="active" className="inactive myvideo-link">Reviews</NavLink>
                        }
                        {
                            showMentorQ ? (
                                <NavLink to="/mentor-q" exact activeClassName="active" className="inactive">Mentor Q</NavLink>
                            ) : <></>
                        }
                        <NavLink to="/profile" exact activeClassName="active" className="inactive">Profile</NavLink>
                        {
                            showLiveTourButton ? (
                                <>
                                <div className="tour-button" onClick={e => {
                                    e.preventDefault();
                                    localStorage.removeItem('getting-started-done');
                                    window.location.href = window.location.origin;
                                }}>
                                    <img src="/_assets/tour-button.png" />
                                    <span>Live Tour</span>
                                </div>
                                <div onClick={()=>{
                                    history.push('/test-instruction');
                                }} 
                                className="insButton"><span>Instructions</span>
                                </div>
                                </>
                            ) : <></>
                        }
                    </Nav>
                    </Navbar.Collapse>
                    </Navbar>
                    </div>
                
                
                    <div className="desktopMenu">
                         <img className="taplingua-logo" src={user ? `https://langappnew.s3.amazonaws.com/logos/${user.CompanyCode}.jpeg` : taplinguaMainLogo} alt="Taplingua Logo" onClick={() => {
                    history.replace(PRACTICE_SET);
                    // window.location.href = window.location.origin;
                }} />
                    <NavLink exact to="/practice-set" activeClassName="active" className="home-link">Home</NavLink>
                     {/* <NavLink exact to="/learn" activeClassName="active" className="inactive">Learn</NavLink> */}
                        <NavLink to="/practice" exact activeClassName="active" className="inactive">{vpiData?.type_id == 3 && vpiData?.vpi_value == 1 ? `English Test` : `Practice`}</NavLink>
                        {vpiData?.type_id == 3 && vpiData?.vpi_value != 1 ? '':
                        <NavLink exact to="/quiz-sets" activeClassName="active" className="inactive">Quiz</NavLink>
                        }
                        {/* <NavLink to="/resume-builder" exact activeClassName="active" className="inactive">Resume</NavLink> */}
                        {vpiData?.type_id == 3 && vpiData?.vpi_value == 1 ? '':
                         <NavLink to="/myvideos" exact activeClassName="active" className="inactive myvideo-link">Reviews</NavLink>
                        }
                        {
                            showMentorQ ? (
                                <NavLink to="/mentor-q" exact activeClassName="active" className="inactive">Mentor Q</NavLink>
                            ) : <></>
                        }
                        <NavLink to="/profile" exact activeClassName="active" className="inactive">Profile</NavLink>
                        {
                            showLiveTourButton ? (
                                <>
                                <div className="tour-button" onClick={e => {
                                    e.preventDefault();
                                    localStorage.removeItem('getting-started-done');
                                    window.location.href = window.location.origin;
                                }}>
                                    <img src="/_assets/tour-button.png" />
                                    <span>Live Tour</span>
                                </div>
                                <div onClick={()=>{
                                    history.push('/test-instruction');
                                }} 
                                className="insButton"><span>Instructions</span>
                                </div>
                                </>
                            ) : <></>
                        }
                    </div>
                    </>
                    :
                    <div className="topbar-button" onClick={() => {
                        localStorage.removeItem('user');
                        history.replace('/login');
                        window.location.reload();
                    }}>Login</div>}
    
            </div>
        )

    }

}

export const TopNavigationBar = withI18(TopNavigationBarComponent);