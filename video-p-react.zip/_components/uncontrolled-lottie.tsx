import React from 'react';
import Lottie from 'react-lottie';

type P = {
    animationData: any,
    height?: number,
    width?: number
}

export function UncontrolledLottie(props: P) {

    const defaultOptions = {
        loop: true,
        autoplay: true,
        animationData: props.animationData,
        rendererSettings: {
            preserveAspectRatio: 'xMidYMid slice'
        }
    };

    return (
        <Lottie options={defaultOptions}
            height={props.height ? props.height : 400}
            width={props.width ? props.width : 400}
        />
    )
}
