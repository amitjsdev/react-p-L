import React, { useCallback, useEffect, useState } from 'react';
import { V2Exercise } from "../_types";
import { Nl2br } from './nl2br.component';
import _ from 'underscore';
import { Link } from 'react-router-dom';
import { makeLearnRoute } from '../_pages';
import { MainService } from '../_services/main.service';

type PropsTranslateSentence = {
    exercise: V2Exercise,
    learnRoute: string,
    saveStatus?: Function | null,
    onNext?: Function | null,
    main: MainService
};

export function ExerciseTranslateSentence(props: PropsTranslateSentence) {

    const { exercise } = props;
    const [popup, setPopup] = useState(-1); // -1 for none. 0 for failure, 1 for success, 
    const [options, setOptions] = useState<string[]>([]);

    const [availableOptions, setAvailableOptions] = useState<string[]>([]);

    useEffect(() => {
        // save available options
        setAvailableOptions(_.shuffle(exercise.options.split(/[; ]/)));

    }, [exercise]);


    // function to add the option
    const addOption = (option: string) => {
        if (!options.includes(option)) {
            setOptions([...options, option]);
        }
    };

    // function to remove the option
    const removeOption = (option: string) => {
        if (options.includes(option)) {
            setOptions(options.filter(o => o !== option));
        }
    }

    // function to check if answer is correct
    const checkAnswer = () => {
        // calculate user answer
        const userAnswer = options.join(" ");
        // get user answer (first  option is the answer)
        const answer = exercise.options.split(";")[0];
        // call the saveStatus
        if (props.saveStatus) {
            props.saveStatus(userAnswer === answer ? 1 : 0);
        }
        // show popup
        setPopup(userAnswer === answer ? 1 : 0);
        if (userAnswer === answer) {
            props.main.playSound("success");
        } else {
            props.main.playSound("failure");
        }

    }

    return (
        <div className="V2Exercise">
            <div className="V2ExerciseHeader">Translate The Sentence</div>
            <div className="V2ExerciseBody">
                {exercise.question}
                <div className="V2ExerciseBodyAnswers">
                    {
                        options.map((option, index) => {
                            return (
                                <div
                                    key={exercise.id + '-' + index}
                                    onClick={() => {
                                        // remove the option
                                        removeOption(option);
                                    }}
                                    className="V2ExerciseOption">
                                    {option}
                                </div>
                            )
                        })
                    }
                </div>
            </div>
            <div className="V2ExerciseOptions">
                {
                    availableOptions.filter(e => e && !options.includes(e)).map((option, index) => {
                        return (
                            <div
                                key={exercise.id + '-' + index}
                                onClick={() => {
                                    addOption(option);
                                }}
                                className="V2ExerciseOption">
                                {option}
                            </div>
                        )
                    })
                }
            </div>
            <div className="V2ExerciseSubmit" onClick={() => {
                checkAnswer();
            }}>Check</div>
            {
                popup !== -1 && (
                    <div className="V2ExerciseResult">
                        {
                            popup === 1 ? (
                                <div className="V2ExerciseResult-body">
                                    <div className="V2ExerciseResult-result">Correct!</div>
                                    <div className="V2ExerciseContinue" onClick={() => {
                                        // show next
                                        if (props.onNext) {
                                            props.onNext();
                                        }
                                    }}>Continue</div>
                                </div>
                            ) : (
                                    <div className="V2ExerciseResult-body">
                                        <div className="V2ExerciseResult-result-incorrect">Incorrect!</div>
                                        <div className="V2ExerciseResult-answer">Correct Answer: {exercise.options.split(";")[0]}</div>
                                        <div className="V2ExerciseResult-hint">
                                            Pssst.... abswers are always in learn
                                            <Link to={props.learnRoute}>Go to Learn</Link>
                                        </div>
                                        <div className="V2ExerciseContinue-error" onClick={() => {
                                            // show next
                                            if (props.onNext) {
                                                props.onNext();
                                            }
                                        }}>Continue</div>
                                    </div>
                                )
                        }
                    </div>
                )
            }
        </div>
    );
}




/**
 * Tap what you hear
 * @param props 
 */
export function ExerciseTapWhatYouHear(props: PropsTranslateSentence) {

    const { exercise } = props;
    const [popup, setPopup] = useState(-1); // -1 for none. 0 for failure, 1 for success, 
    const [options, setOptions] = useState<string[]>([]); // actually are the user select options
    const [availableOptions, setAvailableOptions] = useState<string[]>([]); // options that are available to the user
    const [isHintVisible, setIsHintVisible] = useState(false);

    const sound = new Audio();


    // function to add the option
    const addOption = (option: string) => {
        if (!options.includes(option)) {
            setOptions([...options, option]);
        }
    };

    // function to remove the option
    const removeOption = (option: string) => {
        if (options.includes(option)) {
            setOptions(options.filter(o => o !== option));
        }
    }

    // function to check if answer is correct
    const checkAnswer = () => {
        // calculate user answer
        const userAnswer = options.join(" ");
        // get user answer (first  option is the answer)
        const answer = exercise.options.split(";")[0];
        // call the saveStatus
        if (props.saveStatus) {
            props.saveStatus(userAnswer === answer ? 1 : 0);
        }
        // show popup
        setPopup(userAnswer === answer ? 1 : 0);
        // play sound
        if (userAnswer === answer) {
            props.main.playSound("success");
        } else {
            props.main.playSound("failure");
        }

    }

    const playSound = useCallback(() => {
        sound.src = `https://langappnew.s3.amazonaws.com/Lesson_${exercise.moduleNo}_${exercise.routeNo}_${exercise.lessonNo}_Pack/v2exercises/${exercise.id}.mp3`;
        sound.play();

        return () => {
            // pause sound when users moves on
            sound.pause();
        }
    }, [exercise, sound]);

    useEffect(() => {
        // shuffle the options
        setAvailableOptions(_.shuffle(exercise.options.split(/[; ]/)));
        // play the sound
        playSound();
    }, [exercise]); // dont add paly sound to it, as it will make it respeak at options select

    return (
        <div className="V2Exercise">
            {/* exercise */}
            <div className="V2ExerciseHeader">Tap what you hear</div>
            <div className="V2ExerciseBody">
                {/* play button */}
                <div className="V2ExercisePlayButtonHolder">
                    <div title="play" className="V2ExercisePlayButton" onClick={() => {
                        playSound();
                    }}></div>
                </div>
                {/* hint */}
                {
                    // isHintVisible ? (
                    //     <div className="V2ExerciseHint">{exercise.translation}</div>
                    // ) : (
                    //         <button className="V2ExerciseHintButton" onClick={() => {
                    //             setIsHintVisible(true);
                    //         }}>Show Hint</button>
                    //     )
                }
                {/* user answers */}
                {
                    options.length > 0 ? (
                        <div className="V2ExerciseBodyAnswers">
                            {
                                options.map((option, index) => {
                                    return (
                                        <div
                                            key={exercise.id + '-' + index}
                                            onClick={() => {
                                                // remove the option
                                                removeOption(option);
                                            }}
                                            className="V2ExerciseOption">
                                            {option}
                                        </div>
                                    )
                                })
                            }
                        </div>
                    ) : <></>
                }
            </div>
            {/* options */}
            <div className="V2ExerciseOptions">
                {
                    availableOptions.filter(o => !options.includes(o)).map((option, index) => {
                        return (
                            <div
                                key={exercise.id + '-' + index}
                                onClick={() => {
                                    addOption(option);
                                }}
                                className="V2ExerciseOption">
                                {option}
                            </div>
                        )
                    })
                }
            </div>
            {/* check answer button */}
            <div className="V2ExerciseSubmit" onClick={() => {
                checkAnswer();
            }}>Check</div>
            {/* result popup */}
            {
                popup !== -1 && (
                    <div className="V2ExerciseResult">
                        {
                            popup === 1 ? (
                                <div className="V2ExerciseResult-body">
                                    <div className="V2ExerciseResult-result">Correct!</div>
                                    <div className="V2ExerciseContinue" onClick={() => {
                                        // show next
                                        if (props.onNext) {
                                            props.onNext();
                                        }
                                    }}>Continue</div>
                                </div>
                            ) : (
                                    <div className="V2ExerciseResult-body">
                                        <div className="V2ExerciseResult-result-incorrect">Incorrect!</div>
                                        <div className="V2ExerciseResult-answer">Correct Answer: {exercise.options.split(";")[0]}</div>
                                        <div className="V2ExerciseResult-hint">
                                            Pssst.... abswers are always in learn 
                                            <Link to={props.learnRoute}>Go to Learn</Link>
                                        </div>
                                        <div className="V2ExerciseContinue-error" onClick={() => {
                                            // show next
                                            if (props.onNext) {
                                                props.onNext();
                                            }
                                        }}>Continue</div>
                                    </div>
                                )
                        }
                    </div>
                )
            }
        </div>
    );
}




/**
 * Mini lesson 1
 * @param props 
 */
export function ExerciseMiniLesson1(props: PropsTranslateSentence) {

    const { exercise } = props;
    const [popup, setPopup] = useState(-1); // -1 for none. 0 for failure, 1 for success, 
    const [isHintVisible, setIsHintVisible] = useState(false);

    // function to check if answer is correct
    const checkAnswer = (option: string) => {
        // calculate user answer
        const userAnswer = option;
        // get user answer (first  option is the answer)
        const answer = exercise.answer.split(";")[0];
        // call the saveStatus
        if (props.saveStatus) {
            props.saveStatus(userAnswer === answer ? 1 : 0);
        }
        // show popup
        setPopup(userAnswer === answer ? 1 : 0);
        // play sound
        if (userAnswer === answer) {
            props.main.playSound("success");
        } else {
            props.main.playSound("success");
        }

    }

    const [tip1, tip2, tip3] = exercise.question.split(";");

    return (
        <div className="V2Exercise mini-lesson-1">
            {/* exercise */}
            <div className="">
                <div className="mini-lesson-tip1">{tip1}</div>
                {/* options */}
                <table className="mini-lesson-table">
                    {
                        exercise.options.split(";").map(s => {
                            const [string1, string2] = s.split(",");
                            return { string1, string2 }
                        }).map((obj, index) => (
                            <tr
                                key={exercise.id + '-' + index}>
                                <td>{obj.string1}</td>
                                <td>{obj.string2}</td>
                            </tr>
                        ))
                    }
                </table>
                <div className="mini-lesson-tip2">{tip2}</div>
                <div className="mini-lesson-tip3">{tip3}</div>
                {/* hint */}
                {
                    // isHintVisible ? (
                    //     <div className="V2ExerciseHint">{exercise.translation}</div>
                    // ) : (
                    //         <button className="V2ExerciseHintButton" onClick={() => {
                    //             setIsHintVisible(true);
                    //         }}>Show Hint</button>
                    //     )
                }
            </div>
            {/* options */}
            <div className="V2ExerciseOptions">
                {
                    exercise.answer.split(/[; ]/).map((option, index) => {
                        return (
                            <div
                                key={exercise.id + '-' + index}
                                onClick={() => {
                                    checkAnswer(option);
                                }}
                                className="V2ExerciseOption">
                                {option}
                            </div>
                        )
                    })
                }
            </div>
            {/* result popup */}
            {
                popup !== -1 && (
                    <div className="V2ExerciseResult">
                        {
                            popup === 1 ? (
                                <div className="V2ExerciseResult-body">
                                    <div className="V2ExerciseResult-result">Correct!</div>
                                    <div className="V2ExerciseContinue" onClick={() => {
                                        // show next
                                        if (props.onNext) {
                                            props.onNext();
                                        }
                                    }}>Continue</div>
                                </div>
                            ) : (
                                    <div className="V2ExerciseResult-body">
                                        <div className="V2ExerciseResult-result-incorrect">Incorrect!</div>
                                        <div className="V2ExerciseResult-answer">Correct Answer: {exercise.options.split(";")[0]}</div>
                                        <div className="V2ExerciseResult-hint">
                                            Pssst.... abswers are always in learn
                                            <Link to={props.learnRoute}>Go to Learn</Link>
                                        </div>
                                        <div className="V2ExerciseContinue-error" onClick={() => {
                                            // show next
                                            if (props.onNext) {
                                                props.onNext();
                                            }
                                        }}>Continue</div>
                                    </div>
                                )
                        }
                    </div>
                )
            }
        </div>
    );
}




/**
 * Mini lesson 2
 * @param props 
 */
export function ExerciseMiniLesson2(props: PropsTranslateSentence) {

    const { exercise } = props;
    const [popup, setPopup] = useState(-1); // -1 for none. 0 for failure, 1 for success, 
    const [isHintVisible, setIsHintVisible] = useState(false);

    // function to check if answer is correct
    const checkAnswer = (option: string) => {
        // calculate user answer
        const userAnswer = option;
        // get user answer (first  option is the answer)
        const answer = exercise.answer.split(";")[0];
        // call the saveStatus
        if (props.saveStatus) {
            props.saveStatus(userAnswer === answer ? 1 : 0);
        }
        // show popup
        setPopup(userAnswer === answer ? 1 : 0);
        // play sound
        if (userAnswer === answer) {
            props.main.playSound("success");
        } else {
            props.main.playSound("success");
        }

    }

    const [tip1, tip2, tip3] = exercise.question.split(";");

    return (
        <div className="V2Exercise mini-lesson-1">
            {/* exercise */}
            <div className="">
                <div className="mini-lesson-tip1">{tip1}</div>
                {/* options */}
                <table className="mini-lesson-table">
                    <tr>
                        <td>{exercise.options}</td>
                    </tr>
                </table>
                <div className="mini-lesson-tip2">{tip2}</div>
                <div className="mini-lesson-tip3">{tip3}</div>
                {/* hint */}
                {
                    // isHintVisible ? (
                    //     <div className="V2ExerciseHint">{exercise.translation}</div>
                    // ) : (
                    //         <button className="V2ExerciseHintButton" onClick={() => {
                    //             setIsHintVisible(true);
                    //         }}>Show Hint</button>
                    //     )
                }
            </div>
            {/* options */}
            <div className="V2ExerciseOptions">
                {
                    exercise.answer.split(/[; ]/).map((option, index) => {
                        return (
                            <div
                                key={exercise.id + '-' + index}
                                onClick={() => {
                                    checkAnswer(option);
                                }}
                                className="V2ExerciseOption">
                                {option}
                            </div>
                        )
                    })
                }
            </div>
            {/* result popup */}
            {
                popup !== -1 && (
                    <div className="V2ExerciseResult">
                        {
                            popup === 1 ? (
                                <div className="V2ExerciseResult-body">
                                    <div className="V2ExerciseResult-result">Correct!</div>
                                    <div className="V2ExerciseContinue" onClick={() => {
                                        // show next
                                        if (props.onNext) {
                                            props.onNext();
                                        }
                                    }}>Continue</div>
                                </div>
                            ) : (
                                    <div className="V2ExerciseResult-body">
                                        <div className="V2ExerciseResult-result-incorrect">Incorrect!</div>
                                        <div className="V2ExerciseResult-answer">Correct Answer: {exercise.options.split(";")[0]}</div>
                                        <div className="V2ExerciseResult-hint">
                                            Pssst.... abswers are always in learn
                                            <Link to={props.learnRoute}>Go to Learn</Link>
                                        </div>
                                        <div className="V2ExerciseContinue-error" onClick={() => {
                                            // show next
                                            if (props.onNext) {
                                                props.onNext();
                                            }
                                        }}>Continue</div>
                                    </div>
                                )
                        }
                    </div>
                )
            }
        </div>
    );
}




/**
 * Mini lesson 3
 * @param props 
 */
export function ExerciseMiniLesson3(props: PropsTranslateSentence) {

    const { exercise } = props;
    const [popup, setPopup] = useState(-1); // -1 for none. 0 for failure, 1 for success, 
    const [isHintVisible, setIsHintVisible] = useState(false);

    // function to check if answer is correct
    const checkAnswer = (option: string) => {
        // calculate user answer
        const userAnswer = option;
        // get user answer (first  option is the answer)
        const answer = exercise.answer.split(";")[0];
        // call the saveStatus
        if (props.saveStatus) {
            props.saveStatus(userAnswer === answer ? 1 : 0);
        }
        // show popup
        setPopup(userAnswer === answer ? 1 : 0);
        // play sound
        if (userAnswer === answer) {
            props.main.playSound("success");
        } else {
            props.main.playSound("failure");
        }

    }

    const [tip1, tip2, tip3] = exercise.question.split(";");

    return (
        <div className="V2Exercise mini-lesson-1">
            {/* exercise */}
            <div className="">
                <div className="mini-lesson-tip1">{tip1}</div>
                {/* options */}
                <br />
                <Nl2br text={exercise.options} />
                <br />
                <div className="mini-lesson-tip2">{tip2}</div>
                <div className="mini-lesson-tip3">{tip3}</div>
                {/* hint */}
                {
                    // isHintVisible ? (
                    //     <div className="V2ExerciseHint">{exercise.translation}</div>
                    // ) : (
                    //         <button className="V2ExerciseHintButton" onClick={() => {
                    //             setIsHintVisible(true);
                    //         }}>Show Hint</button>
                    //     )
                }
            </div>
            {/* options */}
            <div className="V2ExerciseOptions">
                {
                    exercise.answer.split(/[; ]/).map((option, index) => {
                        return (
                            <div
                                key={exercise.id + '-' + index}
                                onClick={() => {
                                    checkAnswer(option);
                                }}
                                className="V2ExerciseOption">
                                {option}
                            </div>
                        )
                    })
                }
            </div>
            {/* result popup */}
            {
                popup !== -1 && (
                    <div className="V2ExerciseResult">
                        {
                            popup === 1 ? (
                                <div className="V2ExerciseResult-body">
                                    <div className="V2ExerciseResult-result">Correct!</div>
                                    <div className="V2ExerciseContinue" onClick={() => {
                                        // show next
                                        if (props.onNext) {
                                            props.onNext();
                                        }
                                    }}>Continue</div>
                                </div>
                            ) : (
                                    <div className="V2ExerciseResult-body">
                                        <div className="V2ExerciseResult-result-incorrect">Incorrect!</div>
                                        <div className="V2ExerciseResult-answer">Correct Answer: {exercise.options.split(";")[0]}</div>
                                        <div className="V2ExerciseResult-hint">
                                            Pssst.... abswers are always in learn
                                            <Link to={props.learnRoute}>Go to Learn</Link>
                                        </div>
                                        <div className="V2ExerciseContinue-error" onClick={() => {
                                            // show next
                                            if (props.onNext) {
                                                props.onNext();
                                            }
                                        }}>Continue</div>
                                    </div>
                                )
                        }
                    </div>
                )
            }
        </div>
    );
}




/**
 * Mini lesson 3
 * @param props 
 */
export function ExerciseTapThePairSentences(props: PropsTranslateSentence) {

    const { exercise } = props;
    const [popup, setPopup] = useState(-1); // -1 for none. 0 for failure, 1 for success, 
    const [answers, setAnswers] = useState<string[]>([]); // to hold user answers
    const [questions, setQuestions] = useState<any[]>([]);
    const [optionOrders, setOptionOrders] = useState<number[]>([]);
    const [questionIndex, setQuestionIndex] = useState(0);

    useEffect(() => {
        const q = _.shuffle(exercise.options.split(";")).map(option => {
            const [question, answer] = option.split(",");
            return { question, answer, status: -1 };
        });

        // set questions
        setQuestions(q);

        // set option orders
        setOptionOrders(q.map(qq => _.random(0, 9999)));


    }, [exercise]);

    // function to check if answer is correct
    const checkAnswer = (answer: string) => {
        // check if already selected 
        if (answers.includes(answer)) {
            // do nothing
            return;
        }
        // else , push to answers
        setAnswers([...answers, answer]);
        // check if the answer is correct for the current question
        if (answer === questions[questionIndex].answer) {
            // the answer is correct
            const newQuestions = [...questions];
            newQuestions[questionIndex].status = 1;
            setQuestions(newQuestions);

        } else {
            // the answer is wrong
            // find the question that has this answer and set it wrong
            const newQuestions = [...questions];
            const answerIndex = newQuestions.findIndex(q => q.answer === answer);
            newQuestions[answerIndex].status = 0;
            setQuestions(newQuestions);
        }
        // increase the counter, if necessary, or else end the task
        if (questions.length - 1 > questionIndex) {
            setQuestionIndex(questionIndex + 1);
        } else {
            // show result
            let pass = false;
            if (questions.length > 0) {
                const score = questions.map(q => q.status).reduce((prev, current) => prev + current, 0) / questions.length;
                if (score >= 0.5) {
                    // pass
                    pass = true;
                }
            }

            if (props.saveStatus) {
                props.saveStatus(pass ? 1 : 0);
            }

            setPopup(pass ? 1 : 0);
            // play sound
            if (pass) {
                props.main.playSound("success");
            } else {
                props.main.playSound("failure");
            }


        }

    }

    if(questions.length < 1) {
        return <div>Please wait...</div>
    }

    return (
        <div className="V2Exercise tap-the-pair" key={exercise.id}>
            {/* <div className="V2ExerciseHeader">Translate The Sentence</div> */}
            <div className="V2ExerciseBody plain">
                {exercise.question}
                <div className="V2ExerciseBodyQuestion">
                    {questions[questionIndex].question}
                </div>
            </div>
            <div className="V2ExerciseOptions">
                {
                    questions.map((question, index) => {
                        return (
                            <div
                                key={exercise.id + '-' + index}
                                onClick={() => {
                                    checkAnswer(question.answer);
                                }}
                                style={{
                                    order: optionOrders[index] ? optionOrders[index] : _.random(0, 9999)
                                }}
                                className={
                                    "V2ExerciseOption "
                                    +
                                    (question.status === -1 ? "" : (question.status === 0 ? "wrong" : "right"))
                                }>
                                {question.answer}
                                {
                                    question.status !== -1 ? (
                                        <div style={{ fontSize: "small" }}>{question.question}</div>
                                    ) : <></>
                                }
                            </div>
                        )
                    })
                }
            </div>
            {/* <div className="V2ExerciseSubmit" onClick={() => {
                checkAnswer();
            }}>Check</div> */}
            {
                popup !== -1 && (
                    <div className="V2ExerciseResult">
                        {
                            popup === 1 ? (
                                <div className="V2ExerciseResult-body">
                                    <div className="V2ExerciseResult-result">Correct!</div>
                                    <div className="V2ExerciseContinue" onClick={() => {
                                        // show next
                                        if (props.onNext) {
                                            setPopup(-1);
                                            props.onNext();
                                        }
                                    }}>Continue</div>
                                </div>
                            ) : (
                                    <div className="V2ExerciseResult-body">
                                        <div className="V2ExerciseResult-result-incorrect">Incorrect!</div>
                                        <div className="V2ExerciseResult-answer">Correct Answer: {exercise.options.split(";")[0]}</div>
                                        <div className="V2ExerciseResult-hint">
                                            Pssst.... abswers are always in learn
                                            <Link to={props.learnRoute}>Go to Learn</Link>
                                        </div>
                                        <div className="V2ExerciseContinue-error" onClick={() => {
                                            // show next
                                            if (props.onNext) {
                                                setPopup(-1);
                                                props.onNext();
                                            }
                                        }}>Continue</div>
                                    </div>
                                )
                        }
                    </div>
                )
            }
        </div>
    );
}




/**
 * Mini lesson 3
 * @param props 
 */
export function ExerciseTapThePair(props: PropsTranslateSentence) {

    const { exercise } = props;
    const [popup, setPopup] = useState(-1); // -1 for none. 0 for failure, 1 for success, 
    const [answers, setAnswers] = useState<string[]>([]); // to hold user answers
    const [questions, setQuestions] = useState<any[]>([]);
    const [optionOrders, setOptionOrders] = useState<number[]>([]);
    const [questionIndex, setQuestionIndex] = useState(0);

    useEffect(() => {
        const q = _.shuffle(exercise.options.split(";")).map(option => {
            const [question, answer] = option.split(",");
            return { question, answer, status: -1 };
        });

        // set questions
        setQuestions(q);

        // set option orders
        setOptionOrders(q.map(qq => _.random(0, 9999)));


    }, [exercise]);

    // function to check if answer is correct
    const checkAnswer = (answer: string) => {
        // check if already selected 
        if (answers.includes(answer)) {
            // do nothing
            return;
        }
        // else , push to answers
        setAnswers([...answers, answer]);
        // check if the answer is correct for the current question
        if (answer === questions[questionIndex].answer) {
            // the answer is correct
            const newQuestions = [...questions];
            newQuestions[questionIndex].status = 1;
            setQuestions(newQuestions);

        } else {
            // the answer is wrong
            // find the question that has this answer and set it wrong
            const newQuestions = [...questions];
            const answerIndex = newQuestions.findIndex(q => q.answer === answer);
            newQuestions[answerIndex].status = 0;
            setQuestions(newQuestions);
        }
        // increase the counter, if necessary, or else end the task
        if (questions.length - 1 > questionIndex) {
            setQuestionIndex(questionIndex + 1);
        } else {
            // show result
            let pass = false;
            if (questions.length > 0) {
                const score = questions.map(q => q.status).reduce((prev, current) => prev + current, 0) / questions.length;
                if (score >= 0.5) {
                    // pass
                    pass = true;
                }
            }

            if (props.saveStatus) {
                props.saveStatus(pass ? 1 : 0);
            }

            setPopup(pass ? 1 : 0);
            // play sound
            if (pass) {
                props.main.playSound("success");
            } else {
                props.main.playSound("failure");
            }


        }

    }

    if (questions.length < 1) {
        return <div>Please wait...</div>
    }

    return (
        <div className="V2Exercise tap-the-pair" key={exercise.id}>
            {/* <div className="V2ExerciseHeader">Translate The Sentence</div> */}
            <div className="V2ExerciseBody plain">
                {exercise.question}
                <div className="V2ExerciseBodyQuestion">
                    {questions[questionIndex].question}
                </div>
            </div>
            <div className="V2ExerciseOptions">
                {
                    questions.map((question, index) => {
                        return (
                            <div
                                key={exercise.id + '-' + index}
                                onClick={() => {
                                    checkAnswer(question.answer);
                                }}
                                style={{
                                    order: optionOrders[index] ? optionOrders[index] : _.random(0, 9999)
                                }}
                                className={
                                    "V2ExerciseOption "
                                    +
                                    (question.status === -1 ? "" : (question.status === 0 ? "wrong" : "right"))
                                }>
                                {question.answer}
                                {
                                    question.status !== -1 ? (
                                        <div style={{fontSize: "small"}}>{question.question}</div>
                                    ) : <></>
                                }
                            </div>
                        )
                    })
                }
            </div>
            {/* <div className="V2ExerciseSubmit" onClick={() => {
                checkAnswer();
            }}>Check</div> */}
            {
                popup !== -1 && (
                    <div className="V2ExerciseResult">
                        {
                            popup === 1 ? (
                                <div className="V2ExerciseResult-body">
                                    <div className="V2ExerciseResult-result">Correct!</div>
                                    <div className="V2ExerciseContinue" onClick={() => {
                                        // show next
                                        if (props.onNext) {
                                            setPopup(-1);
                                            props.onNext();
                                        }
                                    }}>Continue</div>
                                </div>
                            ) : (
                                    <div className="V2ExerciseResult-body">
                                        <div className="V2ExerciseResult-result-incorrect">Incorrect!</div>
                                        <div className="V2ExerciseResult-answer">Correct Answer: {exercise.options.split(";")[0]}</div>
                                        <div className="V2ExerciseResult-hint">
                                            Pssst.... abswers are always in learn
                                            <Link to={props.learnRoute}>Go to Learn</Link>
                                        </div>
                                        <div className="V2ExerciseContinue-error" onClick={() => {
                                            // show next
                                            if (props.onNext) {
                                                setPopup(-1);
                                                props.onNext();
                                            }
                                        }}>Continue</div>
                                    </div>
                                )
                        }
                    </div>
                )
            }
        </div>
    );
}