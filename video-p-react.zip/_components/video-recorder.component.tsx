import React, { useEffect, useRef, useState } from 'react'

export default function VideoRecorder({
    startCamera,
    stopCamera,
    startRecording,
    stopRecording,
    style = {},
    onStopRecording,
    uploadChunkCallback,
    handleAbruptMediaClose,
    quizAttemptLogId,
    callbackSetStream
}: {
    startCamera: boolean,
    stopCamera: boolean,
    startRecording: boolean,
    stopRecording: boolean,
    style: any,
    handleAbruptMediaClose: Function,
    uploadChunkCallback: Function,
    onStopRecording: Function,
    quizAttemptLogId: any,
    callbackSetStream:Function
}) {
    // recording related
    const [isStarted, setStarted] = useState<boolean>(false);
    const [stream, setstream] = useState<any>();
    const [mediaRecorder, setmediaRecorder] = useState<any>();
    const [downloadLink, setdownloadLink] = useState<any>(null);
    const [videoObj, setvideoObj] = useState();
    const [blobsRecorded, setblobsRecorded] = useState<any>([]);
    const [S3IntervalRef, setS3IntervalRef] = useState<any>();
    const [error, setError] = useState("");

    // Video ref
    const videoRef = useRef<HTMLVideoElement>(null);
    const constraints = {
        audio:true,
         video: { 
             frameRate: { min:5, ideal: 10, max: 15 },
             width: { min: 426, ideal: 640, max: 1920 },
             height: { min: 240, ideal: 360, max: 1080 }
            } 
        };
        const videoDuration =1000*60;

    //console.log({ handleAbruptMediaClose });

    // start and stop camera if needed
    useEffect(() => {
        if (startCamera) {
            startCameraHandler();
        }
    }, [startCamera]);
    useEffect(() => {
        if (stopCamera) {
            stopCameraHandler();
        }
    }, [stopCamera]);
    useEffect(() => {
        if (startRecording) {
            startRecordingHandler(null);
            console.log('start recording');
        }
    }, [startRecording]);
    useEffect(() => {
        if (stopRecording) {
            console.log('stop recording');
            stopRecordingHandler(null);
        }
    }, [stopRecording]);

    // stop the camera anyways on clear
    useEffect(() => {
        return () => {
            stopCameraHandler(false, true);
            clearInterval(S3IntervalRef);
        };
    }, []);
    // useEffect(() => {
    //     if (stream) {
    //         if (isRecording) {
    //             startRecording(null);
    //             console.log('start recording');
    //         } else {
    //             if (!isRecording) {
    //                 // only stop camera and recording if needed (we were previously recording)
    //                 console.log('stop recording');
    //                 stopRecording(null);
    //             }
    //         }
    //     }
    // }, [isRecording, stream]);

    // manage stream changes 
    useEffect(() => {
        if (stream) {
            // get tracks and add event listner to it
            const tracks = stream.getTracks();
            tracks.forEach((track: any) => {
                track.onended = handleAbruptMediaClose;
            });
            return () => {
                tracks.forEach((track: any) => {
                    track.onended = undefined;
                });
            }
        }
    }, [stream]);

    const startCameraHandler = async () => {
        try {
            // reset the recorded blobs
            setblobsRecorded([])
            setdownloadLink(null)
            setvideoObj(null as any)
            // create a media stream
            let stream = await navigator.mediaDevices.getUserMedia(constraints);

            setstream(stream as any);
           
            

            if (videoRef.current) {
                // update the media element
                var video = videoRef.current as HTMLVideoElement;
                video.srcObject = stream;
                video.volume = 0;
            }
            return;
        } catch (err) {
            setError("Please check camera permissions");
            handleAbruptMediaClose();
            console.log(err);
            return;
        }
    }

    const stopCameraHandler = async (discardFootage = false, cleanup = false) => {
        if (videoRef.current) {
            const vid = videoRef.current as HTMLVideoElement;
            if (vid) {
                vid.pause();
                vid.src = "";
                if (vid.srcObject) {
                    const stream = vid.srcObject as MediaStream;
                    if (stream) {
                        stream.getTracks().forEach(track => track.stop());
                    }
                }
            }
        }

        if (stream) {
            stream.getTracks().forEach(function (track: any) {
                console.log("stopping stream", track);
                track.stop();
            });
            if (!cleanup) {
                setstream(null as any);
            }

        }
    }
    const record_and_send = () => {
        console.log('record_and_send');
        if (stream) {
            try {
                const recorder = new MediaRecorder(stream);
                const chunks: any = [];
                recorder.ondataavailable = e => chunks.push(e.data);
                recorder.onstop = e => {
                    if (uploadChunkCallback) {
                        let video_local = new Blob(chunks, {
                            type: 'video/webm'
                        });
                        uploadChunkCallback(video_local)
                    }

                }
                setTimeout(() => recorder.stop(), videoDuration); // we'll have a 5s media file
                recorder.start();
            } catch (e) {
                console.log(e);

            }
        } else {
            console.log('record_and_send no stream');
        }
    }
    // generate a new file every 5s

    useEffect(() => {
        if (quizAttemptLogId && startRecording) {
            uploadChunk();
        }

    }, [quizAttemptLogId])
    const uploadChunk = () => {
        console.log('uploadChunk', startRecording, stream);
        record_and_send()
        const t = setInterval(record_and_send, videoDuration);
        setS3IntervalRef(t);
    }

    // start recording
    const startRecordingHandler = async (e: any) => {

        console.log('startRecording');
        var mediaRecorder2 = new MediaRecorder(stream, {
            mimeType: "video/webm"
        });
        const recorded_blobs = [] as any;
        // reset the blobs
        setblobsRecorded([]);
        // reset the download link
        setdownloadLink(null)
        setvideoObj(null as any);
        setStarted(true);

        // event : new recorded video blob available 
        mediaRecorder2.addEventListener('dataavailable', (e: any) => {
            recorded_blobs.push(e.data);
            // hacking in through to show the recorded time data, due to insufficient time
            const recordedTimeDiv = document.getElementById('recording-time');
            if (recordedTimeDiv) {
                recordedTimeDiv.innerText = ((Math.floor(recorded_blobs.length / 60) + "").padStart(2, "0") + ":" + (Math.floor(recorded_blobs.length % 60) + "").padStart(2, "0"));
            }

            setblobsRecorded(recorded_blobs);
            callbackSetStream(recorded_blobs,e.data)
            // if(callbackSetStream){
            //     callbackSetStream(e.data)
            // }
        });
        // start recording with each recorded blob having 1 second video
        mediaRecorder2.start(1000);
        setmediaRecorder(mediaRecorder2 as any)
    }

    const stopRecordingHandler = (e: any) => {
        if (mediaRecorder) {
            //this.mediaRecorder.stop();
            mediaRecorder.stop()
            setmediaRecorder(undefined);

            // save the blob as video
            let video_local = new Blob(blobsRecorded, {
                type: 'video/webm'
            });
            setdownloadLink(video_local);
            setvideoObj(URL.createObjectURL(video_local) as any);

            // return the blob
            onStopRecording(video_local);

        }

        if (stream) {
            // stop all tracks
            stream.getTracks().forEach((track: any) => {
                if (track.readyState == "live") {
                    track.stop();
                }
            });
        }
        setStarted(false);
        clearInterval(S3IntervalRef)
    }


    return (
        <div
            className={"VideoRecorder " + (startCamera && !error ? "active" : "inactive")}
            style={{...style,position: 'absolute',
            left: '5px',
            top: '16px',}}>
            <video
                id="video"
                style={{ ...style, display: startCamera && !error ? "block" : "none" }}
                ref={videoRef}
                autoPlay></video>
            {
                startCamera ? <></> : <div>Camera not active</div>
            }
            {
                error ? <div style={{ color: "red" }}>{error}</div> : <></>
            }
        </div>
    )
}
