// const base = "https://devapi.taplingua.com/api/";
// const base = window.location.hostname === "app.taplingua.com" ? "https://api2.taplingua.com/api/" : "https://apistaging.taplingua.com/api/";
const base = process.env.REACT_APP_URL ? process.env.REACT_APP_URL :  process.env.NODE_ENV === 'development' ? "http://localhost:8000/api/" : (window.location.hostname === "app.taplingua.com" ? "https://api2.taplingua.com/api/" : "https://apistaging.taplingua.com/api/");
// const base = process.env.NODE_ENV === 'development' ? "http://localhost:8000/api/" : (window.location.hostname === "app.taplingua.com" ? "https://api2.taplingua.com/api/" : "https://apistaging.taplingua.com/api/");
// const base = 'https://api2.taplingua.com/api/'
// const base = 'https://apistaging.taplingua.com/api/'
// const base = 'http://laravel-api/api/'

export const baseUrl = base

export const endpoints = {
    auth: {
        login: base + 'user/login',
        register: base + 'user/create',
        profile: base + 'employee',
        userActivityLog: base + 'user/activity/log',
        passwordReset: base + 'user/password/reset',
        social: {
            google: base + 'auth/google/profile',
            facebook: base + 'auth/facebook/profile',
        }
    },
    profilePic: base + 'profile_image',
    profileImageUploadUrl: base + 'profileImageUploadUrl',
    module: base + 'module',
    lesson: (moduleno = "0", routeno = "0", lessonno = "0") => base + 'lesson?' + (new URLSearchParams({ moduleno, routeno, lessonno })).toString(),
    moduleLesson: (moduleNo = "0") => base + 'module?' + (new URLSearchParams({ moduleNo, fetchLevel: "1", allLessons: "true" })).toString(),
    exercise: (moduleno = "0", routeno = "0", lessonno = "0") => base + 'exercise?' + (new URLSearchParams({ moduleno, routeno, lessonno })).toString(),
    exercises: (moduleNo = "0", routeNo = "0", lessonNo = "0") => base + 'v2-exercises?' + (new URLSearchParams({ moduleNo, routeNo, lessonNo })).toString(),
    videoTLDR: (moduleNo = "0", routeNo = "0", lessonNo = "0") => base + 'lessons-video-tldrs?' + (new URLSearchParams({ moduleNo, routeNo, lessonNo })).toString(),
    myRank: base + 'leaderboard/my-rank',
    myStreak: base + 'streak',
    saveRoundLog: base + 'round-log',
    saveDailyGoalLog: base + 'log-daily-goal',
    payWallDetails: base + 'employee-paywall-details',
    employee: (userId: string) => base + 'employee?userId=' + userId,
    employeeCustomFetch: (obj: any) => base + 'employee-cf?' + (new URLSearchParams({ ...obj })).toString(),
    allPreviousAttempts: base + 'interview/prev-attempts/all',
    getParameters: base + 'interview/get-parameters',
    getAllPracticeSets: base + 'lesson-by-module-compact/',
    getSelfReview: base + 'interview/review/self/',
    getExternalReview: base + 'interview/review/external/',
    fetchAllPracticeSets: base + 'practice-sets',

    checkUserDetails: base + 'user/details',

    moduleRelatedPreviousAttempts: (moduleNo = "0", routeNo = "0", lessonNo = "0") => base + 'interview/prev-attempts?' + (new URLSearchParams({ moduleNo, routeNo, lessonNo })).toString(),
    saveExternalReview: base + 'interview/review/external/',
    saveMentorReview: base + 'instructor/review/',
    saveSelfReview: base + 'interview/review/self/',
    updateMentorReview: base + 'instructor/review-update/',
    prevAttemptsByuuid: base + 'interview/videos/',
    prevAttemptsByUuidForMentor: base + 'instructor/review/',
    prevAttemptByuuid: base + 'interview/prev-attempt/',
    shareAttemptsByuuid: base + 'interview/videos/share',
    //resume builder endpoints
    getAllResume: base + 'resume',
    getSingleResume: base + 'resume',
    postBasicInfoResume: base + 'resume',
    postSummaryResume: base + 'resume',
    serverTime: base + 'time',
    mentorCohorts: base + 'cohorts-for-instructor',
    cohortStatById: (cohortId: any) => base + `cohorts/${cohortId}/users/stats`,
    deleteVideoByuuid: (uuid: any) => base + `interview/videos/${uuid}`,
    getStudentPracticeAnswerUrl: (data: any) => base + `student_practice_answers/${data.practiceSetId}/${data.practiceQuestionId}`,
    saveStudentPracticeAnswerUrl: base + `student_practice_answers`,
    cohortDetail: base + 'cohort-detail',
    userCohortId: base + 'user-cohortid',
    // profileImageUploadUrl: (data:any) => `https://qnoa4x8gbc.execute-api.us-east-1.amazonaws.com/upload?fileName=${data.name}&path=profile-pics&fileContentType=${data.type}`,
    

    updatePAN: base + "updatePAN",
    saveAttemptTime: base + "attempt-timer",
    quizSetsAssignedToMe: base + "quiz-set/assigned-to-me",
    quizSetsAssignedToMeQuestions: (quizSetId: number) => base + "quiz-set/assigned-to-me/" + quizSetId + "/questions",
    quizSetsAssignedToMeProgression: (quizSetId: number) => base + "quiz-set/" + quizSetId + "/attempts",
    createAttemptForQuizSet: (quizSetId: number) => base + "quiz-set/assigned-to-me/" + quizSetId + "/create-attempt",
    saveAttemptForQuizSet: (quizSetId: number, attemptNumber: number) => base + "quiz-set/assigned-to-me/" + quizSetId + "/log-attempt/" + attemptNumber,
    saveAttemptVideoForQuizSet: (quizSetId: number, attemptNumber: number) => base + "quiz-set/assigned-to-me/" + quizSetId + "/log-attempt-video/" + attemptNumber,
    saveProctoredQuestionnaire: base + "quiz-set/save-proctored-questionnaire",
}