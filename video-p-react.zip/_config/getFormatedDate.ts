import moment from 'moment'
const getFormatedDate = (date: moment.MomentInput) => moment(date).format("MMM DD YYYY")
export default getFormatedDate
