import mixpanel from 'mixpanel-browser';

mixpanel.init('59bae692077ad0378690050996ef40c9');

let envCheck = process.env.NODE_ENV === 'production';

let actions = {
    identify: (id: string) => {
        if (envCheck) mixpanel.identify(id);
    },
    alias: (id: string) => {
        if (envCheck) mixpanel.alias(id);
    },
    track: (eventName: string, props: any) => {
        if (envCheck) mixpanel.track('InterviewPrep.' + eventName, props);
    },
    people: {
        set: (props: any) => {
            if (envCheck) mixpanel.people.set(props);
        },
    },
};

export let mixPanel = actions;