const SocialConfig = {
    google: {
        clientId: '255632787494-an9o2rtbc7erd48b6gspsm039nv0lu0s.apps.googleusercontent.com'
        // clientId: '255632787494-9b7flcotkt486apprn0r11ha85bclvd5.apps.googleusercontent.com'
    },
    facebook: {
        appId: "1221319641380163"
    }
}

export default SocialConfig;