import React, { Component } from 'react';

export const I18Context = React.createContext<{
    current: string,
    handle: Function
} | null>(null);


const withI18 = (Component: any) => (props: any) => (
    <I18Context.Consumer>
        {
            state => <Component {...props} lang={state} />
        }
    </I18Context.Consumer>
);

export { withI18 };