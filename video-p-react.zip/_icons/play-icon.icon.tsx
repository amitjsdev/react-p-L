import React from 'react';

export function PlayIcon() {
    return (
        <div className="PlayIcon">
            <svg
                height="100px"
                width="100px"
                fill="white"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 64 64"
                x="0px"
                y="0px">
                <g data-name="Layer 10">
                    <path d="M54.17,48.82,27.63,32,54.17,15.18a1.52,1.52,0,0,0,.28-2.31h0C36.8-7.88,2.5,4.74,2.5,32s34.4,39.9,52,19.06a1.57,1.57,0,0,0,.35-1.12A1.54,1.54,0,0,0,54.17,48.82ZM29.27,11.17a4.23,4.23,0,0,1,0,8.46A4.23,4.23,0,0,1,29.27,11.17Z" />
                    <path d="M40.89,32a4.23,4.23,0,0,0,8.46,0A4.23,4.23,0,0,0,40.89,32Z" />
                    <path d="M57.27,27.77a4.23,4.23,0,0,0,0,8.46A4.23,4.23,0,0,0,57.27,27.77Z" />
                </g>
            </svg>
        </div>
    );
}