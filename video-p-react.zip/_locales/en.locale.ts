export const en = {
    // bottom navbar
    'home': 'Home',
    'courses': 'Courses',
    'profile': 'Profile',
    // homepage
    'welcome back': 'Welcome back',
    'your other courses': 'Your other courses',
    'resume': 'Resume',
    // other
    'level': 'Level',
    'listen': 'Listen',
    'learn': 'Learn',
    'play': 'Play',
    'completed': 'Completed',
    'milestone unlocked': 'Milestone Unlocked',
    'continue': 'Continue',
    'translation': 'Translation',
    'this feature is only available in the mobile app!': 'This feature is only available in the mobile app!',
    'good job': 'Good Job!',
    'wait, i want to do this again.': 'Wait, I want to do this again.',
}