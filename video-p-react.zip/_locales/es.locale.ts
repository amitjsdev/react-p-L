export const es = {
    // bottom navbar
    'home': 'Casa',
    'courses': 'Cursos',
    'profile': 'Perfil',
    // homepage
    'welcome back': 'Dar una buena acogida',
    'resume': 'Reanudar',
    'your other courses': 'Tus otros cursos',
    // other
    'level': 'Level',
    'listen': 'Listen',
    'learn': 'Learn',
    'play': 'Play',
    'completed': 'Completed',
    'milestone locked': 'Milestone Locked',
    'continue': 'Continue',
    'translation': 'Translation',
    'this feature is only available in the mobile app!': 'This feature is only available in the mobile app!',
    'good job': 'Good Job!',
    'wait, i want to do this again.': 'Wait, I want to do this again.',
}