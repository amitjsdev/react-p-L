export * from './es.locale';
export * from './en.locale';