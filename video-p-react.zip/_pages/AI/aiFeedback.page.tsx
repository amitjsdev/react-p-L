import React, { useEffect, useState } from 'react'
import { useSelector } from 'react-redux'
import { useParams } from 'react-router-dom'
import { useToasts } from 'react-toast-notifications'
import { CDN_URL } from '../../constant'
import { State } from '../../store/reducers'
import { Spinner, TopNavigationBar } from '../../_components'
import { MainService } from '../../_services/main.service'
import "./aiFeedback.scss"
export const AI_FEEDBACK_ROUTE = "/ai-feedback/:uuid"

const main = new MainService();
interface AiRating {
    comment: string;
    created_at: Date;
    id: number
    interviewVideoId: number
    reviewJSON: {}
    rawJSON: {}
    reviewType: number
    reviewerEmail: string
    reviewerName: string
    updated_at: Date
    userId: string
}
const AiFeedbackPage = () => {
    const { addToast } = useToasts();
    const [attempt, setAttempt] = useState<any>(null);
    const [isLoading, setIsLoading] = useState(true);

    const params = useParams() as { uuid: string };
    const uuid = params.uuid;

    // Load the review first
    useEffect(() => {
        setIsLoading(true);
        main.getPrevAttemptsByuuid(uuid)
            .then(res => {
                if (res.attempts && res.attempts.length > 0) {
                    setAttempt(res.attempts[0]);
                }
                setIsLoading(false);
            })
            .catch((err) => {
                setIsLoading(false);
                addToast('Could find Your attempt', { appearance: 'error', autoDismiss: true })
            });
    }, [uuid]);

    if (isLoading) {
        return <div className="text-center mt-5"><Spinner color="red" larger /></div>;
    }

    const aiRating = attempt.ai_rating;
    const rawJSON = aiRating.rawJSON;
    const realRawJSON = JSON.parse(aiRating.comment);
    const reviewJSON = aiRating.reviewJSON;

    console.log({ realRawJSON })

    const getAiRatingMedal = (reviewAverage = 1, attempt = null) => {

        if (reviewAverage > 4) {
            return (
                <img src="/_assets/badge_icons/gold.png" alt="" width="48px" className="m-auto" />
            );
        }

        if (reviewAverage > 3) {
            return (
                <img src="/_assets/badge_icons/silver.png" alt="" width="48px" className="m-auto" />
            );
        }

        if (reviewAverage > 2) {
            return (
                <img src="/_assets/badge_icons/bronze.png" alt="" width="48px" className="m-auto" />
            );
        }

        return (
            <img src="/_assets/badge_icons/basic.png" alt="" width="48px" className="m-auto" />
        );
    }
    const getAiRatingMedalName = (reviewAverage = 1, attempt = null) => {

        if (reviewAverage > 4) {
            return "GOLD";
        }

        if (reviewAverage > 3) {
            return "SILVER";
        }

        if (reviewAverage > 2) {
            return "BRONZE";
        }

        return "IRON";
    }

    const getSpeedImage = (rating = 1) => {
        switch (rating) {
            case 5:
            case 4:
                return <img src="/_assets/_aifeedback/speed-icon-green.svg" alt={rating + ""} width="72px" />;
            case 3:
            case 2:
                return <img src="/_assets/_aifeedback/speed-icon-yellow.svg" alt={rating + ""} width="72px" />;
            default:
                return <img src="/_assets/_aifeedback/speed-icon-red.svg" alt={rating + ""} width="72px" />;
                break;
        }
    }


    return (
        <div className="AiFeedbackPage">
            <TopNavigationBar />
            <div style={{ marginTop: '60px' }}></div>
            <div className="container-fluid" style={{ paddingTop: "3rem" }} >
                <div className="row" style={{ height: 'auto' }}>
                    {/* sidebar */}
                    <div className="col-md-4">
                        <div className="sidebar" style={{ marginLeft: "2rem" }}>
                            <div className="d-flex align-items-center flex-column">
                                {/* <h5 className="mb-auto p-2 bd-highlight">{attempt.lessonNo}.</h5> */}
                                {/* <h4 className="mb-auto p-2 bd-highlight w-75">{attempt.lessonName}</h4> */}
                                <div className="mb-auto pt-5 mt-3 bd-highlight font-bold">
                                    <video height="200" width="250" controls src={CDN_URL+'/uploads/' + attempt.filePath}></video>
                                </div>
                                <h4 className="mb-auto pt-5 mt-2  bd-highlight">Overall Rating</h4>
                                <h1 className="mb-auto pt-2 mt-3" style={{ fontSize: '3rem' }}>{getAiRatingMedal(attempt.ai_rating_avg)}</h1>
                                <h1 className="mb-auto pt-2 pb-5 mt-3" style={{ fontSize: '1.5rem', fontWeight: "bold" }}>{getAiRatingMedalName(attempt.ai_rating_avg)}</h1>
                            </div>
                        </div>
                    </div>
                    {/* main content */}
                    <div className="col-md-8">
                        <div className="d-flex align-items-center flex-column">
                            {!realRawJSON ? <div className="text-center font-bold">AI Review Pending</div>
                                :
                                <>
                                    {/* nlp */}
                                    {
                                        [
                                            ...Object.values(realRawJSON.nlp),
                                            ...Object.values(realRawJSON.cv),
                                        ].filter((r: any) => r.headerText).map((v: any) => (
                                            <div className="ai-rating-card-holder mb-auto pb-5 mb-3 bd-highlight">
                                                {/* lighting */}
                                                <div className="ai-rating-card">
                                                    <div className="card-illustration">
                                                        <div className={"count-holder rating-" + (v.parameterScore)} style={{
                                                            borderColor: v.iconBorderColor
                                                        }}>
                                                            <div className="count">{v.parameterScore}</div>
                                                        </div>
                                                    </div>
                                                    <div className="card-content">
                                                        <h3 className="card-title">{v.headerText}</h3>
                                                        <div className="description-1">{v.bodyText}</div>
                                                        <div className="pt-2 font-bold font-italic">{v.footerText}</div>
                                                    </div>
                                                </div>
                                            </div>
                                        ))
                                    }
                                </>
                            }
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default AiFeedbackPage
