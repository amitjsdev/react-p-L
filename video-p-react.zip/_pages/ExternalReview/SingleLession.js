import React, { useEffect, useState } from 'react'
import RatingComponent from '../../_components/RatingComponent';
import { Spinner } from '../../_components';
import HelpText from '../../_components/HelpText';
import { Col, Container, Form, Row } from 'react-bootstrap';
import { MainService } from '../../_services/main.service';
import Button from "../../_components/button.component"
import { useToasts } from 'react-toast-notifications';
import Mp3 from '../../_components/Mp3Record';
import VideoReview from '../../_components/VideoReview';
import Mp3Player from '../../_components/Mp3Player';
export const EXTERNAL_REVIEW_ROUTE = '/interview/external-review/:videos';
const main = new MainService();
const SingleLession = ({ setattempts,setHaveCheckedForMentor,setReload,lession, reviewParameters, isActive, setEmail, setName, name, email, isMentor, user, setReviewed,getPrevAttemptsUuid,getPrevAttemptsForMentor }) => {
    const { addToast } = useToasts();
    const lessionId = lession.id;
    const [oldReview, setOldReview] = useState(null);

    const [comment, setComment] = useState('')
    const [audios, setAudio] = useState()
    const [videosReviews, setVideosReviews] = useState()
    const [isAlreadyReviewed, setIsAlreadyReviewed] = useState(false)
    const [validated, setValidated] = useState(false);
    const [rating, setrating] = useState(null)
    const [loading, setloading] = useState(false)
    const [isMultFormError, setMultFormError] = useState('');

    const setOldData =(old) => {
        if (old) {
            setOldReview(old);
            setComment(old.comment)
            setIsAlreadyReviewed(!!old)
            setrating(old.reviewJSON)
        }
    }
    useEffect(() => {
        let old = null;
        if (email && lession.external_rating && lession.external_rating.length > 0) {
            old = lession.external_rating.find((item) => item.reviewerEmail == email);
        }
        setOldData(old)
    }, [lession])

    const handleRating = (reviewParameter, r, reviewParametersExternal) => {
        if (reviewParametersExternal && reviewParametersExternal.length > 0) {
            let ob = {};
            reviewParametersExternal.map((rr) => {
                ob = { ...ob, [rr.reviewParameter]: 0 }
            })

            if (rating) {
                ob = { ...ob, ...rating };
            }
            ob = {
                ...ob,
                [reviewParameter]: r
            };
            setrating(ob)

        }
    }
    const handleSubmit = (event) => {
        event.preventDefault()
        if (!name || !email) {
            setMultFormError('Name and Email is required');
            setValidated(false)
            return;
        }
        else if (!rating && !videosReviews && !audios) {
            setMultFormError('Either give video or audio or give Star rating');
            return;
        } else {
            let ratingPost = rating;
            if (!ratingPost) {
                let ob = {};
                reviewParameters.external.map((rr) => {
                    ob = { ...ob, [rr.reviewParameter]: 0 }
                })
                ratingPost = ob;
            }
            setMultFormError('');


            const form = event.currentTarget;
            if (form.checkValidity() === false) {
                event.preventDefault();
                event.stopPropagation();
            }
            event.preventDefault();
            if (form.checkValidity() === true) {
                const payload = {
                    review: ratingPost,
                    comment: comment,
                    userId: lession.userId,
                    reviewerName: name,
                    reviewerEmail: email
                }
                const file = audios;
                const videofile = videosReviews;
                setloading(true)
                setValidated(true)
                const response = isMentor ?
                    main.saveMentorReview(lession.id, payload, file, videofile, user.token)
                    :
                    main.saveExternalReview(lession.id, payload, file, videofile);
                response.then(response => {

                    console.log(response);
                    addToast(response.message, { appearance: 'success', autoDismiss: true })
                    localStorage.setItem('reviewed-attempt-' + lession.id, "true");
                    setIsAlreadyReviewed(true);
                    setloading(false)
                    setValidated(false)
                    setReviewed(lession.id)
                    setOldData(response.review) 
                     if(isMentor){
                        getPrevAttemptsForMentor()
                    }else{
                        getPrevAttemptsUuid()
                    }
                    // setattempts([])
                    // setHaveCheckedForMentor(false)
                    // setReload(true)
                    setAudio('')
                })
                    .catch((err) => {
                        setMultFormError('Oops!! something went wrong ')
                        setloading(false)
                        setValidated(false)
                        console.log('error is', err)
                    })
            }

        }
    };
    if (!isActive) return null;

    return (
        <div className="main-content" style={{ height: 'auto', marginBottom: 20 }}>
            <div className="row" key={lession.id}>


                {/* {isAlreadyReviewed && <div className="col-md-12 text-center pt-2"><div className="text-info pt-5 text-center">
                    You have already shared review for this one!
                </div></div>} */}

                <div className='col-md-12 text-center pt-2 ' >
                    <VideoReview
                        canRecord={true} id={oldReview ? oldReview.id :null} key={lessionId} setVideo={setVideosReviews} video={videosReviews} videoDb={oldReview ? oldReview.video : null} />
                </div>

                <div className="col-md-12 audioReview">
                    {!!oldReview && <Row ><Mp3Player url={oldReview.audio} /></Row>}
                    <Row ><Mp3 key={lessionId} setAudio={(a) => setAudio(a)} audio={audios} /></Row>
                    {reviewParameters ? reviewParameters.external.map((review, index) => {
                        const { id, reviewParameter, help_text } = review;


                        return (
                            <div key={`${lessionId}_${id}`} className="d-flex flex-row justify-content-between">
                                <div>
                                    <HelpText placement="top-start" title={help_text}>
                                        <span>{reviewParameter}</span>
                                    </HelpText>
                                </div>
                                <div className="px-5 bd-highlight">
                                    <RatingComponent
                                        id={index}
                                        name={"rating" + index}
                                        value={rating ? rating[reviewParameter] : ''}
                                        setRating={(r) => {
                                            handleRating(reviewParameter, r, reviewParameters.external)

                                        }} />
                                </div>
                            </div>
                        )
                    }) : null}

                </div>
                <Container>
                    <div className="col-md-12">
                        <Form noValidate validated={validated} onSubmit={handleSubmit}>
                            <Form.Group>
                                <div className="text-left">
                                    <Form.Label className="text-mutated">Other comments</Form.Label>
                                </div>
                                <Form.Control type="text" value={comment} onChange={(e) => setComment(e.target.value)} style={{ borderRadius: '0' }} as="textarea" rows={1} />

                                <Form.Control.Feedback type="invalid">
                                    Other comment is Required.
                                </Form.Control.Feedback>
                                <Row className="my-1">
                                    <Col md={6}>
                                        <div className="text-left">
                                            <Form.Label className="text-mutated">Your name</Form.Label>
                                        </div>
                                        <Form.Control readOnly={isMentor} style={{ borderRadius: '0' }} onChange={(e) => setName(e.target.value)} value={name} type="text" required />
                                        <Form.Control.Feedback type="invalid">
                                            Name is Required.
                                        </Form.Control.Feedback>
                                    </Col>

                                    <Col md={6}>
                                        <div className="text-left">
                                            <Form.Label className="text-mutated">Your email</Form.Label>
                                        </div>
                                        <Form.Control readOnly={isMentor} style={{ borderRadius: '0' }} onChange={(e) => setEmail(e.target.value)} value={email} type="email" required />
                                        <Form.Control.Feedback type="invalid">
                                            Email is Required.
                                        </Form.Control.Feedback>
                                    </Col>
                                </Row>
                            </Form.Group>

                            <div className="text-center">
                                <div style={{ color: 'red', margin: '10px' }}>
                                    {isMultFormError ? isMultFormError : ''}
                                </div>
                                {loading ? <div className="text-center mt-5"><Spinner color="red" larger /></div> : null}
                                <Button color="primary" text="Submit" />
                            </div>
                        </Form>
                    </div>
                </Container>
            </div>
        </div>
    )
}
export default SingleLession;