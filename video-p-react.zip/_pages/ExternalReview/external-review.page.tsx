import React, { useEffect, useState } from 'react'
import { Spinner, TopNavigationBar } from '../../_components';
import { ReactComponent as ProfileLogo } from "./profile_white.svg"
import "./externalReview.scss"
import RatingComponent from '../../_components/RatingComponent';
import HelpText from '../../_components/HelpText';
import { Col, Container, Form, Row } from 'react-bootstrap';
import { MainService } from '../../_services/main.service';
import getFormatedDate from '../../_config/getFormatedDate';
import Button from "../../_components/button.component"
import { useParams } from 'react-router-dom';
import { useToasts } from 'react-toast-notifications';
import { Checkbox } from '@material-ui/core';
import TextField from '@material-ui/core/TextField';
import Autocomplete from '@material-ui/lab/Autocomplete';
import Mp3 from '../../_components/Mp3Record';
import VideoReview from '../../_components/VideoReview';
import { CDN_URL } from '../../constant';
export const EXTERNAL_REVIEW_ROUTE = '/interview/external-review/:videos';

const main = new MainService();

const ExternalReviewPage = () => {
    const { addToast } = useToasts();
    const [comment, setComment] = useState<any>({})
    const [audios, setAudio] = useState<any>({})
    const [videosReviews, setVideosReviews] = useState<any>({})
    const [validated, setValidated] = useState(false);
    const [attempts, setattempts] = useState<any>([])
    const [reviewParameters, setreviewParameters] = useState<any>()
    const [rating, setrating] = useState<any>({})
    const [name, setName] = useState<string>();
    const [email, setEmail] = useState<string>();
    const [videoId, setVideoId] = useState<number>(0);
    const [showError, setshowError] = useState<boolean>(false)
    const [showErrorReviews, setShowErrorReview] = useState<boolean>(false)
    const [selected, setSelected] = useState<boolean>(false)
    const [selectedIndex, setSelectedIndex] = useState<number>(0)
    const [currentSelectedAttempt, setcurrentSelectedAttempt] = useState<string>()
    const [lesson, setLesson] = useState<string>()
    const [lessonNo, setLessonNo] = useState<number>()
    const [loading, setloading] = useState<boolean>(false)
    const [isAlreadyReviewed, setIsAlreadyReviewed] = useState(false);

    const [isMentor, setIsMentor] = useState(false);
    const [haveCheckedForMentor, setHaveCheckedForMentor] = useState(false);

    const [showPending, setShowPending] = useState(true);
    const [showReviewed, setShowReviewed] = useState(false);

    const params = useParams<any>();

    const user = JSON.parse(localStorage.getItem('user') || '{}')
    const [correctnessError, setcorrectnessError] = useState(false)
    const [correctnessVal, setcorrectnessVal] = useState(false)
    const [isMultFormError, setMultFormError] = useState('')

    // check for mentor


    useEffect(() => {
        if (window.location.hostname !== "app.taplingua.com" && user && user.token) {
            setloading(true)
            main.getMentorCohorts(user.token)
                .then(({ cohorts: c }) => {
                    if (Array.isArray(c) && c.length > 0) {
                        setIsMentor(true);
                    }
                    setHaveCheckedForMentor(true);
                })
                .catch(err => {
                    console.log({ err });
                    setHaveCheckedForMentor(true);
                })
                .finally(() => {
                    setloading(false);
                });
        } else {
            setHaveCheckedForMentor(true);
        }
    }, [user.token])

    useEffect(() => {
        if (haveCheckedForMentor) {
            if (isMentor) {
                getPrevAttemptsForMentor();
                setName(user.firstName);
                setEmail(user.email);
            } else {
                getPrevAttemptsUuid()
            }
            getSelfReviewParameters()
        }
    }, [haveCheckedForMentor]);





    useEffect(() => {
        setIsAlreadyReviewed(localStorage.getItem('reviewed-attempt-' + videoId) ? true : false);

    }, [videoId]);

    // get the parameters for review screen
    const getSelfReviewParameters = () => {
        setloading(true)
        main.getSelfReviewParameters().then(response => {
            setreviewParameters(response?.parameters)
            setloading(false)
        })
            .catch((err) => {
                console.log({ err })
            })
    }
    const getPrevAttemptsUuid = () => {
        setloading(true)
        main.getPrevAttemptsByuuid(params.videos)
            .then(res => {
                setattempts(res.attempts);
                if (Array.isArray(res.attempts) && res.attempts.length > 0) {
                    setVideoId(res.attempts[0]?.id)
                    if (!rating[res.attempts[0]?.id]) {
                        setrating({ ...rating, [res.attempts[0]?.id]: {} })
                    }
                }
                setloading(false)
            })
            .catch((err) => {
                setloading(false);
                addToast('Could find Your attempt', { appearance: 'error', autoDismiss: true })
            });
    }
    const getPrevAttemptsForMentor = () => {
        setloading(true)
        main.getPrevAttemptsByUuidForMentor(params.videos, user.token)
            .then(res => {
                setattempts(res.attempts);
                if (Array.isArray(res.attempts) && res.attempts.length > 0) {
                    setVideoId(res.attempts[0]?.id)
                    if (!rating[res.attempts[0]?.id]) {
                        setrating({ ...rating, [res.attempts[0]?.id]: {} })
                    }

                }
                setloading(false)
            })
            .catch((err) => {
                setloading(false);
                addToast('Could find Your attempt', { appearance: 'error', autoDismiss: true })
            });
    }
    const handleSubmit = (event: any) => {
        event.preventDefault()

        if (selectedIndex === 0) {
            setVideoId(attempts[0]?.id)
            setshowError(false)
        }
        let anyError = false;
        if (rating && Object.keys(rating).length > 0) {
            Object.keys(rating).forEach(element => {
                console.log({ element });
                let ratingPost = rating[element];
                if (ratingPost && Object.keys(ratingPost).length === 0) {
                    setMultFormError(element);
                    anyError = true;
                }
                if (ratingPost && Object.keys(ratingPost).length > 0) {
                    const anyEmptyVar = (Object.values(ratingPost)).filter(st => !st)
                    if (anyEmptyVar && anyEmptyVar.length > 0) {
                        setMultFormError(element);
                        anyError = true;

                    }
                }
                if (anyError) {
                    return;

                } else {
                    setMultFormError('');
                    if (attempts && attempts[0] && attempts[0].sagFlag && !correctnessVal) {
                        setcorrectnessError(true);
                    }
                    if (correctnessVal) {
                        ratingPost = { ...ratingPost, 'Correctness of Answer': correctnessVal }
                    }

                    const form = event.currentTarget;
                    if (Object.keys(ratingPost).length <= 0) setShowErrorReview(true)
                    if (form.checkValidity() === false) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    event.preventDefault();
                    if (!correctnessError && form.checkValidity() === true) {
                        const payload = {
                            review: ratingPost,
                            comment: comment[element],
                            userId: attempts[selectedIndex].userId,
                            reviewerName: name,
                            reviewerEmail: email
                        }
                        const file =audios && audios[element] ? audios[element]: null;
                        const videofile =videosReviews && videosReviews[element] ? videosReviews[element]: null;
                        console.log({element, videofile});
                        console.log('saveee');
                        
                        setloading(true)
                        const response = isMentor ? main.saveMentorReview(parseInt(element), payload,file,videofile, user.token) : main.saveExternalReview(videoId, payload, file,videofile);
                        response.then(response => {

                            addToast(response.message, { appearance: 'success', autoDismiss: true })
                            setshowError(false)
                            setShowErrorReview(false)
                            // setComment("")
                            setEmail("")
                            // setVideoId(0)
                            setName("")
                            setValidated(true);
                            localStorage.setItem('reviewed-attempt-' + videoId, "true");
                            setIsAlreadyReviewed(true);
                        })
                            .catch((err) => {
                                setshowError(true)
                                console.log('error is', err)
                            })
                    }
                    setloading(false)
                    setValidated(true);
                }
            });
        }

    };
    const selectVideo = (id: number, index: number, lesson: any) => {
        if (!rating[id]) {
            setrating({ ...rating, [id]: {} })
        }
        setSelectedIndex(index)
        setSelected(!selected)
        setVideoId(id);
        setcurrentSelectedAttempt(lesson.filePath)
        setLesson(lesson.lessonName)
        setLessonNo(lesson.lessonNo)
    }

    const filteredAttempts = attempts.filter((a: any) => {
        if (a.my_rating && showReviewed) {
            return true;
        }
        if (!a.my_rating && showPending) {
            return true;
        }
        return false;
    })

    const onchangeCorrectness = (e: any, v: any) => {
        setcorrectnessVal(v.value)
        setcorrectnessError(false)
    }

    const setReviewEmptyObject = () => {
        if (reviewParameters && reviewParameters.length > 0 && videoId) {
            let ob = {};
            reviewParameters.map((rr: any) => {
                ob = { ...ob, [rr.reviewParameter]: 0 }
            })
            setrating({
                ...rating,
                [videoId]: {
                    ...rating[videoId],
                    ...ob
                }
            })
        }
    }

    const handleRating = (reviewParameter: string, r: number, reviewParametersExternal: any) => {
        let newRating = rating
        if (newRating && videoId && newRating[videoId] && Object.keys(newRating[videoId]).length === 0) {
            if (reviewParametersExternal && reviewParametersExternal.length > 0) {
                let ob = {};
                reviewParametersExternal.map((rr: any) => {
                    ob = { ...ob, [rr.reviewParameter]: 0 }
                })
                setrating({
                    ...rating,
                    [videoId]: {
                        ...ob,
                        [reviewParameter]: r
                    }
                })

            }
        } else {
            newRating = {
                ...newRating,
                [videoId]: {
                    ...rating[videoId],
                    [reviewParameter]: r
                }
            }
            setrating(newRating)

        }


    }

    return (
        <>
            <TopNavigationBar />
            <div style={{ marginTop: '60px' }}></div>
            <div className="main-external-page">
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-12 pt-4 text-center">
                            <span onClick={e => {
                                setShowPending(!showPending);
                            }} style={{ cursor: "pointer" }}>
                                <Checkbox checked={showPending} />
                                Pending Videos</span>
                            <span onClick={e => {
                                setShowReviewed(!showReviewed);
                            }} style={{ cursor: "pointer" }}>
                                <Checkbox checked={showReviewed} />
                                Reviewed Videos</span>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-md-3">
                            <div className="row">
                                <div className="col-12">
                                    {loading ? <div className="text-center mt-5"><Spinner color="red" larger /></div> :
                                        <div className="profile">
                                            <div className="d-flex justify-content-center pt-3"><ProfileLogo /></div>
                                            <div className="d-flex justify-content-center" style={{ color: '#FFFFFFBC', wordBreak: 'break-all', padding: "1rem", textAlign: "center" }}>{filteredAttempts ? filteredAttempts[0]?.userId : null}</div>
                                        </div>
                                    }

                                </div>
                                <div className="col-12">
                                    {filteredAttempts.length > 0 ? filteredAttempts.map((lesson: any, index: number) => (
                                        <div className={selectedIndex === index ? "question-box-active mt-2" : "question-box mt-2"} key={index}>
                                            <div className="font-bold p-4 cursor-pointer" onClick={() => selectVideo(lesson.id, index, lesson)}>{lesson.lessonName.substr(0, 25)} ...</div>
                                            <div className="text-secondary p-4">{getFormatedDate(lesson.created_at)}</div>
                                        </div>
                                    ))
                                        : (
                                            loading ? null : (
                                                <div className="pt-5">
                                                    No videos
                                                </div>
                                            )
                                        )}
                                </div>
                                {showError ?
                                    <div className="text-center">
                                        <span className="text-danger pl-3">Please select a lesson</span>
                                    </div>
                                    : null}
                            </div>
                        </div>

                        <div className="col-md-7">
                            {videoId && (
                                <div className="main-content my-3" style={{height:'auto', marginBottom:20}}>
                                    {
                                        filteredAttempts[selectedIndex] ? (
                                            loading ? <div className="text-center pt-5"><Spinner color="red" larger /> </div> :
                                                <div className="row" key={videoId}>
                                                    <div className="col-md-12 text-center pt-2 " >Question {lessonNo ? lessonNo : filteredAttempts[0]?.lessonNo}. {lesson ? lesson : filteredAttempts[0]?.lessonName}</div>
                                                    <div className="col-md-12 text-center pt-2">
                                                        <div className="col-md-12 d-flex justify-content-center py-2">
                                                            <video controls height="100" width="300" src={!currentSelectedAttempt ? CDN_URL+'/uploads/' + filteredAttempts[0]?.filePath : CDN_URL+'/uploads/' + currentSelectedAttempt}></video>
                                                        </div>
                                                    </div>
                                                    {
                                                        isAlreadyReviewed || (filteredAttempts[selectedIndex] && filteredAttempts[selectedIndex].my_rating) ? (
                                                            (filteredAttempts[selectedIndex] && attempts[selectedIndex].my_rating) ? (
                                                                <div className="col-md-12 my-5 mx-4">
                                                                    <div className="text-info pt-5 text-center">You have already shared review for this one!</div>
                                                                    <CorrectNess attempts={attempts} onchange={onchangeCorrectness} error={correctnessError} />
                                                                    {
                                                                        filteredAttempts[selectedIndex].my_rating && filteredAttempts[selectedIndex].my_rating.reviewJSONArray && filteredAttempts[selectedIndex].my_rating.reviewJSONArray.length > 0 ? 
                                                                        filteredAttempts[selectedIndex].my_rating.reviewJSONArray.map((parameter: any, index: number) => {
                                                                            const { parameterName, parameterValue } = parameter;


                                                                            return (
                                                                                <div key={parameterName} className="d-flex flex-row justify-content-between">
                                                                                    <div>{parameterName}</div>
                                                                                    {/* <HelpText placement="top-start" title={selfHelp && selfHelp[parameter.parameterName] ? selfHelp[parameter.parameterName] : ''}>
                                                                                    <span>{parameterName}</span>
                                                                                </HelpText> */}
                                                                                    <div className="px-5 bd-highlight">
                                                                                        <RatingComponent
                                                                                            id={index}
                                                                                            name={"rating" + index}
                                                                                            value={parameterValue}
                                                                                            setRating={(r: number) => {
                                                                                            }} />
                                                                                    </div>
                                                                                </div>
                                                                            )
                                                                        }): null
                                                                    }
                                                                </div>
                                                            ) : (
                                                                <div className="col-md-12">
                                                                    <div className="text-info pt-5 text-center">You have already shared review for this one!</div>
                                                                </div>
                                                            )
                                                        ) : (
                                                            <> 
                                                            <div className='col-md-12 text-center pt-2 ' >
                                                                <VideoReview 
                                                                canRecord={true} key={videoId} setVideo={(a: any) => setVideosReviews({...videosReviews, [videoId]: a })} 
                                                                video={null} />
                                                                </div>
                                                                
                                                                <div className="col-md-12 audioReview">
                                                               <Row ><Mp3 key={videoId} setAudio={(a: any) => setAudio({...audios, [videoId]: a })} audio={audios[videoId]}/></Row>
                                                                    <CorrectNess attempts={attempts} onchange={onchangeCorrectness} error={correctnessError} />
                                                                    {reviewParameters ? reviewParameters.external.map((review: any, index: number) => {
                                                                        const { id, reviewParameter, help_text } = review;


                                                                        return (
                                                                            <div key={`${videoId}_${id}`} className="d-flex flex-row justify-content-between">
                                                                                <div>
                                                                                    <HelpText placement="top-start" title={help_text}>
                                                                                        <span>{reviewParameter}</span>
                                                                                    </HelpText>
                                                                                </div>
                                                                                <div className="px-5 bd-highlight">
                                                                                    <RatingComponent
                                                                                        id={index}
                                                                                        name={"rating" + index}
                                                                                        value={rating && rating[videoId] ? rating[videoId][reviewParameter] : ''}
                                                                                        setRating={(r: number) => {
                                                                                            handleRating(reviewParameter, r, reviewParameters.external)

                                                                                        }} />
                                                                                </div>
                                                                            </div>
                                                                        )
                                                                    }) : null}
                                                                    {showErrorReviews ?
                                                                        <div className="text-center">
                                                                            <span className="text-danger text-center">All Reviews are required</span>
                                                                        </div>
                                                                        : null}
                                                                </div>
                                                                <Container>
                                                                    <div className="col-md-12">
                                                                    {loading ? <div className="text-center mt-5"><Spinner color="red" larger /></div>: null}
                                                                        <Form noValidate validated={validated} onSubmit={handleSubmit}>
                                                                            <Form.Group>
                                                                                <div className="text-left">
                                                                                    <Form.Label className="text-mutated">Other comments</Form.Label>
                                                                                </div>
                                                                                <Form.Control type="text" value={comment[videoId]} onChange={(e) => setComment({ [videoId]: e.target.value })}  style={{ borderRadius: '0' }} as="textarea" rows={3} />
                                                                               
                                                                                <Form.Control.Feedback type="invalid">
                                                                                    Other comment is Required.
                                                                                </Form.Control.Feedback>
                                                                                <Row className="my-5">
                                                                                    <Col md={6}>
                                                                                        <div className="text-left">
                                                                                            <Form.Label className="text-mutated">Your name</Form.Label>
                                                                                        </div>
                                                                                        <Form.Control readOnly={isMentor} style={{ borderRadius: '0' }} onChange={(e) => setName(e.target.value)} value={name} type="text" required />
                                                                                        <Form.Control.Feedback type="invalid">
                                                                                            Name is Required.
                                                                                        </Form.Control.Feedback>
                                                                                    </Col>

                                                                                    <Col md={6}>
                                                                                        <div className="text-left">
                                                                                            <Form.Label className="text-mutated">Your email</Form.Label>
                                                                                        </div>
                                                                                        <Form.Control readOnly={isMentor} style={{ borderRadius: '0' }} onChange={(e) => setEmail(e.target.value)} value={email} type="email" required />
                                                                                        <Form.Control.Feedback type="invalid">
                                                                                            Email is Required.
                                                                                        </Form.Control.Feedback>
                                                                                    </Col>
                                                                                </Row>
                                                                            </Form.Group>

                                                                            <div className="text-center">
                                                                                <div style={{ color: 'red', margin: '10px' }}>
                                                                                    {isMultFormError ? 'Please give Rating for all parameter' : ''}
                                                                                </div>
                                                                                {/* <button type="submit" className="submit-button">
                                                        Submit
                                                    </button> */}
                                                                                <Button color="primary" text="Submit" />
                                                                            </div>
                                                                        </Form>
                                                                    </div>
                                                                </Container>
                                                            </>
                                                        )
                                                    }
                                                </div>
                                        ) : (
                                            loading ? (
                                                <div className="text-center pt-5"><Spinner color="red" larger /></div>
                                            ) : (
                                                <div className="text-center pt-5">Please select a video first!</div>
                                            )
                                        )
                                    }
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default ExternalReviewPage

const CorrectNess = (props: any) => {
    const options = Array.apply(null, Array(5)).map((val, i) => { return { title: (i + 1).toString(), value: i + 1 } })
    if (props.attempts && props.attempts[0] && props.attempts[0].sagFlag) {
        return (
            <>
                <div className="row" style={{ marginBottom: 30 }}>
                    <div className="col-md-5">
                        <b>Correctness of Answer</b><br />
                        <span style={{ fontSize: 15 }}>Please score between 1 and 5 to evaluate the technical correctness of the answer.</span>
                    </div>
                    <div className="col-md-6">
                        <Autocomplete
                            size="small"
                            onChange={props.onchange}
                            options={options}
                            getOptionLabel={(option) => option.title}
                            // style={{ width: 300 }}
                            renderInput={(params) => <TextField
                                {...params}
                                label="Correctness of Answer"
                                variant="outlined"
                            />}
                        />
                        {props.error && <div className="invalid-feedback" style={{ display: 'block' }}>Correctness of Answer is required</div>}
                    </div>
                </div>

            </>
        )
    } else {
        return null;
    }

}
