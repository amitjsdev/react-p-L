import React, { useEffect, useState } from 'react'
import { Spinner, TopNavigationBar } from '../../_components';
import { ReactComponent as ProfileLogo } from "./profile_white.svg"
import "./externalReview.scss"
import SingleLession from './SingleLession';
import { MainService } from '../../_services/main.service';
import getFormatedDate from '../../_config/getFormatedDate';
import { useParams } from 'react-router-dom';
import { useToasts } from 'react-toast-notifications';
import { CDN_URL } from '../../constant';
export const EXTERNAL_REVIEW_ROUTE = '/interview/external-review/:videos';

const main = new MainService();

const ExternalReviewPage = () => {
    const { addToast } = useToasts();
    const [selectedLession, setselectedLession] = useState()
    const [userId, setUserId] = useState('')
    let [attempts, setattempts] = useState([]);
    const [reviewParameters, setreviewParameters] = useState();
    const [rating, setrating] = useState({})
    const [name, setName] = useState();
    const [email, setEmail] = useState();
    const [loading, setloading] = useState(false)
    const [Reviewed, setReviewedIds] = useState([])

    const [isMentor, setIsMentor] = useState(false);
    const [reload, setReload] = useState(false);
const [selectedId,setSelectedId] = useState()
    const [haveCheckedForMentor, setHaveCheckedForMentor] = useState(false);
    const params = useParams();

    const user = JSON.parse(localStorage.getItem('user') || '{}')
    const setReviewed = (id) => {
        let d = Reviewed;
        d.push(id)
        setReviewedIds([...new Set(d)]);
    }

    useEffect(() => {
        if (window.location.hostname !== "app.taplingua.com" && user && user.token) {
            setloading(true)
            main.getMentorCohorts(user.token)
                .then(({ cohorts: c }) => {
                    if (Array.isArray(c) && c.length > 0) {
                        setIsMentor(true);
                    }
                    setHaveCheckedForMentor(true);
                })
                .catch(err => {
                    console.log({ err });
                    setHaveCheckedForMentor(true);
                })
                .finally(() => {
                    setloading(false);
                });
        } else {
            setHaveCheckedForMentor(true);
        }
    }, [user.token,reload])

    useEffect(() => {
        if (haveCheckedForMentor) {
            if (isMentor) {
                getPrevAttemptsForMentor();
                setName(user.firstName);
                setEmail(user.email);
            } else {
                getPrevAttemptsUuid()
            }
            getSelfReviewParameters()
        }
    }, [haveCheckedForMentor]);







    // get the parameters for review screen
    const getSelfReviewParameters = () => {
        setloading(true)
        main.getSelfReviewParameters().then(response => {
            setreviewParameters(response?.parameters)
            setloading(false)
        })
            .catch((err) => {
                console.log({ err })
            })
    }
    const getPrevAttemptsUuid = () => {
        setloading(true)
        main.getPrevAttemptsByuuid(params.videos)
            .then(res => {
                
                if (Array.isArray(res.attempts) && res.attempts.length > 0) {
                    setattempts(res.attempts.reverse());
                    if (!rating[res.attempts[0]?.id]) {
                        setrating({ ...rating, [res.attempts[0]?.id]: {} })
                    }
                }
                setloading(false)
            })
            .catch((err) => {
                setloading(false);
                addToast('Could find Your attempt', { appearance: 'error', autoDismiss: true })
            });
    }
    const getPrevAttemptsForMentor = () => {
        setloading(true)
        main.getPrevAttemptsByUuidForMentor(params.videos, user.token)
            .then(res => {
               
                if (Array.isArray(res.attempts) && res.attempts.length > 0) {
                    setattempts(res.attempts.reverse());
                    if (!rating[res.attempts[0]?.id]) {
                        setrating({ ...rating, [res.attempts[0]?.id]: {} })
                    }

                }
                setloading(false)
            })
            .catch((err) => {
                setloading(false);
                addToast('Could find Your attempt', { appearance: 'error', autoDismiss: true })
            });
    }

    useEffect(() => {
        if (attempts && attempts.length > 0) {
            setselectedLession(attempts[0]);
            setSelectedId(attempts[0].id)
            setUserId(attempts[0].userId);
            let reved = attempts.filter((item) => {
                if (user && user.email && item.external_rating && item.external_rating.length > 0) {
                    const oldReview = item.external_rating.find((dd) => dd.reviewerEmail === user.email);
                    return !!oldReview;
                } else {
                    return false;
                }
            });
            reved = reved && reved.length ? reved.map((item) => item.id) : [];
            setReviewedIds(reved)
        }
    }, [attempts.length])

    const selectVideo = (lession) => {
        if (!rating[lession.id]) {
            setrating({ ...rating, [lession.id]: {} })
        }
        setselectedLession(lession)
        setSelectedId(lession?.id)
    }

    const order = {};
    let indexForOrder = 0;
    attempts = attempts.sort((a, b) => a.lesson.id - b.lesson.id)
    attempts = attempts.map((a) => {
        if (!order[a.lesson.id]) {
            order[a.lesson.id] = indexForOrder + 1;
            indexForOrder++;
        }
        return { ...a, sn: order[a.lesson.id] }
    })

    return (
        <>
            <TopNavigationBar />
            <div style={{ marginTop: '60px' }}></div>
            {loading ? <div className="text-center mt-5"><Spinner color="red" larger /></div> : null}
            <div className="main-external-page">
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-3" style={{ height: '90vh', overflow: 'auto' }}>
                            <div className="row">
                                <div className="col-12">
                                    <div className="profile">
                                        <div>
                                            <ProfileLogo style={{ width: 20 }} />
                                        </div>
                                        <div>
                                            <span style={{ color: '#FFFFFFBC', wordBreak: 'break-all', padding: "1rem", textAlign: "center" }}>{userId}</span>
                                        </div>
                                    </div>
                                    <div className="video-header">
                                        {selectedLession ? <>
                                            <div className="col-md-12 text-center pt-2 " >Question {selectedLession.lessonName}</div>
                                            <div className="col-md-12 d-flex justify-content-center py-2">
                                                <video controls height="100" width="100%"
                                                    src={`${CDN_URL}/uploads/${selectedLession.filePath}`} />

                                            </div></> : null}
                                    </div>
                                </div>
                                <div className="col-12">
                                    <div className="iconDiv">
                                        <div class="ques-container">
                                            Review completed
                                            <input type="checkbox" checked={true} />
                                            <span class="ques-checkmark"></span>
                                        </div>
                                    </div>
                                 {user.email && attempts.length > 0
                    ? attempts.map((lesson, index) => {
                        let val = lesson?.external_rating.filter(
                          (item, i) => item?.reviewerEmail == user.email
                        );
                        return (
                          <div
                            className={
                              selectedLession &&
                              selectedLession.id === lesson.id
                                ? "question-box-active mt-1 qeusDiv"
                                : Reviewed.includes(lesson.id)
                                ? "question-box mt-1 qeusDiv"
                                : "question-box mt-1 qeusDiv"
                            }
                            key={lesson.id}
                          >
                            <div
                              className="cursor-pointer qusList"
                              onClick={() => selectVideo(lesson)}
                            >
                              <div>
                                <span title={lesson.lessonName}>
                                  {index + 1}.{lesson.lessonName.substr(0, 125)}
                                </span>
                              </div>
                              <div className="text-secondary">
                                {getFormatedDate(lesson.created_at)}
                              </div>
                            </div>
                            {lesson?.external_rating != null &&
                              !!val &&
                              Object.keys(val).length > 0 && (
                                <div class="ques-container">
                                  <input type="checkbox" checked={true} />
                                  <span class="ques-checkmark"></span>
                                </div>
                              )}
                          </div>
                        );
                      })
                    : null}
                                </div>

                            </div>
                        </div>

                        <div className="col-md-7" style={{ marginTop: 20 }}>
                             {haveCheckedForMentor && selectedLession && attempts.length > 0
                                 ? attempts.map((lesson) => (
                    <SingleLession
                      key={lesson.id}
                      isActive={selectedId === lesson.id}
                      lession={lesson}
                      reviewParameters={reviewParameters}
                      setEmail={setEmail}
                      setName={setName}
                      name={user.firstName}
                      email={user.email}
                      isMentor={isMentor}
                      user={user}
                      setReviewed={setReviewed}
                      getPrevAttemptsForMentor={getPrevAttemptsForMentor}
                      getPrevAttemptsUuid={getPrevAttemptsUuid}
                      setReload={setReload}
                      setHaveCheckedForMentor={setHaveCheckedForMentor}
                      setattempts={setattempts}
                    />
                  ))
                : null}
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default ExternalReviewPage

