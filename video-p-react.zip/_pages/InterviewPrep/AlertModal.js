import React from "react";
// import "./AllCompleteAlert.scss";
const Alert = ({ children, close, closeText = "Ok", alertMsg,saveAttempt,nextQuestion }) => {

    

  return (
    <div className="SkipModal">
      <div className="modal-body">
        {alertMsg ? (
          <>
            <h5 className="text-center">
            Do you still want to Submit the Answer?
            </h5>
          </>
        ) : (
          children
        )}
        <div className="d-flex justify-center">
        <button
            className="continue-exam-button"
            style={{ padding: "0px 24px" }}
            onClick={() => {
                saveAttempt();
                close(false);
            }}
          >
            {`Yes`}
          </button>

          <button
            className="continue-exam-button"
            style={{ padding: "0px 24px" }}
            onClick={() => {
                nextQuestion('alert');
                close(false);
            }}
          >
            {`No`}
          </button>
        </div>
      </div>
    </div>
  );
};
export default Alert;
