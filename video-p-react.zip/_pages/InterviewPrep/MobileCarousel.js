import React, { useRef, useEffect, useState } from "react";
import { useToasts } from "react-toast-notifications";

import { ProgressBar, Carousel } from "react-bootstrap";

import "./mobilecarousel.css";
import { MainService } from "../../_services/main.service";

import { CDN_URL } from "../../constant";
import { useRouteMatch, Route } from "react-router-dom";

import speech from "./speech";
import axios from "axios";
import { mixPanel } from "../../_config/mixpanel.config";
import { baseUrl } from "../../_config/endpoints.config";
import { Spinner } from "../../_components/spinner.component";

const main = new MainService();
export const PRATICE_ROUTE = "/practice";
const s3Url = CDN_URL + "/uploads/";

function MobileCarousel({
  setLessonCount,
  lessonsCounts,
  setLessons,
  setSubmittedCount,
  vpiData,
  user,
  setIsSavingAttempt,
  setShowModal,
  module,
  lessons,
  setSelectedLessonIndex,
  isSavingAttempt,
  moduleName,
  isLoading,
  selectedLessonIndex,
}) {
  const videoRef = useRef(null);
 

  // get video link
  let videoLink = "";
  if (lessons && lessons[selectedLessonIndex]) {
    const selectedLesson = lessons[selectedLessonIndex];
    if (selectedLesson.video_type == "webm") {
      videoLink = `${CDN_URL}/interviewprep/${module.moduleNumber}/${module.moduleNumber}_${selectedLesson.routeno}_${selectedLesson.lesson_no}.webm`;
    } else {
      videoLink = `${CDN_URL}/interviewprep/${module.moduleNumber}/${module.moduleNumber}_${selectedLesson.routeno}_${selectedLesson.lesson_no}.mp4`;
    }
    // else{
    //   videoLink = selectedLesson.video_type;
    // }
  }

  const { addToast } = useToasts();

  const [counterVisible, setCounterVisible] = useState(false);
  const [counterCount, setCounterCount] = useState(3);

  const [progress, setProgress] = useState();

  const [previousAttempts, setPreviousAttempts] = useState([]);
  const [isLoadingPreviousAttempt, setIsLoadingPreviousAttempt] =
    useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const [isVideoLoading, setIsVideoLoading] = useState(false);

  const [moduleNo, setmoduleNo] = useState(module.moduleNumber);
  const [AddTipsModal, setAddTipsModal] = useState(false);
  // recording related
  const [stream, setstream] = useState();
  const [mediaRecorder, setmediaRecorder] = useState();
  const [isRecording, setisRecording] = useState();
  const [downloadLink, setdownloadLink] = useState(null);
  const [videoObj, setvideoObj] = useState();
  const [blobsRecorded, setblobsRecorded] = useState([]);

  const [alertMsg, setAlert] = useState(false);
  const [enableRecording, setEnableRecording] = useState(false);
  const [videoTimeCount, setVideoTimeCount] = useState("1");
  const [videoLimit, setVideoLimit] = useState(false);
  const [audioWord, setAudioWord] = useState("");
  const [isAudioWordError, setAudioWordError] = useState(false);
  const [stopError, setStopErrorMsg] = useState(false);
  const [showAnswer, setShowAnswer] = useState(true);
  const [closePopup,setClosePopup] = useState(false);
  const speechObj = speech();

  // change lesson only if not saving something
  const selectLesson = (index) => {
    if (!isSavingAttempt) {
      // reset recording
      resetCameraAndMedia().then(() => {
        // select lesson
        setSelectedLessonIndex(index);
      });
    }
  };
  const {
    params: { id },
  } = useRouteMatch();

  useEffect(() => {
    if (lessons && lessons.length > 0) {
      // if (id) {
      //   lessons.map((item, i) => {
      //     if (item.practiceQuestionId == id) {
      //       selectLesson(i);
      //     }
      //   })

      // } else {
      //   selectLesson(0)
      // }
      if (selectedLessonIndex) {
        selectLesson(selectedLessonIndex);
      } else {
        selectLesson(0);
      }
    }

    let cohortData = [];
    // user.cohort && user.cohort.length > 0 && user.cohort.map((item)=>{
    //     cohortData.push(item[0])
    // })
  }, [lessons, id]);

  const getAudioText = () => {
    setAudioWord("");
    setAudioWordError(false);
    speechObj.start();
    speechObj.onresult = (event) => {
      let interim_transcript = "";
      let final_transcript = audioWord;

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          final_transcript += event.results[i][0].transcript;
        } else {
          interim_transcript += event.results[i][0].transcript;
        }
      }
      setAudioWord(final_transcript ? final_transcript : interim_transcript);
    };
  };

  const loadPreviousAttempts = async (index) => {
    setIsLoadingPreviousAttempt(true);

    // get selected lesson
    const lessonIndex = index !== undefined ? index : selectedLessonIndex;

    if (!lessons || (!lessonIndex && lessonIndex !== 0)) return;

    const selectedLesson = lessons[lessonIndex];
    if (!selectedLesson) {
      return;
    }
    main
      .moduleRelatedPreviousAttempts(
        user.token,
        module.moduleNumber,
        selectedLesson.routeno,
        selectedLesson.lesson_no
      )
      .then((response) => {
        setPreviousAttempts(response.attempts);
        setIsLoadingPreviousAttempt(false);
      })
      .catch((err) => {
        setIsLoadingPreviousAttempt(false);
        addToast("Something went wrong, please refresh!", {
          appearance: "error",
          autoDismiss: true,
        });
        console.log({
          err,
        });
      });
  };

  const stopCamera = (discardFootage = false) => {
    setShowAnswer(true);

    const vid = document.getElementById("video");
    if (vid) {
      vid.pause();
      vid.src = "";
    }

    if (stream) {
      stream.getTracks().forEach(function (track) {
        track.stop();
      });
      setstream(null);
    }
  };

  const resetCameraAndMedia = () => {
    return new Promise((res, rej) => {
      stopCamera(true);
      clearRecording();
      return res(true);
    });
  };

  const clearRecording = () => {
    setblobsRecorded([]);
    setisRecording(false);
    setdownloadLink(null);
    setvideoObj(null);
    // startCamera()
  };

  // load previous attempts
  useEffect(() => {
    if (selectedLessonIndex || selectedLessonIndex === 0) {
      loadPreviousAttempts(selectedLessonIndex);
    }
    // reset previous data
    resetCameraAndMedia();
  }, [selectedLessonIndex]);

  // if counter count is zero, hide the counter and start recording
  useEffect(() => {
    if (counterCount === 0) {
      setCounterVisible(false);
      setCounterCount(3); // reset the count
      // start recording
      startRecording(null);
    }
  }, [counterCount]);

  if (!selectedLessonIndex && selectedLessonIndex !== 0) {
    return (
      <div className="content-holder">
        <div className="content-holder-content">
          <div className="content-heading">
            <div className="my-5 text-center ">
              Please select a lesson first!
            </div>
          </div>
        </div>
      </div>
    );
  }

  // get video link
  //   let videoLink = "";
  //   if (lessons && lessons[selectedLessonIndex]) {
  //     const selectedLesson = lessons[selectedLessonIndex];
  //   if(selectedLesson.video_type == 'webm'){
  //       videoLink = `${CDN_URL}/interviewprep/${module.moduleNumber}/${module.moduleNumber}_${selectedLesson.routeno}_${selectedLesson.lesson_no}.webm`;
  //     }else{
  //       videoLink = `${CDN_URL}/interviewprep/${module.moduleNumber}/${module.moduleNumber}_${selectedLesson.routeno}_${selectedLesson.lesson_no}.mp4`;
  //     }
  //     // else{
  //     //   videoLink = selectedLesson.video_type;
  //     // }
  //   }

  // handlers

  // camera related
  const startCamera = async () => {
    setShowAnswer(false);
    setVideoLimit(false);
    setblobsRecorded([]);
    setdownloadLink(null);
    setvideoObj(null);
    let stream = await navigator.mediaDevices.getUserMedia({
      video: true,
      audio: true,
    });
    var video = document.getElementById("video");
    video.srcObject = stream;
    video.volume = 0;
    if (videoRef.current) {
      videoRef.current.srcObject = stream;
      setstream(stream);
      video.srcObject = stream;
      video.volume = 0;
    }
    return;
  };

  const mediaRecorderDataAvailableListener = (e) => {
    setblobsRecorded([...blobsRecorded, e.data]);
  };

  const mediaRecorderStopEventHandler = () => {
    // create local object URL from the recorded video blobs
    let video_local = new Blob(blobsRecorded, {
      type: "video/webm",
    });
    setdownloadLink(video_local);
    setvideoObj(URL.createObjectURL(video_local));
  };

  // start recording
  const startRecording = async (e) => {
    getAudioText();
    // set MIME type of recording as video/mp4
    var mediaRecorder2 = new MediaRecorder(stream, {
      mimeType: "video/webm",
    });
    const recorded_blobs = [];
    // reset the blobs
    setblobsRecorded([]);
    // reset the download link
    setdownloadLink(null);
    setvideoObj(null);

    // event : new recorded video blob available
    mediaRecorder2.addEventListener("dataavailable", (e) => {
      recorded_blobs.push(e.data);
      // hacking in through to show the recorded time data, due to insufficient time
      const recordedTimeDiv = document.getElementById("recording-time");
      if (recordedTimeDiv) {
        let videoTime =
          (Math.floor(recorded_blobs.length / 60) + "").padStart(2, "0") +
          ":" +
          (Math.floor(recorded_blobs.length % 60) + "").padStart(2, "0");
        recordedTimeDiv.innerText =
          (Math.floor(recorded_blobs.length / 60) + "").padStart(2, "0") +
          ":" +
          (Math.floor(recorded_blobs.length % 60) + "").padStart(2, "0");
        let convertedVal = convert(videoTime);
        // console.log('parseFloat',convertedVal,videoTime)
        setVideoTimeCount(convertedVal);
      }

      setblobsRecorded(recorded_blobs);
    });
    // start recording with each recorded blob having 1 second video
    mediaRecorder2.start(1000);
    setmediaRecorder(mediaRecorder2);
    // set state to recording
    setisRecording(true);

    mixPanel.track("InterviewSimulatorRecordVideo", {
      userId: user.email ? user.email : user.userId,
      module,
      moduleName,
      lessonNo: lessons[selectedLessonIndex].lesson_no,
    });
  };

  const stopRecording = (e) => {
    // setShowAnswer(true);
    setStopErrorMsg(false);
    speechObj.stop();
    setIsVideoLoading(false);
    if (isRecording) {
      //this.mediaRecorder.stop();
      mediaRecorder.stop();
      setisRecording(false);
      setmediaRecorder(undefined);

      // stop all tracks
      stream.getTracks().forEach((track) => {
        if (track.readyState == "live") {
          track.stop();
        }
      });

      // save the blob as video
      let video_local = new Blob(blobsRecorded, {
        type: "video/webm",
      });
      setdownloadLink(video_local);
      setvideoObj(URL.createObjectURL(video_local));
    }
  };
  const markComplete = () => {
    lessons[selectedLessonIndex].completed = true;
    // move to next index if not last
    if (selectedLessonIndex < lessons.length - 1) {
      selectLesson(selectedLessonIndex + 1);
      // clearRecording();
    }
  };

  // triggers pre recording
  const preStartRecording = (e) => {
    // if (vpiData?.type_id == 3 && vpiData?.vpi_value == 1) {
    //   stopVideo();
    // }
    setEnableRecording(true);
    // start the 3 sec counter
    setCounterVisible(true);
    setTimeout(() => {
      setCounterCount(2);
    }, 1000);
    setTimeout(() => {
      setCounterCount(1);
    }, 2000);
    setTimeout(() => {
      setCounterCount(0);
    }, 3000);
  };
  const saveAttempt = async () => {
    console.log({ audioWord });

    if (!audioWord.length) {
      setAudioWordError(true);
      return;
    }
    setAudioWordError(false);
    const fileName = "UserAttempt.webm";
    const file = new File([downloadLink], fileName);
    setIsVideoLoading(true);
    setIsCompleted(true);
    setIsSavingAttempt(true);
    const selectedLesson = lessons[selectedLessonIndex];
    // save attempt first
    const response = await fetch(
      baseUrl + "interview/save-attempt-for-signed-url",
      {
        method: "POST",
        headers: {
          Authorization: "Bearer " + user.token,
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          fileName,
          moduleNo: moduleNo,
          routeNo: selectedLesson.routeno,
          lessonNo: selectedLesson.lesson_no,
        }),
      }
    ).then((r) => r.json());

    try {
      const videoResponse = await axios.put(response.uploadURL, file, {
        headers: {
          "Content-Type": "video/webm",
        },
        onUploadProgress: (data) => {
          //Set the progress value to show the progress bar
          setProgress(Math.round((100 * data.loaded) / data.total));
        },
      });
      if (videoResponse.status === 200) {
        const videoSaveResponse = await axios.post(
          baseUrl +
            "interview/mark-attempt-video-uploaded/" +
            response.attemptNo,
          {
            reviewFileLocation: response.Key,
            moduleNo: moduleNo,
            routeNo: selectedLesson.routeno,
            lessonNo: selectedLesson.lesson_no,
            cohortId: vpiData?.id
              ? vpiData?.id
              : localStorage.getItem("cohortId"),
          },
          {
            headers: {
              Authorization: "Bearer " + user.token,
              Accept: "application/json",
              "Content-Type": "application/json",
            },
          }
        );
        if (videoSaveResponse.status === 200) {
          stopCamera();
          addToast("Your attempted has been saved successfully", {
            appearance: "success",
            autoDismiss: true,
          });
          if (
            videoSaveResponse?.data?.distinctAttempts &&
            videoSaveResponse?.data?.distinctAttempts.length > 0
          ) {
            setSubmittedCount(videoSaveResponse?.data?.distinctAttempts.length);
          }
          setProgress(undefined);
          setIsSavingAttempt(false);
          // clear recording
          clearRecording();
          // update the prev attempts
          loadPreviousAttempts(selectedLessonIndex);
          mixPanel.track("InterviewSimulatorUploadVideo", {
            userId: user.email ? user.email : user.userId,
            module,
            moduleName,
            lessonNo: lessons[selectedLessonIndex].lesson_no,
          });
          setLessons(videoSaveResponse?.data?.lessons);
          let lessonsCounts =
            videoSaveResponse?.data?.lessons &&
            videoSaveResponse?.data?.lessons.length > 0 &&
            videoSaveResponse?.data?.lessons.filter(
              (item) => item.completed == true
            );
          setLessonCount(lessonsCounts);
          setSelectedLessonIndex(selectedLessonIndex);
          setShowModal(true);
        } else {
          stopCamera();
          clearRecording();
          setIsSavingAttempt(true);
          addToast("Could not save attempt", {
            appearance: "error",
            autoDismiss: true,
          });
        }
      } else {
        setIsSavingAttempt(true);
        stopCamera();
        clearRecording();
        addToast("Could not save attempt", {
          appearance: "error",
          autoDismiss: true,
        });
      }
      setIsVideoLoading(false);
      setEnableRecording(false);
    } catch (e) {
      setEnableRecording(false);
      setIsVideoLoading(false);
      setIsSavingAttempt(true);
      console.log("ERROR", e);
    }
  };

  const nextQuestion = (val) => {
    if (vpiData?.type_id == 3 && vpiData?.vpi_value == 1 && !!enableRecording) {
      if (val == "alert") {
        setEnableRecording(false);
        if (selectedLessonIndex < lessons.length - 1) {
          selectLesson(selectedLessonIndex + 1);
        }
      } else {
        setAlert(true);
      }
    } else {
      if (selectedLessonIndex < lessons.length - 1) {
        selectLesson(selectedLessonIndex + 1);
        // clearRecording();
      }
    }
  };

  const addTipsHandler = () => {
    setAddTipsModal(true);
  };
  const handleCloseTipsModal = () => {
    setAddTipsModal(false);
  };

  const convert = (input) => {
    if (!!input) {
      let parts = input.toString().split(":");
      let minutes = +parts[0];
      let seconds = +parts[1];

      return minutes * 60 + seconds;
    } else {
      return 0;
    }
  };

  //   const stopVideo = () => {
  //     var myVideo = document.getElementById("myVideo");
  //     myVideo.pause();
  //   };

  //   const playVideo = () => {
  //     console.log("playVideo");
  //   };

  //   let stopErrorMsg = stopError;
  //   const play = document.getElementById("myVideo");
  //   if (play) {
  //     if (isRecording && vpiData?.type_id == 3 && vpiData?.vpi_value == 1) {
  //       var myVideo = document.getElementById("myVideo");
  //       myVideo.pause();
  //       play.onclick = function () {
  //         stopErrorMsg = true;
  //       };
  //     } else {
  //       // setStopErrorMsg(false);
  //     }
  //   }

  const tldrs =
    lessons &&
    lessons[selectedLessonIndex] &&
    lessons[selectedLessonIndex].tldrs
      ? lessons[selectedLessonIndex].tldrs
      : null;
  const istldrs = tldrs && tldrs.length > 0 ? true : false;
  
  const onSelect = (e) => {
    console.log("onSelect", e);
    setSelectedLessonIndex(e);
  };
const onPrev = () => {
  document.getElementsByClassName('carousel-control-prev')[0].click();

}
const onNext = () => {

  document.getElementsByClassName('carousel-control-next')[0].click();

}

  return (
    <Carousel
      autoPlay={false}
      onSelect={onSelect}
      interval={80000000}
      slide={false}
      controls={!!showAnswer}
      indicators={false}
      // nextIcon={<span aria-hidden="true" className="fas fa-chevron-right fa-3x customNextClass"/>}
      // prevIcon={<span aria-hidden="true" className="fas fa-chevron-left fa-3x customPrevClass"/>}      className={`${selectedLessonIndex == 0 ? `` : 'prevArrow'} ${selectedLessonIndex + 1 == lessons.length ? `nextArrow` : ''}` }
      className={`${selectedLessonIndex == 0 ? `` : 'prevArrow'} ${selectedLessonIndex + 1 == lessons.length ? `nextArrow` : ''}` }

    >
      {/* console.log() */}
      {lessons.map((lesson, index) => {
        return (
          <Carousel.Item
          >
            <Carousel.Caption>
              <h3>
                {index + 1}. {lesson.long_description}
              </h3>
              {showAnswer ? 
              <div className="nextPrev">
              <p onClick={()=>{ onPrev(index-1)}} style={{textAlign: 'left'}} className="descp prvNxtDesp">
              {selectedLessonIndex != 0 ?
                `prev`
                : `` }
                </p>

              {lesson?.completed ?  <p className="descp messgDecp">You have submitted your video answer!</p>: <p className="descp messgDecp"></p>} 
             
              <p onClick={()=>{ onNext(index-1)}} style={{textAlign: 'right'}} className="descp prvNxtDesp">
              {selectedLessonIndex+1 == lessons.length ?
                ``
                : `next` }
                </p>

              </div>
              :''
             }
            </Carousel.Caption>
            {/* question video start  */}
            {showAnswer ? (
              <>
                {lessons[selectedLessonIndex]?.video_type != "0" ? (
                  <div className="question-view prevVideo">
                    <div className="videoDiv">
                      <video
                        id="myVideo"
                        className={"question-video qsVideo"}
                        autoPlay={index == selectedLessonIndex}
                        src={videoLink}
                        controls
                      ></video>
                      {/* {stopErrorMsg ? <span className="playErrorVideo">Recording in progress. Cannot play video at the same time.</span> : ''} */}
                    </div>
                  </div>
                ) : (
                  <div className="question-view">
                    {lessons[selectedLessonIndex]?.referenceAnswer ? (
                      <p>{lessons[selectedLessonIndex]?.referenceAnswer}</p>
                    ) : (
                      <p>
                        Schumacher knew which race his mother meant: the women’s
                        team sprint at the 2018 Olympics in Pyeongchang, South
                        Korea. The race had taken place while he slept, but
                        Schumacher, an aspiring professional cross country
                        skier, did as he was told. And in the dark in Alaska, as
                        he watched Jessie Diggins come off the final turn in
                        South Korea with a burst of power and speed to secure
                        her team’s gold medal — the first American medal of any
                        kind in cross-country skiing since 1976 — everything he
                        thought about his future as a competitive racer shifted.
                      </p>
                    )}
                  </div>
                )}
              
                {/* {console.log('lessonsCounts',lessons.length ,lessonsCounts.length)} */}
                {vpiData?.type_id == 3 &&
                vpiData?.vpi_value == 1 &&
                lessons.length == lessonsCounts.length ? (
                  ""
                ) : 
                lesson?.completed ? 
                  ''
                  :
                   <div className="strtBtn">
                  <button id="start-record" onClick={() => startCamera()}>
                    Start Camera
                  </button>
                </div>
                }
              </>
            ) : (
              //question video end

              ''
            )}

          </Carousel.Item>
        );
      })}
      {showAnswer ? '': 
      // recorder
      <div className="recorder">
      {isVideoLoading && (
        <div className="loader spinerVideo">
          <Spinner larger />
        </div>
      )}
      {counterVisible ? (
        <div className="countdown-counter">{counterCount}</div>
      ) : (
        <></>
      )}
      {progress && (
        <div className="progressBar">
          <ProgressBar
            variant="success"
            now={progress}
            label={`${progress}%`}
          />
        </div>
      )}
      {!isRecording && downloadLink ? (
        <button id="stop-camera" onClick={() =>
         setClosePopup(true)}>
          <span>&times;</span>
        </button>
      ) : null}

      {stream && !isRecording && !downloadLink ? (
        <button id="stop-camera" onClick={() => stopCamera()}>
          <span>&times;</span>
        </button>
      ) : null}
      {isRecording ? (
        <button id="recording-time" onClick={() => stopCamera()}>
          <span></span>
        </button>
      ) : null}
      {!downloadLink ? (
        !stream ? (
          <video
            id="video"
            style={{ display: "none" }}
            className="record-video c1234"
            ref={videoRef}
            autoPlay
          ></video>
        ) : (
          <video
            id="video"
            className="record-video c12345"
            ref={videoRef}
            autoPlay
          ></video>
        )
      ) : (
        <video
          id="video"
          style={{ display: "none" }}
          className="record-video c2134567"
          ref={videoRef}
          autoPlay
        ></video>
      )}
      {/* {!downloadLink && stream ? <video id="video" ref={videoRef} width="320" height="240" autoPlay></video> : null} */}
      {downloadLink ? (
        <video
          className="record-video c212121"
          src={videoObj}
          autoPlay
          controls
        ></video>
      ) : null}
      {/* {!stream ? <video src={s3Url + previousAttempts[0]?.filePath} className="record-video c111111" style={{ backgroundColor: 'black' }}>
    </video> : null} */}
      <div className="mobileVideo">
        {stream &&
        !counterVisible &&
        !isRecording &&
        !downloadLink ? (
          <button
            id="start-record"
            onClick={(e) => preStartRecording(e)}
          >
            Start Recording
          </button>
        ) : null}
        {/* {previousAttempts.length === 0 && !stream ? (
          <button id="start-record" onClick={() => startCamera()}>
            Start Camera
          </button>
        ) : null} */}
        {vpiData?.type_id == 3 &&
        vpiData?.vpi_value == 1 &&
        lessons.length == lessonsCounts.length ? (
          ""
        ) : (
          <>
            {!isRecording && downloadLink ? (
              <button
                className="re-record"
                onClick={() => startCamera()}
              >
                Re-record
              </button>
            ) : null}
            {previousAttempts.length > 0 && !stream ? (
              <button
                className="re-record2"
                onClick={() => startCamera()}
              >
                Re-record
              </button>
            ) : null}
          </>
        )}
        {/* the recording timer */}

        {isRecording ? (
          <button id="stop-record" onClick={(e) => stopRecording(e)}>
            Stop Recording
          </button>
        ) : null}
        {!isRecording && downloadLink ? (
          <button
            className="save-answer"
            onClick={(e) => {
              if (
                videoTimeCount < 5 &&
                vpiData?.type_id == 3 &&
                vpiData?.vpi_value == 1
              ) {
                setVideoLimit(true);
              } else {
                if (!isSavingAttempt) saveAttempt();
              }
            }}
          >
            {vpiData?.type_id == 3 && vpiData?.vpi_value == 1
              ? "Submit Answer"
              : "Save Answer"}
          </button>
        ) : null}
      </div>
      {videoLimit && (
        <span className="videoMinimum-mobile">
          Your video must be minimum of 1 minute duration. Please
          re-record video of duration at least 1 minute.
        </span>
      )}
      {isAudioWordError && (
        <span className="videoMinimum-mobile">
          Audio has no word, Please re-record video
        </span>
      )}
    </div>}

    {/* <ol className="carousel-indicators custIndicator">
          {lessons.map((item, index) => {
            return (
              <li
                key={index}
                // onClick={() => this.goToIndex(index)}
                className={ index == selectedLessonIndex ? 'active' : ''}
                // style={{ backgroundImage: `url(${item.src})` }}
              >test-user<div class="lesson-completed-icon flex-shrink-0"><span class="checkmark"><div class="checkmark_circle"></div><div class="checkmark_stem"></div><div class="checkmark_kick"></div></span></div></li>
            );
          })}
        </ol> */}

      {/* modal start*/}
      {closePopup && 
      <div className="SkipModal">
      <div className="modal-body">
            <h5 className="text-center">
            Do you want to cancel the record? 
                     </h5>
        <div className="d-flex justify-center">
        <button
            className="continue-exam-button"
            style={{ padding: "0px 24px" }}
            onClick={() => {
                stopCamera();
                setClosePopup(false);

            }}
          >
            {`Yes`}
          </button>
          <button
            className="continue-exam-button"
            style={{ padding: "0px 24px" }}
            onClick={() => {
                 setClosePopup(false);
            }}
          >
            {`No`}
          </button>
        </div>
      </div>
    </div>
}
      {/* modal end */}
    </Carousel>
    
  );
}
export default MobileCarousel;
