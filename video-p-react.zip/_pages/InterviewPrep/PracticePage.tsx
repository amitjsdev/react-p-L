import React, { useRef, useEffect, useState } from 'react'
import { Modal, Form, Row, Col, Button as B } from 'react-bootstrap'
import { Spinner } from "../../_components/spinner.component"
import RichEditor from '../../_components/RichEditor';
import { useSelector } from 'react-redux';
import { State } from '../../store/reducers';
import { BackArrow, TopNavigationBar } from '../../_components';
import { Tips } from '../../_components/Tips';
import { baseUrl } from "../../_config/endpoints.config"
import { MainService } from '../../_services/main.service';
import { ProgressBar,Carousel } from 'react-bootstrap';
import { useRouteMatch, Route } from 'react-router-dom';
import "./Practice.scss";
import Button from '../../_components/button.component';
import { useToasts } from 'react-toast-notifications';
import axios from 'axios';
import { LottieLoader } from '../../_components/lottie-loader.component';
import Joyride from 'react-joyride';
import { mixPanel } from '../../_config/mixpanel.config';
import { history } from '../../_config';
import { PRACTICE_SET } from '../PracticeSet/PracticeSetPage';
import { CDN_URL } from '../../constant';
import Alert from './AlertModal';
import ThankyouModal from './ThankyouModal';
import speech from './speech';
import {
  isMobile
} from "react-device-detect";

import MobileCarousel from './MobileCarousel';
import { green } from '@material-ui/core/colors';
const main = new MainService();
export const PRATICE_ROUTE = '/practice';
const s3Url = CDN_URL+'/uploads/';


type PPP = {
  user: any,
};

const PracticePage = ({ user }: PPP) => {
  const { addToast } = useToasts();

  const [moduleName, setmoduleName] = useState();
  const [lessons, setLessons] = useState([]);
  const [selectedLessonIndex, setSelectedLessonIndex] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const [isSavingAttempt, setIsSavingAttempt] = useState(false);

  const [submittedCount, setSubmittedCount] = useState(0);

  const [lessonCount, setLessonCount] = useState([]);

  const [showModal, setShowModal] = useState(false);

  const module = useSelector((state: State) => state.module as any)

  const [noPracticeSetIsSelected, setNoPracticeSetIsSelected] = useState(false);
  const [cohort, setCohort] = useState<any>(null);


 

  // react joyride related
  const [showJoyride, setShowJoyride] = useState<boolean>();
  

  useEffect(() => {
    // hide the joyride now
    if (showJoyride) {
      localStorage.setItem('joyride-show.practicepage', "true");
    }
  }, [showJoyride]);

  // load lessons
  useEffect(() => {

    setCohort(user.cohort);

    setShowJoyride(localStorage.getItem('joyride-show.practicepage') ? false : true);

    // load lessons for module
    setIsLoading(true);
    main.getAllPracticeSets(module.moduleNumber, user.token)
      .then(response => {
        if (response.message) {
          return setNoPracticeSetIsSelected(true);
        }
        setmoduleName(response.module);
        setLessons(response.lessons)
        setIsLoading(false);
        let lessonsCounts = response.lessons && response.lessons.length > 0 && response.lessons.filter((item:any)=>item.completed == true);
        setLessonCount(lessonsCounts);
      })
      .catch(err => {
        addToast("Something went wrong, please refresh from  !", { appearance: 'error', autoDismiss: true });
        console.log({
          err
        });
      })

  }, []);



    let vpiData:any = [];
    if(cohort && cohort.length > 0){

      let checkData = cohort && cohort.length > 0 && cohort.find((item:any)=> item.type_id == 3 && item.vpi_value == '0');
      if(checkData && Object.keys(checkData).length){
        vpiData = [];
      }else{
        vpiData = cohort && cohort.length > 0 && cohort.find((item:any)=> item.type_id == 3 && item.vpi_value == '1');
      }
  
    }else{
      let checkData = user?.cohort && user?.cohort.length > 0 && user?.cohort.find((item:any)=>item.type_id == 3 && item.vpi_value == '1');
      if(checkData && Object.keys(checkData).length){
        vpiData = [];
      }else{
        vpiData = user?.cohort && user?.cohort.length > 0 && user?.cohort.find((item:any)=> item.type_id == 3 && item.vpi_value == '1');
      }
    }



  const hideModal = () =>{
    setShowModal(false);
  }

  return (
    <div>
      <TopNavigationBar />
      {/* show joyride */}
      {
        lessons.length > 0 && showJoyride ? (
          <Joyride steps={[
            {
              disableBeacon: true,
              target: '.topic.active',
              content: 'Choose from the list of questions to select the question you want to practice.'
            },
            {
              target: '#start-record',
              content: 'Tap on the button to record your video.'
            },
            {
              target: '.re-record2',
              content: 'Tap on the button to record your video.'
            },
            {
              target: '.myvideo-link',
              content: 'You can go here to review your saved videos.'
            },
          ]}
            locale={{
              last: "Got it",
              close: "Got it"
            }}
            hideBackButton
            styles={{
              options: {
                arrowColor: "#713CFB",
                backgroundColor: "#713CFB",
                textColor: "#FFF",
                primaryColor: '#FFF3',
              }
            }}
            disableScrolling continuous />
        ) : <></>
      }
      {/* show alert if no practice set is there */}
      {
        noPracticeSetIsSelected ? (
          <Joyride steps={[
            {
              disableBeacon: true,
              target: '.home-link',
              content: 'Please select a practice page first.'
            },
          ]}
            callback={data => {
              if (data.action === "reset") {
                // redirect back to practice set page
                history.push(PRACTICE_SET);
              }
            }}
            locale={{
              last: "Got it",
              close: "Got it"
            }}
            hideBackButton
            styles={{
              options: {
                arrowColor: "#713CFB",
                backgroundColor: "#713CFB",
                textColor: "#FFF",
                primaryColor: '#FFF3',
              }
            }}
            disableScrolling continuous />
        ) : <></>
      }
      <div className="PracticePage">
        {/* <div style={{ marginTop: '20px' }}></div> */}

        {/* main container */}
        <div className="container">
        {vpiData?.type_id == 3 && vpiData?.vpi_value == 1 ? 
        lessonCount.length == lessons.length && submittedCount == 0 ? 
         <p className="heighLitedText bold"> Thank you for submitting all your answers. </p> : '' : ''}
       
        {vpiData?.type_id == 3 && vpiData?.vpi_value == 1 ? 
          submittedCount > 0 ? 
          lessons.length == submittedCount ? 
          <p className="heighLitedText bold"> Thank you for submitting all your answers. </p>
          : 
          <p className="heighLitedText bold"> Question {submittedCount > 0 ? submittedCount : lessonCount.length} of {lessons && lessons.length} submitted.</p>

           : 
             <p className="heighLitedText bold"> Question {submittedCount > 0 ? submittedCount : lessonCount.length} of {lessons && lessons.length} submitted.</p>
          : ''}

 {isMobile && window.screen.availWidth <= 768 && vpiData?.type_id == 3 && vpiData?.vpi_value == 1 ?
        <MobileCarousel
           module={module}
          isSavingAttempt={isSavingAttempt}
          moduleName={moduleName ? moduleName : ""}
          lessons={lessons}
          isLoading={isLoading}
          setSelectedLessonIndex={(index: number) => {
            setSelectedLessonIndex(index);
          }}
          selectedLessonIndex={selectedLessonIndex}
          setShowModal={setShowModal}
          setIsSavingAttempt={setIsSavingAttempt}
          user={user}
          vpiData={vpiData}
          setSubmittedCount={setSubmittedCount}
          setLessons={setLessons}
          lessonsCounts={lessonCount}
          setLessonCount={setLessonCount}
          />
      :
      
            <div className="sectionVideo flex">
                {/* sidebar */}
                <Sidebar
                  isSavingAttempt={isSavingAttempt}
                  moduleName={moduleName ? moduleName : ""}
                  lessons={lessons}
                  isLoading={isLoading}
                  setSelectedLessonIndex={(index: number) => {
                    setSelectedLessonIndex(index);
                  }}
                  selectedLessonIndex={selectedLessonIndex}

              
                  />
                {/* content */}
                <MainContent
                  setShowModal={setShowModal}
                  moduleName={moduleName ? moduleName : ""}
                  module={module}
                  setSelectedLessonIndex={setSelectedLessonIndex}
                  selectedLessonIndex={selectedLessonIndex}
                  lessons={lessons}
                  isSavingAttempt={isSavingAttempt}
                  setIsSavingAttempt={setIsSavingAttempt}
                  user={user}
                  vpiData={vpiData}
                  setSubmittedCount={setSubmittedCount}
                  setLessons={setLessons}
                  lessonsCounts={lessonCount}
                  setLessonCount={setLessonCount}
                />
                </div>
      }

        </div>
      </div>
      {/* {vpiData?.type_id == 3 && vpiData?.vpi_value == 1 ? 
      submittedCount > 0 ? 
         lessons.length == submittedCount ? 
         showModal ? <ThankyouModal close={hideModal}/> : 
         '' 
          : ''
         : ''
        } */}
        { vpiData?.type_id == 3 && vpiData?.vpi_value == 1 ? 
          submittedCount > 0 ? 
          lessons.length == submittedCount ? 
          showModal ? <ThankyouModal message={`Thank you for submitting all your answers.
          `} close={hideModal}/>
          : 
          ''          
           : 
           showModal ? <ThankyouModal message={`Question ${submittedCount > 0 ? submittedCount : lessonCount.length} of ${lessons && lessons.length} submitted.`} close={hideModal}/>
            :''
          : ''
           :''
        }

    </div>
  );
}

type MCP = {
  moduleName: string | undefined,
  selectedLessonIndex: number | null,
  setSelectedLessonIndex: Function,
  isSavingAttempt: boolean,
  setIsSavingAttempt: Function,
  lessons: Array<any>,
  module: any,
  user: any,
  vpiData:any,
  setSubmittedCount:any,
  setLessons:any,
  setShowModal:any,
  lessonsCounts:any,
  setLessonCount:any,
}

function MainContent({ moduleName, isSavingAttempt, setIsSavingAttempt, selectedLessonIndex, setSelectedLessonIndex, lessons, user, module,setSubmittedCount,vpiData,setLessons,setShowModal,lessonsCounts,setLessonCount }: MCP) {

  const { addToast } = useToasts();

  const [counterVisible, setCounterVisible] = useState<boolean>(false);
  const [counterCount, setCounterCount] = useState<number>(3);

  const [progress, setProgress] = useState<number>();

  const [previousAttempts, setPreviousAttempts] = useState<Array<any>>([]);
  const [isLoadingPreviousAttempt, setIsLoadingPreviousAttempt] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const [isVideoLoading, setIsVideoLoading] = useState(false);

  const [moduleNo, setmoduleNo] = useState(module.moduleNumber);
  const [AddTipsModal, setAddTipsModal] = useState(false)
  // recording related
  const [stream, setstream] = useState<any>();
  const [mediaRecorder, setmediaRecorder] = useState<any>();
  const [isRecording, setisRecording] = useState();
  const [downloadLink, setdownloadLink] = useState<any>(null);
  const [videoObj, setvideoObj] = useState();
  const [blobsRecorded, setblobsRecorded] = useState<any>([]);

  const [alertMsg, setAlert] = useState(false);
  const [enableRecording, setEnableRecording] = useState(false);
  const [videoTimeCount, setVideoTimeCount] = useState<any>('1');
  const [videoLimit, setVideoLimit] = useState<any>(false);
  const [audioWord, setAudioWord]=useState('');
  const [isAudioWordError, setAudioWordError]=useState(false);
  const [AudioNoEnglishError, setAudioNoEnglishError]=useState(false);
  const [stopError, setStopErrorMsg] = useState(false);

  const speechObj =speech();
  
  // Video ref
  const videoRef = useRef<HTMLVideoElement>(null);


  // change lesson only if not saving something
  const selectLesson = (index: number) => {
    if (!isSavingAttempt) {
      // reset recording
      resetCameraAndMedia().then(() => {
        // select lesson
        setSelectedLessonIndex(index);
      });
    }
  }
  const { params: { id } } = useRouteMatch();

  useEffect(() => {
    if (lessons && lessons.length > 0) {
      // if (id) {
      //   lessons.map((item, i) => {
      //     if (item.practiceQuestionId == id) {
      //       selectLesson(i);
      //     }
      //   })

      // } else {
      //   selectLesson(0)
      // }
      if(selectedLessonIndex){
        selectLesson(selectedLessonIndex)
      }else{
        selectLesson(0)
      }
    }

     
    let cohortData:any = []
    // user.cohort && user.cohort.length > 0 && user.cohort.map((item:any)=>{
        //     cohortData.push(item[0])
        // })
  }, [lessons,id]);

  const getAudioText =() =>{
    setAudioWord('');
    setAudioWordError(false);
    speechObj.start()
    speechObj.onresult=(event:any)=>{
      let interim_transcript = "";
      let final_transcript = audioWord;

                for (let i = event.resultIndex; i < event.results.length; ++i) {
                    if (event.results[i].isFinal) {
                        final_transcript += event.results[i][0].transcript;
                    } else {
                        interim_transcript += event.results[i][0].transcript;
                    }
                }
                setAudioWord(final_transcript ? final_transcript :interim_transcript)
    }
  }


  const loadPreviousAttempts = async (index: number) => {
    setIsLoadingPreviousAttempt(true);


    // get selected lesson
    const lessonIndex = index !== undefined ? index : selectedLessonIndex;

    if (!lessons || (!lessonIndex && lessonIndex !== 0)) return;

    const selectedLesson = lessons[lessonIndex] as any;
    if (!selectedLesson) {
      return;
    }
    main.moduleRelatedPreviousAttempts(user.token, module.moduleNumber, selectedLesson.routeno, selectedLesson.lesson_no)
      .then(response => {
        setPreviousAttempts(response.attempts)
        setIsLoadingPreviousAttempt(false);
      })
      .catch(err => {
        setIsLoadingPreviousAttempt(false);
        addToast("Something went wrong, please refresh!", { appearance: 'error', autoDismiss: true });
        console.log({
          err
        });
      })
  }

  const stopCamera = (discardFootage = false) => {
    const vid = document.getElementById("video") as HTMLVideoElement;
    if (vid) {
      vid.pause();
      vid.src = "";
    }
    stream?.getTracks().forEach(function (track: any) {
      track.stop();
    });
    if (stream) {
      setstream(null as any);
    }
  }


  const resetCameraAndMedia = () => {
    return new Promise((res, rej) => {
      stopCamera(true);
      clearRecording();
      return res(true);
    });
  }

  const clearRecording = () => {
    setblobsRecorded([])
    setisRecording(false as any);
    setdownloadLink(null);
    setvideoObj(null as any);
    // startCamera()
  }

  // load previous attempts
  useEffect(() => {
    if (selectedLessonIndex || selectedLessonIndex === 0) {
      loadPreviousAttempts(selectedLessonIndex);
    }
    // reset previous data
    resetCameraAndMedia();
  }, [selectedLessonIndex])

  // if counter count is zero, hide the counter and start recording
  useEffect(() => {
    if (counterCount === 0) {
      setCounterVisible(false);
      setCounterCount(3); // reset the count
      // start recording
      startRecording(null);
    }
  }, [counterCount]);

  if (!selectedLessonIndex && selectedLessonIndex !== 0) {
    return (
      <div className="content-holder">
        <div className="content-holder-content">
          <div className="content-heading">
            <div className="my-5 text-center ">Please select a lesson first!</div>
          </div>
        </div>
      </div>
    );
  }

  // get video link
  let videoLink = "";
  if (lessons && lessons[selectedLessonIndex]) {
    const selectedLesson = lessons[selectedLessonIndex];
  if(selectedLesson.video_type == 'webm'){
      videoLink = `${CDN_URL}/interviewprep/${module.moduleNumber}/${module.moduleNumber}_${selectedLesson.routeno}_${selectedLesson.lesson_no}.webm`;
    }else{
      videoLink = `${CDN_URL}/interviewprep/${module.moduleNumber}/${module.moduleNumber}_${selectedLesson.routeno}_${selectedLesson.lesson_no}.mp4`;
    }
    // else{
    //   videoLink = selectedLesson.video_type;
    // }
  }
  

  // handlers

  // camera related
  const startCamera = async () => {
    setVideoLimit(false)
    setAudioWord('')
    setblobsRecorded([])
    setdownloadLink(null)
    setvideoObj(null as any)
    let stream = await navigator.mediaDevices.getUserMedia({
      video: true,
      audio: true
    });
    var video = document.getElementById('video') as HTMLVideoElement;
    video.srcObject = stream;
    video.volume = 0;
    if (videoRef.current) {
      videoRef.current!.srcObject = stream;
      setstream(stream as any)
      video.srcObject = stream;
      video.volume = 0;
    }
    return;
  }

  const mediaRecorderDataAvailableListener = (e: any) => {
    setblobsRecorded([...blobsRecorded, e.data]);
  }

  const mediaRecorderStopEventHandler = () => {
    // create local object URL from the recorded video blobs
    let video_local = new Blob(blobsRecorded, {
      type: 'video/webm'
    });
    setdownloadLink(video_local);
    setvideoObj(URL.createObjectURL(video_local) as any)
  }
  

  // start recording
  const startRecording = async (e: any) => {
    getAudioText();
    // set MIME type of recording as video/mp4
    var mediaRecorder2 = new MediaRecorder(stream, {
      mimeType: "video/webm"
    });
    const recorded_blobs = [] as any;
    // reset the blobs
    setblobsRecorded([]);
    // reset the download link
    setdownloadLink(null)
    setvideoObj(null as any);

    // event : new recorded video blob available 
    mediaRecorder2.addEventListener('dataavailable', (e: any) => {
      recorded_blobs.push(e.data);
      // hacking in through to show the recorded time data, due to insufficient time
      const recordedTimeDiv = document.getElementById('recording-time');
      if (recordedTimeDiv) {
        let videoTime:any = ((Math.floor(recorded_blobs.length / 60) + "").padStart(2, "0") + ":" + (Math.floor(recorded_blobs.length % 60) + "").padStart(2, "0"));
        recordedTimeDiv.innerText = ((Math.floor(recorded_blobs.length / 60) + "").padStart(2, "0") + ":" + (Math.floor(recorded_blobs.length % 60) + "").padStart(2, "0"));
        let convertedVal = convert(videoTime);
        // console.log('parseFloat',convertedVal,videoTime)
        setVideoTimeCount(convertedVal);
      }

      setblobsRecorded(recorded_blobs);
    });
    // start recording with each recorded blob having 1 second video
    mediaRecorder2.start(1000);
    setmediaRecorder(mediaRecorder2 as any)
    // set state to recording
    setisRecording(true as any)


    mixPanel.track("InterviewSimulatorRecordVideo", {
      userId: user.email ? user.email : user.userId,
      module,
      moduleName,
      lessonNo: lessons[selectedLessonIndex].lesson_no
    });

  }

  const stopRecording = (e:any) => {
    setStopErrorMsg(false);
    speechObj.stop()
    setIsVideoLoading(false);
    if (isRecording) {
      //this.mediaRecorder.stop();
      mediaRecorder.stop()
      setisRecording(false as any);
      setmediaRecorder(undefined);
    
      // stop all tracks
      stream.getTracks().forEach((track: any) => {
        if (track.readyState == "live") {
          track.stop();
        }
      });

      // save the blob as video
      let video_local = new Blob(blobsRecorded, {
        type: 'video/webm'
      });
      setdownloadLink(video_local);
      setvideoObj(URL.createObjectURL(video_local) as any);
    }
    
  }
  const markComplete = () => {

    lessons[selectedLessonIndex].completed = true;
    // move to next index if not last
    if (selectedLessonIndex < lessons.length - 1) {
      selectLesson(selectedLessonIndex + 1);
      // clearRecording();
    }
  }

  // triggers pre recording 
  const preStartRecording = (e: any) => {
    if(vpiData?.type_id == 3 && vpiData?.vpi_value == 1 ){
      stopVideo();
    }
    setEnableRecording(true);
    // start the 3 sec counter
    setCounterVisible(true);
    setTimeout(() => {
      setCounterCount(2);
    }, 1000);
    setTimeout(() => {
      setCounterCount(1);
    }, 2000);
    setTimeout(() => {
      setCounterCount(0);
    }, 3000);
  }

  const checkAudioinEnglishHandler =async(text:string)=>{
    return await fetch(`${baseUrl}languageDetect`, {
      method: "POST",
      headers: {
        "Accept": "application/json",
        'Content-Type': "application/json"
      },
      body: JSON.stringify({text})
    })
    .then(r => r.json())
    .then((r)=> r && r.data && r.data==='en')
    .catch(()=>false);
  }
  const saveAttempt = async () => {
    console.log('audioWord',audioWord);
    
    
    if(!audioWord.length){
      setAudioWordError(true)
      return;
    }
    setIsVideoLoading(true)
    const checkAudioinEnglish =await checkAudioinEnglishHandler(audioWord);
    console.log({checkAudioinEnglish});
    
    if(!checkAudioinEnglish){
      setAudioNoEnglishError(true)
      return;
    }
    setAudioWordError(false)
    setAudioNoEnglishError(false)
    const fileName = "UserAttempt.webm";
    const file = new File([downloadLink], fileName);
    setIsCompleted(true);
    setIsSavingAttempt(true);
    const selectedLesson = lessons[selectedLessonIndex];
    // save attempt first
    const response = await fetch(baseUrl + 'interview/save-attempt-for-signed-url', {
      method: "POST",
      headers: {
        "Authorization": "Bearer " + user.token,
        "Accept": "application/json",
        'Content-Type': "application/json"
      },
      body: JSON.stringify({
        fileName,
        moduleNo: moduleNo,
        routeNo: selectedLesson.routeno,
        lessonNo: selectedLesson.lesson_no,
      }),
    }).then(r => r.json());

    try {
      const videoResponse = await axios.put(response.uploadURL,
        file, {
        headers: {
          "Content-Type": "video/webm"
        },
        onUploadProgress: data => {
          //Set the progress value to show the progress bar
          setProgress(Math.round((100 * data.loaded) / data.total))
        },
      });
      if (videoResponse.status === 200) {
        const videoSaveResponse = await axios.post(baseUrl + "interview/mark-attempt-video-uploaded/" + response.attemptNo, {
          reviewFileLocation: response.Key,
          moduleNo: moduleNo,
          routeNo: selectedLesson.routeno,
          lessonNo: selectedLesson.lesson_no,
          cohortId:vpiData?.id ? vpiData?.id : localStorage.getItem('cohortId')
        }, {
          headers: {
            "Authorization": "Bearer " + user.token,
            "Accept": "application/json",
            'Content-Type': "application/json"
          }
        });
        if (videoSaveResponse.status === 200) {
          stopCamera()
          addToast('Your attempted has been saved successfully', { appearance: 'success', autoDismiss: true })
          if(videoSaveResponse?.data?.distinctAttempts && videoSaveResponse?.data?.distinctAttempts.length > 0){
            setSubmittedCount(videoSaveResponse?.data?.distinctAttempts.length)
          }
          setProgress(undefined)
          setIsSavingAttempt(false);
          // clear recording
          clearRecording();
          // update the prev attempts
          loadPreviousAttempts(selectedLessonIndex);
          mixPanel.track("InterviewSimulatorUploadVideo", {
            userId: user.email ? user.email : user.userId,
            module,
            moduleName,
            lessonNo: lessons[selectedLessonIndex].lesson_no
          });
          setLessons(videoSaveResponse?.data?.lessons);
          let lessonsCounts = videoSaveResponse?.data?.lessons && videoSaveResponse?.data?.lessons.length > 0 && videoSaveResponse?.data?.lessons.filter((item:any)=>item.completed == true);
          setLessonCount(lessonsCounts);
          setSelectedLessonIndex(selectedLessonIndex)
          setShowModal(true);
        } else {
          stopCamera()
          clearRecording()
          setIsSavingAttempt(true);
          addToast("Could not save attempt", { appearance: 'error', autoDismiss: true });
        }

      } else {
        setIsSavingAttempt(true);
        stopCamera()
        clearRecording()
        addToast("Could not save attempt", { appearance: 'error', autoDismiss: true });
      }
      setIsVideoLoading(false);
     setEnableRecording(false);
    }
    catch (e) {
      setEnableRecording(false);
      setIsVideoLoading(false);
      setIsSavingAttempt(true);
      console.log('ERROR', e)
    }

  }


  const nextQuestion = (val:string) => {
    if(vpiData?.type_id == 3 && vpiData?.vpi_value == 1 && !!enableRecording){
       if(val == 'alert'){
        setEnableRecording(false);
        if (selectedLessonIndex < lessons.length - 1) {
          selectLesson(selectedLessonIndex + 1);
        }
       }else{
        setAlert(true);
       }
    }else{
      if (selectedLessonIndex < lessons.length - 1) {
        selectLesson(selectedLessonIndex + 1);
        // clearRecording();
      }
    }
  }

  const addTipsHandler = () => {
    setAddTipsModal(true)
  }
  const handleCloseTipsModal = () => {
    setAddTipsModal(false)
  }

  const  convert = (input:any)  =>{
    if(!!input){
      let parts = input.toString().split(':');
      let  minutes = +parts[0];
      let seconds = +parts[1];

    return (minutes * 60 + seconds);
    }else{
      return 0;
    }
     
}


const stopVideo = () => {
  var myVideo:any = document.getElementById ("myVideo");
  myVideo.pause ();
}



const playVideo = () => {
 console.log('playVideo')
}

let stopErrorMsg = stopError;
const play:any = document.getElementById("myVideo");
if(play){
  
  if(isRecording && vpiData?.type_id == 3 && vpiData?.vpi_value == 1){
    var myVideo:any = document.getElementById ("myVideo");
    myVideo.pause();
    play.onclick = function () {
      stopErrorMsg = true;
     }

  }else{
    // setStopErrorMsg(false);
  }
}



  const tldrs = lessons && lessons[selectedLessonIndex] && lessons[selectedLessonIndex].tldrs ? lessons[selectedLessonIndex].tldrs : null
  const istldrs = tldrs && tldrs.length > 0 ? true : false

  return (
    <>
  
 <div className="content-holder">
      
      <div className="content-holder-content">
        <div className="content-heading">
          {!selectedLessonIndex && selectedLessonIndex !== 0 ? <div className="my-5 text-center ">Please select a lesson first!</div> :
            <>
              <div className="mt-5 text-left pl-3 text-lg font-semibold">
                {lessons ? <div> Question {selectedLessonIndex + 1}. {lessons[selectedLessonIndex]?.long_description} </div> : null}
              </div>
              <div className="row">
                <div className="col">
                </div>
                {/* <div className="col text-right mt-5 font-bold mr-3" style={{ color: '#9d9c9c' }}>
                    Question {selectedLessonIndex + 1} of {lessons?.length}
                  </div> */}
              </div>
            </>
          }
          {selectedLessonIndex || selectedLessonIndex === 0 ?
            <Row>
              <Col >
                <div style={{ color: '#7943FB', display: 'inline-flex' }} className="">
                  <span className="cursor-pointer" style={{ margin: '10px 0 10px 20px' }}><Tips tldrs={tldrs} /></span>
                  <span onClick={addTipsHandler} className="cursor-pointer" style={{ margin: istldrs ? '10px 0 10px 20px' : '10px 0 10px 0px' }}>Your answer and notes</span>
                </div>
              </Col>

            </Row>
            : null}
        </div>

        {/* recording and preview section */}
        {selectedLessonIndex || selectedLessonIndex === 0 ?
          <div className="video-box flex items-left justify-around">

            {/* preview */}
           { lessons[selectedLessonIndex]?.video_type != '0' ?
            <div className="question-view">
              <div onClick={playVideo} className="videoDiv">
              <video id="myVideo" className={"question-video qsVideo"} autoPlay={true} src={videoLink} controls></video>
             {stopErrorMsg ? <span className="playErrorVideo">Recording in progress. Cannot play video at the same time.</span> : ''}
           </div>
            </div>
            :
            <div className="question-view">
             {lessons[selectedLessonIndex]?.referenceAnswer ? 
             <p>{lessons[selectedLessonIndex]?.referenceAnswer}</p>
             : 
            <p>Schumacher knew which race his mother meant: the women’s team sprint at the 2018 Olympics in Pyeongchang, South Korea. The race had taken place while he slept, but Schumacher, an aspiring professional cross country skier, did as he was told. And in the dark in Alaska, as he watched Jessie Diggins come off the final turn in South Korea with a burst of power and speed to secure her team’s gold medal — the first American medal of any kind in cross-country skiing since 1976 — everything he thought about his future as a competitive racer shifted.</p>
             }
            </div>
            }
            {/* recorder */}
            <div className="recorder">
              {isVideoLoading &&
            <div className="loader spinerVideo">
                        <Spinner larger />
                    </div>
              }
              {counterVisible ? <div className="countdown-counter">{counterCount}</div> : <></>}
              {progress && <div className="progressBar"><ProgressBar variant="success" now={progress} label={`${progress}%`} /></div>}

              {!downloadLink ?
                !stream ? <video id="video" style={{ display: 'none' }} className="record-video c1234" ref={videoRef} autoPlay={false}></video> : <video id="video" className="record-video c12345" ref={videoRef} autoPlay></video>
                : <video id="video" style={{ display: 'none' }} className="record-video c2134567" ref={videoRef} autoPlay={false}></video>
              }
              {/* {!downloadLink && stream ? <video id="video" ref={videoRef} width="320" height="240" autoPlay></video> : null} */}
              {downloadLink ? <video className="record-video c212121" src={videoObj} autoPlay={false} controls></video> : null}
              {!stream ? <video src={s3Url + previousAttempts[0]?.filePath} className="record-video c111111" style={{ backgroundColor: 'black' }}>
              </video> : null}
              {stream && !counterVisible && !isRecording && !downloadLink ? <button id="start-record" onClick={(e) => preStartRecording(e)}>Start
                Recording</button> : null}
              {stream && !isRecording && !downloadLink ? <button id="stop-camera" onClick={() => stopCamera()}><span>&times;</span></button> : null}
              {previousAttempts.length === 0 && !stream ? <button id="start-record" onClick={() => startCamera()}>Start Camera</button> : null}
             {vpiData?.type_id == 3 && vpiData?.vpi_value == 1 && lessons.length == lessonsCounts.length ?
             '' : 
             <>
             {!isRecording && downloadLink ? <button className="re-record" onClick={() => startCamera()}>Re-record</button> : null}
            {lessons[selectedLessonIndex].completed == true &&  vpiData?.type_id == 3 && vpiData?.vpi_value == 1 ? ''
              : 
              previousAttempts.length > 0 && !stream ? <button className="re-record2" onClick={() => startCamera()}>Re-record</button> : null
               }
               </>
                }
              {/* the recording timer */}
              {isRecording ? <button id="recording-time" onClick={() => stopCamera()}><span>
              </span></button> : null}
              {isRecording ? <button id="stop-record" onClick={(e) => stopRecording(e)}>Stop
                Recording</button> : null}
              {!isRecording && downloadLink ? 
              <button className="save-answer" onClick={(e) => {
                if(videoTimeCount < 3 && vpiData?.type_id == 3 && vpiData?.vpi_value == 1){
                   setVideoLimit(true);
                }else{
                  if (!isSavingAttempt) saveAttempt();
                }
              }}>

              {vpiData?.type_id == 15 && vpiData?.vpi_value == 1 ?  'Submit Answer' : 'Save Answer'}
              </button> : null}
               {lessons[selectedLessonIndex].completed == true &&  <span style={{color: 'green'}} className="videoMinimum">You have submitted your video answer!</span>
}

           {videoLimit && vpiData?.type_id == 3 && vpiData?.vpi_value == 1 &&
              <span className="videoMinimum">Your video must be minimum of 1 minute duration. Please re-record video of duration at least 1 minute.</span>
              }
               {isAudioWordError && 
              <span className="videoMinimum">No words were detected in the video. Please re-record your answer with speech.</span>
              }
               {AudioNoEnglishError && 
              <span className="videoMinimum">We didn't detect English speech. Please re-record while answering in English</span>
              }
            </div>
           
          
          </div> : null}
        <div className="flex justify-content-center mb-10" style={{ color: 'white' }}>
          <div className="btn-next" onClick={() => nextQuestion('yes')}>
            Next question
          </div>
        </div>
      </div>
      {AddTipsModal && !isRecording && <TipsModal handleClose={handleCloseTipsModal} data={lessons[selectedLessonIndex]} />}
    </div>

    {alertMsg && <Alert nextQuestion={nextQuestion} saveAttempt={saveAttempt} alertMsg={alertMsg} close={setAlert}>
       
    </Alert>}
    </>
  );
}

type P = {
  moduleName: string | undefined,
  isLoading: boolean,
  isSavingAttempt: boolean,
  lessons: Array<any>,
  selectedLessonIndex: number | null,
  setSelectedLessonIndex: Function
};

function Sidebar({ moduleName, isSavingAttempt, lessons, isLoading, selectedLessonIndex, setSelectedLessonIndex }: P) {
  return (
    <div className="sidebar">
      <div className="section-header">
        <div>{moduleName}</div>
        {lessons ? <span className="text-left">{lessons.length} questions</span> : null}
      </div>
      {/* lesson list */}
      <div>
        {
          isLoading ? (
            <div className="text-center">
              <LottieLoader />
            </div>
          ) : <></>
        }
        {
          lessons.map((lesson: any, index) => {
            return (
              <div className={index === selectedLessonIndex ?
                "topic active" :
                "topic"}
                onClick={() => {
                  if (!isSavingAttempt) {
                    setSelectedLessonIndex(index);
                  }
                }} key={index}>
                {index + 1}. {lesson.long_description}
                {lesson.completed ? <div className="lesson-completed-icon flex-shrink-0"><span className="checkmark">
                  <div className="checkmark_circle"></div>
                  <div className="checkmark_stem"></div>
                  <div className="checkmark_kick"></div>
                </span></div> : <div className="lesson-incomplete-icon flex-shrink-0"></div>}
              </div>
            )
          })
        }
      </div>
    </div>
  );
}

export default PracticePage

const TipsModal = (props: { handleClose: () => void, data: any }) => {
  const { addToast } = useToasts();
  const user = JSON.parse(localStorage.getItem('user') || '{}');
  const { data: { practiceQuestionId, practiceSetId } } = props;
  const [loading, setloading] = useState(true)
  const [value, setValue] = useState('')
  useEffect(() => {
    main.getStudentPracticeAnswer(user.token, { practiceQuestionId, practiceSetId }).then(res => {
      if (res && res.studentResponse) {
        setValue(res.studentResponse)
      } else {

      }
      setloading(false);
    })
      .catch(err => {
        setloading(false);
      })
  }, [])


  const handleSave = () => {
    setloading(true);
    let payload = {
      practiceQuestionId,
      practiceSetId,
      studentResponse: value
    }
    main.saveStudentPracticeAnswer(user.token, payload)
      .then(res => {
        addToast("Tips Added", { appearance: 'success', autoDismiss: true });
        setloading(false);
        props.handleClose()
      })
      .catch(err => {
        setloading(false);
        addToast("Something went wrong", { appearance: 'error', autoDismiss: true });
      })
  }
  const onChange = (e: any) => {
    setValue(e.target.value)
  }

  return (
    <Modal centered show={true} onHide={props.handleClose} size="lg">
      <Modal.Header closeButton>
        <Modal.Title >
          <Row><Col style={{ color: 'black', marginLeft: '10px', fontWeight: "bold" }}>{`Q. ${props.data.long_description}`}
          </Col>
          </Row>
          <Row><Col style={{ color: '#7943FB', marginLeft: '10px' }}>Write down your answer/notes for the questions
          </Col>
          </Row>
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        {loading && <Spinner />}
        <Form>
          <Row>
            <Form.Group as={Col} controlId="formGridEmail">

              <Col >
                <RichEditor rows="3" data={value} onChange={(data: string) => setValue(data)} />
              </Col>
            </Form.Group>
          </Row>
        </Form>
      </Modal.Body>
      <Modal.Footer style={{ alignSelf: 'center' }}>
        <B style={{ background: '#7943FB', width: '150px', borderRadius: '40px', borderColor: '#7943FB' }} onClick={handleSave}>
          Save Answer
        </B>
      </Modal.Footer>
    </Modal>
  )
}
