import React from "react";
// import "./AllCompleteAlert.scss";
const ThankyouModal = ({ message,close }) => {
  return (
    <div className="SkipModal">
      <div className="modal-body">
        
            <h5 className="text-center">
                {message}
             </h5>
        <div className="d-flex justify-center">
        <button
            className="continue-exam-button"
            style={{ padding: "0px 24px" }}
            onClick={() => {
                close(false);
            }}
          >
            {`Ok`}
          </button>
        </div>
      </div>
    </div>
  );
};
export default ThankyouModal;
