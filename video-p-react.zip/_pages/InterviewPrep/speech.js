const a = () => {
    if (window.speechRecognition || window.webkitSpeechRecognition) {
        const ss = window.speechRecognition || window.webkitSpeechRecognition;
        const speechRecognition = new ss();
        speechRecognition.continuous = true;
        speechRecognition.interimResults = true;
        speechRecognition.lang = 'en-IN';
        return speechRecognition;
    } else {
        alert('Please use latest version of Google Chrome')
        console.log("Speech Recognition Not Available");
    }
}
export default a;