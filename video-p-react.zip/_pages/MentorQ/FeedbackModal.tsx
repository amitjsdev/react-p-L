import React, { useRef, useEffect, useState } from 'react'
import { Modal, Form, Row, Col, Button as B } from 'react-bootstrap'
import { useToasts } from 'react-toast-notifications';
import { MainService } from '../../_services/main.service';
import { Spinner } from "../../_components/spinner.component"
import RichEditor from '../../_components/RichEditor';
import { useDispatch, useSelector } from 'react-redux';

const main = new MainService();

const FeedbackModal = (props: { handleClose: () => void, data: any }) => {
    const { addToast } = useToasts();
    const module = useSelector((state: any) => state.module as any)

    const user = JSON.parse(localStorage.getItem('user') || '{}');
    const [loading, setloading] = useState(false)
    const [value, setValue] = useState('')

  

    const handleSave = () => {
      setloading(true);
      let payload = {
        practiceSetId:module?.moduleNumber,
        overall_feedback: value,
        email: props?.data?.userId
      }
      main.saveOverallFeedback(user.token, payload)
        .then(res => {
          addToast("Overall Feedback Saved!", { appearance: 'success', autoDismiss: true });
          setloading(false);
          props.handleClose()
        })
        .catch(err => {
          setloading(false);
            addToast("Something went wrong", { appearance: 'error', autoDismiss: true });
        })
    }
    const onChange = (e: any) => {
      setValue(e.target.value)
    }
  
    return (
      <Modal centered show={true} onHide={props.handleClose} size="lg">
        <Modal.Header closeButton>
          <Modal.Title >
            <Row><Col style={{ color: 'black', marginLeft: '10px', fontWeight: "bold" }}>
                {`Enter overall feedback`}
            </Col>
            </Row>
            {/* <Row><Col style={{ color: '#7943FB', marginLeft: '10px' }}>Write down your answer/notes for the questions
            </Col>
            </Row> */}
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {loading && <Spinner />}
          <Form>
            <Row>
              <Form.Group as={Col} controlId="formGridEmail">
  
                <Col >
                  <RichEditor rows="6" data={value} onChange={(data: string) => setValue(data)} />
                </Col>
              </Form.Group>
            </Row>
          </Form>
        </Modal.Body>
        <Modal.Footer style={{ alignSelf: 'center' }}>
          <B style={{ background: '#7943FB', width: '150px', borderRadius: '40px', borderColor: '#7943FB' }} onClick={handleSave}>
            Submit
          </B>
        </Modal.Footer>
      </Modal>
    )
  }
  
  export default FeedbackModal;