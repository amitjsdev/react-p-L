import React, { useEffect, useState } from 'react'
import { Dropdown, DropdownButton } from 'react-bootstrap';
import { Spinner, TopNavigationBar } from '../../_components';
import { ReactComponent as Star } from './start_icon.svg';
import "./mentor-q.scss";
import { MainService } from '../../_services/main.service';
import { history } from '../../_config';
import { State } from '../../store/reducers';
import getFormatedDate from '../../_config/getFormatedDate';
import Button from "../../_components/button.component";
import { useToasts } from 'react-toast-notifications';
import { LottieLoader } from '../../_components/lottie-loader.component';
import Joyride from 'react-joyride';
import { Link } from 'react-router-dom';
import { Checkbox } from '@material-ui/core';
import Feedback from 'react-bootstrap/esm/Feedback';
import FeedbackModal from './FeedbackModal';

export const MENTORQ_ROUTE = '/mentor-q';

const main = new MainService();

type P = {
    user: any,
};

const MentorQPage = ({ user }: P) => {
    let selectedCohortOld:any =  localStorage.getItem('selectedCohort');
    selectedCohortOld = selectedCohortOld ? JSON.parse(selectedCohortOld) :null; 

    const [loading, setLoading] = useState(false);
    const [cohorts, setCohorts] = useState([]);
    const [selectedCohort, setSelectedCohort] = useState<any>(selectedCohortOld);
    const [users, setUsers] = useState([]);
    const [feedbackmodal, setFeedBackModal] = useState(false);

       
     const [currentUser, setCurrentUser] = useState([]);

    const [showActivity, setShowActivity] = useState(false);

    // get mentor cohorts
    useEffect(() => {
        main.getMentorCohorts(user.token)
            .then(({ cohorts: c }) => {
                setCohorts(c);
            });
            getCohortStats()
    }, []);

    // load users in when selected cohort changes
    const getCohortStats =()=>{
        console.log({selectedCohort});
        
        if (selectedCohort ) {
            // setLoading(true);
            main.getCohortStatById(user.token, selectedCohort.id)
                .then(({ users: u }) => {
                    setUsers(u);
                });
        }
    }

    


    
    useEffect(() => {
        getCohortStats()
    }, [selectedCohort]);

    const addFeedBack = (user:any) => {
        
         setCurrentUser(user)
         setFeedBackModal(true)
      }
      const handleCloseTipsModal = () => {
        setFeedBackModal(false)
      }

    return (
        <>
            <TopNavigationBar />
            {/* main content */}
            <div className="main">
                <div className="container">
                    <div className="">
                        <h3>Mentor Q - Manage student reviews</h3>
                        {/* cohort selector */}
                        <div className="row">
                            <div className="col-md-6">
                                <div className="cohort-selector-holder">
                                    <select onChange={e => {
                                        const datum =cohorts.find((item:any)=>item.id ==e.target.value);
                                        setSelectedCohort(datum);
                                        localStorage.setItem('selectedCohort', datum ? JSON.stringify(datum):'')
                                    }}>
                                        <option>Select a cohort...</option>
                                        {
                                            cohorts.map((cohort: any, index: number) => (
                                                <option key={cohort.id} value={cohort.id} selected={selectedCohort && selectedCohort.id ==cohort.id}>Cohort - {cohort.name}</option>
                                            ))
                                        }
                                    </select>
                                </div>
                            </div>
                            <div className="col-md-6 text-right activity-toggle">
                                <Checkbox checked={showActivity} onChange={e => {
                                    setShowActivity(!showActivity);
                                }} /> <span onClick={e => {
                                    setShowActivity(!showActivity);
                                }}>Show activity</span>
                            </div>
                        </div>
                        <div className="user-list">
                            {/* selected cohort */}
                            {
                                selectedCohort ? (
                                    loading ? (
                                        <div className="text-center">
                                            <LottieLoader />
                                        </div>
                                    ) :
                                        (
                                            !loading && users.length > 0 ?
                                                <div className="table-responsive">

                                                    <table className="w-full">
                                                        <thead>
                                                            <tr>
                                                                <th className="text-sm" style={{ textAlign: 'left', paddingLeft: "5px" }}>Student</th>
                                                                <th className="text-sm" style={{ textAlign: 'left', paddingLeft: "5px" }}>Student Email</th>
                                                                {
                                                                    showActivity ? <th className="text-sm">Videos Recorded</th> : <></>
                                                                }
                                                                <th className="text-sm">Asked For Review</th>
                                                                <th className="text-sm">Reviews Completed</th>
                                                                {/* <th>Overall Feedback</th> */}
                                                            </tr>

                                                        </thead>
                                                        <tbody>
                                                            {
                                                                Array.isArray(users) && users.length ? users.map((user: any, index: number) => {
                                                                    return (
                                                                        <MentorQRow user={user} key={index} showActivity={showActivity} addFeedBack={addFeedBack} />
                                                                    )
                                                                }) : null
                                                            }
                                                        </tbody>
                                                    </table>
                                                </div> : (
                                                    <div>No users available here</div>
                                                )
                                        )
                                ) : (
                                    <div>
                                        Please select a cohort first!
                                    </div>
                                )
                            }
                        </div>
                    </div>
                </div>
            </div>
           {feedbackmodal &&  <FeedbackModal handleClose={handleCloseTipsModal} data={currentUser} />}
        </>
    )
}

function MentorQRow({ user, showActivity,addFeedBack }: any) {

    const [showDropDown, setShowDropDown] = useState(false);

    return (
        <tr>
            <td style={{ width: '30%', textAlign: 'left' }}>
                {user.FirstName} {user.LastName}
            </td>
            <td style={{ textAlign: 'left' }}>{user.userId}</td>
            {showActivity ? <td>{user.videosRecorded}</td> : <></>}
            <td>
                {
                    user.reviewsAsked != 0 && !user.reviewAsked ? (
                        <Link to={"/interview/external-review/" + user.interviewReviewLogs.map((i: any) => i.videoId).join("-")}>
                            {user.reviewsAsked}
                        </Link>
                    ) : user.reviewsAsked
                }
            </td>
            <td>
                {user.reviewsCompleted > 0 ?  <Link to={"/interview/external-review/" + user.interviewReviewLogs.map((i: any) => i.videoId).join("-")}>
                    {user.reviewsCompleted}
                </Link> : user.reviewsCompleted}

            </td>
            <td onClick={()=>{addFeedBack(user)}}>
                <span className="overFeedback">Feedback</span>
            </td>
           
        </tr>
    )
}

export default MentorQPage
