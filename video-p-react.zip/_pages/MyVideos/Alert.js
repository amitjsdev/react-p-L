import React from "react";
import "./AllCompleteAlert.scss";
const Alert = ({ children, close, closeText = "Ok", alertMsg }) => {
  return (
    <div className="SkipModal">
      <div className="modal-body">
        {alertMsg ? (
          <>
            <h5 className="text-center">
             You have selected
              {alertMsg &&
                alertMsg.length > 0 &&
                alertMsg.map((item, index) => {
                  return (
                    <span>
                      {" "}
                      Q{item.seqNo}.
                      {alertMsg.length > 1 &&
                        index + 1 < alertMsg.length &&
                        ","}{' '}
                    </span>
                  );
                })}
                more than once.
            </h5>
            <p className="text-center">Please select your best answer to submit.     </p>
          </>
        ) : (
          children
        )}
        <div className="d-flex justify-center">
          <button
            className="continue-exam-button"
            style={{ padding: "0px 24px" }}
            onClick={() => {
              close("");
            }}
          >
            {closeText}
          </button>
        </div>
      </div>
    </div>
  );
};
export default Alert;
