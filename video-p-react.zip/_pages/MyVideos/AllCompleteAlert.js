import React, { useEffect, useState } from "react";
import "./AllCompleteAlert.scss";
import Button from "../../_components/button.component";

const AllCompleteAlert = ({
  selectAll,
  ids,
  close,
  lessons,
  previousAttempts,
  history,
  recordedAnswer,
  uuidArray,
  questionsArray,
  setAskForReview,
  ask
}) => {
  ids = ids.map((id) => id.split("_")[1]);
  const [checkBtn, setCheckBtn] = useState(false);
  const [quesNewArray, setQuesNewArray] = useState([]);

  const onHandleClick = () => {
    close(false)
if(questionsArray && questionsArray.length > 0){
  setAskForReview(true)

}else{
  ask(null, null, null)
}
  };

  useEffect(() => {
    checkSelectedQues();
  }, [questionsArray]);

  const checkSelectedQues = () => {
    let newArray = [];
    questionsArray &&
      questionsArray.length > 0 &&
      questionsArray.map((item) => {
        newArray.push(item.split("_")[0]);
      });
    setQuesNewArray(newArray);
    var isDuplicate = questionsArray.filter(function (item, idx) {
      return questionsArray.indexOf(item) != idx;
    });

    let btn = false;
    lessons.map((item) => {
      if (!btn) {
        if (!newArray.includes(item?.lesson_no.toString())) {
          btn = true;
          setCheckBtn(true);
        }

        //   console.log('setCheckBtn--',btn)
        // let find = newArray.find((datum) => datum == item.lesson_no);
        // if (!find) {
        //     console.log('setCheckBtn--find',find,btn)
        //   btn = true;
        //   setCheckBtn(true);
        // }
      }
    });
  };
  return (
    <div className="SkipModal">
      <div className="sidebar">
        <div className="headerCotent">
        <h6
          style={{
            textAlign: "center",
            padding: "10px",
            fontWeight: "bold",
            fontSize: '15px',
          }}
        >
          {/* {selectAll ? 'Please select all lession ' : 'Please answer all question before Submitting'} */}
          We recommend you to submit the videos  for review in a single request or as instructed by your mentor.
          
        </h6>
        <button style={{ float: "right",marginBottom: '16%'}} onClick={() => close(false)}>
            x
          </button>
</div>
        <div class="ques-container">
          Recorded
          <input type="checkbox" checked={true} />
          <span class="ques-checkmark"></span>
        </div>

        <div class="ques-container">
          Selected for submission
          <input type="checkbox" checked={true} />
          <span class="ques-sub-checkmark"></span>
        </div>
        <div>
          {lessons.map((item, index) => {
            let find = previousAttempts.find(
              (datum) => datum.lesson.id === item.id
            );
            return (
              <div
                className="topic"
                key={item.id}
                onClick={() => history.push(`practice/${item.lesson_no}`)}
              >
                Q.{index + 1} {item.practiceSetQuestion}
                {recordedAnswer.includes(item?.practiceSetQuestion) && (
                  <div class="ques-container">
                    <input type="checkbox" checked={true} />
                    <span class="ques-checkmark"></span>
                  </div>
                )}
                {console.log(
                  "includes--",
                  quesNewArray.find((item) => item == item?.lesson_no),
                  item?.lesson_no,
                  quesNewArray.includes(item?.lesson_no)
                )}
                {quesNewArray.includes(item?.lesson_no.toString()) && (
                  <div class="ques-container">
                    <input type="checkbox" checked={true} />
                    <span class="ques-sub-checkmark"></span>
                  </div>
                )}
                {/* <div>
                                {!!find ? <div className="lesson-completed-icon flex-shrink-0">
                                    <span className="checkmark">
                                    <div className="checkmark_circle"></div>
                                    <div className="checkmark_stem"></div>
                                    <div className="checkmark_kick"></div>
                                </span></div> : <div className="lesson-incomplete-icon flex-shrink-0"></div>}
                                {selectAll && ids && ids.includes(item.id.toString()) && <div style={{ fontSize: 12 }}>selected</div>}
                            </div> */}
              </div>
            );
          })}
        </div>
        <div className="contnBtn text-center">
          {" "}
          <Button
            handleClick={onHandleClick}
            text="Continue"
            className={checkBtn ? "disableBtn" : ""}
            color="primary"
          />
        </div>
      </div>
    </div>
  );
};
export default AllCompleteAlert;
