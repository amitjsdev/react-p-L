import React from 'react'
import { Button, Modal } from 'react-bootstrap'
import { CDN_URL } from '../../../constant';

const DeleteModal = (props: { show: boolean, handleClose: () => void, handleDelete:()=>void ,attempt:any}) => {
    // const attempt = useSelector((state: State) => state.attempt.currentAttempt)
    const { filePath } = props.attempt
    console.log({filePath});
    
    return (
        <Modal centered show={props.show} onHide={props.handleClose}>
            <Modal.Header closeButton style={{ border: 'none' }} />
            <Modal.Body>
                <div className="text-center font-bold">Are you sure you want to delete this video ?</div>
                <div className="col-md-12 d-flex justify-content-center py-5 border">
                                <video controls height="200" width="400" src={CDN_URL+'/uploads/' + filePath}></video>
                            </div>
            </Modal.Body>
            <Modal.Footer style={{ alignSelf: 'center' }}>
                <Button style={{ background: '#206735', width: '150px', borderRadius: '40px', borderColor: '#a3b5c9' }} onClick={props.handleDelete}>
                    Yes
                </Button>
            </Modal.Footer>
        </Modal>
    )
}

export default DeleteModal
