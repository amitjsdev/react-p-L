import React, { useEffect, useState } from 'react'
import { Dropdown, DropdownButton } from 'react-bootstrap';
import { Spinner, TopNavigationBar } from '../../_components';
import { ReactComponent as Star } from './start_icon.svg';
import "./MyVideos.scss";
import { MainService } from '../../_services/main.service';
import { history } from '../../_config';
import DeleteModal from './Delete/DeleteModal';
import { useDispatch, useSelector } from 'react-redux';
import { State } from '../../store/reducers';
import getFormatedDate from '../../_config/getFormatedDate';
import Button from "../../_components/button.component";
import { useToasts } from 'react-toast-notifications';
import { LottieLoader } from '../../_components/lottie-loader.component';
import Joyride from 'react-joyride';
import { ReviewModal } from './review-modal/review-modal';
import ShareForReviewModal from './share-for-review-modal/share-for-review.modal';
import Lottie from 'react-lottie';
import loaderAnimation from '../../_assets/lottie/driving.json';
import HelpText from '../../_components/HelpText';
import AllCompleteAlert from './AllCompleteAlert';
import Alert from './Alert';
import { CDN_URL } from '../../constant';
import { PRACTICE_SET } from '../PracticeSet/PracticeSetPage';
import Mp3Player from '../../_components/Mp3Player';
import VideoReview from '../../_components/VideoReview';

export const MYVIDEOS_ROUTE = '/myvideos';

const main = new MainService();
const queryParams = new URLSearchParams(window.location.search);
const reviewVideoId = queryParams.get('videoId');
type P = {
  user: any,
};

const MyVideosPage = () => {


  // all the states
  const [videoId, setVideoId] = useState(reviewVideoId);
  const [AllCompleteShow, setAllCompleteShow] = useState(false);
  const [AllCompleteShowAllLession, setAllCompleteShowAllLession] = useState(false);
  const [videoAudioModal, setVideoAudioModal] = useState<any>(null);
  const [alertMsg, setAlert] = useState('');
  const dispatch = useDispatch()
  const { addToast } = useToasts();
  const [attempt, setAttempt] = useState<any>();
  const showSelfReviewModal = useSelector((state: State) => state.modal?.show)
  let [previousAttempts, setpreviousAttempts] = useState<any>([])
  const [recordedAnswer, setRecorderAnswer] = useState<any>([])


  const [loading, setloading] = useState(false);
  const [moduleName, setmoduleName] = useState();
  const [lessons, setLessons] = useState([]);
  // review related
  const [showReviewModal, setShowReviewModal] = useState<boolean>(false);
  const [reviewIsExternal, setReviewIsExternal] = useState<boolean>(false);

  const [askForReview, setAskForReview] = useState(false);
  const [showDeleteModal, setdeleteModal] = useState(false);
  const [NoModuleError, setNoModuleError] = useState(false);
  const user = JSON.parse(localStorage.getItem('user') || '{}')
  const [token, setToken] = useState<any>()
  const [previousSelfReview, setPreviousSelfReview] = useState<any>() // previously give self review data
  const [otherReview, setotherReview] = useState(false)


  const [questionsArray, setQuestionArray] = useState<Array<string>>([]);

  const [uuidArray, setUuidArray] = useState<Array<string>>([]);
  const [SelectedIdsArray, setSelectedIdsArray] = useState<Array<string>>([]);
  const module = useSelector((state: State) => state.module as any)
  const [noPracticeSetIsSelected, setNoPracticeSetIsSelected] = useState(false);

  const setSelectedIdsArrayHandler = (item: any, removeIt=false) => {
    const str = `${item.id}_${item.lesson.id}`;
    if (removeIt || SelectedIdsArray.includes(str)) {
      const arr = SelectedIdsArray.filter((it: string) => it !== str)
      setSelectedIdsArray(arr)
    } else {
      let arr = SelectedIdsArray;
      arr.push(str)
      setSelectedIdsArray(arr)
    }
  }

  useEffect(() => {
    if (!module.moduleNumber) {
      setNoModuleError(true);
      return;
    }
    // load lessons for module
    setloading(true);
    main.getAllPracticeSets(module.moduleNumber, user.token)
      .then(response => {
        if (response.message) {
          return setNoPracticeSetIsSelected(true);
        }
        setmoduleName(response.module);
        setLessons(response.lessons);
        setloading(false);
      })
      .catch(err => {
        addToast("Something went wrong, please refresh from  !", { appearance: 'error', autoDismiss: true });
        console.log({
          err
        });
      })
  }, []);

  // LOAD THE PREVIOUS ATTEMPTS
  useEffect(() => {
    if (user.token) {
      loadPreviousAttempts();
    }
  }, [user.token]);

  // handle the selection of videos
  const handleSelect = (uuid: string, lessonName: string, lessonId: string, sequenceNo: number) => {
    if (!uuidArray.includes(uuid)) {
      setUuidArray([...uuidArray, uuid]);
    } else {
      // remove it from the list
      const newUuidArray = [...uuidArray];
      newUuidArray.splice(newUuidArray.indexOf(uuid), 1);
      setUuidArray(newUuidArray);
    }
   
    let selectedQues = lessonId + '_' + lessonName + '=' + sequenceNo + '=' + uuid;
    if (!questionsArray.includes(selectedQues)) {
      setQuestionArray([...questionsArray, selectedQues]);
    } else {
      // remove it from the list
      const newquestionsArray = [...questionsArray];
      newquestionsArray.splice(newquestionsArray.indexOf(selectedQues), 1);
      // insert new
      setQuestionArray(newquestionsArray);
    }
    setAlert('')
    //  ask(null, null, null)
  }

  // api to load all previous attempts
  const loadPreviousAttempts = async () => {
    // load previous attempts
    setloading(true)
    main.getAllPreviousAttempts(user.token)
      .then(response => {
        let responseList = response.attempts
        let answerList: any = []
        setpreviousAttempts(responseList);

        responseList.length > 0 && responseList.map((item: any) => {
          answerList.push(item.lessonName)
        })
        const uniqueChars = answerList.filter((v: any, i: any, a: any) => a.findIndex((t: any) => t === v) === i);
        setRecorderAnswer(uniqueChars);
        setloading(false)
      })
      .catch(err => {
        addToast("Something went wrong, please refresh!", { appearance: 'error', autoDismiss: true });
        console.log({
          err
        });
      })
  }



  // helper to generate the ai rating medal
  const getAiRatingMedal = (reviewAverage = 1, attempt: any) => {

    if (reviewAverage > 4) {
      return (
        <a className="text-center cursor-pointer" href={"/ai-feedback/" + attempt.uuid}>
          <img src="/_assets/badge_icons/gold.png" alt="" width="48px" className="m-auto" />
        </a>
      );
    }

    if (reviewAverage > 3) {
      return (
        <a className="text-center cursor-pointer" href={"/ai-feedback/" + attempt.uuid}>
          <img src="/_assets/badge_icons/silver.png" alt="" width="48px" className="m-auto" />
        </a>
      );
    }

    if (reviewAverage > 2) {
      return (
        <a className="text-center cursor-pointer" href={"/ai-feedback/" + attempt.uuid}>
          <img src="/_assets/badge_icons/bronze.png" alt="" width="48px" className="m-auto" />
        </a>
      );
    }

    return (
      <a className="text-center cursor-pointer" href={"/ai-feedback/" + attempt.uuid}>
        <img src="/_assets/badge_icons/basic.png" alt="" width="48px" className="m-auto" />
      </a>
    );
  }

  // react joyride related
  const [showJoyride, setShowJoyride] = useState<boolean>();
  useEffect(() => {
    setShowJoyride(localStorage.getItem('joyride-show.myvideopage') ? false : true);
  }, []);
  useEffect(() => {
    // hide the joyride now
    if (showJoyride) {
      localStorage.setItem('joyride-show.myvideopage', "true");
    }
  }, [showJoyride]);


  const deleteVideo = async () => {
    if (attempt && attempt.uuid) {

      const isDeleted: any = await main.deleteVideo(user.token, attempt.uuid);

      if (isDeleted && isDeleted.status) {
        setSelectedIdsArrayHandler(attempt, true)
        const remaining = previousAttempts.filter((item: any) => item.uuid !== attempt.uuid)
        setpreviousAttempts(remaining)
        addToast("The video was successfully deleted", { appearance: 'success', autoDismiss: true });
      } else {
        addToast("Something went wrong, please retry", { appearance: 'error', autoDismiss: true });
      }
      setdeleteModal(false);


    }
  }

  // // update the attempt
  // const updateAttempt = (attempt: any) => {
  //   // go through previous attempts and try to find the one we need
  //   const attemptIndex = previousAttempts.findIndex((pA: any) => pA.id == attempt.attempt.id);
  //   console.log({ attempt, attemptIndex, aid: attempt.attempt.id, pAID: previousAttempts[0].id });
  //   // update if found
  //   if (attemptIndex > -1) {
  //     const newAttempts = [...previousAttempts];
  //     newAttempts.splice(attemptIndex, 1, attempt.attempt);
  //     setpreviousAttempts(newAttempts);
  //   }
  // };

  // trigger open modal

  const openModal = (name: string, attempt?: any, showExternal?: boolean) => {
    if(name ==='review'){
      setVideoAudioModal(attempt);
      return;
    }

    // if its a self review modal to be shown
    if (name === "selfreview") {
      // if external flag is on, show it
      if (showExternal) {
        setReviewIsExternal(true);
      }
      setShowReviewModal(true);
      // get the review details needed
      setAttempt(attempt);
    }
    if (name === "delete") {
      setAttempt(attempt);
      setdeleteModal(true)
    }
  }

  // update the attempt
  const updateAttempt = (attempt: any) => {
    // go through previous attempts and try to find the one we need
    const attemptIndex = previousAttempts.findIndex((pA: any) => pA.id == attempt.id);
    // update if found
    if (attemptIndex > -1) {
      const newAttempts = [...previousAttempts];
      newAttempts.splice(attemptIndex, 1, attempt);
      setpreviousAttempts(newAttempts);
    }
  };
  // console.log(lessons,previousAttempts);
  const checkAllLessionAttempted = () => {
    if (lessons && lessons.length > 0) {
      let attempts = lessons.filter((lession: any) => {
        const find = previousAttempts.find((item: any) => item.lesson.id === lession.id)
        return !!find;
      })
      return attempts.length === lessons.length;
    }
    return false;

  }

  const isAllCompleted = checkAllLessionAttempted();
  const ids = SelectedIdsArray.map((id) => id.split('_')[1]);
  let duplicate = false;
  ids.forEach((idd) => {
    const multi = ids.filter((iddd) => iddd === idd);
    if (multi && multi.length > 1) {
      duplicate = true;
    }
  });

  const checkAnyVideohasReview = () => {
    const any = previousAttempts.every((att: any) => {
      if (att && att.external_rating.length > 0) {
        return false;
      }
      return true;
    });
    return !any;
  }

  const ask = (att: any, callback: any, callbackParams: any) => {
    let newArray: any = [];
    let newArrayData: any = [];
    questionsArray && questionsArray.length > 0 && questionsArray.map((item: any) => {
      newArray.push(item.split('=')[0])
    })

    var isDuplicate = newArray.filter(function (item: any, idx: any) {
      return newArray.indexOf(item) != idx;
    });

    questionsArray && questionsArray.length > 0 && questionsArray.map((item: any) => {
      newArrayData.push({ ques: item.split('=')[0], seqNo: item.split('=')[1] })
    })


    //find unique values data
    let uniqueChars = isDuplicate.filter((c: any, index: number) => {
      return isDuplicate.indexOf(c) === index;
    });

    let repeatedData: any = [];
    uniqueChars &&
      uniqueChars.length > 0 &&
      uniqueChars.forEach((val: any) => {
        repeatedData.push(newArrayData.find((item: any) => item.ques == val));
      });

    if (!att && uuidArray.length === 0) {
      addToast('Please select atleast one video!');
      return;
    }
    else if (repeatedData && repeatedData.length > 0) {
      setAlert(repeatedData)
      return;
    }
    else if (!isAllCompleted) {
      setAllCompleteShowAllLession(false)
      setAllCompleteShow(true)
    } else if (duplicate) {
      addToast('Select Unique lession');

      return;
    } else {
      const anyHaveReview = checkAnyVideohasReview();
      console.log({ anyHaveReview });

      if (!anyHaveReview && lessons.length !== SelectedIdsArray.length) {
        setAllCompleteShow(true)
        setAllCompleteShowAllLession(true)
        return;
      } else if (!anyHaveReview && lessons.length === SelectedIdsArray.length) {
        setAskForReview(true);
      } else if (anyHaveReview) {
        if (att) {
          setUuidArray([att.uuid]);
        }
        setAskForReview(true);
      }

    }


  }

  const closeNoModuleError = () => {
    setNoModuleError(false)
    history.push('/practice-set')
  }
  const order:any ={};
  let indexForOrder=0;
  previousAttempts =previousAttempts.sort((a:any,b:any) =>a.lesson.id -b.lesson.id)
  previousAttempts =previousAttempts.map((a:any) =>{
    if(!order[a.lesson.id]){
      order[a.lesson.id] =indexForOrder+1;
      indexForOrder++;
    }
    return {...a,sn:order[a.lesson.id]}
  })

  return (
    <>
          {/* show alert if no practice set is there */}
          {
        noPracticeSetIsSelected ? (
          <Joyride steps={[
            {
              disableBeacon: true,
              target: '.home-link',
              content: 'Please select a practice page first.'
            },
          ]}
            callback={data => {
              if (data.action === "reset") {
                // redirect back to practice set page
                history.push(PRACTICE_SET);
              }
            }}
            locale={{
              last: "Got it",
              close: "Got it"
            }}
            hideBackButton
            styles={{
              options: {
                arrowColor: "#713CFB",
                backgroundColor: "#713CFB",
                textColor: "#FFF",
                primaryColor: '#FFF3',
              }
            }}
            disableScrolling continuous />
        ) : <></>
      }
      {
        previousAttempts.length > 0 && !loading && showJoyride ? (
          <Joyride steps={[
            {
              disableBeacon: true,
              target: '.myvideos-videopreview',
              content: 'Click here to show the video preview.'
            },
            {
              target: '.self-review-button',
              content: 'Tap on this button to do the self review.'
            },
          ]}
            locale={{
              last: "Got it",
              close: "Got it"
            }}
            hideBackButton
            styles={{
              options: {
                arrowColor: "#713CFB",
                backgroundColor: "#713CFB",
                textColor: "#FFF",
                primaryColor: '#FFF3',
              }
            }}
            disableScrolling continuous />
        ) : <></>
      }
      <TopNavigationBar />
      {/* main content */}
      {AllCompleteShow &&
        <AllCompleteAlert
        ask={ask}
         setAskForReview={setAskForReview}
          questionsArray={questionsArray}
          uuidArray={uuidArray}
          recordedAnswer={recordedAnswer}
          selectAll={AllCompleteShowAllLession}
          history={history}
          ids={SelectedIdsArray}
          close={setAllCompleteShow}
          lessons={lessons}
          previousAttempts={previousAttempts}
        />}
      {alertMsg && <Alert alertMsg={alertMsg} close={setAlert}>
       
      </Alert>}
      {NoModuleError && <Alert alertMsg={''} close={closeNoModuleError} >
        <h5 className="text-center">Please select a practice set</h5>
      </Alert>} 
      {videoAudioModal && <Alert alertMsg={''} close={setVideoAudioModal} closeText="Close">
        <h6 style={{textAlign:'center', fontWeight:'bold'}}>Audio / Video Review</h6>
        {videoAudioModal.external_rating.map((item:any) => <div style={{margin:5}}>
          {item.audio ? <Mp3Player url={item.audio} /> : null }
          {item.video ? <VideoReview video={null} setVideo={() =>{}} canRecord={false} id={item.id } key={item.id} videoDb={item.video} /> : null }
        </div>)}
      </Alert>}
      <div className="main">
        <div className="my-videos">
          <div className="d-flex">
            <h1 className="flex-grow-1 mb-5 ml-3 font-bold">My Videos</h1>
            <div className="w-50 text-right">
              <Button text="Submit" color="primary" handleClick={() => ask(null, null, null)} />
            </div>
          </div>
          {previousAttempts.length === 0 && !loading ?
            <div>

              <h3 className="text-center py-5">Please Record a video first</h3>
              <h4 className="text-center cursor-pointer" style={{ color: 'blue' }} onClick={() => history.push('/practice')}>Record</h4>
            </div> : null}
          {loading ? <h3 className="text-center py-5">Searching....</h3> : !loading && previousAttempts.length > 0 ?
            <div className="table-responsive video_table">

              <table className="w-full">
                <thead>
                  <tr>
                    <th></th>
                    <th className="text-sm">Videos</th>
                    <th className="text-sm">Date</th>
                    <th className="text-sm">Self Review</th>
                    <th className="text-sm">Instructor Review</th>
                    {/* <th className="text-sm">Audio/Video Review</th> */}
                    <th className="text-sm">Ai Review</th>
                   
                    <th className="text-sm"></th>
                  </tr>

                </thead>
                <tbody>
                  {previousAttempts ? previousAttempts.map((attempt: any, index: number) => (
                    <AttemptRow
                      sequenceNo={index}
                      ask={ask}
                      duplicate={duplicate}
                      isAllCompleted={isAllCompleted}
                      setAllCompleteShow={setAllCompleteShow}
                      videoId={videoId}
                      attempt={attempt}
                      uuidArray={uuidArray}
                      handleSelect={handleSelect}
                      openModal={openModal}
                      setUuidArray={setUuidArray}
                      setSelectedIdsArray={setSelectedIdsArrayHandler}
                      getAiRatingMedal={getAiRatingMedal}
                      user={user}
                      updateAttempt={updateAttempt} />
                  )) : null}
                </tbody>
              </table>
            </div> : null}
          {loading ? (
            <div className="text-center">
              <LottieLoader />
            </div>
          ) : null}
          {/* review detail modal, for self and external */}
          <ReviewModal
            mentor={false}
            user={user}
            reviewIsExternal={reviewIsExternal}
            setReviewIsExternal={setReviewIsExternal}
            show={showReviewModal}
            setShowReviewModal={setShowReviewModal}
            // aiFeedback={() => {
            //   window.location.href = "/ai-feedback/" + attempt.uuid;
            // }}
            attempt={attempt}
            updateSelfReview={(review: any) => {
              const newAttempt = { ...attempt };
              newAttempt.self_review = review;
              const reviewParameters = Object.values(review.reviewJSON) as Array<number>;
              newAttempt.self_rating_avg = (reviewParameters.reduce((a: any, b: any) => (a + b), 0) as number) / reviewParameters.length;
              setAttempt(newAttempt);
              // update the attempt in list as well
              updateAttempt(newAttempt);
            }}
          />
          {/* share for review modal */}
          {
            askForReview ? (
              <ShareForReviewModal
                handleClose={() => {
                  // close the modal
                  setAskForReview(false);
                }}
                token={user.token}
                uuidsArray={uuidArray} />
            ) : <></>
          }

          {
            showDeleteModal ? (
              <DeleteModal
                attempt={attempt}
                handleClose={() => {
                  // close the modal
                  setdeleteModal(false);
                }}
                handleDelete={deleteVideo}
                show={showDeleteModal}
              />
            ) : <></>
          }
        </div>
      </div>
    </>
  )
}

function getReviewStatusText(reviewStatus = 1, debugInfo = "") {
  switch (reviewStatus) {
    case 0:
      return <span style={{ color: "gray" }}>Not Started</span>;
      break;
    case 1:
      return <span style={{ color: "blue", display: "flex", alignItems: "center" }}>

        <Lottie options={{
          loop: true,
          autoplay: true,
          animationData: loaderAnimation,
          rendererSettings: {
            preserveAspectRatio: "xMidYMid slice"
          }
        }}
          width={48}
          height={48} />
        <span style={{ paddingRight: "10px" }}>AI Review on it's way</span></span>;
      break;
    case 2:
      return <span style={{ color: "green" }}>Success</span>;
      break;
    case 3:
      return (
        <HelpText placement="top-start" title={debugInfo} altIcon>
          <span style={{ color: "#aaa" }}>AI Review not available</span>
        </HelpText>
      );
      break;

    default:
      return "";
      break;
  }
}

interface MVVPP {
  openModal: any;
  attempt: any;
  sequenceNo: number;
}

function MyVideosVideoPreview({ openModal, attempt, sequenceNo }: MVVPP) {
  return (
    <div className="myvideos-videopreview flex cursor-pointer items-center" onClick={() => openModal("selfreview", attempt)}>
      <div className="video-holder">
        <div className="play-button-holder">
          <span className="play-button"></span>
        </div>
        <video width="150" height="140" src={CDN_URL + '/uploads/' + attempt.filePath} className="rounded-xl"></video>
      </div>
      <div className="pl-3">
        <div className="fontWt my-2">
         <div> Q{attempt.sn}.</div> <div>{attempt.lessonName}</div></div>
        {/* <p style={{ fontWeight: 'normal' }}></p> */}
      </div>
    </div>
  );
}

type ARP = {
  sequenceNo: number,
  setSelectedIdsArray: Function,
  isAllCompleted: boolean,
  setAllCompleteShow: Function,
  ask: Function,
  videoId: any,
  attempt: any,
  handleSelect: Function,
  uuidArray: Array<any>,
  openModal: Function,
  setUuidArray: Function,
  getAiRatingMedal: Function,
  user: any,
  updateAttempt: Function,
  duplicate: boolean,
}

/**
 * Create the attempt row in table
 * @param param0 
 * @returns 
 */
function AttemptRow({ ask, duplicate, setSelectedIdsArray, isAllCompleted, setAllCompleteShow, videoId, attempt, handleSelect, uuidArray, openModal, setUuidArray, getAiRatingMedal, user, updateAttempt, sequenceNo }: ARP) {
  const { self_rating_avg, external_rating_avg, ai_rating_avg, reviewStatus ,external_rating} = attempt;
  const anyAudio =external_rating ? external_rating.find((item:any)=> item.audio) : null;
  const anyVideo =external_rating ? external_rating.find((item:any)=> item.video) : null;
  const hasReview =anyAudio || anyVideo || external_rating_avg;
  const [isCheckingForUpdate, setIsCheckingForUpdate] = useState<boolean>(false);

  // check for update
  useEffect(() => {
    // if we are in processing state and not already checking for update
    if (reviewStatus == 1) {
      const interval = setInterval(() => {
        main.getPrevAttemptByuuid(attempt.uuid, user.token)
          .then(({ attempt: a }) => {
            if (a.reviewStatus != 1) { // if review is processed dont bother check again
              // update the review so that interval stops
              updateAttempt(a);
            }
          })
          .catch(e => {
            console.log("check for update of status failed", e);
          });
      }, 5000);

      return () => {
        window.clearInterval(interval);
      };
    }
  }, [reviewStatus]);
  // some new test code

  return (
    <tr key={attempt.uuid}>
      <td className="px-2" onClick={() => { handleSelect(attempt.uuid, attempt.lessonName, attempt.lessonNo, attempt.sn); setSelectedIdsArray(attempt) }}>
        <span style={{
          width: "21px",
          height: "21px",
          display: "block",
          borderRadius: "50%",
          border: "1px solid black",
          padding: "2px",
          cursor: "pointer",
        }}>
          {
            uuidArray.includes(attempt.uuid) ? <span
              style={{
                width: "15px",
                height: "15px",
                display: "block",
                borderRadius: "50%",
                background: "black",
              }}
            ></span> : <></>
          }
        </span>
      </td>
      <td style={{ width: '30%' }}>
        <MyVideosVideoPreview sequenceNo={sequenceNo} openModal={openModal} attempt={attempt} />
      </td>
      <td>
        <p style={{ fontWeight: 'normal', marginBottom: "0" }}>{getFormatedDate(attempt.created_at)}</p>
      </td>
      {/* self rating */}
      <td>
        {/* <div className={attempt.self_rating === null ? "no-review":"self-review"}> */}
        {
          self_rating_avg ? (
            <div className={self_rating_avg ? self_rating_avg <= 2 ? "review-red cursor-pointer" : self_rating_avg <= 3 ? "review-yellow cursor-pointer" : "review-green cursor-pointer" : "ai-review NA cursor-pointer"} onClick={() => openModal('selfreview', attempt)}>
              <div className="">
                {self_rating_avg ? <Star /> : <div className="circle cursor-pointer"></div>}
              </div>
              <div className="ml-2">
                {attempt.self_rating_avg.toFixed(2)}
              </div>
            </div>
          ) : (
            <div style={{ fontWeight: "lighter", color: "#1A43F0", cursor: "pointer", textAlign: "center" }} className="self-review-button" onClick={() => openModal("selfreview", attempt)}>Do Now</div>
          )
        }

      </td>
      {/* <td>
       
        {
          external_rating_avg ? (
            <div className={external_rating_avg ? external_rating_avg <= 2 ? "review-red cursor-pointer" : external_rating_avg <= 3 ? "review-yellow cursor-pointer" : "review-green cursor-pointer" : "ai-review NA cursor-pointer"} onClick={() => openModal('selfreview', attempt, true)}>
              <div className="">
                {external_rating_avg ? <Star /> : <div className="circle cursor-pointer"></div>}
              </div>
              <div className="ml-2">
                {external_rating_avg === null ? "NA" : external_rating_avg.toFixed(2)}
              </div>
            </div>
          ) : (
            <div style={{ fontWeight: "lighter", color: "#1A43F0", cursor: "pointer", textAlign: "center" }} onClick={() => ask(attempt)}>Ask</div>
          )
        }
        {attempt?.id == videoId && <span style={{ color: 'red' }}>New</span>}
      </td> */}
      {/* external rating */}
      <td>
        {hasReview  ? 
       <div style={{ fontWeight: "lighter",  cursor: "pointer", textAlign: "center" }} onClick={() => openModal('selfreview', attempt, true)}><button style={{color: "white",backgroundColor:'#1F5842', padding:'10px 20px'}}>Review</button> </div> :(
        <div style={{ fontWeight: "lighter", color: "#1A43F0", cursor: "pointer", textAlign: "center" }} onClick={() => ask(attempt)}>Ask</div>
      )}
       
      </td>
     
      {/* ai rating */}
      <td>
        { // show only if we have ai rating avg
          ai_rating_avg ? (
            getAiRatingMedal(ai_rating_avg, attempt)
          ) : (
            <span className="review-na">
              {getReviewStatusText(reviewStatus as number, attempt.debugInfo)}
            </span>
          )
        }
      </td>
      <td>
        <DropdownButton id="dropdown-basic-button" title="Actions">
          <Dropdown.Item onClick={() => openModal("selfreview", attempt)}>Self review</Dropdown.Item>
          <hr />
          <Dropdown.Item onClick={() => ask(attempt, openModal, "askForReview")}>Ask for review</Dropdown.Item>
          <hr />
          <Dropdown.Item onClick={() => history.push(`/practice/${attempt.lessonNo}`)}>Re-record</Dropdown.Item>
          <hr />
          <Dropdown.Item onClick={() => openModal("delete", attempt)}>Delete</Dropdown.Item>
        </DropdownButton>
      </td>
    </tr>
  )
}

export default MyVideosPage
