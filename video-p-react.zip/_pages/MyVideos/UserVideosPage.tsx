import React, { useEffect, useState } from 'react'
import { TopNavigationBar } from '../../_components';
import { ReactComponent as Star } from './start_icon.svg';
import "./MyVideos.scss";
import { MainService } from '../../_services/main.service';
import { useDispatch, useSelector } from 'react-redux';
import { State } from '../../store/reducers';
import getFormatedDate from '../../_config/getFormatedDate';
import { useToasts } from 'react-toast-notifications';
import { LottieLoader } from '../../_components/lottie-loader.component';
import { ReviewModal } from './review-modal/review-modal';
import { CDN_URL } from '../../constant';

const main = new MainService();

type P = {
  user: any,
};

const UserVideosPage = (props:any) => {
  const email =props.match.params.email;
  

  // all the states
  const dispatch = useDispatch()
  const { addToast } = useToasts();
  const [attempt, setAttempt] = useState<any>();
  const showSelfReviewModal = useSelector((state: State) => state.modal?.show)
  const [previousAttempts, setpreviousAttempts] = useState<any>([])
  const [loading, setloading] = useState(false);

  // review related
  const [showReviewModal, setShowReviewModal] = useState<boolean>(false);
  const [reviewIsExternal, setReviewIsExternal] = useState<boolean>(false);
  const user = JSON.parse(localStorage.getItem('user') || '{}')
  const [previousSelfReview, setPreviousSelfReview] = useState<any>() // previously give self review data

  const [uuidArray, setUuidArray] = useState<Array<string>>([]);

  // LOAD THE PREVIOUS ATTEMPTS
  useEffect(() => {
    if (email) {
      loadPreviousAttempts();
    }
  }, [email]);

  // handle the selection of videos
  const handleSelect = (uuid: string) => {
    if (!uuidArray.includes(uuid)) {
      setUuidArray([...uuidArray, uuid]);
    } else {
      // remove it from the list
      const newUuidArray = [...uuidArray];
      newUuidArray.splice(newUuidArray.indexOf(uuid), 1);
      setUuidArray(newUuidArray);
    }
  }

  // api to load all previous attempts
  const loadPreviousAttempts = async () => {
    // load previous attempts
    setloading(true)
    main.getAllPreviousAttempts(user.token,email)
      .then(response => {
        setpreviousAttempts(response.attempts)
        setloading(false)
      })
      .catch(err => {
        addToast("Something went wrong, please refresh!", { appearance: 'error', autoDismiss: true });
        console.log({
          err
        });
      })
  }



  

  // react joyride related
  const [showJoyride, setShowJoyride] = useState<boolean>();
  useEffect(() => {
    setShowJoyride(localStorage.getItem('joyride-show.myvideopage') ? false : true);
  }, []);
  useEffect(() => {
    // hide the joyride now
    if (showJoyride) {
      localStorage.setItem('joyride-show.myvideopage', "true");
    }
  }, [showJoyride]);


  const openModal = (name: string, attempt?: any, showExternal?: boolean) => {
        setReviewIsExternal(true);
      setShowReviewModal(true);
      setAttempt(attempt);
  }

  // update the attempt
  const updateAttempt = (attempt: any) => {
    // go through previous attempts and try to find the one we need
    const attemptIndex = previousAttempts.findIndex((pA: any) => pA.id == attempt.id);
    // update if found
    if (attemptIndex > -1) {
      const newAttempts = [...previousAttempts];
      newAttempts.splice(attemptIndex, 1, attempt);
      setpreviousAttempts(newAttempts);
    }
  };

  return (
    <>
      <TopNavigationBar />
      {/* main content */}
      <div className="main">
        <div className="my-videos">
          <div className="d-flex">
            <h1 className="flex-grow-1 mb-5 ml-3 font-bold">{email} Videos</h1>
            
          </div>
          {loading ? <h3 className="text-center py-5">Searching....</h3> : !loading && previousAttempts.length > 0 ?
            <div className="table-responsive video_table">

              <table className="w-full">
                <thead>
                  <tr>
                    <th className="text-sm">Videos</th>
                    <th className="text-sm">Date</th>
                    <th className="text-sm">Instructor Review</th>
                  </tr>

                </thead>
                <tbody>
                  {previousAttempts ? previousAttempts.map((attempt: any, index: number) => (
                    <AttemptRow
                      attempt={attempt}
                      openModal={openModal}
                       />
                  )) : null}
                </tbody>
              </table>
            </div> : null}
          {loading ? (
            <div className="text-center">
              <LottieLoader />
            </div>
          ) : null}
          {/* review detail modal, for self and external */}
          <ReviewModal
            mentor={true}
            user={user}
            reviewIsExternal={reviewIsExternal}
            setReviewIsExternal={setReviewIsExternal}
            show={showReviewModal}
            setShowReviewModal={setShowReviewModal}
            attempt={attempt}
            updateSelfReview={(review: any) => {
              const newAttempt = { ...attempt };
              newAttempt.self_review = review;
              const reviewParameters = Object.values(review.reviewJSON) as Array<number>;
              newAttempt.self_rating_avg = (reviewParameters.reduce((a: any, b: any) => (a + b), 0) as number) / reviewParameters.length;
              setAttempt(newAttempt);
              updateAttempt(newAttempt);
            }}
          />
        </div>
      </div>
    </>
  )
}

interface MVVPP {
  openModal: any;
  attempt: any;
}

function MyVideosVideoPreview({ openModal, attempt }: MVVPP) {
  return (
    <div className="myvideos-videopreview flex cursor-pointer items-center" onClick={() => openModal("selfreview", attempt)}>
      <div className="video-holder">
        <div className="play-button-holder">
          <span className="play-button"></span>
        </div>
        <video width="150" height="140" src={CDN_URL+'/uploads/' + attempt.filePath} className="rounded-xl"></video>
      </div>
      <div className="pl-3 mr-5">
        <div className="font-bold my-2">{attempt.lessonName}</div>
        <p style={{ fontWeight: 'normal' }}></p>
      </div>
    </div>
  );
}

type ARP = {
  attempt: any,
  openModal: Function,
}

/**
 * Create the attempt row in table
 * @param param0 
 * @returns 
 */
function AttemptRow({ attempt,  openModal }: ARP) {
  const {  external_rating_avg } = attempt;
 

  return (
    <tr key={attempt.uuid}>
      <td style={{ width: '30%' }}>
        <MyVideosVideoPreview openModal={openModal} attempt={attempt} />
      </td>
      <td>
        <p style={{ fontWeight: 'normal', marginBottom: "0" }}>{getFormatedDate(attempt.created_at)}</p>
      </td>
      
      <td>
        {
          external_rating_avg ? (
            <div className={external_rating_avg ? external_rating_avg <= 2 ? "review-red cursor-pointer" : external_rating_avg <= 3 ? "review-yellow cursor-pointer" : "review-green cursor-pointer" : "ai-review NA cursor-pointer"} onClick={() => openModal('selfreview', attempt, true)}>
              <div className="">
                {external_rating_avg ? <Star /> : <div className="circle cursor-pointer"></div>}
              </div>
              <div className="ml-2">
                {external_rating_avg === null ? "NA" : external_rating_avg.toFixed(2)}
              </div>
            </div>
          ) : null
        }
      </td>
     
    </tr>
  )
}

export default UserVideosPage
