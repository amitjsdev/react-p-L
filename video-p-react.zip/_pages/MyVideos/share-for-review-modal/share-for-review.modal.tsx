import React, { useEffect, useState } from 'react'
import { Form, Modal } from 'react-bootstrap';
import { ReactComponent as ShareIcon } from "../../../_assets/share-icon.svg";
import { ReactComponent as CopyLink } from "../../../_assets/copy-icon.svg";
import Button from '../../../_components/button.component'
import { MainService } from '../../../_services/main.service';
import { useToasts } from 'react-toast-notifications';
interface Props {
    show?: boolean;
    handleClose: () => void;
    token: string;
    uuidsArray: string[]
}
const main = new MainService()
const ShareForReviewModal: React.FC<Props> = ({ show = true, handleClose, token, uuidsArray }) => {
    const { addToast } = useToasts();
    const [validated, setValidated] = useState(false);
    const [emails, setEmail] = useState<string[]>([]);
    const [showError, setShowError] = useState<boolean>(false)

    // get uuids as dashed values
    const uuidsDashed = uuidsArray.join("-");

    const handleSubmit = (e: any) => {
        const form = e.currentTarget;
        e.preventDefault();
        e.stopPropagation();
        if (emails.length <= 0) setShowError(true)
        if (form.checkValidity() === false) return
        const payload = {
            emails,
            uuids: uuidsArray
        }
        if (emails.length > 0) {
            main.shareAttemptsByuuid(token, payload)
                .then(response => {
                    handleClose()
                    addToast(response.message, { appearance: 'success', autoDismiss: true })
                })
                .catch(err => addToast('Something went wrong please try again', { appearance: 'error', autoDismiss: true }))
        }
    }

    const copyUrl = () => {
        if (uuidsArray.length > 0) {
            navigator.clipboard.writeText(`http://app.taplingua.com/interview/external-review/${uuidsDashed}`);
            addToast('Link has been copied!', { appearance: 'success', autoDismiss: true });
        } else {
            addToast('No video to review!', { appearance: 'error', autoDismiss: true })
        }
    }
    const handleChange = (e: any) => {
        let email = e.target.value.split(",")
        setEmail(email)
    }


    const [cohort, setCohort] = useState({
        instructorReviewsOnly: undefined,
        instructorEmails: ''
    })

    const [cohortLoading, setCohortLoading] = useState(true);

    useEffect(() => {
        main.getCohortDetail(token)
            .then((dt) => {
                if (dt) {
                    setCohort(dt);
                    let email = dt.instructorEmails.split(",")
                    setEmail(email)
                }
                setCohortLoading(false);
            })
            .catch(err => {
                setCohortLoading(false);
                console.log("No getCohortDetail found", err)
            });
    }, []);

    let hide = true;
    if (cohort && cohort.instructorReviewsOnly === 0 && !cohortLoading) {
        hide = false;
    }

    return (
        <>
            <Modal centered size="lg" show={show} onHide={handleClose}>
                <Modal.Header closeButton style={{ border: 'none' }} />
                <Modal.Body>
                    <div className="container">
                        <div className="row">
                            <div className="share_icon"><ShareIcon /></div>
                            <div className="col-md-12 text-center font-bold">
                                Get Feedback
                            </div>
                            <div className="col-md-12 text-secondary text-center mb-5">
                                Sharing Answer
                            </div>
                            <div className="col-md-12 font-bold text-center mt-5">Share via email</div>
                            <div className="col-md-12">
                                <div className="container">
                                    <Form noValidate validated={validated} onSubmit={handleSubmit}>

                                        <Form.Group controlId="exampleForm.ControlInput1">
                                            {hide ? null : <>
                                                <div className="row">
                                                    <div className="col-2"> <Form.Label className="font-bold">Copy link</Form.Label></div>
                                                    <div className="col copy_link" onClick={() => copyUrl()}> <CopyLink /></div>
                                                </div>

                                                <Form.Control id="url" style={{ borderRadius: '0' }} size="sm" value={`http://app.taplingua.com/interview/external-review/${uuidsDashed}`} type="input" readOnly />
                                            </>
                                            }

                                            <Form.Label className="font-bold">Email Address</Form.Label>
                                            <Form.Control disabled={hide} onChange={(e) => handleChange(e)} value={emails} style={{ borderRadius: '0' }} multiple type="email" />
                                            {showError ? <div className="text-danger text-left">Email is Required</div> : null}
                                        </Form.Group>
                                        <Form.Group controlId="exampleForm.ControlTextarea1">
                                            <Form.Label className="font-bold">Your message</Form.Label>
                                            <Form.Control type="text" style={{ borderRadius: '0' }} as="textarea" rows={3} />
                                            <Form.Control.Feedback type="invalid">
                                                Your message is required.
                                            </Form.Control.Feedback>
                                        </Form.Group>
                                        <div className="d-flex justify-content-center">
                                            <Button color="primary" text="Ask for review" />
                                        </div>
                                    </Form>
                                </div>
                            </div>
                        </div>
                    </div>
                </Modal.Body>
                <Modal.Footer style={{ alignSelf: 'center' }}>


                </Modal.Footer>
            </Modal>
        </>
    )
}

export default ShareForReviewModal
