import React from "react";
import { CKEditor } from "@ckeditor/ckeditor5-react";
import ClassicEditor from "@ckeditor/ckeditor5-build-classic";
import { Spinner, TopNavigationBar } from "../../_components";
import { history } from '../../_config'

import { Button } from "react-bootstrap";

export const INSTRUCTION_MODAL = "/test-instruction";

const InstructionModal = (props) => {

    const handleClick = () => {
        history.push('/practice')
    }
  return (
    <>
      <TopNavigationBar />

      <div className="main ">
        <div className="container exam_dos">
          <div className="row exam_dos_row">
            <div className="col-md-12">
              <h2 className="insTitle">Instructions for the Test - Please read carefully</h2>
            </div>
            <div className="col-md-12"></div>
            {/* <p>You are taking an AI based proctored test. Please follow the instructions carefully.</p> */}
          </div>
          <ol className="descriptionIns">
            <li> Please take the test on your laptop/desktop</li>
            <li>
               Please have a stable internet connection during test-taking
            </li>
            <li>
              Submitting the interview video recording/Communication test is
              mandatory for clearing this test. Without submitting the same, you
              will not be cleared for the next step.
            </li>
            <li>
               Make sure your mic and webcam working properly while you taking
              this test
            </li>
            <li>
               Make sure once you start the video recording you stop only once
              you finish the recording, if you are not satisfied with your
              answer you can reattempt the question by recording the video again
            </li>
            <li>
               This test just need basic speaking of English and the minimum
              video requirement is 1 minute
            </li>
          </ol>
          <div className="row checkbox_btn">
            <div className="col-md-12">
              {/* <div className="d-flex justify-center">
          <button
            className="continue-exam-button"
            style={{ padding: "5px 24px" }}
            onClick={() => {
            }}
          >
            Continue
          </button>
        </div> */}

              <Button
                variant="success"
                size="lg"
                onClick={handleClick}
              >
                Continue
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default InstructionModal;
