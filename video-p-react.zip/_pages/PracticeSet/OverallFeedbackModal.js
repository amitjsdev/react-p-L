import React from "react";
import { CKEditor } from '@ckeditor/ckeditor5-react';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
// import "./AllCompleteAlert.scss";
const OverallFeedbackModal = ({  close, alertMsg }) => {
  return (
    <div className="SkipModal">
      <div className="modal-body">
            {/* <h5 className="text-center">
            
            </h5> */}
            <div className="text-center homeRichText">
            <CKEditor
                    editor={ ClassicEditor }
                    data={alertMsg?.feedback}
                    disabled={true}
                />
               </div>
        
       
        <div className="d-flex justify-center">
          <button
            className="continue-exam-button"
            style={{ padding: "0px 24px" }}
            onClick={() => {
              close("");
            }}
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
export default OverallFeedbackModal;
