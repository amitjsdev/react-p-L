import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { State } from '../../store/reducers'
import { Spinner, TopNavigationBar } from '../../_components'
import { history } from '../../_config'
import "./set.css"
import { withdrawMoney, despositMoney, changeModuleNumber, setUserToken } from "../../store/action-creator"
import { MainService } from '../../_services/main.service'
import getFormatedDate from '../../_config/getFormatedDate'
// import Button from '../../_components/button.component'
import { LottieLoader } from '../../_components/lottie-loader.component'
import Joyride from 'react-joyride';
import { Button } from 'react-bootstrap'
 import feedbackImg from '../../_assets/overall.png';
import OverallFeedbackModal from './OverallFeedbackModal';
import SubmiitedModal from './SubmiitedModal';


export const PRACTICE_SET = "/practice-set"


const main = new MainService()

const PracticeSetPage = () => {
    const dispatch = useDispatch();
    const module = useSelector((state: State) => state.module as any)
    const [token, setToken] = useState<string>()
    const user = JSON.parse(localStorage.getItem('user') || '{}')
    const [loading, setloading] = useState(false)
    const [practiceSets, setpracticeSets] = useState<any>();
    const [overallFeedback, setOverallFeedback] = useState<[]>()
    const [showComplete,setshowComplete] = useState<boolean>(false)
    const [showModal,setShowModal] = useState(false);

    const [sunmittedShow,setSubmittedShow] = useState(false);

    
    const [alertMsg,setAlertMsg] = useState('')
    const [cohort, setCohort] = useState<any>(null);

    useEffect(() => {
        setToken(user.token)
        if (token) {
            created()
            dispatch(setUserToken(token))
        }
        setCohort(user.cohort);
    }, [token]);

    const created = async () => {
        setloading(true)
        main.fetchAllPracticeSets(token as any).then(response => {
            setpracticeSets(response)
            setOverallFeedback(response?.overall_feedback)
            setloading(false)
        })

    }

    const toggle=()=>{
        setshowComplete(!showComplete)
    }


    const closeModal = () => {
        setShowModal(false);
        setSubmittedShow(false);
    }
    // react joyride related
    const [showJoyride, setShowJoyride] = useState<boolean>();
    useEffect(() => {
        setShowJoyride(localStorage.getItem('joyride-show.practicesetpage') ? false : true);
    }, []);
    useEffect(() => {
        // hide the joyride now
        if (showJoyride) {
            localStorage.setItem('joyride-show.practicesetpage', "true");
        }
    }, [showJoyride]);
    let vpiData:any = [];
    if(user?.cohort && user?.cohort.length > 0){
        let checkData = cohort && cohort.length > 0 && cohort.find((item:any)=> item.type_id == 3 && item.vpi_value == 0);
        if(checkData && Object.keys(checkData).length){
            vpiData = [];
        }else{
            vpiData = cohort && cohort.length > 0 && cohort.find((item:any)=> item.type_id == 3 && item.vpi_value == '1');
        }
    }else{
    let checkData = user?.cohort && user?.cohort.length > 0 && user?.cohort.find((item:any)=> item.type_id == 3 && item.vpi_value == 0);
        if(checkData && Object.keys(checkData).length){
            vpiData = [];
        }else{
            vpiData = user?.cohort && user?.cohort.length > 0 && user?.cohort.find((item:any)=> item.vpi_value == '1');
        }

    }

    const changeModule = (moduleNum: number,cohortId:string,vpiData:any) => {
        localStorage.setItem('cohortId',cohortId);
        dispatch(changeModuleNumber(moduleNum));
        if(vpiData?.type_id == 3 && vpiData?.vpi_value == 1){
            history.push('/test-instruction')
        }else{
            history.push('/practice')
        }
    }
  
    const submittedQuestion = () =>{
        setSubmittedShow(true);
    }
    
    return (
        <>
            <TopNavigationBar />
            {
                practiceSets?.practiceSets && showJoyride ? (
                    <Joyride steps={[
                        {
                            disableBeacon: true,
                            target: '.btn-success',
                            content: 'Welcome to Taplingua, start by tapping on the button to go into the practice session.'
                            
                        },
                    ]}
                    locale={{
                        last: "Got it",
                        close: "Got it"
                    }}
                    hideBackButton
                    styles={{
                        options: {
                            arrowColor: "#713CFB",
                            backgroundColor: "#713CFB",
                            textColor: "#FFF",
                            primaryColor: '#FFF3',
                        }
                    }}
                    disableScrolling />
                ) : <></>
            }
            <div className="" style={{ marginTop: '60px', marginBottom: '7%' }}></div>
            <div className="main ">

                {/* <p>TOTAL AMOUNT - {amount}</p>
                    <button onClick={()=> dispatch(despositMoney(100))}>DEPOSIT</button>{' '}
                    <button onClick={()=> dispatch(withdrawMoney(500))}>WITHDRAW</button> */}
                {/* <div className="d-flex justify-content-center title">
                    <h4  className={showComplete ? "text-secondary cursor-pointer":"cursor-pointer"} onClick={()=>toggle()}>In Progress</h4>
                    <h4 className={showComplete ?"ml-5 pl-5 cursor-pointer" :"ml-5 pl-5 text-secondary cursor-pointer"} onClick={()=>toggle()}>Completed</h4>
                </div> */}
                {loading ? (
                    <div className="d-flex justify-content-center mt-5 pt-5">
                        <LottieLoader />
                    </div>
                ) : null}
                {!showComplete ?  
                <div className="container">
                    {practiceSets?.practiceSets ? (
                            practiceSets?.practiceSets.length > 0 ? practiceSets?.practiceSets.map((set: any) => {
                                const { created_at, id, practiceSetName, practiceSetId, completedLessons, totalLessons,overall_feedback } = set;
                                let percentage = Math.round((completedLessons / totalLessons) * 100)
                                return (
                                    <div key={id} className="card mb-5" style={{ cursor: 'pointer' }}>
                                        <div className="card-body">
                                            <table className="table table-borderless">
                                                <thead className="practicTh">
                                                    <tr>
                                                    <th scope="col">{vpiData?.type_id == 3 && vpiData?.vpi_value == 1 ? 'English Test' : 'Practice Set'}
                                                        </th>
                                                        {overall_feedback?.feedback && vpiData?.type_id != 3 && vpiData?.vpi_value != 1 &&
                                                        <th scope="col">Overall Feedback</th> }
                                                        <th scope="col">Started On</th>
                                                        <th scope="col">Progress</th>
                                                        {vpiData?.type_id == 3 && vpiData?.vpi_value == 1 ? 
                                                        <th scope="col">Instructions</th>
                                                        : <th scope="col"></th>}
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td className="forMobile w-25" style={{ paddingTop: '32px' }}>{practiceSetName}</td>
                                                        {overall_feedback?.feedback && vpiData?.type_id != 3 && vpiData?.vpi_value != 1 &&
                                                        <td className="forMobile" onClick={()=>{ 
                                                            setAlertMsg(overall_feedback)
                                                             setShowModal(true)}}
                                                        >
                                                            <img className="feedbackImg" src={feedbackImg} />
                                                            <span style={{ color: 'green' }}>New</span>
                                                        </td>

                                                         }
                                                        <td className="forMobile" style={{ paddingTop: '32px' }}>{getFormatedDate(created_at)}</td>
                                                        <td className="forMobile progressbar">
                                                            <div className="font-bold" style={{ color: '#6f3afc' }}>{percentage}%</div>
                                                            <div className="progress">
                                                                <div className="progress-bar " role="progressbar" style={{ backgroundColor : '#6f3afc', width: percentage + '%' }} ></div>
                                                            </div>
                                                        </td>
                                                        <td className="forMobile btn">
                                                            <div className="vpiData">
                                                         {percentage == 100 && vpiData?.type_id == 3 && vpiData?.vpi_value == 1  ? 
                                                            <Button className="btnVpi" variant="success" size="lg" onClick={() => submittedQuestion()} >Continue</Button>
                                                        :
                                                        <Button className={`${vpiData?.type_id == 3 && vpiData?.vpi_value == 1 ? `btnVpi`: ''}`} variant="success" size="lg" onClick={() => changeModule(practiceSetId,set.cohortId[0],vpiData)} >{percentage > 0 ? "Continue" : vpiData?.type_id == 3 && vpiData?.vpi_value == 1 ? "Start test": "Start course"}</Button>
 
                                                        }
                                                        </div>
                                                            {/* <Button color="primary" handleClick={() => changeModule(practiceSetId)} text={percentage > 0 ? "Continue" : "Start course"} /> */}

                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                )
                            }) : <div className="text-center">No practice set available for you!</div>
                    ) : null}
                </div>
                :null}

               {showModal && alertMsg && <OverallFeedbackModal alertMsg={alertMsg} close={closeModal} />}
               {sunmittedShow && <SubmiitedModal close={closeModal} />}

            </div>
        </>
    )
}

export default PracticeSetPage
