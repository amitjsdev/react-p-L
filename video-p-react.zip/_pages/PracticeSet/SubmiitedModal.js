import React from "react";
// import "./AllCompleteAlert.scss";
const SubmiitedModal = ({ close }) => {
  return (
    <div className="SkipModal">
      <div className="modal-body">
        {/* <h5 className="text-center">
            
            </h5> */}
        <div className="text-center homeRichText">
        Your video answers have been submitted!
        </div>

        <div className="d-flex justify-center">
          <button
            className="continue-exam-button"
            style={{ padding: "0px 24px" }}
            onClick={() => {
              close();
            }}
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
export default SubmiitedModal;
