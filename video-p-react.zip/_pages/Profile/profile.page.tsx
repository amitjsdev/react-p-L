import React, { useEffect, useState } from 'react'
import { Form, Row, Col } from 'react-bootstrap';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import IconButton from '@material-ui/core/IconButton';
import PhotoCamera from '@material-ui/icons/PhotoCamera';
import { TopNavigationBar } from '../../_components';
import "./profilePage.scss"
import { HttpService } from "../../_services/http.service";
import { history } from '../../_config/history.config';
import { ReactComponent as Profile_Icon } from "./profile_icon.svg";
import { MainService } from '../../_services/main.service';
export const PROFILE_PAGE_ROUTE = "/profile";
const main = new MainService();
const http = new HttpService();
export const Profile: React.FC = () => {
    const [userData, setUserData] = useState({
        FirstName: '',
        LastName: '',
        Location: ''
    });
    const [profileUrl, setProfileUrl] = useState('')
    const user = JSON.parse(localStorage.getItem('user') || '{}')
    useEffect(() => {
        if (user && user.token && user.email) {
            main.getEmployee(user).then(data => {
                setUserData(data)
                setProfileUrl(data.profile_image)
            });
        }
    }, [])



    const onChangeFiles = async (e: any) => {

        const { target: { files } } = e;
        if (files && files[0]) {
            const file = files[0];
            const datum = {
                name: file.name,
                type: file.type,
            }
            const res = await main.getProfilePicUploadUrl(user.token, datum);

            if (res && res.uploadURL) {
                const { status } = await http.put(res.uploadURL, files[0], datum.type);
                if (status === 200) {
                    setProfileUrl(res.Key)
                    main.setProfilePic(user.token, { key: res.Key });
                }
            }

        }
    }
    const useStyles = makeStyles((theme) => ({
        root: {
          '& > *': {
            margin: theme.spacing(1),
          },
        },
        input: {
          display: 'none',
        },
      }));
    const classes = useStyles();
    return (
        <>
            {/* {console.log('user', user)} */}
            <TopNavigationBar />
            <div className="" style={{ marginTop: '80px' }}></div>
            <div className="layout">
                <div className="row">
                    <div className="col-md-3">
                        <div className="my_account">
                            <div className="row">
                                <div className="col-12 profile_icon">
                                    {profileUrl ? <img src={`https://langappnew.s3.amazonaws.com/${profileUrl}`} style ={{maxWidth:200, maxHeight:200}} /> :
                                        <Profile_Icon />
                                    }
                                </div>

                                <div className="col-12">
                                    My Account
                                </div>
                                <div className="col-12">
                                    <div className={classes.root}>
                                        <input
                                            accept="image/png, image/jpg, image/jpeg"
                                            className={classes.input}
                                            id="contained-button-file"
                                            
                                            type="file"
                                            onChange={onChangeFiles}
                                        />
                                        <label htmlFor="contained-button-file">
                                            <Button variant="contained" color="primary" component="span">
                                                Upload
                                            </Button>
                                        </label>
                                        <input  onChange={onChangeFiles} accept="image/png, image/jpg, image/jpeg" className={classes.input} id="icon-button-file" type="file" />
                                        <label htmlFor="icon-button-file">
                                            <IconButton color="primary" aria-label="upload picture" component="span">
                                                <PhotoCamera />
                                            </IconButton>
                                        </label>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <ul className="list-group">
                            <li className="list-group-item cursor-pointer">Profile</li>
                            <li className="list-group-item cursor-pointer" onClick={() => {
                                localStorage.removeItem('user');
                                localStorage.removeItem('cohortId');

                                history.replace('/login')
                                window.location.reload()
                            }}> Logout</li>
                        </ul>
                    </div>
                    <div className="col p-3">
                        <h1 className="pl-2">Profile</h1>
                        <div className="container-fluid">
                            <Form>
                                <Row>
                                    <Form.Group as={Col} controlId="formGridEmail">
                                        <Form.Label>First Name</Form.Label>
                                        <Form.Control value={userData?.FirstName} type="text" style={{ borderRadius: '0', width: '70%' }} />
                                    </Form.Group>

                                    <Form.Group as={Col} controlId="formGridPassword">
                                        <Form.Label>Last Name</Form.Label>
                                        <Form.Control value={userData?.LastName} type="text" style={{ borderRadius: '0', width: '70%' }} />
                                    </Form.Group>
                                </Row>
                                <Row className="mb-3">
                                    <Form.Group as={Col} controlId="formGridCity">
                                        <Form.Label>Email</Form.Label>
                                        <Form.Control disabled type="email" value={user.email} style={{ borderRadius: '0', width: '70%' }} />
                                        {/* <h4>{user.email}</h4> */}
                                    </Form.Group>

                                    <Form.Group as={Col} controlId="formGridZip">
                                        <Form.Label>Location</Form.Label>
                                        <Form.Control value={userData?.Location} type="text" style={{ borderRadius: '0', width: '70%' }} />
                                    </Form.Group>
                                </Row>
                                <h5 className="cursor-pointer" style={{ color: 'blue' }}>Reset password</h5>
                            </Form>
                        </div>

                    </div>
                </div>
            </div>
        </>
    )
}
