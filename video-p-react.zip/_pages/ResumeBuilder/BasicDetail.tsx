import React, { useEffect, useState } from 'react'
import { Form, Row, Col } from 'react-bootstrap';
import Button from "../../_components/button.component";
import { MainService } from '../../_services/main.service';
const user = JSON.parse(localStorage.getItem('user') || '{}');
const main = new MainService();
const BasicDetail = (props: Props) => {
    const { resume, id, setloading, changeTab, setSelectedResumeId } = props;
    const initialData: BasicInfoData = {
        firstName: '',
        lastName: '',
        phone: '',
        email: '',
        address: '',
        linkedin: '',
        twitter: '',
        website: '',
    };
    const data: BasicInfoData = resume && resume.resumeContent && resume.resumeContent.basicInfo ? resume.resumeContent.basicInfo : initialData;
    const name: string = resume && resume.resumeName ? resume.resumeName : '';
    const [basicInfoData, setData] = useState(data);
    const [resumeName, setResumeName] = useState(name);
    const onFinishHandler = (e: any) => {
        setloading(true);
        e.preventDefault()
        if (id>0) {
            main.postBasicInfoResume(user.token, id, { basicInfo: basicInfoData })
                .then(res => {
                    if (res && res.message && res.message == 'data updated') {
                        changeTab(1, 'basicInfo', res.resume)
                    } else {

                    }
                    setloading(false);
                })
                .catch(err => {
                    //    setData([])
                    setloading(false);
                })
        } else {
            main.createResume(user.token, { resumeName })
                .then(res => {
                    if (res && res.resume && res.resume.id) {
                        props.history.push(`/resume-builder/${res.resume.id}`)
                    } else {

                    }
                    setloading(false);
                })
                .catch(err => {
                    //    setData([])
                    setloading(false);
                })
        }
    }

    const onchange = (e: any) => {
        setData({
            ...basicInfoData,
            [e.target.name]: e.target.value
        })
    }

    return (
        <>
            <Row style={{ textAlign: 'center', margin: '20px,0', width: '100%' }}>
                <h3 className="pl-2" style={{ textAlign: 'center', margin: '20px,0', width: '100%', fontWeight: 'bold' }}>Enter your Basic Detail Below</h3>
            </Row>
            <div className="container-fluid">
                <Form onSubmit={onFinishHandler}>
                    <Row>
                        <Form.Group as={Col} controlId="formGridEmail">
                            <Form.Label>Resume Name</Form.Label>
                            <Form.Control required={true} onChange={e => setResumeName(e.target.value)} type="text" value={resumeName} style={{ borderRadius: '0', width: '70%' }} />
                        </Form.Group>
                        <Form.Group as={Col} controlId="formGridPassword">

                        </Form.Group>

                    </Row>
                    {id >0 ? <>
                        <Row>
                            <Form.Group as={Col} controlId="formGridEmail">
                                <Form.Label>First Name</Form.Label>
                                <Form.Control required={true} onChange={onchange} name="firstName" type="text" value={basicInfoData?.firstName} style={{ borderRadius: '0', width: '70%' }} />
                            </Form.Group>

                            <Form.Group as={Col} controlId="formGridPassword">
                                <Form.Label>Last Name</Form.Label>
                                <Form.Control required={true} onChange={onchange} name="lastName" type="text" value={basicInfoData?.lastName} style={{ borderRadius: '0', width: '70%' }} />
                            </Form.Group>
                        </Row>
                        <Row>
                            <Form.Group as={Col} controlId="formGridEmail">
                                <Form.Label>Phone</Form.Label>
                                <Form.Control required={true} onChange={onchange} name="phone" type="text" value={basicInfoData?.phone} style={{ borderRadius: '0', width: '70%' }} />
                            </Form.Group>

                            <Form.Group as={Col} controlId="formGridPassword">
                                <Form.Label>Address</Form.Label>
                                <Form.Control required={true} onChange={onchange} name="address" type="text" value={basicInfoData?.address} style={{ borderRadius: '0', width: '70%' }} />
                            </Form.Group>
                        </Row>
                        <Row>
                            <Form.Group as={Col} controlId="formGridEmail">
                                <Form.Label>LinkedIn</Form.Label>
                                <Form.Control required={true} onChange={onchange} name="linkedin" type="text" value={basicInfoData?.linkedin} style={{ borderRadius: '0', width: '70%' }} />
                            </Form.Group>

                            <Form.Group as={Col} controlId="formGridPassword">
                                <Form.Label>Twitter Handle</Form.Label>
                                <Form.Control required={true} onChange={onchange} name="twitter" type="text" value={basicInfoData?.twitter} style={{ borderRadius: '0', width: '70%' }} />
                            </Form.Group>
                        </Row>
                        <Row className="mb-3">
                            <Form.Group as={Col} controlId="formGridCity">
                                <Form.Label>Website</Form.Label>
                                <Form.Control required={true} onChange={onchange} name="website" style={{ borderRadius: '0', width: '70%' }} value={basicInfoData?.website} />

                            </Form.Group>

                            <Form.Group as={Col} controlId="formGridZip">
                                <Form.Label>Email</Form.Label>
                                <Form.Control required={true} onChange={onchange} name="email" type="email" style={{ borderRadius: '0', width: '70%' }} value={basicInfoData?.email} />
                            </Form.Group>
                        </Row>
                    </>:null
                    }
                    <div className="" >
                        <Button text="Save and Countinue" color="primary" />
                    </div>
                </Form>
            </div>
        </>
    )
}

export default BasicDetail;
interface Props {
    update: (key: string, formData: any) => void;
    setloading: (loading: boolean) => void;
    setSelectedResumeId: (id: number) => void;
    changeTab: (tabId: number, key: string, data: any) => void;
    resume?: any;
    id: number;
    history:any;
}

interface BasicInfoData {
    firstName: string;
    lastName: string;
    phone: string;
    email: string;
    address: string;
    linkedin: string;
    twitter: string;
    website: string;
}
