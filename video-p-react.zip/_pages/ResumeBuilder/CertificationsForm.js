import React, { useEffect, useState } from 'react'
import {  Modal } from 'react-bootstrap'
import { Form, Row, Col } from 'react-bootstrap';
import RichEditor from '../../_components/RichEditor'
import Button from "../../_components/button.component";
const CertificationsForm = (props) => {
    const { datum, save } = props;

    const [formData, setData] = useState(datum);
    const onChange = (e) => {
        const d = {
            ...formData,
            [e.target.name]: e.target.value
        }

        setData(d)
    }


    const onSubmit = (e) => {
        e.preventDefault()
        save(formData);
    }

    return (
        <Modal show={props.show} onHide={props.onClose}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered
        >
            <Modal.Header closeButton style={{ border: 'none' }} />
            <Modal.Body>

                <div className="container-fluid">
                    <Form onSubmit={onSubmit}>
                        <Row>
                            <Form.Group as={Col} controlId="formGridEmail">
                                <Form.Label>Certification Name</Form.Label>
                                <Form.Control required={true} name="certificationName" value={formData.certificationName} onChange={onChange} type="text" style={{ borderRadius: '0', width: '70%' }} />
                            </Form.Group>
                            <Form.Group as={Col} controlId="formGridPassword">

                            </Form.Group>

                        </Row>
                        <Row>
                            <Form.Group as={Col} controlId="formGridEmail">
                                <Form.Label>Certification Link</Form.Label>
                                <Form.Control name="certificationLink" value={formData.certificationLink} onChange={onChange} type="text" style={{ borderRadius: '0', width: '70%' }} />
                            </Form.Group>

                            <Form.Group as={Col} controlId="formGridPassword">

                            </Form.Group>
                        </Row>
                        <Row>
                            <Form.Group as={Col} controlId="formGridEmail">
                                <Form.Label>Describe your Certification</Form.Label>
                                <RichEditor data={formData.certificationDescription} onChange={e => {
                                    setData({ ...formData, certificationDescription: e })
                                }} />
                            </Form.Group>

                            <Form.Group as={Col} controlId="formGridPassword">

                            </Form.Group>
                        </Row>
                        <Row>
                            <Col >
                                <div className="" style={{ marginTop: 20 }} >
                                    <Button text="Save" color="primary" />
                                </div>
                            </Col>
                        </Row>

                    </Form>
                </div>
            </Modal.Body>
            
        </Modal>

    )
}

export default CertificationsForm
