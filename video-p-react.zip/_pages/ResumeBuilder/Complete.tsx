import React, { useEffect, useState } from 'react'
import { Form, Row, Col } from 'react-bootstrap';
const Complete = () => {



    return (
        <>
            <Row style={{ textAlign: 'center', margin: '20px,0', width: '100%' }}>

            </Row>
            <div className="container-fluid" style={{ marginTop: 30 }}>
                <Row>
                    <Col md="4">
                        Download Resume in PDF format
                        <div className="" >
                            <button style={{ width: '250px' }} className="button-custom button-custom-primary" >Download </button>
                        </div>
                    </Col>
                    <Col md="8">
                    </Col>


                </Row>

            </div>

        </>
    )
}

export default Complete
