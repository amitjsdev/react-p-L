import React, { useEffect, useState } from 'react'
import { Form, Row, Col } from 'react-bootstrap';
import EducationForm from './EducationalForm';
import Button from '@material-ui/core/Button';
import AddIcon from '@material-ui/icons/Add';
import DeleteForeverIcon from '@material-ui/icons/DeleteForever';
import BorderColorIcon from '@material-ui/icons/BorderColor';
import { MainService } from '../../_services/main.service';
const user = JSON.parse(localStorage.getItem('user') || '{}');
const main = new MainService();

const ListItem = (props: ListItemProps) => {
    const { data, index,edit, deleteRow } = props;
    return (
        <Row key={index} className="list-item">
            <Col md={1}><span className="list-count">{index + 1}</span></Col>
            <Col md={5}><label className="form-label label-bold-list">{data.degree}</label></Col>
            <Col md={4}></Col>
            <Col md={1}><BorderColorIcon fontSize="large" style={{color:'gray',}} onClick={e=>edit(index)}/></Col>
            <Col md={1}><DeleteForeverIcon fontSize="large" style={{color:'red'}} onClick={e=>deleteRow(index)}/></Col>
        </Row>)
}


const Education = (props: Props) => {
    const [show, setShow] = useState(false);
    const [editIndex, setIndex] = useState(-1);
    const initialData:Qualification = {
        sno: '',
        degree: '',
        institution: '',
        university: '',
        location: '',
        startYear: '',
        endYear: '',
        gpaOrPecentage: '',
    }
    const [editData, setEditData] =useState(initialData)
    const onClose = (data: any) => {
        setShow(false);
    }

    const { resume, id, setloading, changeTab, } = props;

    const propsdata: Qualification[] = resume && resume.resumeContent && resume.resumeContent.education ? resume.resumeContent.education : [];
    const [data, setData] = useState(propsdata);

    const onFinishHandler = (datum: Qualification) => {
        let postData:Qualification[] =data;
        if(editIndex >-1){
            postData =postData.map((item,index)=> index === editIndex ? datum :item)
        } else {
            postData.push(datum)
        }

        setloading(true);

        main.postEducationResume(user.token, id, { education: postData })
            .then(res => {
                if (res && res.message && res.message == 'data updated') {
                    setData(postData)
                    setShow(false)
                } else {

                }
                setloading(false);
            })
            .catch(err => {
                //    setData([])
                setloading(false);
            })

    }

    const deleteRow = (Delindex: number) =>{
        let postData:Qualification[] =data;
        postData = postData.filter((item,index)=> index !== Delindex)
        setloading(true);

        main.postEducationResume(user.token, id, { education: postData })
            .then(res => {
                if (res && res.message && res.message ==='data updated') {
                    setData(postData)
                    setShow(false)
                } else {

                }
                setloading(false);
            })
            .catch(err => {
                //    setData([])
                setloading(false);
            })
    }

    const edit = (index:number) =>{
        setEditData(data[index]);
        setIndex(index);
        setShow(true);
    }
    const setVisibleModal = () =>{
            setEditData(initialData);
            setIndex(-1);
            setShow(true);
        }

    return (
        <>
            <Row style={{ textAlign: 'center', margin: '20px,0', width: '100%' }}>
                <h3 className="pl-2" style={{ textAlign: 'left', margin: '20px,0', width: '100%', fontWeight: 'bold' }}>
                    Enter your educational qualifications
                </h3>
            </Row>
            <>
                <Row style={{ textAlign: 'center', margin: '30px,0', width: '100%' }}>
                    <h4 className="pl-2" style={{ textAlign: 'left', margin: '20px,0', width: '100%', fontWeight: 'bold' }}>
                        My Qualifications
                    </h4>
                </Row>
                {data && data.map((datum, index) => <ListItem data={datum} index={index} edit={edit} deleteRow={deleteRow}/>)}
            </>
            <div className="container-fluid" style={{ marginTop: 30 }}>
                <Row>
                    <Col md="4">
                        <Button
                            variant="contained"
                            color="default"
                            size="large"
                            style={{ backgroundColor: '#fff', borderRadius: 10 }}
                            onClick={setVisibleModal}
                            startIcon={<AddIcon />}
                        >Add new Qualification</Button>
                    </Col>
                    <Col md="3">
                    </Col>
                    <Col md="5">
                        <p>
                            you are a fresh graduate, this is very critical part of your resume. Experienced grads will have more weight on work experience.
                        </p>
                    </Col>

                </Row>

            </div>
            {show && <EducationForm show={show} onClose={onClose} save={onFinishHandler} datum={editData} />}
            
        </>
    )
}
interface Props {
    update: (key: string, formData: any) => void;
    setloading: (loading: boolean) => void;
    changeTab: (tabId: number, key: string, data: any) => void;
    resume?: any;
    id: number;
}
interface Qualification {
    sno: string;
    degree: string;
    institution: string;
    university: string;
    location: string;
    startYear: string;
    endYear: string;
    gpaOrPecentage: string;
}
interface ListItemProps {
    index: number;
    data: Qualification;
    edit: (index:number) => void;
    deleteRow: (index:number) => void;
}
export default Education
