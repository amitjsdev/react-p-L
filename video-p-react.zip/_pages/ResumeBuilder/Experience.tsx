import React, { useEffect, useState } from 'react'
import { Form, Row, Col } from 'react-bootstrap';
import ExperienceForm from './ExperienceForm';
import Button from '@material-ui/core/Button';
import AddIcon from '@material-ui/icons/Add';
import DeleteForeverIcon from '@material-ui/icons/DeleteForever';
import BorderColorIcon from '@material-ui/icons/BorderColor';
import { MainService } from '../../_services/main.service';
const user = JSON.parse(localStorage.getItem('user') || '{}');
const main = new MainService();

const ListItem = (props: ListItemProps) => {
    const { data, index, edit, deleteRow } = props;
    return (
        <Row key={index} className="list-item">
            <Col md={1}><span className="list-count">{index + 1}</span></Col>
            <Col md={5}><label className="form-label label-bold-list">{data.companyName}</label></Col>
            <Col md={4}></Col>
            <Col md={1}><BorderColorIcon fontSize="large" style={{ color: 'gray', }} onClick={e => edit(index)} /></Col>
            <Col md={1}><DeleteForeverIcon fontSize="large" style={{ color: 'red' }} onClick={e => deleteRow(index)} /></Col>
        </Row>)
}


const Experiences = (props: Props) => {
    const [show, setShow] = useState(false);
    const [editIndex, setIndex] = useState(-1);
    const initialData: Experience = {
        "sno": '',
        "yearEnd": '',
        "location": '',
        "monthEnd": '',
        "yearStart": '',
        "monthStart": '',
        "companyName": '',
        "currentlyWorking": null,
    }
    const [editData, setEditData] = useState(initialData)
    const onClose = (data: any) => {
        setShow(false);
    }

    const { resume, id, setloading, changeTab, } = props;

    const propsdata: Experience[] = resume && resume.resumeContent && resume.resumeContent.workExperience ? resume.resumeContent.workExperience : [];
    const [data, setData] = useState(propsdata);

    const onFinishHandler = (datum: Experience) => {
        let postData: Experience[] = data;
        if (editIndex > -1) {
            postData = postData.map((item, index) => index === editIndex ? datum : item)
        } else {
            postData.push(datum)
        }

        setloading(true);

        main.postExperienceResume(user.token, id, { workExperience: postData })
            .then(res => {
                if (res && res.message && res.message == 'data updated') {
                    setData(postData)
                    setShow(false)
                } else {

                }
                setloading(false);
            })
            .catch(err => {
                //    setData([])
                setloading(false);
            })

    }

    const deleteRow = (Delindex: number) => {
        let postData: Experience[] = data;
        postData = postData.filter((item, index) => index !== Delindex)
        setloading(true);

        main.postExperienceResume(user.token, id, { workExperience: postData })
            .then(res => {
                if (res && res.message && res.message === 'data updated') {
                    setData(postData)
                    setShow(false)
                } else {

                }
                setloading(false);
            })
            .catch(err => {
                //    setData([])
                setloading(false);
            })
    }

    const edit = (index: number) => {
        setEditData(data[index]);
        setIndex(index);
        setShow(true);
    }
    const setVisibleModal = () => {
        setEditData(initialData);
        setIndex(-1);
        setShow(true);
    }

    return (
        <>
            <Row style={{ textAlign: 'center', margin: '20px,0', width: '100%' }}>
                <h3 className="pl-2" style={{ textAlign: 'left', margin: '20px,0', width: '100%', fontWeight: 'bold' }}>
                    Enter your work experiences
                </h3>
            </Row>
            <>
                <Row style={{ textAlign: 'center', margin: '30px,0', width: '100%' }}>
                    <h4 className="pl-2" style={{ textAlign: 'left', margin: '20px,0', width: '100%', fontWeight: 'bold' }}>
                        My Experiences
                    </h4>
                </Row>
                {data && data.map((datum, index) => <ListItem data={datum} index={index} edit={edit} deleteRow={deleteRow} />)}
            </>
            <div className="container-fluid" style={{ marginTop: 30 }}>
                <Row>
                    <Col md="4">
                        <Button
                            variant="contained"
                            color="default"
                            size="large"
                            style={{ backgroundColor: '#fff', borderRadius: 10 }}
                            onClick={setVisibleModal}
                            startIcon={<AddIcon />}
                        >Add new Experience</Button>
                    </Col>
                    <Col md="3">
                    </Col>
                    <Col md="5">
                        <p>
                            you are a fresh graduate, this is very critical part of your resume. Experienced grads will have more weight on work experience.
                        </p>
                    </Col>

                </Row>

            </div>
            {show && <ExperienceForm show={show} onClose={onClose} save={onFinishHandler} datum={editData} />}

        </>
    )
}
interface Props {
    update: (key: string, formData: any) => void;
    setloading: (loading: boolean) => void;
    changeTab: (tabId: number, key: string, data: any) => void;
    resume?: any;
    id: number;
}
interface Experience {
    "sno": string;
    "yearEnd": string;
    "location": string;
    "monthEnd": string;
    "yearStart": string;
    "monthStart": string;
    "companyName": string;
    "currentlyWorking": any;
}
interface ListItemProps {
    index: number;
    data: Experience;
    edit: (index: number) => void;
    deleteRow: (index: number) => void;
}
export default Experiences
