import React, { useEffect, useState } from 'react'
import { Modal } from 'react-bootstrap'
import { Form, Row, Col } from 'react-bootstrap';
import RichEditor from '../../_components/RichEditor';
import Button from "../../_components/button.component";
const ExperienceForm = (props) => {
    const { datum, save } = props;

    const [formData, setData] = useState(datum);
    const onChange = (e) => {
        const d ={
            ...formData,
            [e.target.name]: e.target.value
        }
       
        setData(d)
    }


    const onSubmit = (e) => {
        e.preventDefault()
        save(formData);
    }

    return (
        <Modal  show={props.show} onHide={props.onClose}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
        >
            <Modal.Header closeButton style={{ border: 'none' }} />
            <Modal.Body>
               
            <div className="container-fluid">
                <Form onSubmit={onSubmit}>
                    <Row>
                        <Form.Group as={Col} controlId="formGridEmail">
                            <Form.Label>Company Name</Form.Label>
                            <Form.Control required={true} name="companyName" value={formData.companyName} onChange={onChange}  type="text" style={{ borderRadius: '0', width: '70%' }} />
                        </Form.Group>
                        <Form.Group as={Col} controlId="formGridPassword">

                        </Form.Group>

                    </Row>
                    <Row>
                        <Form.Group as={Col} controlId="formGridEmail">
                            <Form.Label>Location</Form.Label>
                            <Form.Control required={true} name="location" value={formData.location} onChange={onChange}  type="text" style={{ borderRadius: '0', width: '70%' }} />
                        </Form.Group>

                        <Form.Group as={Col} controlId="formGridPassword">
                            
                        </Form.Group>
                    </Row>
                    <Row>
                        <Form.Group as={Col} controlId="formGridEmail">
                            <Form.Label>Start Month</Form.Label>
                            <Form.Control required={true} name="monthStart" value={formData.monthStart} onChange={onChange}  type="text" style={{ borderRadius: '0', width: '70%' }} />
                        </Form.Group>

                        <Form.Group as={Col} controlId="formGridPassword">
                        <Form.Label>End Month</Form.Label>
                            <Form.Control required={true} name="monthEnd" value={formData.monthEnd} onChange={onChange}  type="text" style={{ borderRadius: '0', width: '70%' }} />
                        </Form.Group>
                    </Row>
                     <Row>
                        <Form.Group as={Col} controlId="formGridEmail">
                            <Form.Label>Start Year</Form.Label>
                            <Form.Control required={true} name="yearStart" value={formData.yearStart} onChange={onChange}  type="text" style={{ borderRadius: '0', width: '70%' }} />
                        </Form.Group>

                        <Form.Group as={Col} controlId="formGridPassword">
                        <Form.Label>End Year</Form.Label>
                            <Form.Control required={true} name="yearEnd" value={formData.yearEnd} onChange={onChange}  type="text" style={{ borderRadius: '0', width: '70%' }} />
                        </Form.Group>
                    </Row>
                    <Row>
                        <Form.Group as={Col} controlId="formGridEmail">
                        <Form.Label>Currently working here</Form.Label>
                            <Form.Control name="currentlyWorking" checked={formData.currentlyWorking} onChange={e=>setData({...formData,currentlyWorking:e.target.checked})}  type="checkbox" style={{ borderRadius: '0', width: '15%' }} />
                        </Form.Group>

                        <Form.Group as={Col} controlId="formGridPassword">
                            
                        </Form.Group>
                    </Row>
                    <Row>
                        <Form.Group as={Col} controlId="formGridEmail">
                            <Form.Label>Describe your role , responsibilities and achievements</Form.Label>
                            <RichEditor onChange ={e=>console.log(e)}/>
                        </Form.Group>

                        <Form.Group as={Col} controlId="formGridPassword">
                            
                        </Form.Group>
                    </Row>
                    <Row>
                            <Col >
                                <div className="" style={{ marginTop: 20 }} >
                                    <Button text="Save" color="primary" />
                                </div>
                            </Col>
                        </Row>
                    
                </Form>
            </div>
            </Modal.Body>
            
        </Modal>
        
    )
}

export default ExperienceForm
