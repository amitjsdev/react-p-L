import React, { useEffect, useState } from 'react'
import { TopNavigationBar } from '../../_components'
import './set.css';
import { Form, Row, Col ,Button} from 'react-bootstrap';
import { LottieLoader } from '../../_components/lottie-loader.component'
import { MainService } from '../../_services/main.service';
import DeleteForeverIcon from '@material-ui/icons/DeleteForever';
import BorderColorIcon from '@material-ui/icons/BorderColor';
import { Link } from 'react-router-dom';
import FileCopyIcon from '@material-ui/icons/FileCopy';
const user = JSON.parse(localStorage.getItem('user') || '{}');
const main = new MainService();

const ListItem = (props: ListItemProps) => {
    const { data, index, deleteRow ,duplicate} = props;
    return (
        <Row key={index} className="list-item">
            <Col md={1}><span className="list-count">{index + 1}</span></Col>
            <Col md={5}><Link to={`/resume-builder/${data.id}`}><label className="form-label label-bold-list">{data.resumeName}</label></Link></Col>
            <Col md={3}></Col>
            <Col md={1}><Link to={`/resume-builder/${data.id}`}><BorderColorIcon fontSize="large" style={{ color: 'gray', }} /></Link></Col>
            <Col md={1}><FileCopyIcon onClick={e => duplicate(data.id)}  fontSize="large" style={{ color: 'gray', }} /></Col>
            <Col md={1}><DeleteForeverIcon fontSize="large" style={{ color: 'red' }} onClick={e => deleteRow(index)} /></Col>
        </Row>)
}

const ResumeBuilder = () => {
    const initialData: Datum[] = [];
    const [data, setData] = React.useState(initialData);
    const [loading, setloading] = React.useState(false);

    useEffect(() => {
        setloading(true);
        main.getAllResume(user.token)
            .then(res => {
                if (res && res.resumes) {
                    setData(res.resumes)
                } else {
                    setData([])
                }
                setloading(false);
            })
            .catch(err => {
                setData([])
                setloading(false);
            })

    }, [])
    const deleteRow = (id: number) => {
        let postData: Datum[] = data;
        postData = postData.filter((item) => id !== item.id)
        setloading(true);

        main.createResume(user.token, { resume: postData })
            .then(res => {
                if (res && res.message && res.message === 'data updated') {
                    setData(postData)
                } else {

                }
                setloading(false);
            })
            .catch(err => {
                //    setData([])
                setloading(false);
            })
    }
    const duplicate = (id: number) => {
        
    }


    return (
        <>

            <TopNavigationBar />

            <div className="" style={{ marginTop: '60px', marginBottom: '7%' }}></div>
            <div className="main ">
                {loading ? (
                    <div className="d-flex justify-content-center mt-5 pt-5">
                        <LottieLoader />
                    </div>
                ) : 

                <div className="container">
                    <Row style={{ textAlign: 'center', margin: '20px,0', width: '100%' }}>
                        <h3 className="pl-2" style={{ textAlign: 'left', margin: '20px,0', width: '100%', fontWeight: 'bold' }}>
                            Resume Builder
                        </h3>
                    </Row>
                    {data.length > 0 ?
                        data.map((datum: Datum, index: number) =>
                            <ListItem data={datum} index={index} deleteRow={deleteRow} duplicate={duplicate} />
                        ) : (
                            <label className="formm-label" style={{margin:'50px auto'}}>
                                No resumes  are there yet. Create a New Resume by tapping the button below.
                            </label>
                        )}
                        <Row style={{ textAlign: 'center', margin: '20px,0', width: '100%',display:'grid' }}>
                        <Link to="/resume-builder/new" >
                           <Button  size="lg" style={{backgroundColor:'green', borderRadius:'20px', fontWeight:'bold'}}>Create a New Resume</Button>
                        </Link>
                    </Row>
                </div>}
            </div>
        </>
    )
}

export default ResumeBuilder;
interface ListItemProps {
    index: number;
    data: Datum;
    duplicate: (index: number) => void;
    deleteRow: (index: number) => void;
}
interface Datum {
    resumeName: string;
    id: number;
}

