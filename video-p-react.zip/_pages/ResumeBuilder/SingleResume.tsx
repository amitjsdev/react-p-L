import React, { useEffect, useState } from 'react'
import { TopNavigationBar } from '../../_components'
import { makeStyles } from '@material-ui/core/styles';
import {withRouter} from 'react-router-dom';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Typography from '@material-ui/core/Typography';
import Box from '@material-ui/core/Box';
import PropTypes from 'prop-types';
import BasicDetail from './BasicDetail';
import Educational from './Educational';
import Certifications from './Certifications';
import Skills from './Skills';
import Complete from './Complete';
import Summary from './Summary';
import './set.css';
import { LottieLoader } from '../../_components/lottie-loader.component'
import { MainService } from '../../_services/main.service';
import Experiences from './Experience';
const user = JSON.parse(localStorage.getItem('user') || '{}');
const main = new MainService();
const SingleResume = (props:any) => {
    const classes = useStyles();
    const [value, setValue] = React.useState(0);
    const [selectedResumeId, setSelectedResumeId] = React.useState(0);
    const [data, setData] = React.useState([])
    const [resume, setResume] = React.useState(undefined)
    const [loading, setloading] = useState(false)
    const [initialLoading, setInitialLoading] = useState(true)
    let {match:{path,params:{id}}}=props;
    const isNew =path ==='/resume-builder/new';
    id =  isNaN(parseInt(id)) ? null : parseInt(id);
    console.log({id});
    
    useEffect(()=>{
        if(!id && !isNew){
            props.history.push('/resume-builder');
        } else if(isNew){
            setSelectedResumeId(-1);
            setInitialLoading(false);
        } else if (id) {
            selectResume(id);
        }
    },[id,isNew]);

    
    const handleChange = (event: any, newValue: any) => {
        setValue(newValue);

    };

    const saveBaseData = (key: string, formData: any) => {
        setData({ ...data, [key]: formData })
    }
    const selectResume = (id: number) => {
        setSelectedResumeId(id)
        setloading(true);
        main.getSingleResume(user.token, id).then(res => {
            if (res && res.resume) {
                setResume(res.resume)
                setValue(0);
                setInitialLoading(false)
                
            } else {
                setResume(undefined)
                setInitialLoading(false)
            }
            setloading(false);
        })
            .catch(err => {
                setResume(undefined)
                setloading(false);
                setInitialLoading(false)
            })
    }

    const changeTab =(tabId:number, key:string, data:any)=>{
        setValue(tabId);
        setResume(data)
    }

    return (
        <>

            <TopNavigationBar />

            <div className="" style={{ marginTop: '60px', marginBottom: '7%' }}></div>
            <div className="main ">
                {loading ? (
                    <div className="d-flex justify-content-center mt-5 pt-5">
                        <LottieLoader />
                    </div>
                ) : null}

                {!initialLoading && <div className="container">
                
                    <div className={classes.root}>
                        <AppBar position="static">
                            <Tabs value={value} onChange={handleChange} aria-label="simple tabs example">
                                
                                <Tab label="Basic Info" {...a11yProps(0)} />
                                <Tab label="Summary" {...a11yProps(1)} />
                                <Tab label="Education" {...a11yProps(2)} />
                                <Tab label="Work Experience" {...a11yProps(3)} />
                                <Tab label="Certifications" {...a11yProps(4)} />
                                <Tab label="Skills" {...a11yProps(5)} />
                                <Tab label="Complete" {...a11yProps(6)} />
                            </Tabs>
                        </AppBar>
                        
                        <TabPanel value={value} index={0} >
                            <BasicDetail history={props.history} setSelectedResumeId={setSelectedResumeId} update={saveBaseData} resume={resume} id={selectedResumeId} setloading={setloading} changeTab={changeTab}/>
                        </TabPanel>
                        <TabPanel value={value} index={1}>
                            <Summary
                            update={saveBaseData} resume={resume} id={selectedResumeId} setloading={setloading} changeTab={changeTab}
                            />
                        </TabPanel>
                        <TabPanel value={value} index={2}>
                            <Educational
                            update={saveBaseData} resume={resume} id={selectedResumeId} setloading={setloading} changeTab={changeTab}
                            />
                        </TabPanel>
                        <TabPanel value={value} index={3}>
                            <Experiences
                             update={saveBaseData} resume={resume} id={selectedResumeId} setloading={setloading} changeTab={changeTab}
                            />
                        </TabPanel>
                        <TabPanel value={value} index={4}>
                            <Certifications
                            update={saveBaseData} resume={resume} id={selectedResumeId} setloading={setloading} changeTab={changeTab}
                            
                            />
                        </TabPanel>
                        <TabPanel value={value} index={5}>
                            <Skills
                            //  update={saveBaseData}
                            />
                        </TabPanel>
                        <TabPanel value={value} index={6}>
                            <Complete
                            // update={saveBaseData}
                            />
                        </TabPanel>

                    </div>

                </div>}
            </div>
        </>
    )
}

export default withRouter(SingleResume);
function TabPanel(props: any) {
    const { children, value, index, ...other } = props;

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`simple-tabpanel-${index}`}
            aria-labelledby={`simple-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box p={3}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}

TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.any.isRequired,
    value: PropTypes.any.isRequired,
};

function a11yProps(index: number) {
    return {
        id: `simple-tab-${index}`,
        'aria-controls': `simple-tabpanel-${index}`,
    };
}

const useStyles = makeStyles((theme) => ({
    root: {
        flexGrow: 1,
        backgroundColor: theme.palette.background.paper,
    },
}));
interface Datum {
    resumeName: string;
    id: number;
}

