import React, { useEffect, useState } from 'react'
import { Form, Row, Col } from 'react-bootstrap';
import SkillsForm from './SkillsForm';
import Button from '@material-ui/core/Button';
import AddIcon from '@material-ui/icons/Add';
const Skills = () => {
    const [show, setShow] = useState(false)
    const data = {
        resume_name: '',
        first_name: '',
        last_name: '',
        phone: '',
        address: '',
        linked_in: '',
        twitter: '',
        website: '',
        email: '',
    }

    const onClose = (data: any) => {
        console.log({ data });
        setShow(false);
    }

    return (
        <>
            <Row style={{ textAlign: 'center', margin: '20px,0', width: '100%' }}>
                <h3 className="pl-2" style={{ textAlign: 'left', margin: '20px,0', width: '100%', fontWeight: 'bold' }}>
                    Add skills you posses
                </h3>
            </Row>
            <div className="container-fluid" style={{ marginTop: 30 }}>
                <Row>
                    <Col md="4">
                        <Button
                            variant="contained"
                            color="default"
                            size="large"
                            style={{ backgroundColor: '#fff', borderRadius: 10 }}
                            onClick={e => setShow(true)}
                            startIcon={<AddIcon />}
                        >Add new skill</Button>
                    </Col>
                    <Col md="3">
                    </Col>
                    <Col md="5">
                        <p>
                            list out your that you posses that make your application stand out.
                        </p>
                    </Col>

                </Row>

            </div>
            <SkillsForm show={show} onClose={onClose} />
        </>
    )
}

export default Skills
