import React, { useEffect, useState } from 'react'
import { Button, Modal } from 'react-bootstrap'
import { Form, Row, Col } from 'react-bootstrap';
const SkillsForm = (props) => {

    const data = {
        resume_name: '',
        first_name: '',
        last_name: '',
        phone: '',
        address: '',
        linked_in: '',
        twitter: '',
        website: '',
        email: '',
    }

    

    return (
        <Modal  show={props.show} onHide={props.onClose}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
        >
            <Modal.Header closeButton style={{ border: 'none' }} />
            <Modal.Body>
               
            <div className="container-fluid">
                <Form>
                    <Row>
                        <Form.Group as={Col} controlId="formGridEmail">
                            <Form.Label>Skill Name</Form.Label>
                            <Form.Control type="text" style={{ borderRadius: '0', width: '70%' }} />
                        </Form.Group>
                        <Form.Group as={Col} controlId="formGridPassword">

                        </Form.Group>

                    </Row>
                   
                    
                </Form>
            </div>
            </Modal.Body>
            <Modal.Footer style={{ alignSelf: 'center' }}>
                <Button style={{ background: '#2E27D9', width: '150px', borderRadius: '40px', borderColor: '#a3b5c9' }}
                 onClick={props.onClose}>
                    Save
                </Button>
            </Modal.Footer>
        </Modal>
        
    )
}

export default SkillsForm
