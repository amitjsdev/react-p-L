import React, { useEffect, useState } from 'react'
import { Form, Row, Col } from 'react-bootstrap';
import RichEditor from '../../_components/RichEditor';
import Button from "../../_components/button.component";
import { MainService } from '../../_services/main.service';
import Alert from '@material-ui/lab/Alert';
const user = JSON.parse(localStorage.getItem('user') || '{}');
const main = new MainService();
const Summary = (props: Props) => {
    const { resume, id, setloading, changeTab } = props;
   
    const data: string = resume && resume.resumeContent && resume.resumeContent.summary ? resume.resumeContent.summary : '';
    const [summaryData, setData] = useState(data);
    const [hasError, setError] = useState(false);
    
    const onFinishHandler = (e: any) => {
        e.preventDefault()
        if(summaryData.length <1) {
            setError(true);
        } else {
        setloading(true);
       
        main.postSummaryResume(user.token, id, {summary:summaryData} )
            .then(res => {
                if (res && res.message && res.message == 'data updated') {
                    changeTab(2, 'summary', res.resume)
                } else {

                }
                setloading(false);
            })
            .catch(err => {
                setloading(false);
            })
        }
    }


    return (
        <>
            <Row style={{ textAlign: 'center', margin: '20px,0', width: '100%' }}>
                <h3 className="pl-2" style={{ textAlign: 'left', margin: '20px,0', width: '100%', fontWeight: 'bold' }}>
                    Write a professional Summary
                </h3>
            </Row>
            <div className="container-fluid" style={{ marginTop: 30 }}>
                <Form onSubmit={onFinishHandler}>
                    <Row>
                        <Col >
                            <RichEditor data={summaryData} onChange={(data: string) => {setData( data );setError(data.length >0 ? false :true)}} />
                        </Col>
                        <Col>
                            <p>
                                Please enter a short summary of your key selling points. Think of it as an elevator pitch where you want the interviewer to quickly gets impressed with your credentials.
                            </p>
                        </Col>

                    </Row>
                    <Row>
                        <Col >
                    <div className="" style={{marginTop:20}} >
                        {hasError && <Alert severity="error">Summary is Required</Alert>}
                        <Button text="Save and Countinue" color="primary" />
                    </div>
                    </Col>
                    </Row>
                </Form>
            </div>
        </>

    )
}

export default Summary
interface Props {
    update: (key: string, formData: any) => void;
    setloading: (loading: boolean) => void;
    changeTab: (tabId: number, key: string, data: any) => void;
    resume?: any;
    id: number;
}

interface SummaryDataInterface {
    summary: string;
}

