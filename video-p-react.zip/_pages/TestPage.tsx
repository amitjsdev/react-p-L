import React from 'react'


export const TEST_ROUTE = '/test';
const TestPage = () => {
    return (
        <div>
            Testing
        </div>
    )
}

export default TestPage
