import React, { ReactNode } from 'react';
import { TopNavigationBarWithBack } from '../_components';
import { history } from '../_config';

export const ABOUT_ROUTE = '/about';

export function AboutPage() {
    return (
        <div className="AboutPage">
            <TopNavigationBarWithBack />
            <div className="body">
                <h4>Playfully serious language learning</h4>
                <div className="content">
                    Taplingua App was conceived by Dr. Cristina Guijarro, a PhD in Romance Languages from the University of Chicago.
                    Before starting the Taplingua project, Cristina worked as a professor, researcher and instructor for over 15 years.
                    She has taught at the University of Chicago and other leading American universities.
                    The App is the result of her long experience teaching languages to thousands of university students and industrial professionals.
                </div>
            </div>
        </div>
    )
}
