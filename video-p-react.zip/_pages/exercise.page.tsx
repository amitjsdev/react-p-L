
import React, { ReactNode, useEffect } from 'react';
import { BackArrow, ExerciseMiniLesson1, ExerciseMiniLesson2, ExerciseMiniLesson3, ExerciseTapThePairSentences, ExerciseTapThePair, ExerciseTapWhatYouHear, ExerciseTranslateSentence, PreExercise, TopNavigationBarWithBack, Spinner, UncontrolledLottie } from '../_components';
import { MainService } from '../_services/main.service';
import { Lesson, Module, ModuleRoute, RecentModule, ResponseMyStreak, ResponsePayWallDetail, V2Exercise, V2ExerciseType } from '../_types';
import { Nl2br, SwitchButton } from '../_components';
import { Link } from 'react-router-dom';
import { makeLearnRoute } from './learn.page';
import moment from 'moment';
import { history } from '../_config';
import { AuthService } from '../_services';
import { HOME_ROUTE } from './home_learn.page';
import heartFull from '../_assets/heart-full.png';
import heartEmpty from '../_assets/heart-empty.png';
import animationData from '../_assets/_animations/pre-play.json';
import streakAnimationData from '../_assets/_animations/_streaks/plus_25_1.json';


type P = {
    user: any,
    match: any,
    myStreak: ResponseMyStreak,
    coursesRegistered: Array<RecentModule>
}

type S = {
    module: Module | null,
    lesson: Lesson | null,
    route: ModuleRoute | null,
    preExerciseDone: boolean, // is pre exercise done? show main exercise
    dialogProgress: number, // tells which dialog are we currently on
    startTime: Date,
    exercises: V2Exercise[],
    exerciseIndex: number, // the exercise we are at
    dailyGoalTotal: number,
    dailyLivesLeft: number,
    currentScore: number,
    showExerciseCompletePopup: boolean,
    showLivesExaustedPopup: boolean,
    result: any[],
    isLoading: boolean,
    streakAttained: boolean,
}

export const EXERCISE_ROUTE = '/module/:moduleNo/route/:routeNo/level/:levelNo/lesson/:lessonNo/exercise';

export const makeExerciseRoute = (
    moduleNo: string,
    routeNo: string,
    levelNo: string,
    lessonNo: string,
    redir?: string,
) => `/module/${moduleNo}/route/${routeNo}/level/${levelNo}/lesson/${lessonNo}/exercise`;

export class ExercisePage extends React.Component<P, S> {

    private main = new MainService();

    private auth = new AuthService();

    private moduleNo: number;
    private routeNo: number;
    private levelNo: number;
    private lessonNo: number;

    constructor(props: P) {
        super(props);



        this.moduleNo = props.match.params.moduleNo;
        this.routeNo = props.match.params.routeNo;
        this.levelNo = props.match.params.levelNo;
        this.lessonNo = props.match.params.lessonNo;

        this.state = {
            module: null,
            lesson: null,
            route: null,
            preExerciseDone: false,
            dialogProgress: 0,
            startTime: new Date(),
            exercises: [],
            exerciseIndex: 0,
            dailyGoalTotal: 0,
            dailyLivesLeft: 0,
            currentScore: 0,
            showLivesExaustedPopup: false,
            showExerciseCompletePopup: false,
            result: [],
            isLoading: false,
            streakAttained: false,
        }
    }

    componentDidMount() {

        // fetch daily score
        this.main.getEmployeeCustomFetch(this.props.user, {
            userId: "",
            daily_goal_total: "",
            dailyLivesLeft: ""
        }).then(data => {
            this.setState({
                dailyGoalTotal: data.daily_goal_total,
                dailyLivesLeft: data.dailyLivesLeft
            });
        });
    }

    render() {

        return this.state.preExerciseDone ? this.showExercise() : this.showPreExercise();

    }

    /**
     * Shows the pre-exercise dialog
     */
    showPreExercise() {
        return (
            <div className="ExercisePage">
                <TopNavigationBarWithBack onClick={() => {
                    history.push(HOME_ROUTE);
                }} />
                <div className="pre_exercise_heading">Now it's time to play</div>
                <UncontrolledLottie animationData={animationData} width={275} />
                <div className="pre_exercise_content">
                    In the play section, you will practice listening, reading
                    and speaking exercises based on the dialogs and videos.
                </div>
                <div className="pre_exercise_continue" onClick={() => {
                    // mark pre-exercise as done
                    this.loadExercise();
                }}>Continue</div>
            </div>
        )
    }

    // get the data related to the exercise
    loadExercise() {
        // fetch the exercise
        this.main.getExercises(this.props.user, this.moduleNo, this.routeNo, this.lessonNo)
            .then(exercises => {
                // set v2exercise to state
                this.setState({
                    exercises
                });
            });
        // then showTheExercise
        this.setState({
            preExerciseDone: true
        });
    }


    /**
     * Show the main exercise
     */
    showExercise() {
        return (
            <div className="ExercisePage">
                {/* top bar */}
                <TopNavigationBarWithBack buttonTwoComponent={
                    // show remaining lives here
                    <span className="remaining_lives">
                        {this.showLives()}
                        <span className="dailyGoalTotal">{this.state.dailyGoalTotal + this.state.currentScore}</span>
                    </span>
                } />
                {/* container */}
                <div className="container mt-5 text-center">
                    {/* get exercise progress */}
                    {
                        this.showCurrentExerciseProgress()
                    }
                    {/* current exercise switch */}
                    {
                        this.state.isLoading ? (
                            <div className="loader" style={{
                                display: "flex",
                                padding: "5rem 0",
                                justifyContent: "center"
                            }}>
                                <Spinner larger />
                            </div>
                        ) : (
                                <div className="CurrentExercise">
                                    {
                                        this.showCurrentExercise()
                                    }
                                </div>
                            )
                    }
                </div>
                {/* exercise done popup */}
                {
                    this.showCompletedPopup()
                }
                {/* streak achieve popup */}
                {
                    this.showStreakAchievedPopup()
                }
                {/* lives exausted popup */}
                {
                    this.state.showLivesExaustedPopup ?
                        <div className="LivesExaustedPopup">
                            <div>
                                <div>You are out of lives!, Get more lives and continue playing.</div>
                                <div className="available-points">Available Points: {this.state.dailyGoalTotal + this.state.currentScore}</div>
                                <div className="additional-info">
                                    <div>-15 points</div>
                                    <div className="remaining_lives">
                                        {this.showLives()}
                                    </div>
                                </div>
                                <div className="get-more-lives"
                                    onClick={() => {
                                        // reduce 15 points, give 3 lives, remove popup
                                        this.setState({
                                            dailyLivesLeft: 3,
                                            currentScore: this.state.currentScore - 15,
                                            showLivesExaustedPopup: false,
                                        });
                                    }}
                                >Get More Lives</div>
                                <div className="restart-lesson" onClick={() => {
                                    // TODO: show restart popup and then reload
                                    window.location.reload();
                                }}>Restart Lesson</div>
                            </div>
                        </div>
                        : <></>
                }
            </div>
        );
    }

    /**
     * Show current progress
     */
    showCurrentExerciseProgress(): ReactNode {
        return (
            <div className="current-exercise-progress-bar">
                <div className="current-exercise-progress" style={{
                    width: ((this.state.exerciseIndex / (this.state.exercises.length - 1)) * 100) + "%"
                }}></div>
            </div>
        )
    }


    /**
     * Switch on exercise type to show current exercise
     */
    showCurrentExercise(): ReactNode {
        const currentExercise = this.state.exercises[this.state.exerciseIndex];

        const learnRoute = makeLearnRoute(this.moduleNo.toString(), this.routeNo.toString(), this.levelNo.toString(), this.lessonNo.toString());

        if (!currentExercise) {
            return <div>Please wait!</div>;
        }


        switch (currentExercise.exerciseType) {
            case V2ExerciseType.translate_sentence:
                return <ExerciseTranslateSentence
                    main={this.main}
                    exercise={currentExercise}
                    key={currentExercise.id}
                    learnRoute={learnRoute}
                    saveStatus={(status: number, failCount: number = 0) => {
                        this.saveStatus(status, currentExercise, failCount);
                    }}
                    onNext={() => {
                        this.showNextExercise();
                    }} />;
            case V2ExerciseType.tap_what_you_hear:
                return <ExerciseTapWhatYouHear
                    main={this.main}
                    exercise={currentExercise}
                    key={currentExercise.id}
                    learnRoute={learnRoute}
                    saveStatus={(status: number, failCount: number = 0) => {
                        this.saveStatus(status, currentExercise, failCount);
                    }}
                    onNext={() => {
                        this.showNextExercise();
                    }} />;
            case V2ExerciseType.mini_lesson_1:
                return <ExerciseMiniLesson1
                    main={this.main}
                    exercise={currentExercise}
                    key={currentExercise.id}
                    learnRoute={learnRoute}
                    saveStatus={(status: number, failCount: number = 0) => {
                        this.saveStatus(status, currentExercise, failCount);
                    }}
                    onNext={() => {
                        this.showNextExercise();
                    }} />;
            case V2ExerciseType.mini_lesson_2:
                return <ExerciseMiniLesson2
                    main={this.main}
                    exercise={currentExercise}
                    key={currentExercise.id}
                    learnRoute={learnRoute}
                    saveStatus={(status: number, failCount: number = 0) => {
                        this.saveStatus(status, currentExercise, failCount);
                    }}
                    onNext={() => {
                        this.showNextExercise();
                    }} />;
            case V2ExerciseType.mini_lesson_3:
                return <ExerciseMiniLesson3
                    main={this.main}
                    exercise={currentExercise}
                    key={currentExercise.id}
                    learnRoute={learnRoute}
                    saveStatus={(status: number, failCount: number = 0) => {
                        this.saveStatus(status, currentExercise, failCount);
                    }}
                    onNext={() => {
                        this.showNextExercise();
                    }} />;
            case V2ExerciseType.tap_the_pair:
                return <ExerciseTapThePair
                    main={this.main}
                    exercise={currentExercise}
                    key={currentExercise.id}
                    learnRoute={learnRoute}
                    saveStatus={(status: number, failCount: number = 0) => {
                        this.saveStatus(status, currentExercise, failCount);
                    }}
                    onNext={() => {
                        this.showNextExercise();
                    }} />;
            case V2ExerciseType.tap_the_pair_sentences:
                return <ExerciseTapThePairSentences
                    main={this.main}
                    exercise={currentExercise}
                    key={currentExercise.id}
                    learnRoute={learnRoute}
                    saveStatus={(status: number, failCount: number = 0) => {
                        this.saveStatus(status, currentExercise, failCount);
                    }}
                    onNext={() => {
                        this.showNextExercise();
                    }} />;
            default:
                return <div>{currentExercise.exerciseType} Not implemented!</div>;
        }
    }

    saveStatus(status: number, currentExercise: V2Exercise, failCount: number = 0) {
        // save the status of in state
        const result = {
            questionId: currentExercise.id,
            additionalInfo: "",
            status,
            failCount
        };

        // check if status is 1, increase score if so
        let score = status ? this.state.currentScore + 5 : this.state.currentScore;

        if (status) {
            // save the daily goal log
            this.main.saveDailyGoalLog(
                this.props.user,
                this.moduleNo,
                this.routeNo,
                this.lessonNo,
                5
            ).then(response => {
                const { data } = response;
                if (data.is_daily_goal_attained) {
                    // if daily goal is attained, show the goal attained screen
                    this.setState({
                        streakAttained: true
                    });
                    // play streak sound
                    this.main.playSound("streak");
                }
            })
                .catch(err => {
                    console.error('error while saving daily points', { err });
                })
        } else {
            // remove a life
            const newLife = this.state.dailyLivesLeft - 1;

            if (newLife >= 0) {
                // remove the life
                this.setState({
                    dailyLivesLeft: newLife
                });
            } else {
                // show lives exausted popup
                this.setState({
                    showLivesExaustedPopup: true
                });
                // play the sound of exaustion
                this.main.playSound("failure");
            }
        }

        this.setState({
            currentScore: score,
            result: [...this.state.result, result]
        });
    }

    showNextExercise() {
        // increase the exercise index or save log accordingly
        if (this.state.exerciseIndex + 1 === this.state.exercises.length) {
            // if we are at the last exercise
            // save the log
            // this.main.saveRoundLog(this.props.user, this.state.result);

            // show the ending screen
            // save the result
            this.setState({
                isLoading: true
            });
            this.main.saveRoundLog(this.props.user, {
                moduleNo: this.moduleNo,
                routeNo: this.routeNo,
                lessonNo: this.lessonNo,
                status: 1, // status one on success
                livesLeft: this.state.dailyLivesLeft,
                additionalLivesClaimed: 0,
                questions: this.state.result,
                score: this.state.currentScore,
            })
                .then(response => {
                    console.log({ response })
                })
                .catch(err => {
                    console.log({ err })
                })
                .finally(() => {
                    // show the exercise complete popup
                    this.setState({
                        showExerciseCompletePopup: true,
                        isLoading: false
                    })
                });
            console.log({ lastExercise: "Yes" })
        } else {
            // increase the exercise
            this.setState({
                exerciseIndex: this.state.exerciseIndex + 1
            });
        }
    }

    /**
     * The continue or skip button
     */
    saveProgressAndMoveForward() {


        // save the user activity log
        const payload = {
            userId: this.props.user.email,
            activityDateFrom: moment(this.state.startTime).format('YYYY-MM-DD hh:mm:ss'),
            activityDateTo: moment(new Date()).format('YYYY-MM-DD hh:mm:ss'),
            activityType: 3, // 1= Listen, 2 = Learn, 3 = Play
            moduleNo: this.moduleNo,
            routeNo: this.routeNo,
            levelNo: this.levelNo,
            totalQuestions: this.state.lesson?.dialog.length,
            lessonNo: this.lessonNo
        };

        this.auth.saveActivityLog(this.props.user, payload)
            .then(response => {
                //
            })
            .catch(error => {
                // TODO: Error handled
            })
            .finally(() => {
                const redir = (new URLSearchParams(window.location.search)).get('redir');
                if (redir === "exercise") {
                    history.push('/exercise');
                } else {
                    history.push(makeLearnRoute(this.moduleNo.toString(), this.routeNo.toString(), this.levelNo.toString(), this.lessonNo.toString()));
                }
            });
    }

    /**
     * Shows the lives left on top
     */
    showLives() {
        const { dailyLivesLeft } = this.state;

        return (
            <>
                {
                    Array(dailyLivesLeft).fill(1).map((h, index) => (
                        <img key={index} src={heartFull} alt="heart-full" />
                    ))
                }
                {
                    Array(3 - dailyLivesLeft).fill(1).map((h, index) => (
                        <img key={index} src={heartEmpty} alt="heart-empty" />
                    ))
                }
            </>
        )
    }

    /**
     * Show completed popup if needed
     */
    showCompletedPopup() {
        return (
            this.state.showExerciseCompletePopup ?
                <div className="ExerciseCompletePopup">
                    {/* top bar */}
                    <TopNavigationBarWithBack />
                    <div className="body">
                        <div className='almost-there'>Oh, almost there!</div>
                        <div className='points-earned'>Points Earned: {this.state.currentScore}</div>
                        {/* place for happy polly */}
                        <div className="you-can-do-better">
                            I'm sure you can do better! <br />
                            Try to repeat this lesson to improve your result.
                        </div>
                        <div className="go-to-next-lesson" onClick={() => {
                            window.location.assign(window.location.origin);
                        }}>Go to next lesson</div>
                    </div>
                </div>
                : <></>
        );
    }

    /**
     * Show streak Achieved popup
     */
    showStreakAchievedPopup() {

        return (
            this.state.streakAttained ?
                <div className="StreakAttainedPopup">
                    {/* top bar */}
                    <TopNavigationBarWithBack onClick={() => {
                        this.setState({
                            streakAttained: false
                        });
                    }} />
                    <div className="body">
                        <div className='points-earned'>Awesome</div>
                        <div className=''>You have achieved your daily streak.</div>
                        {/* <div className='almost-there'>Oh, almost there!</div> */}
                        {/* place for happy polly */}
                        <UncontrolledLottie animationData={streakAnimationData} width={175} height={175} />
                        {/* <div className="you-can-do-better">
                            I'm sure you can do better! <br />
                            Try to repeat this lesson to improve your result.
                        </div> */}
                        {/* streak progress */}
                        {
                            this.props.myStreak ? (
                                <div className="streak-weekly-progress">
                                    <div className="progress-day">
                                        <div className="day-name">M</div>
                                        <div className={
                                            "day-progress " + (this.props.myStreak.progress[0] ? "completed" : "")
                                        }></div>
                                    </div>
                                    <div className="progress-day">
                                        <div className="day-name">T</div>
                                        <div className={
                                            "day-progress " + (this.props.myStreak.progress[1] ? "completed" : "")
                                        }></div>
                                    </div>
                                    <div className="progress-day">
                                        <div className="day-name">W</div>
                                        <div className={
                                            "day-progress " + (this.props.myStreak.progress[2] ? "completed" : "")
                                        }></div>
                                    </div>
                                    <div className="progress-day">
                                        <div className="day-name">T</div>
                                        <div className={
                                            "day-progress " + (this.props.myStreak.progress[3] ? "completed" : "")
                                        }></div>
                                    </div>
                                    <div className="progress-day">
                                        <div className="day-name">F</div>
                                        <div className={
                                            "day-progress " + (this.props.myStreak.progress[4] ? "completed" : "")
                                        }></div>
                                    </div>
                                    <div className="progress-day">
                                        <div className="day-name">S</div>
                                        <div className={
                                            "day-progress " + (this.props.myStreak.progress[5] ? "completed" : "")
                                        }></div>
                                    </div>
                                    <div className="progress-day">
                                        <div className="day-name">S</div>
                                        <div className={
                                            "day-progress " + (this.props.myStreak.progress[6] ? "completed" : "")
                                        }></div>
                                    </div>
                                </div>
                            ) : <></>
                        }
                        <div className="go-to-next-lesson" onClick={() => {
                            this.setState({
                                streakAttained: false
                            });
                        }}>Continue</div>
                    </div>
                </div>
                : <></>
        );
    }
}