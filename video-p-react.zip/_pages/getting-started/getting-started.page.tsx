import React, { useEffect, useState } from 'react'
import { Carousel } from 'react-responsive-carousel';
import { useSelector } from 'react-redux'
import { useParams } from 'react-router-dom'
import { useToasts } from 'react-toast-notifications'
import taplinguaMainLogo from '../../_assets/Screenshot_277.png';
import { TopNavigationBar } from '../../_components'
import './getting-started.style.scss';
import "react-responsive-carousel/lib/styles/carousel.min.css";
export const GETTING_STARTED_PAGE_ROUTE = "/"

interface I {
    setGettingStartedDone: (e: any) => void
}

const GettingStartedPage = (p: I) => {

    const [showTour, setShowTour] = useState(false);

    return (
        <div className="GettingStarted">
            <TopNavigationBar />
            <div style={{ marginTop: '60px' }}></div>
            <div className="container" style={{ paddingTop: "3rem" }} >
                {
                    showTour ? (
                        <div className="carousal-holder">
                            <Carousel
                                showStatus={false}
                                showThumbs={false}>
                                <div className="carousel-page">
                                    <img src="/_assets/getting-started/1.png" />
                                    <div className="heading">Extensive Practice Sets</div>
                                    <div className="sub-heading">Taplingua provides extensive practice sets in technical and HR rounds. You can practice interview questions using the AI based feedback system. You can also ask mentors and peers to evaluate your answers and keep improving at every step.</div>
                                </div>
                                <div className="carousel-page alt">
                                    <img src="/_assets/getting-started/learn.png" />
                                    <div className="heading-holder">
                                        <div className="heading">LEARN</div>
                                        <div className="sub-heading">Follow the in-depth curriculum to understand the interview process, pit-falls and best practices. A structured course that helps you prepare for the most difficult questions to the tricky ones.</div>
                                    </div>
                                </div>
                                <div className="carousel-page alt">
                                    <img src="/_assets/getting-started/practice.png" />
                                    <div className="heading-holder">
                                        <div className="heading">PRACTICE</div>
                                        <div className="sub-heading">Record your answers to interview questions from your desktop or mobile. Practice as many times you want until feel you have nailed the answer. Build your confidence whether they are technical questions or HR ones.</div>
                                    </div>
                                </div>
                                <div className="carousel-page alt">
                                    <img style={{ maxWidth: '35%' }} src="/_assets/getting-started/review.png" />
                                    <div className="heading-holder">
                                        <div className="heading">REVIEW</div>
                                        <div className="sub-heading">Get automatic reviews from the AI feedback
                                            system. Ask mentors for feedback. Rate your own
                                            answers. Keep improving along the way.</div>
                                    </div>
                                </div>
                                {/* <div className="carousel-page">
                                    <img src="/_assets/getting-started/3.PNG" />
                                    <div className="heading">PRACTICE</div>
                                    <div className="sub-heading">Follow the in-depth curriculum to understand the interview process, pit-falls and best practices. A structured course that helps you prepare for the most difficult questions to the tricky ones.</div>
                                </div> */}
                                {/* <div className="carousel-page alt" style={{
                                    padding: "1rem 3rem"
                                }}>
                                    <div>
                                        <img src="/_assets/getting-started/2.png" />
                                        <div className="heading">REVIEW</div>
                                        <div className="sub-heading">Follow the in-depth curriculum to understand the interview process, pit-falls and best practices. A structured course that helps you prepare for the most difficult questions to the tricky ones.</div>
                                    </div>
                                    <div className="alt-right">
                                        <div className="img-holder"><img src="/_assets/getting-started/111.PNG" /></div>
                                        <div className="img-holder"><img src="/_assets/getting-started/222.PNG" /></div>
                                        <div className="img-holder"><img src="/_assets/getting-started/333.PNG" /></div>
                                        <div className="img-holder"><img src="/_assets/getting-started/444.PNG" /></div>
                                    </div>
                                </div> */}
                            </Carousel>
                            <div className="tourSkipper" onClick={e => {
                                localStorage.setItem('getting-started-done', 'true');
                                p.setGettingStartedDone(true);
                            }}>&times;</div>
                        </div>
                    ) : (
                        <>
                            <div className="center-logo-1">
                                <img className="taplingua-logo" src={taplinguaMainLogo} alt="Taplingua Logo" />
                            </div>
                            <div className="welcome-text">Welcome to the Taplingua Interview Prep Platform</div>
                            <div className="welcome-subtext">
                                All-in-one solution to get you interview ready
                            </div>
                            <div className="button-holder">
                                <div className="button-red" onClick={e => {
                                    setShowTour(true);
                                }}>Give me an  overview</div>
                                <div className="button-purple" onClick={e => {
                                    localStorage.setItem('getting-started-done', 'true');
                                    p.setGettingStartedDone(true);
                                    localStorage.removeItem('joyride-show.practicepage');
                                    localStorage.removeItem('joyride-show.myvideopage');
                                    localStorage.removeItem('joyride-show.practicesetpage');
                                }}>Show me how it works</div>
                            </div>
                        </>
                    )
                }
            </div>
        </div>
    )
}

export default GettingStartedPage
