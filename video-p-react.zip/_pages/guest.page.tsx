import React, { useState } from 'react';
import logo from '../_assets/main-logo.png'
import { Link } from 'react-router-dom';
import { LOGIN_ROUTE } from './login.page';
import { ONBOARDING_ROUTE } from './onboarding.page';
import { history } from '../_config';

import logo1 from '../_assets/main-logo-alt.png'
import HomeImg001 from '../_assets/GuestImage001.svg'
import HomeImg002 from '../_assets/GuestImage002.png'
import HomeImg003 from '../_assets/GuestImage003.png'
import HomeImg004 from '../_assets/GuestImage004.png'
import Iconnew from '../_assets/Iconnew.png'





export const GUEST_ROUTE = "/guest";


type GuestPageProps = {
    setPreferredCourse: Function,
}

const languages = {
    "3": "Spanish",
    "43": "French",
    "45": "German",
    "33": "Portuguese",
    "44": "Italian"
};

function getLanguage(code = 3) {
    switch (code) {
        case 3:
            return "Spanish";
        case 43:
            return "French";
        case 45:
            return "German";
        case 33:
            return "Portuguese";
        case 44:
            return "Italian";
    }
    return "Spanish";
}

function getLanguageIcon(code = 3) {
    return '/_assets/_language_icons/icon_module_' + code + '.png';
}


export function GuestPage(props: GuestPageProps) {

    const [language, setLanguage] = useState(3);
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);


    /*  return (
         <div style={{background: "red"}}>sdsd</div>
     ) */
    return (
        <>
            <div className="GuestPageNew">
                <div className="container-fluid">
                    <div className="HeaderGuest">
                        <div className="row" style={{
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center"
                        }}>
                            <div className="col-md-6">
                                <Link className="GuestLogo" to=""><img src={logo1} alt={'Logo'} /></Link>
                            </div>
                            <div className="col-md-6">

                                <div className="GuestNav">
                                    <Link to={LOGIN_ROUTE}>Login</Link>
                                    <Link to="">Register</Link>
                                </div>
                            </div>
                        </div>
                        <div className="row my-3">
                            <div className="col-md-6">
                                <div className="ImgTextCont">
                                    <div>
                                        <h2 className="mb-5">The Seriously Fun Language Learning App</h2>
                                        <h2>I want to learn</h2>
                                        <div className="LearnButtonDropdown">
                                            <div style={{
                                                display: "flex",
                                                justifyContent: "center",
                                                alignItems: "center"
                                            }}>
                                                <div
                                                    onClick={() => { setIsDropdownOpen(!isDropdownOpen) }}
                                                    className={"custom2-select " + (isDropdownOpen ? "open" : "")}>
                                                    <div className="current-choice">
                                                        <img src={getLanguageIcon(language)} alt={language.toString()} />
                                                        <span>{getLanguage(language)}</span>
                                                    </div>
                                                    <div className="custom2-options">
                                                        {
                                                            Object.entries(languages).map(([key, value]) => {
                                                                if (key === language.toString()) {
                                                                    return <></>
                                                                }
                                                                return (
                                                                    <div className="custom2-option" onClick={() => {
                                                                        setLanguage(parseInt(key));
                                                                    }}>
                                                                        <img src={getLanguageIcon(parseInt(key))} alt={key} /> <span>{value}</span>
                                                                    </div>
                                                                )
                                                            })
                                                        }
                                                    </div>
                                                </div>
                                                <button className="StartLearning" onClick={() => {
                                                    // set the preferred language
                                                    props.setPreferredCourse(language);
                                                    // send to onboarding
                                                    history.push(ONBOARDING_ROUTE);
                                                }}>Start Learning</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-6">
                                <div className="CenterImg">
                                    <img src={HomeImg001} alt={'Home image 001'} />
                                </div>
                            </div>

                        </div>

                        <div className="row my-5">
                            <div className="col-md-4">
                                <div className="HowLearnList">
                                    <div className="RoundCount">1</div>
                                    <div className="RoundCountText">
                                        <h2>Learn Everyday Conversations</h2>
                                        <p>Word and phrases you can really use</p>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div className="HowLearnList">
                                    <div className="RoundCount">2</div>
                                    <div className="RoundCountText">
                                        <h2>From an expert instructor</h2>
                                        <p>From an expert instructor</p>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div className="HowLearnList">
                                    <div className="RoundCount">3</div>
                                    <div className="RoundCountText">
                                        <h2>Practice makes perfect</h2>
                                        <p>Fun and games to help you along</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-12 my-5">
                                <h2 className="BigHeadingNew">The Taplingua Method</h2>
                            </div>
                            <div className="col-md-6">
                                <div className="TextCenterTable">
                                    <div className="">
                                        <h2>Learn in Context</h2>
                                        <p>Always learn the language in the context it's used. <br /> Research has proven that adults learn best when hearing an actual conversation in the foreign language.</p>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-6">
                                <div className="ImagesCenterTable"><img src={HomeImg002} alt={'mobimg'} /></div>
                            </div>
                        </div>

                        <div className="row">

                            <div className="col-md-6">
                                <div className="ImagesCenterTable TopMarginMinus"><img src={HomeImg003} alt={'mobimg'} /></div>
                            </div>
                            <div className="col-md-6">
                                <div className="TextCenterTable">
                                    <div className="">
                                        <h2>In depth video tutorials</h2>
                                        <p>The app integrates short video tutorials in all the lessons which have clear in-depth explanations which jump starts your learning and you can quickly absorb new grammar and vocabulary.</p>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div className="row">

                            <div className="col-md-6">
                                <div className="TextCenterTable">
                                    <div className="">
                                        <h2>Fun and Dynamic</h2>
                                        <p>Taplingua exercises are fun and makes you keep coming back day after day. The games helps you create the habit that you really need to develop long casting language skills.</p>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-6">
                                <div className="ImagesCenterTable"><img src={HomeImg004} alt={'mobimg'} /></div>
                            </div>
                        </div>
                    </div>
                </div>
                <Footer />
            </div>
        </>
    );
}


function Footer() {
    return (
        <footer className="footer" id="footer">
            <div className="container">
                <div className="footer_wrap">
                    <div className="footer_left">
                        <a className="footer_logo" href="https://www.taplingua.com/">
                            <img src="" alt="" />
                        </a>
                        <div className="footer_box">
                            <h5 className="footer_title">Taplingua</h5>
                            <div className="footer_content">
                                <ul id="menu-taplingua" className="footer_list">
                                    <li id="menu-item-34"><a href="#">About</a></li>
                                    <li id="menu-item-35"><a href="#">Blog</a></li>
                                    <li id="menu-item-733"><a href="https://www.taplingua.com/contact-us/">Contact Us</a></li>
                                    <li id="menu-item-492"><a href="https://www.taplingua.com/method/">Method</a></li>
                                </ul>
                            </div>
                        </div>
                        <div className="footer_box">
                            <h5 className="footer_title">Products</h5>
                            <div className="footer_content"><ul id="menu-products" className="footer_list"><li id="menu-item-234"><a href="https://www.taplingua.com/business/">Business</a></li>
                                <li id="menu-item-490"><a href="https://www.taplingua.com/tourism/">Tourism</a></li>
                                <li id="menu-item-489"><a href="https://www.taplingua.com/individual/">Individual</a></li>
                            </ul></div>              </div>
                        <div className="footer_box">
                            <h5 className="footer_title">Site language</h5>
                            <div className="footer_content">
                                <ul className="footer_list">
                                    <li>
                                        <a className=" current" href="https://www.taplingua.com/">English</a>
                                    </li>
                                    <li>
                                        <a className="" href="https://www.taplingua.com/es/home-page-es/">Español</a>
                                    </li>
                                    <li>
                                        <a className="" href="https://www.taplingua.com/fr/this-is-the-french-version-2/">Français</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div className="footer_right">
                        <ul className="store_list">
                            <li>
                                <a href="https://apps.apple.com/us/app/taplingua-learn-languages/id1479879730?ls=1">
                                    <img src="https://www.taplingua.com/wp-content/themes/taplingua/images/app_store.svg" alt="" />
                                </a>
                            </li>
                            <li>
                                <a href="https://play.google.com/store/apps/details?id=com.taplingua.languages">
                                    <img src="https://www.taplingua.com/wp-content/themes/taplingua/images/google_play.svg" alt="" />
                                </a>
                            </li>
                        </ul>
                        <div className="footer_right_it">
                            <ul className="social_list">
                                <li>
                                    <a target="_blank" href="https://twitter.com/taplingua">
                                        {/*?xml version="1.0" encoding="utf-8"?*/}<svg xmlns="http://www.w3.org/2000/svg" width="38.28" height="38.279" viewBox="0 0 38.28 38.279">
                                            <rect className="a" fill="transparent" width="38.28" height="38.28" transform="translate(0)" />
                                            <path fill="#fff" d="M50.122,33.049c14.461,0,22.33-11.909,22.33-22.33V9.656A17.287,17.287,0,0,0,76.28,5.615a17.654,17.654,0,0,1-4.466,1.276,8.274,8.274,0,0,0,3.4-4.253,19.506,19.506,0,0,1-4.891,1.914A7.6,7.6,0,0,0,64.583,2a7.99,7.99,0,0,0-7.869,7.869,4.146,4.146,0,0,0,.213,1.7A21.987,21.987,0,0,1,40.765,3.276,8.144,8.144,0,0,0,39.7,7.317a8.449,8.449,0,0,0,3.4,6.593,7.169,7.169,0,0,1-3.615-1.063h0a7.772,7.772,0,0,0,6.38,7.656,6.556,6.556,0,0,1-2.127.213,3.619,3.619,0,0,1-1.489-.213A8.057,8.057,0,0,0,49.7,26.031a16.057,16.057,0,0,1-9.783,3.4A5.888,5.888,0,0,1,38,29.221a20.073,20.073,0,0,0,12.122,3.828" transform="translate(-38 0.551)" />
                                        </svg>                                                          </a>
                                </li>
                                <li>
                                    <a target="_blank" href="https://www.facebook.com/taplingua">
                                        {/*?xml version="1.0" encoding="utf-8"?*/}<svg xmlns="http://www.w3.org/2000/svg" width="19.99" height="38.279" viewBox="0 0 19.99 38.279">
                                            <path fill="#fff" d="M92.972,38.279V20.841h5.955l.851-6.805H92.972V9.782c0-1.914.638-3.4,3.4-3.4H99.99V.213C99.139.213,97.013,0,94.674,0c-5.1,0-8.719,3.19-8.719,8.932v5.1H80v6.805h5.955V38.279Z" transform="translate(-80 0)" />
                                        </svg>                                                          </a>
                                </li>
                            </ul>
                            <a className="footer_email" href="mailto:santanu@taplingua.com">santanu@taplingua.com</a>
                            <ul className="footer_list type2">
                                <li>
                                    <a href="https://www.taplingua.com/es/home-page-es/">Home page – ES</a>
                                </li>
                                <li>
                                    <a href="https://www.taplingua.com/">Home page</a>
                                </li>
                                <li>
                                    <a href="https://www.taplingua.com/fr/this-is-the-french-version-2/">Home page FR</a>
                                </li>
                            </ul>
                            <div className="footer_copyright">Copyright © Taplingua SL. All Rights Reserved.</div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    );
}