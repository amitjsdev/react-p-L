import React, { ReactNode } from 'react';
import { RecentModule } from '../_types';

import 'react-circular-progressbar/dist/styles.css';
import { BottomNavigationBar, Spinner, TopNavigationBar } from '../_components';
import { Link } from 'react-router-dom';
import { withI18 } from '../_context';
import { lang } from 'moment';
import { MainService } from '../_services/main.service';
import { ModuleWithLesson } from '../_types/module-with-lesson.type';
import { makeListenRoute } from './listen.page';
import { makeLearnRoute } from './learn.page';
import { LearnIcon } from '../_icons/learn-icon.icon';
import { PlayIcon } from '../_icons';
import { history } from '../_config';
import { makePlayRoute } from './play.page';
import { ABOUT_ROUTE } from './about.page';
import userIcon from '../_assets/user-icon-96.png';

type P = {
    user: any,
    mostRecent?: RecentModule,
    coursesRegistered: Array<RecentModule>,
    lang: any,
    myRank: number,
    myStreak: number,
    lastLesson: number,
    userActivity: Array<any>,
}

type S = {
    module: ModuleWithLesson,
    unlockedLesson: number,
    activeLesson: number,
}

export const HOME_ROUTE = '/';

const main = new MainService();

class HomePageComponent extends React.Component<P, S> {

    componentDidMount() {
        // get module, unlockedLesson, activeLesson from cache and update, it gets triggered when coming from different page
        let module = localStorage.getItem('taplingua.module') as any;
        let unlockedLesson = localStorage.getItem('taplingua.unlockedLesson') as any;
        try {
            if (module) {
                module = JSON.parse(module);
            }
        } catch (error) { }
        try {
            if (unlockedLesson) {
                unlockedLesson = JSON.parse(unlockedLesson);
            }
        } catch (error) { }

        this.setState({
            module,
            unlockedLesson: unlockedLesson,
            activeLesson: unlockedLesson
        });

    }

    componentDidUpdate(prevProps: P) {
        // get triggered when props are changed

        // check if props has module and module has changed from last update
        if (this.props.mostRecent && this.props.mostRecent.moduleNumber && prevProps.mostRecent?.moduleNumber !== this.props.mostRecent.moduleNumber) {
            main.moduleLesson(this.props.user, parseInt(this.props.mostRecent?.moduleNumber ? this.props.mostRecent.moduleNumber : '0'))
                .then(result => {

                    let unlockedLesson = this.props.lastLesson + 1;
                    // check if unlocked lesson is practice
                    // get all the lessons
                    const module = result.data[0] as ModuleWithLesson;

                    // const lessons = [];

                    module.routes.forEach(route => {
                        route.levels.forEach(level => {
                            level.lessons.forEach((lesson, index) => {
                                // check if lessonNo and unlockedLesson are same and if lesson is practice
                                if (lesson.lessonno === unlockedLesson && (index === 2 && !lesson.isChallenge)) {
                                    // this means we need to make the next lessonNo as unlocked lesson
                                    unlockedLesson = lesson.lessonno + 1;
                                }
                                // lessons.push(lesson);
                            })
                        })
                    })

                    this.setState({
                        module: result.data[0],
                        unlockedLesson: unlockedLesson,
                        activeLesson: unlockedLesson
                    });
                    // save module to localstorage
                    localStorage.setItem('taplingua.module', JSON.stringify(result.data[0]));
                    // save unlockedLesson to localstorage,
                    localStorage.setItem('taplingua.unlockedLesson', JSON.stringify(unlockedLesson));
                })
                .catch(err => {
                    console.log({ err });
                });
        }
    }

    render() {
        const { lang } = this.props;
        return (
            <div className="HomePage">
                <TopNavigationBar
                    myRank={this.props.myRank}
                    myStreak={this.props.myStreak}
                    recentModule={this.props.mostRecent} />
                {/* <div className="parallax-bg" style={{ backgroundImage: 'url("/_assets/homepage-decoration.png")' }}></div> */}
                <div className="container-holder">
                    <div className="container" style={{ padding: "5rem 0" }}>
                        {/* <div className="message fade-in">{lang.handle('Welcome back')}</div>
                    <h2 className="user-email fade-in-slower">{this.props.user.email}</h2> */}
                        {this.buildTimeline()}
                    </div>
                    <div className="profile-placeholder">&nbsp;</div>
                    <div className="profile">
                        <div className="user-details">
                            <div className="user-icon">
                                <img src={userIcon} alt="User Icon" />
                            </div>
                            <h2>{this.props.user.firstName}</h2>
                            <h5>{this.props.user.email}</h5>
                        </div>
                        <div className="body">
                            <ProfileButton label="Points" extraInfo={
                                <div className="points">185 <span>points</span></div>
                            } />
                            <ProfileButton label="My Rank" extraInfo={
                                <div className="points">{this.props.myRank}</div>
                            } />
                            <br />
                            <ProfileButton label="About taplingua" onClick={() => {
                                history.push(ABOUT_ROUTE);
                            }} />
                            <ProfileButton label="Logout" onClick={() => {
                                localStorage.removeItem('cohortId');
                                localStorage.removeItem('user');
                                history.replace('/');
                                window.location.reload();
                            }} />
                        </div>
                    </div>
                </div>
                {/* <BottomNavigationBar /> */}
            </div>
        )
    }

    buildTimeline() {

        if (!this.state || !this.state.module) {
            return (
                <div className="loader" style={{
                    display: "flex",
                    padding: "5rem 0",
                    justifyContent: "center"
                }}>
                    <Spinner larger />
                </div>
            );
        }

        const { module } = this.state;

        return (
            <div>{
                module.routes.map(route => {
                    return (
                        <div key={route.routeno} className="TimelineRoute">
                            {route.levels.map(level => {
                                return (
                                    <div key={level.levelno} className="TimelineLevel">
                                        {
                                            level.lessons.map((lesson, index) => {
                                                // only show third lesson if its a challenge
                                                if ((index === 2 && lesson.isChallenge) || index !== 2) {
                                                    return this.buildTimelineLesson(
                                                        module.moduleno,
                                                        route.routeno,
                                                        level.levelno,
                                                        lesson.lessonno,
                                                        lesson.long_description,
                                                        lesson
                                                    );
                                                } else {
                                                    // check if lessonno is unlockedLesson, increase if so
                                                    if (this.state.unlockedLesson === lesson.lessonno) {

                                                        // this.setState({
                                                        //     unlockedLesson: this.state.unlockedLesson + 1,
                                                        // });
                                                    }
                                                    return <></>;
                                                }
                                            })
                                        }
                                    </div>
                                )
                            })}
                        </div>
                    )
                })
            }</div>
        )
    }

    buildTimelineLesson(moduleno: number, routeno: number, levelno: number, lessonno: number, long_description: string, lesson: any) {

        let className = "";

        if (lesson.isChallenge) {
            if (lesson.challengeType === "milestone") {
                // give milestone icon
                className = "milestone";
            } else {
                // give simple challenge icon
                className = "challenge";
            }
        }

        return (
            <div
                key={lessonno}
                className={"TimelineLesson " + className + " " + (this.state.activeLesson === lessonno ? "active " : "") + (lessonno <= this.state.unlockedLesson ? " completed " : "")} onClick={() => {
                    // if clicking a unlocked lesson
                    if (lessonno <= this.state.unlockedLesson) {
                        // make it active
                        this.setState({
                            activeLesson: lessonno
                        });
                    }
                }}>
                {/* non active state */}
                <div className={
                    "lesson-icon " + (this.props.lastLesson + 1 >= lessonno || (lesson.isChallenge && lesson.challengeType === "milestone") ? "normal" : "gray")
                }>
                    {
                        this.getIconImage(moduleno, lessonno, lesson)
                    }
                </div>
                <div className="long_description">{long_description}</div>
                {/* active state */}
                <div className="long_description_active">{long_description}</div>
                <div className="lesson_body_active">
                    <div
                        onClick={() => {
                            history.push(makeLearnRoute(
                                moduleno.toString(),
                                routeno.toString(),
                                levelno.toString(),
                                lessonno.toString(),
                            ));
                        }}
                        className={"LessonButtonIcon " + (this.isActivityDone(moduleno, routeno, lessonno, 2) ? "active" : "")} >
                        <LearnIcon />
                        <span>
                            Learn
                        </span>
                    </div>
                    <div
                        onClick={() => {
                            history.push(makeListenRoute(
                                moduleno.toString(),
                                routeno.toString(),
                                levelno.toString(),
                                lessonno.toString(),
                                "exercise"
                            ));
                        }}
                        className={"LessonButtonIcon " + (this.isActivityDone(moduleno, routeno, lessonno, 3) ? "active" : "")}>
                        <PlayIcon />
                        <span>Play</span>
                    </div>
                </div>

            </div>
        )
    }

    isActivityDone(moduleno: any, routeno: any, lessonno: any, activityType = 1) {
        const activity = this.props.userActivity.find(act => {
            return (
                act.activityType === activityType.toString() &&
                act.moduleNo === moduleno &&
                act.routeNo === routeno &&
                act.lessonNo === lessonno
            )
        })

        return activity ? true : false;
    }

    getIconImage(moduleno: any, lessonno: any, lesson: any): any {
        return (
            <img src={
                this.getIconLink(moduleno, lessonno, lesson)
            } alt="" />
        )
    }

    getIconLink(moduleno: any, lessonno: any, lesson: any): string {
        const type = this.props.lastLesson + 1 >= lessonno ? "normal" : "gray";

        if (lesson.isChallenge) {
            if (lesson.challengeType === "milestone") {
                // give milestone icon
                return "/_assets/milestone-icon.svg";
            } else {
                // give simple challenge icon
                return "/_assets/challenge-icon.svg";
            }
        }

        return "/_assets/lesson_icons/module_"
            + moduleno
            + "/" + type + "/"
            + moduleno
            + "_"
            + lessonno
            + "@3x.png"
    }
}

function ProfileButton(props: { label: string, onClick?: Function, extraInfo?: ReactNode }) {
    return (
        <button
            className={"profile-button " + (props.onClick ? "has-onclick" : "")} onClick={() => {
                if (props.onClick) {
                    props.onClick();
                }
            }} >
            <span>{props.label}</span>
            {props.extraInfo ? props.extraInfo : <></>}
        </button>
    )
}

const HomePage = withI18(HomePageComponent);

export { HomePage }