import React, { ReactNode } from 'react';
import { Lesson, RecentModule } from '../_types';

import 'react-circular-progressbar/dist/styles.css';
import { BottomNavigationBar, Spinner, TopNavigationBar } from '../_components';
import { Link } from 'react-router-dom';
import { withI18 } from '../_context';
import { lang } from 'moment';
import { MainService } from '../_services/main.service';
import { ModuleWithLesson } from '../_types/module-with-lesson.type';
import { makeListenRoute } from './listen.page';
import { makeLearnRoute } from './learn.page';
import { LearnIcon } from '../_icons/learn-icon.icon';
import { PlayIcon } from '../_icons';
import { history } from '../_config';
import { makePlayRoute } from './play.page';
import { ABOUT_ROUTE } from './about.page';
import userIcon from '../_assets/user-icon-96.png';
import { getVideoTLDRFromJson, VideoTLDR } from '../_types/video-tldr.type';
import { LottieLoader } from '../_components/lottie-loader.component';
import { mixPanel } from '../_config/mixpanel.config';

type P = {
    user: any,
    mostRecent?: RecentModule,
    coursesRegistered: Array<RecentModule>,
    lang: any,
    myRank: number,
    myStreak: number,
    lastLesson: number,
    userActivity: Array<any>,
}

type S = {
    module: ModuleWithLesson | null,
    unlockedLesson: number,
    activeLessonName: String,
    activeSectionName: String,
    tldrs: VideoTLDR[],
    loadingTldr: boolean
}

export const HOME_ROUTE = '/learn';

const main = new MainService();

class HomePageComponent extends React.Component<P, S> {

    private main = new MainService();

    constructor(props: P) {
        super(props);

        this.state = {
            module: null,
            unlockedLesson: 0,
            activeLessonName: "",
            activeSectionName: "",
            tldrs: [],
            loadingTldr: false,
        };
    }

    componentDidMount() {
        main.moduleLesson(this.props.user, 150)
            // main.moduleLesson(this.props.user, parseInt(this.props.mostRecent?.moduleNumber ? this.props.mostRecent.moduleNumber : '0'))
            .then(result => {

                let unlockedLesson = this.props.lastLesson + 1;
                // check if unlocked lesson is practice
                // get all the lessons
                const module = result.data[0] as ModuleWithLesson;

                // const lessons = [];
                let firstLessonData: any = undefined; // used to get mrl of first lesson

                module.routes.forEach(route => {
                    route.levels.forEach(level => {
                        level.lessons.forEach((lesson, index) => {
                            if (!firstLessonData) {
                                firstLessonData = [module.moduleno, route.routeno, lesson.lessonno, lesson.description, route.description];
                                this.getTLDR(module.moduleno, route.routeno, lesson.lessonno, lesson.description, route.description);
                            }
                            // check if lessonNo and unlockedLesson are same and if lesson is practice
                            if (lesson.lessonno === unlockedLesson && (index === 2 && !lesson.isChallenge)) {
                                // this means we need to make the next lessonNo as unlocked lesson
                                unlockedLesson = lesson.lessonno + 1;
                            }
                            // lessons.push(lesson);
                        })
                    })
                })

                this.setState({
                    module: result.data[0],
                    unlockedLesson: unlockedLesson,
                });
                // save module to localstorage
                localStorage.setItem('taplingua.module', JSON.stringify(result.data[0]));
                // save unlockedLesson to localstorage,
                localStorage.setItem('taplingua.unlockedLesson', JSON.stringify(unlockedLesson));
            })
            .catch(err => {
                console.log({ err });
            });

    }

    render() {
        const { lang } = this.props;
        return (
            <div className="HomePage">
                <TopNavigationBar
                    myRank={this.props.myRank}
                    myStreak={this.props.myStreak}
                    recentModule={this.props.mostRecent} />
                {/* <div className="parallax-bg" style={{ backgroundImage: 'url("/_assets/homepage-decoration.png")' }}></div> */}
                <div className="container-holder">
                    <div className="container">
                        <div className="sidebar-holder">
                            <div className="sidebar">
                                {this.buildTimeline()}
                            </div>
                        </div>
                        <div className="content-holder">
                            {
                                this.state.loadingTldr || !this.state.module ? (
                                    <div style={{ paddingLeft: "20px", display: "flex", justifyContent: "center" }}>
                                        <LottieLoader />
                                    </div>
                                ) : (
                                    this.state.tldrs.length === 0 ? (
                                        <div style={{ padding: "20px", textAlign: "center" }}>No TLDR to display</div>
                                    ) :
                                        this.state.tldrs.map((tldr: VideoTLDR, index: number) => {
                                            return (
                                                <div key={index}>
                                                    <div className="active-section-name">{this.state.activeSectionName}</div>
                                                    <div className="active-lesson-name">{this.state.activeLessonName}</div>
                                                    <div className="divider"></div>
                                                    {/* <div className="tldr-title">{tldr.title}</div> */}
                                                    {
                                                        tldr.image ? (
                                                            <img src={tldr.image} />
                                                        ) : <></>
                                                    }
                                                    <div className="tldr-description" dangerouslySetInnerHTML={{ __html: tldr.description ? tldr.description : "" }}></div>
                                                </div>
                                            )
                                        })
                                )
                            }
                        </div>
                    </div>
                </div>
                {/* <BottomNavigationBar /> */}
            </div>
        )
    }

    buildTimeline() {

        if (!this.state || !this.state.module) {
            return (
                <div className="loader" style={{
                    display: "flex",
                    padding: "5rem 0",
                    justifyContent: "center"
                }}>
                    <LottieLoader />
                </div>
            );
        }

        const { module } = this.state;

        return (
            <div className="Timeline">{
                module.routes.map(route => {
                    return (
                        <div key={route.routeno} className="TimelineRoute">
                            <div className="section-header">
                                Section {route.routeno} <br />
                                <span>{route.description}</span>
                            </div>
                            <div className="TimelineLevel">
                                {route.levels.map(level => {
                                    return (
                                        <div key={level.levelno}>
                                            {
                                                level.lessons.map((lesson, index) => {
                                                    // only show third lesson if its a challenge
                                                    return this.buildTimelineLesson(
                                                        module.moduleno,
                                                        route.routeno,
                                                        level.levelno,
                                                        lesson.lessonno,
                                                        lesson.long_description,
                                                        lesson,
                                                        `Section ${route.routeno}. ${route.description}`
                                                    );
                                                })
                                            }
                                        </div>
                                    )
                                })}
                            </div>
                        </div>
                    )
                })
            }</div>
        )
    }

    buildTimelineLesson(moduleno: number, routeno: number, levelno: number, lessonno: number, long_description: string, lesson: any, sectionName: string) {

        let className = "";

        if (lesson.isChallenge) {
            if (lesson.challengeType === "milestone") {
                // give milestone icon
                className = "milestone";
            } else {
                // give simple challenge icon
                className = "challenge";
            }
        }

        if (!lesson.description) {
            return <></>;
        }

        return (
            <div
                key={lessonno}
                className={"topic " + (lesson.description === this.state.activeLessonName && sectionName === this.state.activeSectionName ? "active" : "")} onClick={() => {
                    this.getTLDR(moduleno, routeno, lessonno, lesson.description, sectionName);
                }}>
                <img src={`https://langappnew.s3.amazonaws.com/icons_v2/${moduleno}/${moduleno}_${routeno}_${lessonno}.png`} onError={e => {
                    e.currentTarget.src = "https://langappnew.s3.amazonaws.com/icons_v2/150/icon_default.png";
                }} />
                {/* <div className="long_description">{long_description}</div> */}
                {/* active state */}
                <div>
                    {lesson.description}
                </div>
            </div>
        )
    }

    getTLDR(moduleNo: number, routeNo: number, lessonNo: number, lessonName: string, sectionName: string) {

        this.setState({
            loadingTldr: true
        });
        const user = this.props.user;
        // get tldrs
        this.main.getVideoTLDR(this.props.user, moduleNo, routeNo, lessonNo)
            .then((response) => {
                const tldrs = response;
                this.setState({
                    tldrs: tldrs.map(getVideoTLDRFromJson),
                    activeLessonName: lessonName,
                    activeSectionName: sectionName,
                    loadingTldr: false
                })
                // fire event 
                mixPanel.track('InterviewSimulatorLearn', {
                    userId: user.email ? user.email : user.userId,
                    moduleNo,
                    routeNo,
                    lessonNo
                });
            })
            .catch(error => {
                console.log(error);
                this.setState({
                    loadingTldr: false
                });
            });
    }

    isActivityDone(moduleno: any, routeno: any, lessonno: any, activityType = 1) {
        const activity = this.props.userActivity.find(act => {
            return (
                act.activityType === activityType.toString() &&
                act.moduleNo === moduleno &&
                act.routeNo === routeno &&
                act.lessonNo === lessonno
            )
        })

        return activity ? true : false;
    }

    getIconImage(moduleno: any, lessonno: any, lesson: any): any {
        return (
            <img src={
                this.getIconLink(moduleno, lessonno, lesson)
            } alt="" />
        )
    }

    getIconLink(moduleno: any, lessonno: any, lesson: any): string {
        const type = this.props.lastLesson + 1 >= lessonno ? "normal" : "gray";

        if (lesson.isChallenge) {
            if (lesson.challengeType === "milestone") {
                // give milestone icon
                return "/_assets/milestone-icon.svg";
            } else {
                // give simple challenge icon
                return "/_assets/challenge-icon.svg";
            }
        }

        return "/_assets/lesson_icons/module_"
            + moduleno
            + "/" + type + "/"
            + moduleno
            + "_"
            + lessonno
            + "@3x.png"
    }
}

function ProfileButton(props: { label: string, onClick?: Function, extraInfo?: ReactNode }) {
    return (
        <button
            className={"profile-button " + (props.onClick ? "has-onclick" : "")} onClick={() => {
                if (props.onClick) {
                    props.onClick();
                }
            }} >
            <span>{props.label}</span>
            {props.extraInfo ? props.extraInfo : <></>}
        </button>
    )
}

const HomePage = withI18(HomePageComponent);

export { HomePage }