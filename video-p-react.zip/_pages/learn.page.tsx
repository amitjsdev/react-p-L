
import React, { useEffect } from 'react';
import { BackArrow, Nl2br, Spinner, TopNavigationBarWithBack } from '../_components';
import { MainService } from '../_services/main.service';
import { Lesson, Module, ModuleRoute, RecentModule } from '../_types';
import { Link } from 'react-router-dom';

import play_button from '../_assets/_learn/play-2x.png';
import pause_button from '../_assets/_learn/pause-2x.png';
import { history } from '../_config';
import moment from 'moment';
import { AuthService } from '../_services';
import { makePlayRoute } from './play.page';
import { makeListenRoute } from './listen.page';
import { getVideoTLDRFromJson, VideoTLDR } from '../_types/video-tldr.type';
import { HOME_ROUTE } from './home_learn.page';


type P = {
    user: any,
    match: any,
    coursesRegistered: Array<RecentModule>
}

type S = {
    module: Module | null,
    lesson: Lesson | null,
    route: ModuleRoute | null,
    paused: boolean,
    subtitle: Subtitle,
    isVideoStreamable: boolean,
    tldrs: VideoTLDR[] | null,
    startTime: Date
}

enum Subtitle {
    EN,
    ES,
    NONE
}

export const LEARN_ROUTE = '/module/:moduleNo/route/:routeNo/level/:levelNo/learn/:learnNo';

export const makeLearnRoute = (
    moduleNo: string,
    routeNo: string,
    levelNo: string,
    learnNo: string
) => `/module/${moduleNo}/route/${routeNo}/level/${levelNo}/learn/${learnNo}`;

export class LearnPage extends React.Component<P, S> {

    private main = new MainService();

    private auth = new AuthService();

    private moduleNo: number;
    private routeNo: number;
    private levelNo: number;
    private lessonNo: number;
    private player: React.RefObject<HTMLVideoElement>;

    constructor(props: P) {
        super(props);



        this.moduleNo = props.match.params.moduleNo;
        this.routeNo = props.match.params.routeNo;
        this.levelNo = props.match.params.levelNo;
        this.lessonNo = props.match.params.learnNo;

        this.state = {
            module: null,
            lesson: null,
            route: null,
            paused: false,
            subtitle: Subtitle.EN,
            isVideoStreamable: false,
            tldrs: null,
            startTime: new Date()
        }

        this.player = React.createRef<HTMLVideoElement>();

    }


    get course() {
        return this.props.coursesRegistered.find(c => (c.moduleNumber ?? null) == this.moduleNo.toString());
    }

    get route() {
        return this.state.module ?
            this.state.module.routes.find(r => r.routeno == this.routeNo) :
            null
    }

    get video() {
        return this.main.getResource(this.moduleNo, this.routeNo, this.lessonNo, 'videos/Lesson_' + this.lessonNo + '_Tutorial.mp4');
    }

    componentDidMount() {
        // get modules
        this.main.getModules(this.props.user, this.moduleNo, 1)
            .then(response => {
                if (response.data.length < 1) {
                    throw new Error('Module not found!');
                }
                const module = response.data[0] as Module;
                // get module route
                this.setState({
                    module,
                    route: module.routes.find(r => r.routeno == this.routeNo) || null
                });
            })
            .catch(error => {
                console.log(error);
            });
        //  get the lesson
        this.main.getLesson(this.props.user, this.moduleNo, this.routeNo, this.lessonNo).then(response => {
            this.setState({
                lesson: response.data as Lesson
            });
        })
            .catch(error => {
                console.log(error);
            });

        // get tldrs
        this.main.getVideoTLDR(this.props.user, this.moduleNo, this.routeNo, this.lessonNo)
            .then((response) => {
                const tldrs = response;
                this.setState({
                    tldrs: tldrs.map(getVideoTLDRFromJson)
                })
            })
            .catch(error => {
                console.log(error);
            });
    }

    render() {

        return (
            <div className="LearnPage">
                {
                    !this.state.isVideoStreamable &&
                    <div className="loader">
                        <Spinner larger />
                    </div>
                }
                <TopNavigationBarWithBack title={this.state.lesson?.long_description} onClick={() => {
                    history.push(HOME_ROUTE);
                }} />
                <div className="container mt-5 pt-1 text-center">
                    {/* <div className="exercise-meta"> */}
                    {/* <div className="exercise-header">Listen</div> */}
                    {/* <span>Level {this.state.lesson?.long_description}</span> */}
                    {/* </div> */}
                    {/*                    <div className="subtitle-options">
                        <span className={"sub-option" + (this.state.subtitle === Subtitle.ES ? " selected" : "")} onClick={() => { this.setState({ subtitle: Subtitle.ES }) }}>
                            <span>ES</span>
                        </span>
                        <span className={"sub-option" + (this.state.subtitle === Subtitle.EN ? " selected" : "")} onClick={() => { this.setState({ subtitle: Subtitle.EN }) }}>
                            <span>EN</span>
                        </span>
                        <span className={"sub-option" + (this.state.subtitle === Subtitle.NONE ? " selected" : "")} onClick={() => { this.setState({ subtitle: Subtitle.NONE }) }}>
                            <span>&#8230;</span>
                        </span>
                    </div> */}
                    <div className="VideoPlayer">
                        <video
                            src={this.video}
                            autoPlay
                            ref={this.player}
                            onCanPlay={
                                () => {
                                    this.setState({ isVideoStreamable: true })
                                }
                            }
                            controls
                            onEnded={() => {
                                if (this.player.current) {
                                    this.player.current.currentTime = 0;
                                    this.setState({ paused: true });
                                }
                            }} />
                        {/* <div className="controls">
                            {
                                !this.state.paused ?
                                    <div className="pause">
                                        <img src={pause_button} alt='' className="center" onClick={() => {
                                            this.player.current?.pause();
                                            this.setState({ paused: true });
                                        }} />
                                    </div> :
                                    <div className="play">
                                        <img src={play_button} alt='' className="center" onClick={() => {
                                            this.player.current?.play();
                                            this.setState({ paused: false });
                                        }} />
                                    </div>
                            }
                        </div> */}
                    </div>
                    <div>
                        {/* <span
                            className="continue-button"
                            onClick={() => {

                                // save the user activity log
                                const payload = {
                                    userId: this.props.user.email,
                                    activityDateFrom: moment(this.state.startTime).format('YYYY-MM-DD hh:mm:ss'),
                                    activityDateTo: moment(new Date()).format('YYYY-MM-DD hh:mm:ss'),
                                    activityType: 1, // 1= Listen, 2 = Learn, 3 = Play
                                    moduleNo: this.moduleNo,
                                    routeNo: this.routeNo,
                                    levelNo: this.levelNo,
                                    totalQuestions: 1,
                                    lessonNo: this.lessonNo,
                                    courseNumber: this.course?.courseNumber
                                };

                                this.auth.saveActivityLog(this.props.user, payload)
                                    .then(response => {
                                        //
                                    })
                                    .catch(error => {
                                        // TODO: Error handled
                                    })
                                    .finally(() => {
                                        history.push(makePlayRoute(this.moduleNo.toString(), this.routeNo.toString(), this.levelNo.toString(), this.lessonNo.toString()));
                                    });
                            }}>
                            Experience this situation in action
                                        </span> */}
                        <Link className="continue-button" to={makeListenRoute(
                            this.moduleNo.toString(),
                            this.routeNo.toString(),
                            this.levelNo.toString(),
                            this.lessonNo.toString()
                        )}>
                            Experience this situation in action</Link>
                        {/* <div
                            onClick={() => {
                                window.location.reload();
                            }}
                            className="do-not-continue">
                            Wait, I want to do this again.
                                        </div> */}
                        {/* TLDR section */}
                        {
                            this.state.tldrs ?
                                (
                                    this.state.tldrs.map(tldr => {
                                        return (
                                            <div key={tldr.id} className="VideoTLDR">
                                                <div className="bold tldr-title">{tldr.title}</div>
                                                <div className="tldr-description">{tldr.description}</div>
                                                {/* table */}
                                                <table className="TLDRTable">
                                                    <tbody>
                                                        {
                                                            tldr.miniLesson.map((miniLesson, index) => {
                                                                return (
                                                                    <tr key={index}>
                                                                        <td>{miniLesson.sentence}</td>
                                                                        <td>{miniLesson.translation}</td>
                                                                    </tr>
                                                                )
                                                            })
                                                        }
                                                    </tbody>
                                                </table>
                                                {/* example */}
                                                {
                                                    tldr.voice.length > 0 ? (
                                                        <div className="tldr-voice">
                                                            {
                                                                tldr.voice.map((voice, index) => {
                                                                    return (
                                                                        <div key={index}>{voice}</div>
                                                                    )
                                                                })
                                                            }
                                                        </div>
                                                    ) : ''
                                                }
                                                {/* extra info */}
                                                <Nl2br text={typeof tldr.extra_info === "string" ? tldr.extra_info : ""} />
                                            </div>
                                        );
                                    })
                                ) :
                                <div className="loader2">
                                    <Spinner alt />
                                </div>
                        }
                    </div>
                </div>
            </div>
        );

    }
}
