
import React, { useEffect } from 'react';
import { BackArrow, PreExercise, TopNavigationBarWithBack, UncontrolledLottie } from '../_components';
import { MainService } from '../_services/main.service';
import { Lesson, Module, ModuleRoute, RecentModule } from '../_types';
import { Nl2br, SwitchButton } from '../_components';
import { Link } from 'react-router-dom';
import { makeLearnRoute } from './learn.page';
import moment from 'moment';
import { history } from '../_config';
import { AuthService } from '../_services';
import { makeExerciseRoute } from './exercise.page';
import { HOME_ROUTE } from './home_learn.page';
import animationData from '../_assets/_animations/pre-listen.json';


type P = {
    user: any,
    match: any,
    coursesRegistered: Array<RecentModule>
}

type S = {
    module: Module | null,
    lesson: Lesson | null,
    route: ModuleRoute | null,
    preExerciseDone: boolean, // is pre exercise done? show main exercise
    areTranslationsVisible: boolean, // to show translations conditionally
    dialogProgress: number, // tells which dialog are we currently on
    startTime: Date
}

export const LISTEN_ROUTE = '/module/:moduleNo/route/:routeNo/level/:levelNo/listen/:listenNo';

export const makeListenRoute = (
    moduleNo: string,
    routeNo: string,
    levelNo: string,
    listenNo: string,
    redir?: string,
) => `/module/${moduleNo}/route/${routeNo}/level/${levelNo}/listen/${listenNo}?redir=${redir}`;

export class ListenPage extends React.Component<P, S> {

    private main = new MainService();

    private auth = new AuthService();

    private moduleNo: number;
    private routeNo: number;
    private levelNo: number;
    private lessonNo: number;

    constructor(props: P) {
        super(props);



        this.moduleNo = props.match.params.moduleNo;
        this.routeNo = props.match.params.routeNo;
        this.levelNo = props.match.params.levelNo;
        this.lessonNo = props.match.params.listenNo;

        this.state = {
            module: null,
            lesson: null,
            route: null,
            preExerciseDone: false,
            areTranslationsVisible: true,
            dialogProgress: 0,
            startTime: new Date()
        }
    }


    get course() {
        return this.props.coursesRegistered.find(c => (c.moduleNumber ?? null) == this.moduleNo.toString());
    }

    get route() {
        return this.state.module ?
            this.state.module.routes.find(r => r.routeno == this.routeNo) :
            null
    }

    getAudio(resource: string) {
        return this.main.getResource(this.moduleNo, this.routeNo, this.lessonNo, resource);
    }

    componentWillUnmount() {
        // will mount, pause all the unwanted audio as well
        for (const audio of Array.from(window.document.getElementsByTagName('audio'))) { audio.pause(); }
    }

    componentDidMount() {
        // get modules
        this.main.getModules(this.props.user, this.moduleNo, 1)
            .then(response => {
                if (response.data.length < 1) {
                    throw new Error('Module not found!');
                }
                const module = response.data[0] as Module;
                // get module route
                this.setState({
                    module,
                    route: module.routes.find(r => r.routeno == this.routeNo) || null
                });
            })
            .catch(error => {
                console.log(error);
            });
        //  get the lesson
        this.main.getLesson(this.props.user, this.moduleNo, this.routeNo, this.lessonNo).then(response => {
            this.setState({
                lesson: response.data as Lesson
            });
        })
            .catch(error => {
                console.log(error);
            });
    }

    render() {

        // show pre exercise
        if (!this.state.preExerciseDone) {
            return (
                <div className="ExercisePage">
                    <TopNavigationBarWithBack onClick={() => {
                        history.push(HOME_ROUTE);
                    }} />
                    <div className="pre_exercise_heading">Let's hear a short dialog</div>
                    <UncontrolledLottie animationData={animationData} width={275} />
                    <div className="pre_exercise_content">
                        {this.state.lesson?.pre_dialog_msg}
                </div>
                    <div className="pre_exercise_continue" onClick={() => {
                        // mark pre-exercise as done
                        this.setState({
                            preExerciseDone: true
                        });
                    }}>Continue</div>
                </div>
            );
        }

        return (
            <div className="ListenPage">
                <TopNavigationBarWithBack buttonTwoLabel="Skip" buttonTwoOnClick={() => {
                    this.saveProgressAndMoveForward();
                }} />
                <div className="container mt-5 pt-5 text-center">
                    {
                        <div className="listen-exercise">
                            {/* <div className="exercise-meta">
                                <div className="side-1">
                                    <div className="exercise-header">Listen</div>
                                    <span>Level {this.state.lesson?.title}</span>
                                </div>
                                <div className="side-2">
                                    <SwitchButton on={this.state.areTranslationsVisible} onClick={() => {
                                        this.setState({ areTranslationsVisible: !this.state.areTranslationsVisible })
                                    }} />
                                    <div className="translation-label">Translation</div>
                                </div>
                            </div> */}
                            <div className="pre-dialog-message">
                                {this.state.lesson?.pre_dialog_msg}
                            </div>
                            <div className="exercise-content">
                                {
                                    this.state.lesson?.dialog.map((dialog, index) => {
                                        if (index > this.state.dialogProgress) {
                                            return '';
                                        }
                                        const i = index % 2;
                                        const audioRef = React.createRef<HTMLAudioElement>();
                                        return (
                                            <div className="dialog-holder fade-in" key={index}>
                                                <div className={"dialogue" + (i === 0 ? " first" : " second")}>
                                                    <div className="speaker">{this.state.lesson?.speakers[i]}</div>
                                                    <div className="dialog-body">
                                                        <div className="dialog-itself">
                                                            {this.state.lesson?.dialog_translation[index].replace(/\*/g, ',')}
                                                        </div>
                                                        {
                                                            this.state.areTranslationsVisible &&
                                                            <div className="dialog-translation">
                                                                {dialog.replace(/\*/g, ',')}
                                                            </div>
                                                        }
                                                    </div>
                                                    <label
                                                        onClick={() => {
                                                            if (audioRef.current) {
                                                                audioRef.current.currentTime = 0;
                                                                audioRef.current.play();
                                                            }
                                                        }}
                                                        className="dialogue-audio">
                                                        <img src={i === 0 ? "/_assets/audio-listen-first.png" : "/_assets/audio-listen-second.png"} alt="" />
                                                        <audio
                                                            autoPlay
                                                            ref={audioRef}
                                                            onEnded={() => {
                                                                /*                                                                if (index === this.state.dialogProgress) {
                                                                                                                                   // check if we are at last question
                                                                                                                                   this.setState({ // increases the progress and shows nextt dialog
                                                                                                                                       dialogProgress: this.state.dialogProgress + 1
                                                                                                                                   }, () => {
                                                                                                                                       window.scrollTo(0, window.document.body.scrollHeight || 0);
                                                                                                                                   })
                                                                                                                               } */
                                                            }}
                                                            src={this.getAudio(this.state.lesson?.audio[index] ?? '')}
                                                        />
                                                    </label>
                                                </div>
                                            </div>
                                        )
                                    })
                                }
                                <div className="listen-next-button-holder" >
                                    {
                                        this.state.lesson?.dialog.length !== this.state.dialogProgress ? (
                                            <div className="listen-next-button" onClick={() => {
                                                for (const audio of Array.from(window.document.getElementsByTagName('audio'))) { audio.pause(); }
                                                // check if we are at last question
                                                this.setState({ // increases the progress and shows nextt dialog
                                                    dialogProgress: this.state.dialogProgress + 1
                                                }, () => {
                                                    window.scrollTo(0, window.document.body.scrollHeight || 0);
                                                })
                                            }}>Next &gt;</div>
                                        ) : ''
                                    }
                                </div>
                            </div>
                            {
                                this.state.lesson?.dialog.length === this.state.dialogProgress &&
                                <div>
                                    <span
                                        className="continue-button"
                                        onClick={() => {
                                            this.saveProgressAndMoveForward();
                                        }}>
                                        Continue
                                        </span>
                                    <div
                                        onClick={() => {
                                            window.location.reload();
                                        }}
                                        className="do-not-continue">
                                        Wait, I want to do this again.
                                        </div>
                                </div>
                            }
                        </div>
                    }
                </div>
            </div>
        );

    }

    saveProgressAndMoveForward() {


        // save the user activity log
        const payload = {
            userId: this.props.user.email,
            activityDateFrom: moment(this.state.startTime).format('YYYY-MM-DD hh:mm:ss'),
            activityDateTo: moment(new Date()).format('YYYY-MM-DD hh:mm:ss'),
            activityType: 1, // 1= Listen, 2 = Learn, 3 = Play
            moduleNo: this.moduleNo,
            routeNo: this.routeNo,
            levelNo: this.levelNo,
            totalQuestions: this.state.lesson?.dialog.length,
            lessonNo: this.lessonNo,
            courseNumber: this.course?.courseNumber
        };

        this.auth.saveActivityLog(this.props.user, payload)
            .then(response => {
                //
            })
            .catch(error => {
                // TODO: Error handled
            })
            .finally(() => {
                const redir = (new URLSearchParams(window.location.search)).get('redir');
                if (redir === "exercise") {
                    history.push(makeExerciseRoute(this.moduleNo.toString(), this.routeNo.toString(), this.levelNo.toString(), this.lessonNo.toString()));
                } else {
                    history.push(makeLearnRoute(this.moduleNo.toString(), this.routeNo.toString(), this.levelNo.toString(), this.lessonNo.toString()));
                }
            });
    }
}