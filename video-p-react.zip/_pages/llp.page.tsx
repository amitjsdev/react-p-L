
import React, { useEffect } from 'react';
import { BackArrow } from '../_components';
import { MainService } from '../_services/main.service';
import { Module } from '../_types';
import { Nl2br } from '../_components/nl2br.component';

import listen from '../_assets/llp-listen-1x.png';
import learn from '../_assets/llp-learn-1x.png';
import play from '../_assets/llp-play-1x.png';
import { Link } from 'react-router-dom';
import { makeListenRoute } from './listen.page';
import { makeLearnRoute } from './learn.page';
import { makePlayRoute } from './play.page';
import { withI18 } from '../_context';


// lesson types for creating lesson card
enum LessonType {
    listen = 'listen',
    learn = 'learn',
    play = 'play'
}

// the props
type P = {
    user: any,
    match: any,
    userActivity: Array<any>,
}

// the state
type S = {
    module?: Module | null,
    moduleActivity?: any, // moduleActivity[levelNo][lessonNo]
    moduleActivityLoaded: boolean, // to check if module acitivity is loaded (prevemts rerender)
    lessons: any,
}

// route
export const LLP_ROUTE = '/module/:moduleNo/route/:routeNo/level/:levelNo';

// route generator
export const makeLLPRoute = (moduleNo: string, routeNo: string, levelNo: string) => `/module/${moduleNo}/route/${routeNo}/level/${levelNo}`;

export class LLPPage extends React.Component<P, S> {

    private main = new MainService();

    private moduleNo: number;
    private routeNo: number;
    private levelNo: number;
    private lessonNos: Array<number>;

    constructor(props: P) {
        super(props);



        this.moduleNo = props.match.params.moduleNo;
        this.routeNo = props.match.params.routeNo;
        this.levelNo = props.match.params.levelNo;

        // every level has 3 lesson so lesson no. is (this.levelNo - 1) * 3 + i
        this.lessonNos = [(this.levelNo - 1) * 3 + 1, (this.levelNo - 1) * 3 + 2, (this.levelNo - 1) * 3 + 3];

        this.state = {
            module: null,
            moduleActivityLoaded: false,
            lessons: {}
        }
    }

    get route() {
        return this.state.module ?
            this.state.module.routes.find(r => r.routeno == this.routeNo) :
            null
    }

    get level() {
        return this.route?.levels.find(l => l.levelno == this.levelNo);
    }

    componentDidMount() {
        // get modules
        this.main.getModules(this.props.user, this.moduleNo, 1)
            .then(response => {
                if (response.data.length < 1) {
                    throw new Error('Module not found!');
                }
                const module = response.data[0] as Module;
                this.setState({
                    module
                });
            })
            .catch(error => {
                console.log(error);
            });
        //  get the lessons
        this.lessonNos.forEach(lesson => {
            this.main.getLesson(this.props.user, this.moduleNo, this.routeNo, lesson).then(response => {
                const lessons = { ...this.state.lessons };
                this.setState({
                    lessons: { ...lessons, [lesson]: response.data[0] }
                });
            })
                .catch(error => {
                    console.log(error);
                });
        });
    }


    componentDidUpdate(prevProps: P) {
        // get module activity
        if (prevProps.userActivity.length > 0 && this.state.moduleActivityLoaded === false) {
            const moduleActivity = {} as Array<any>;
            this.props.userActivity.forEach(activity => {
                if (activity.moduleNo == this.moduleNo) {
                    if (moduleActivity[activity.routeNo] === undefined) {
                        moduleActivity[activity.routeNo] = {};
                    }
                    if (moduleActivity[activity.routeNo][activity.levelNo] === undefined) {
                        moduleActivity[activity.routeNo][activity.levelNo] = {};
                    }
                    if (moduleActivity[activity.routeNo][activity.levelNo][activity.lessonNo] === undefined) {
                        moduleActivity[activity.routeNo][activity.levelNo][activity.lessonNo] = [];
                    }
                    // if acitivity not there push activity
                    if (!moduleActivity[activity.routeNo][activity.levelNo][activity.lessonNo].includes(activity.activityType)) {
                        moduleActivity[activity.routeNo][activity.levelNo][activity.lessonNo].push(activity.activityType);
                    }
                }
                // debugger;
            });
            this.setState({
                moduleActivity,
                moduleActivityLoaded: true
            });
        }
    }

    // components

    LearnScreen = (p: {}) => {
        return (
            <div className="learn-screen">
                Learn Screen
            </div>
        );
    }


    render() {

        return (
            <div className="LLPPage">
                <div className="parallax-bg" style={{ backgroundImage: 'url("/_assets/llppage-decoration.png")' }}></div>
                <BackArrow alt />
                <div className="container mt-5 pt-5">
                    <div className="level-description">
                        <Nl2br text={this.level ? this.level.description : ''} />
                    </div>
                    <div className="level-number">
                        Level {this.levelNo}
                    </div>
                    <div className="tab">
                        <div className="tab-item active">Lessons</div>
                        <div className="tab-item">Review <span className="exclaim">!</span></div>
                    </div>
                    <div className="tab-content">
                        <LessonGroup index={0} locked={false} moduleNo={this.moduleNo} routeNo={this.routeNo} levelNo={this.levelNo} lessonNo={this.lessonNos[0]} />
                        <LessonGroup index={1} locked={true} moduleNo={this.moduleNo} routeNo={this.routeNo} levelNo={this.levelNo} lessonNo={this.lessonNos[1]} />
                        <LessonGroup index={2} locked={true} moduleNo={this.moduleNo} routeNo={this.routeNo} levelNo={this.levelNo} lessonNo={this.lessonNos[2]} />
                    </div>
                </div>
            </div>
        );

    }
}

function LessonGroupComponent(props: { index: number, locked: boolean, moduleNo: number, routeNo: number, levelNo: number, lessonNo: number, lang: any }) {
    let base = props.index * 3;
    return (
        <div className="lesson-group">
            {
                props.index !== 2 &&
                <LessonCard type={LessonType.listen} icon={++base}
                    moduleNo={props.moduleNo} routeNo={props.routeNo} levelNo={props.levelNo} lessonNo={props.lessonNo} />
            }
            {
                props.index !== 2 &&
                <LessonCard type={LessonType.learn} icon={++base}
                    moduleNo={props.moduleNo} routeNo={props.routeNo} levelNo={props.levelNo} lessonNo={props.lessonNo} />
            }
            <LessonCard type={LessonType.play} icon={++base} moduleNo={props.moduleNo} routeNo={props.routeNo} levelNo={props.levelNo} lessonNo={props.lessonNo} />
            <span className={"milestone-status " + (props.locked ? "locked" : "")}>
                <span>Milestone {props.lang.handle(props.locked ? "locked" : "unlocked")}</span>
            </span>
        </div>
    )
}

const LessonGroup = withI18(LessonGroupComponent);

function LessonCardComponent(props: { type: LessonType, icon: number, moduleNo: number, routeNo: number, levelNo: number, lessonNo: number, lang: any }) {
    const getSrc = () => {
        switch (props.type) {
            case LessonType.learn:
                return learn;
            case LessonType.play:
                return play;
            case LessonType.listen:
            default:
                return listen;
        }
    }
    const getURL = () => {
        switch (props.type) {
            case LessonType.learn:
                return makeLearnRoute(props.moduleNo.toString(), props.routeNo.toString(), props.levelNo.toString(), props.lessonNo.toString());
            case LessonType.play:
                return makePlayRoute(props.moduleNo.toString(), props.routeNo.toString(), props.levelNo.toString(), props.lessonNo.toString());
            case LessonType.listen:
                return makeListenRoute(props.moduleNo.toString(), props.routeNo.toString(), props.levelNo.toString(), props.lessonNo.toString());
            default:
                return '/';
        }
    }
    return (
        <Link to={getURL()} className={"lesson " + props.type}>
            <div className={"lesson-icon icon-" + props.icon.toString()}>
                <img src={getSrc()} alt={props.lang.handle(props.type)} />
            </div>
            <div className="lesson-description">
                <div className="lesson-instruction">{props.lang.handle(props.type)}</div>
                <div className="lesson-status">{props.lang.handle('completed')}</div>
            </div>
        </Link>
    )
}

const LessonCard = withI18(LessonCardComponent);