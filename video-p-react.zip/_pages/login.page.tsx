import React, { FormEvent, useState } from 'react';
import { Link } from 'react-router-dom';
import logo from '../_assets/main-logo-alt.png';
import { AuthService } from '../_services';
import { Spinner } from '../_components';
import { history } from '../_config';
import GoogleLogin from 'react-google-login';
import FacebookLogin from 'react-facebook-login';
import SocialConfig from '../_config/social.config';
import { REGISTER_ROUTE } from './register.page';
import { PRACTICE_SET } from './PracticeSet/PracticeSetPage';
import { setUserToken } from '../store/action-creator';
import { useToasts } from 'react-toast-notifications';

export const LOGIN_ROUTE = "/login";

const auth = new AuthService();

type P = {
    setUser: Function,
    preferredLevel: string, // level of language
    preferredCourse: number | undefined
}

export default function LoginPage(props: P) {
    const { addToast } = useToasts();
    const [message, setMessage] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [isModalVisible, setIsModalVisible] = useState(false);

    const login = (event: FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        const form = event.target as HTMLFormElement;
        const credentials = {
            email: form.email.value,
            password: form.password.value,
            levelOfLanguage: props.preferredLevel,
            currentModule: props.preferredCourse
        };
        setIsLoading(true);
        auth.login(credentials)
            .then(response => {
                if ('message' in response.data) {
                    setMessage(response.data.message);
                    setIsLoading(false);
                } else {
                    const user = response.data;
                    props.setUser(user);
                    localStorage.setItem('user', JSON.stringify(user));
                    let checkType = user?.cohort && user?.cohort.length > 0 && user?.cohort.find((item:any)=> item.type_id == 2);
                    if(checkType?.type_id == 2){
                        history.push('/quiz-sets');
                    } else {
                        history.push(PRACTICE_SET); 
                    }
                }
            })
            .catch(err => {
                setIsLoading(false);
                setMessage(err.Message);
            });

    }

    const resetPassword = (event: FormEvent<HTMLFormElement>) => {
        console.log('here')
        event.preventDefault();
        setMessage('');
        setIsLoading(true);
        const form = event.target as HTMLFormElement;
        const email = form.email.value;
        if (!email.trim()) {
            return;
        }
        auth.resetPassword(email).then(response => {
            setMessage(response.data.message);
        }).catch(error => {
            setMessage('Some error occurred!');
        }).finally(() => {
            form.reset();
            setIsLoading(false);
            setIsModalVisible(false);
        });
    }

    /**
     * Google Auth
     * @param {*} response 
     */
    const googleAuthResponse = (response: any) => {
        
        if (response && ('accessToken' in response)) {
            const accessToken = response.accessToken;
            auth.loginGoogle(accessToken)
                .then(response => {
                    if(response.data.status=== false){
                        setIsLoading(false);
                        setMessage(response.data.message);
                    }
                    else if ('message' in response.data) {
                        setMessage(response.data.message);
                        setIsLoading(false);
                    } else {
                        const user = response.data;
                        props.setUser(user);
                        localStorage.setItem('user', JSON.stringify(user));
                        history.push('/quiz-sets');
                    }
                })
                .catch(err => {
                    setIsLoading(false);
                    setMessage(err.Message);
                    console.log({ err })
                });
        } else {
            console.log({ response })
            //alert('something went wrong, please try again!');
        }
    }

    /**
     * Google Auth
     * @param {*} response 
     */
    const facebookAuthResponse = (response: any) => {
        // Check if there is a token

        console.log({ facebookResponse: response })

        if (response && ('accessToken' in response)) {
            const accessToken = response.accessToken;
            auth.loginFacebook(accessToken)
                .then(response => {
                    if(response.data.status=== false){
                        setIsLoading(false);
                        setMessage(response.data.message);
                    }
                    else if ('message' in response.data) {
                        setMessage(response.data.message);
                        setIsLoading(false);
                    } else {
                        const user = response.data;
                        props.setUser(user);
                        localStorage.setItem('user', JSON.stringify(user));
                        history.push('/quiz-sets');
                    }
                })
                .catch(err => {
                    setIsLoading(false);
                    setMessage(err.Message);
                });
        } else {
            addToast('something went wrong, please try again!',{appearance:'error',autoDismiss:true});
        }
    }

    return (
        <>
            <div className="LoginPage">
                <div>
                    <div className="text-center h1 mb-5">Welcome to the Taplingua AI Based Interview Prep Tool</div>
                    <img className="main-logo" src={logo} alt="Main Logo" />
                    <form onSubmit={login}>
                        {message && <div style={{ color: 'red', fontSize: '21px', marginBottom: '1rem' }}>{message}</div>}
                        <input className="form-control" name="email" type="email" placeholder="Email" />
                        <input className="form-control" name="password" type="password" placeholder="Password" />
                        <span className="password-forgot-link" onClick={() => { setIsModalVisible(true) }}>Forgot your password?</span>
                        {
                            isLoading ?
                                <div style={{
                                    fontSize: '25px',
                                    padding: '1rem',
                                    marginTop: '32px'
                                }}>
                                    <Spinner color="red" larger />
                                </div> :
                                <button type="submit">Log in</button>
                        }

                    </form>
                    <div className="social_ican" style={{ marginTop: '1rem', textAlign: 'center', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                                    <GoogleLogin
                                        clientId={SocialConfig.google.clientId}
                                        buttonText="Login"
                                        onSuccess={googleAuthResponse}
                                        onFailure={googleAuthResponse}
                                        cookiePolicy={'single_host_origin'}
                                    />
                                    {/* <FacebookLogin
                                        appId={SocialConfig.facebook.appId}
                                        textButton="Continue with Facebook"
                                        callback={facebookAuthResponse}
                                        cssClass="btnFacebook"
                                        icon="fa-facebook"
                                    /> */}
                                </div>
                    <div className="mt-5" style={{ fontSize: '16px' }}>The Taplingua Interview Prep tool is a companion app for the Taplingua Business English App.
                        The tool and the app is only available on through our College or Corporate partners.
                        Please contact us at info@taplingua.com if you would like to get access.
                    </div>
                </div>
                <div
                    className="password-forgot-modal"
                    style={{ display: isModalVisible ? 'flex' : 'none' }}
                    onClick={e => { setIsModalVisible(false); }}>
                    <form onSubmit={resetPassword} onClick={e => { e.stopPropagation() }}>
                        <input className="form-control" type="email" placeholder="Email" name="email" />
                        {
                            isLoading ?
                                <div style={{
                                    fontSize: '25px',
                                    padding: '1rem',
                                    marginTop: '32px'
                                }}>
                                    <Spinner color="red" larger />
                                </div> :
                                <button type="submit">Send Reset Link</button>
                        }
                        <span className="close" onClick={() => { setIsModalVisible(false) }}>&times;</span>
                    </form>
                </div>
            </div>
        </>
    );
}