import React from 'react';
import { BackArrow, ProgressBar } from '../_components';
import { MainService } from '../_services/main.service';
import { Module } from '../_types';
import { Link } from 'react-router-dom';
import { endpoints } from '../_config';
import { makeLLPRoute } from './llp.page';
import { Nl2br } from '../_components/nl2br.component';
import { withI18 } from '../_context';
import { lang } from 'moment';

type P = {
    user: any,
    match: any,
    userActivity: Array<any>,
    lang: any
}

type S = {
    module?: Module | null,
    moduleActivity?: any, // moduleActivity[levelNo][lessonNo]
    moduleActivityLoaded: boolean // to check if module acitivity is loaded (prevemts rerender)
}

export const MODULE_ROUTE = '/module/:moduleNo';

export const moduleRoute = (moduleNumber = "0") => '/module/' + moduleNumber;

export class ModulePageComponent extends React.Component<P, S> {
    private main = new MainService();
    private moduleNo: number;
    constructor(props: P) {
        super(props);
        this.moduleNo = props.match.params.moduleNo;
        this.state = {
            module: null,
            moduleActivityLoaded: false
        }
    }
    componentDidMount() {
        this.main.getModules(this.props.user, this.moduleNo, 1)
            .then(response => {
                if (response.data.length < 1) {
                    throw new Error('Module not found!');
                }
                const module = response.data[0] as Module;
                this.setState({
                    module
                });
            })
            .catch(error => {
                console.log(error);
            })
    }

    componentDidUpdate(prevProps: P) {
        // get module activity
        if (prevProps.userActivity.length > 0 && this.state.moduleActivityLoaded === false) {
            const moduleActivity = {} as Array<any>;
            this.props.userActivity.forEach(activity => {
                if (activity.moduleNo == this.moduleNo) {
                    if (moduleActivity[activity.routeNo] === undefined) {
                        moduleActivity[activity.routeNo] = {};
                    }
                    if (moduleActivity[activity.routeNo][activity.levelNo] === undefined) {
                        moduleActivity[activity.routeNo][activity.levelNo] = {};
                    }
                    if (moduleActivity[activity.routeNo][activity.levelNo][activity.lessonNo] === undefined) {
                        moduleActivity[activity.routeNo][activity.levelNo][activity.lessonNo] = [];
                    }
                    // if acitivity not there push activity
                    if (!moduleActivity[activity.routeNo][activity.levelNo][activity.lessonNo].includes(activity.activityType)) {
                        moduleActivity[activity.routeNo][activity.levelNo][activity.lessonNo].push(activity.activityType);
                    }
                }
                // debugger;
            });
            this.setState({
                moduleActivity,
                moduleActivityLoaded: true
            });
        }
    }

    getRoutePercent(routeNo: string | number, levelNo: string | number): number {
        if (
            this.state.moduleActivity && // if activity is there
            this.state.moduleActivity[routeNo] && // if it has route
            this.state.moduleActivity[routeNo][levelNo] // if it have level no.
        ) {
            try {
                return Math.floor((
                    Object.values<any>(
                        this.state.moduleActivity[routeNo][levelNo])
                        .flat()
                        .reduce((a: any, b: any) => parseInt(a) + parseInt(b))
                    / 15
                ) * 100);
            } catch (err) {
                return 0;
            }
        } else {
            return 0;
        }
    }

    // get if week is touched or not
    getWeekTouchedOrNot(routeNo: string | number) {
        try {
            const route = this.state.module?.routes.find(r => r.routeno == routeNo);
            if (route) {
                return route.levels.map(level => this.getRoutePercent(routeNo, level.levelno)).filter(e => e !== 0).length > 0;
            } else {
                return false;
            }
        } catch(e) {
            return false;
        }
    }

    render() {
        const { module } = this.state;
        return (
            <div className="ModulePage">
                <BackArrow />
                {
                    module &&
                    <div className="container mt-5 pt-5">
                        <div className="pt-5 module-description">
                            <div>
                                <div className="module-name">{module.description}</div>
                                <div className="module-week-count">
                                    {module.routeCount === 1 ? module.routeCount + " Week" : module.routeCount + " Weeks"}
                                </div>
                            </div>
                            <img src={"/_assets/module_icons/icon_module_" + module.moduleno + ".svg"} alt={module.description} />
                        </div>
                        <div className="module-route-list">
                            {
                                module.routes.map((route, j) => {
                                    return (
                                        <div key={j} className="route-card">
                                            <div className={"route-card-head" + (this.getWeekTouchedOrNot(route.routeno) ? "" : " untouched")}>
                                                <div className="route-name">{route.description}</div>
                                            </div>
                                            <div className="route-body">
                                                {
                                                    route.levels.map((level, i) => (
                                                        <Link
                                                         to={makeLLPRoute(this.moduleNo.toString(), route.routeno.toString(), level.levelno.toString())}
                                                          className="route d-block" key={i}>
                                                            <div className="route-level">
                                                                <div className="level-no">{this.props.lang.handle('level')} {level.levelno}</div>
                                                                <div className="level-description">
                                                                    <Nl2br text={level.description} />
                                                                </ div>
                                                            </div>
                                                            <ProgressBar percent={this.getRoutePercent(route.routeno, level.levelno)} withText />
                                                        </Link>
                                                    ))
                                                }
                                            </div>
                                        </div>
                                    )
                                })
                            }
                        </div>
                    </div>
                }
            </div>
        )
    }
}

export const ModulePage = withI18(ModulePageComponent);