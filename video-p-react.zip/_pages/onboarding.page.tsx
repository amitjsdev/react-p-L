import React, { useState } from 'react';
import logo from '../_assets/main-logo.png'
import { Link } from 'react-router-dom';
import { LOGIN_ROUTE } from './login.page';
import { TopNavigationBarWithBack } from '../_components';
import { history } from '../_config';

export const ONBOARDING_ROUTE = "/onboarding";

type OnboardingPageProps = {
    setPreferredCourse: any, // function to set the preferred course
    preferredCourse: number | undefined,
    setPreferredLevel: any, // function to set the preferred languageLevel
    preferredLevel: string,
}

export function OnboardingPage(props: OnboardingPageProps) {

    const [step, setStep] = useState(2); // skipping step 1 of choosing language for now


    /*  return (
         <div style={{background: "red"}}>sdsd</div>
     ) */
    return (
        <div className="OnboardingPage">
            <ShowOnboardingProcess
                step={step}
                preferredCourse={props.preferredCourse}
                setPreferredCourse={props.setPreferredCourse}
                setPreferredLevel={props.setPreferredLevel}
                preferredLevel={props.preferredLevel}
                nextStep={() => {
                    setStep(step + 1);
                }} lastStep={() => {

                }} />
        </div>
    );
}

type ShowOnboardingProcessProp = {
    step: number,
    nextStep: any,
    preferredCourse: number | undefined,
    setPreferredCourse: any,
    setPreferredLevel: any, // function to set the preferred languageLevel
    preferredLevel: string,
    lastStep: any
}

function ShowOnboardingProcess(props: ShowOnboardingProcessProp) {

    let title = "";
    let content = <></>;
    const [selectedLanguage, setSelectedLanguage] = useState("");

    switch (props.step) {
        case 1:
            title = "Choose your language";
            content = (
                <div>
                    <div className="i-want-to-learn">I want to learn</div>
                    <div
                        onClick={() => {
                            setSelectedLanguage("Spanish");
                            props.setPreferredCourse(3);
                        }}
                        className={
                            "course-option " + (props.preferredCourse === 3 ? "selected" : "")
                        }>Spanish</div>
                    <div
                        onClick={() => {
                            setSelectedLanguage("French");
                            props.setPreferredCourse(43);
                        }}
                        className={
                            "course-option " + (props.preferredCourse === 43 ? "selected" : "")
                        }>French</div>
                    <div
                        onClick={() => {
                            setSelectedLanguage("German");
                            props.setPreferredCourse(45);
                        }}
                        className={
                            "course-option " + (props.preferredCourse === 45 ? "selected" : "")
                        }>German</div>
                    <div
                        onClick={() => {
                            setSelectedLanguage("Portugese");
                            props.setPreferredCourse(33);
                        }}
                        className={
                            "course-option " + (props.preferredCourse === 33 ? "selected" : "")
                        }>Portugese</div>
                    <div
                        onClick={() => {
                            setSelectedLanguage("Italian");
                            props.setPreferredCourse(44);
                        }}
                        className={
                            "course-option " + (props.preferredCourse === 44 ? "selected" : "")
                        }>Italian</div>

                    <div className="continue-button" onClick={() => {
                        props.nextStep();
                    }}>Continue</div>
                </div>
            );
            break;
        case 2:
            title = "";
            content = (
                <div>
                    <div className="i-want-to-learn">What is your level of {selectedLanguage}</div>
                    <div
                        className={
                            "language-option " + (props.preferredLevel === "beginner" ? "selected" : "")
                        }
                        onClick={() => {
                            props.setPreferredLevel("beginner");
                        }}>
                        <div className="level-title">Complete Beginner</div>
                        <div className="level-description">I am learning Spanish for the first time</div>
                    </div>
                    <div
                        className={
                            "language-option " + (props.preferredLevel === "basic" ? "selected" : "")
                        }
                        onClick={() => {
                            props.setPreferredLevel("basic");
                        }}>
                        <div className="level-title">Beginner</div>
                        <div className="level-description">I know few words</div>
                    </div>
                    <div
                        className={
                            "language-option " + (props.preferredLevel === "intermediate" ? "selected" : "")
                        }
                        onClick={() => {
                            props.setPreferredLevel("intermediate");
                        }}>
                        <div className="level-title">Intermediate</div>
                        <div className="level-description">I can have simple conversations</div>
                    </div>

                    <div className="continue-button" onClick={() => {
                        // throw user at login screen
                        history.push(LOGIN_ROUTE);
                    }}>Continue</div>
                </div>
            );
            break;
    }

    return (
        <div className="content">
            <TopNavigationBarWithBack title={title} />
            {content}
        </div>
    );
}
