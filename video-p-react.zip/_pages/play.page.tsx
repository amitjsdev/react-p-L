
import React, { useState } from 'react';
import { BackArrow, PreExercise } from '../_components';
import { MainService } from '../_services/main.service';
import { Lesson, Module, ModuleRoute, Exercise, ExerciseType, RecentModule } from '../_types';
import { Link } from 'react-router-dom';
import { makeListenRoute } from './listen.page';
import { makeLLPRoute } from './llp.page';
import { moduleRoute } from './module.page';

import Audio from '../_components/audio.component';
import SpeechRecognition from '../_components/speech.component';
import moment from 'moment';
import { AuthService } from '../_services';
import { history } from '../_config';


type P = {
    user: any,
    match: any,
    coursesRegistered: Array<RecentModule>
}

type S = {
    module: Module | null,
    lesson: Lesson | null,
    route: ModuleRoute | null,
    exercise: Exercise | null,
    preExerciseDone: boolean,
    startTime: Date
}

// Route for router
export const PLAY_ROUTE = '/module/:moduleNo/route/:routeNo/level/:levelNo/play/:playNo';

// painlessly create route to this component
export const makePlayRoute = (
    moduleNo: string,
    routeNo: string,
    levelNo: string,
    playNo: string
) => `/module/${moduleNo}/route/${routeNo}/level/${levelNo}/play/${playNo}`;

export class PlayPage extends React.Component<P, S> {

    private main = new MainService();
    private auth = new AuthService();

    private moduleNo: number;
    private routeNo: number;
    private levelNo: number;
    private lessonNo: number;

    constructor(props: P) {
        super(props);



        this.moduleNo = props.match.params.moduleNo;
        this.routeNo = props.match.params.routeNo;
        this.levelNo = props.match.params.levelNo;
        this.lessonNo = props.match.params.playNo;

        this.state = {
            module: null,
            lesson: null,
            route: null,
            exercise: null,
            preExerciseDone: true,
            startTime: new Date()
        }

    }


    // get the audio from server
    media(media: string) {
        return this.main.getResource(this.moduleNo, this.routeNo, this.lessonNo, media);
    }

    get course() {
        return this.props.coursesRegistered.find(c => (c.moduleNumber ?? null) == this.moduleNo.toString());
    }


    get route() {
        return this.state.module ?
            this.state.module.routes.find(r => r.routeno == this.routeNo) :
            null
    }

    componentDidMount() {
        // get modules
        this.main.getModules(this.props.user, this.moduleNo, 1)
            .then(response => {
                if (response.data.length < 1) {
                    throw new Error('Module not found!');
                }
                const module = response.data[0] as Module;
                // get module route
                this.setState({
                    module,
                    route: module.routes.find(r => r.routeno == this.routeNo) || null
                });
            })
            .catch(error => {
                console.log(error);
            });

        //  get the lesson
        this.main.getLesson(this.props.user, this.moduleNo, this.routeNo, this.lessonNo).then(response => {
            this.setState({
                lesson: response.data[0] as Lesson
            });
        })
            .catch(error => {
                console.log(error);
            });
        //  get the exercise
        this.main.getExercise(this.props.user, this.moduleNo, this.routeNo, this.lessonNo).then(response => {
            this.setState({
                exercise: response.data[0]
            });
        })
            .catch(error => {
                console.log(error);
            });
    }

    get nextRoute() {
        try {
            if (this.lessonNo == this.levelNo * 3) { // if its last lesson of the level of this route
                if (this.state.module) {
                    if (this.state.module.routes.length == this.routeNo) { // if its the last route of the modules
                        return "/"; // return home
                    } else if (this.state.route) { // not the last route of the route
                        if (this.state.route.levels.length != this.levelNo) { // not last level of this route
                            return makeLLPRoute(this.moduleNo.toString(), this.routeNo.toString(), (parseInt(this.levelNo.toString()) + 1).toString());
                        } else { // to increment to next routes first lesson
                            return makeLLPRoute(this.moduleNo.toString(), (parseInt(this.routeNo.toString()) + 1).toString(), this.state.module.routes[this.routeNo].levels[0].levelno.toString());
                        }
                    } else {
                        return "/";
                    }
                } else {
                    return "/";
                }
            } else if (this.lessonNo == ((this.levelNo - 1) * 3) + 1) { // if its the first lesson of this level
                return makeListenRoute(this.moduleNo.toString(), this.routeNo.toString(), this.levelNo.toString(), (parseInt(this.lessonNo.toString()) + 1).toString());
            } else if (this.lessonNo == ((this.levelNo - 1) * 3) + 2) { // if its the second lesson of the route
                return makePlayRoute(this.moduleNo.toString(), this.routeNo.toString(), this.levelNo.toString(), (parseInt(this.lessonNo.toString()) + 1).toString());
            }
            return "/";
        } catch (e) {
            return "/";
        }
    }

    render() {

        return (
            <div className="PlayPage">
                <BackArrow alt />
                <div className="container mt-5 pt-5 text-center">
                    {
                        this.state.preExerciseDone ?
                            <div>
                                <div className="exercise-meta">
                                    <div className="exercise-header">Play</div>
                                    <span>Level {this.state.lesson?.title}</span>
                                </div>
                                {
                                    this.state.exercise ?
                                        this.state.exercise.exercise_no === ExerciseType.READING || this.state.exercise.exercise_no === ExerciseType.LISTEN || this.state.exercise.exercise_no === ExerciseType.VOICE ? // check which type of exercise is it.
                                            <ReadingExercise
                                                exercise={this.state.exercise}
                                                nextRoute={this.nextRoute || ''}
                                                media={(media: string) => {
                                                    return this.media(media);
                                                }}
                                                props={this.props}
                                                moduleNo={this.moduleNo}
                                                routeNo={this.routeNo}
                                                levelNo={this.levelNo}
                                                state={this.state}
                                                lessonNo={this.lessonNo}
                                                course={this.course}
                                                auth={this.auth}
                                            /> :
                                            <SpeakingExercise
                                                exercise={this.state.exercise}
                                                nextRoute={this.nextRoute || ''} /> :
                                        ''
                                }
                            </div> :
                            // the pre exercise window
                            <PreExercise
                                state={{ lesson: this.state.lesson, route: this.state.route }}
                                preExerciseDone={() => {
                                    this.setState({ preExerciseDone: true });
                                    // TODO: fire activity log api
                                }}
                                type={'play'}
                            />
                    }
                </div>
            </div>
        );

    }
}


export function ReadingExercise(props: {
    exercise: Exercise, nextRoute: string, media: Function,
    props: any,
    moduleNo: any,
    routeNo: any,
    levelNo: any,
    state: any,
    lessonNo: any,
    course: any,
    auth: AuthService
}) {

    //  to track the progress of the questionary
    const [progress, setProgress] = useState(0 as number);

    const [isSpeechDone, setIsSpeechDone] = useState(false);

    // creating well formed models from data provided
    const [exercises, setExercises] = useState(props.exercise.description.map((description, i) => {
        const exercise = {} as any;
        exercise.question = description;
        const options = props.exercise.media_alt1[i].split(';');
        exercise.options = [...options].sort(() => Math.random() - 0.5).map(e => e.trim());
        exercise.answer = options[0].trim();
        exercise.remark = props.exercise.media_alt3[i];
        exercise.userAnswer = null;
        return exercise as Exercise;
    }));

    // static typechecking model
    type Exercise = {
        question: string,
        options: Array<string>,
        answer: string,
        remark: string,
        userAnswer: string | null,
    }

    // the current exercise
    const exercise: Exercise = exercises[progress];

    return (
        <div className="ReadingExerciseHolder">
            <div className="exercise-card">
                <div className="exercise-title">
                    {props.exercise?.title}
                </div>
                <div className="ReadingExercise">
                    <div className="exercise-content">
                        {
                            /* props.exercise.media[progress] === '_' ? '' :
                                <Audio
                                    src={props.media('exercises/' + props.exercise.media[progress])}
                                    autoPlay
                                /> */
                        }
                        {props.exercise.exercise_no === ExerciseType.VOICE ? 'This feature is only available in the mobile app!' : exercise.question}
                    </div>
                    {
                        props.exercise.exercise_no === ExerciseType.VOICE ? // shows nothing as expected t be hidden according to client
                            true ? '' : <div className="" style={{ paddingBottom: isSpeechDone ? "15rem" : "0" }}>
                                <SpeechRecognition onComplete={() => {
                                    setIsSpeechDone(true);
                                }} />
                            </div> :
                            <div className="options">
                                {
                                    exercise.options.map((option, i) => (
                                        <div
                                            className={
                                                "option" + (
                                                    exercise.userAnswer !== null ?
                                                        exercise.userAnswer === option ?
                                                            exercise.userAnswer === exercise.answer ?
                                                                " correct" : " incorrect"
                                                            : ""
                                                        :
                                                        ""
                                                )
                                            }
                                            key={i}
                                            onClick={
                                                event => {
                                                    if (!exercise.userAnswer || exercise.userAnswer !== exercise.answer) {
                                                        const e = { ...exercise };
                                                        e.userAnswer = option;
                                                        const es = [...exercises];
                                                        es[progress] = e;
                                                        setExercises(es);
                                                    }
                                                }
                                            }>{option.replace(/\*/g, ',')}</div>
                                    ))
                                }
                            </div>
                    }
                    { // if exercise is not speech type and answer matches
                        (
                            (props.exercise.exercise_no !== ExerciseType.VOICE && exercise.userAnswer && exercise.userAnswer === exercise.answer) ||
                            (props.exercise.exercise_no === ExerciseType.VOICE && isSpeechDone)
                        ) &&
                        <div className="exercise-remark">
                            <div className="remark-message">
                                <div className="remark-title">Good Job!</div>
                                {exercise.remark}
                                {
                                    // TODO: implement the save review section, show hurray message!
                                    props.exercise.total_questions - 1 === progress ?
                                        <div>
                                            <span
                                                className="continue-button"
                                                onClick={() => {

                                                    // save the user activity log
                                                    const payload = {
                                                        userId: props.props.user.email,
                                                        activityDateFrom: moment(props.state.startTime).format('YYYY-MM-DD hh:mm:ss'),
                                                        activityDateTo: moment(new Date()).format('YYYY-MM-DD hh:mm:ss'),
                                                        activityType: 1, // 1= Listen, 2 = Learn, 3 = Play
                                                        moduleNo: props.moduleNo,
                                                        routeNo: props.routeNo,
                                                        levelNo: props.levelNo,
                                                        totalQuestions: props.state.lesson?.dialog.length,
                                                        lessonNo: props.lessonNo,
                                                        courseNumber: props.course?.courseNumber
                                                    };

                                                    props.auth.saveActivityLog(props.props.user, payload)
                                                        .then(response => {
                                                            //
                                                        })
                                                        .catch(error => {
                                                            // TODO: Error handled
                                                        })
                                                        .finally(() => {
                                                            history.push(props.nextRoute);
                                                        });
                                                }}>
                                                Continue
                                        </span>
                                            <div
                                                onClick={() => {
                                                    window.location.reload();
                                                }}
                                                className="do-not-continue">
                                                Wait, I want to do this again.
                                        </div>
                                        </div> :
                                        <div className="continue-button" onClick={() => {
                                            setIsSpeechDone(false);
                                            setProgress(progress + 1);
                                        }}>Continue</div>
                                }
                            </div>
                        </div>
                    }
                </div>
            </div>
        </div>
    );

}

export function SpeakingExercise(props: { exercise: Exercise, nextRoute: string }) {
    return (
        <div className="SpeakingExerciseHolder">
            {
                !('webkitSpeechRecognition' in window) ?
                    'Your browser does not support Speech Recognition, please try in Chrome.' :
                    'LOL'
            }
        </div>
    )
}
