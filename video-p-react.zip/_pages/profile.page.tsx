import React, { ReactNode } from 'react';
import { history } from '../_config';
import { Employee } from '../_types';
import { ABOUT_ROUTE } from './about.page';
import userIcon from '../_assets/user-icon-96.png';
import { Link } from 'react-router-dom';
import { HOME_ROUTE } from './home_learn.page';
import backArrow from '../_assets/back-arrow-3x.png';

export const PROFILE_ROUTE = '/profile';

export function ProfilePage(props: { user: any, employee: Employee }) {
    return (
        <div className="ProfilePage">
            <span className="back-button" onClick={() => {
                history.push(HOME_ROUTE)
            }}>
                <img
                    src={backArrow}
                    alt="Back" />
            </span>
            <div className="profile-background"></div>
            <div className="content">
                <div className="user-details">
                    <div className="user-icon">
                        <img src={userIcon} alt="User Icon" />
                    </div>
                    <h2>{props.user.firstName}</h2>
                    <h5>{props.user.email}</h5>
                </div>
                <div className="body">
                    <ProfileButton label="Points" extraInfo={
                        <div className="points">185 <span>points</span></div>
                    } />
                    <br/>
                    <ProfileButton label="About taplingua" onClick={() => {
                        history.push(ABOUT_ROUTE);
                    }} />
                    <ProfileButton label="Logout" onClick={() => {
                        localStorage.removeItem('cohortId');
                        localStorage.removeItem('user');
                        history.replace('/');
                        window.location.reload();
                    }} />
                </div>
            </div>
        </div>
    )
}

function ProfileButton(props: { label: string, onClick?: Function, extraInfo?: ReactNode }) {
    return (
        <button
            className={"profile-button " + (props.onClick ? "has-onclick" : "")} onClick={() => {
                if (props.onClick) {
                    props.onClick();
                }
            }} >
            <span>{props.label}</span>
            {props.extraInfo ? props.extraInfo : <></>}
        </button>
    )
}