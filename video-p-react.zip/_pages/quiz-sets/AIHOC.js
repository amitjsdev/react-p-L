import React from 'react';
import p5 from "p5";
import ai from '../../ai/key_pose_features'
// This function takes a component...
var aiObj = null;
const  processAITimer = (data) => {
  const total = data.exam_timer;

  let finalResult = 'Low';

  let zero_candidate = ((data.zero_candidate_timer / total) * 100);
  let multi_user_counter = ((data.multi_user_counter / total) * 100);
  let away_looking = ((data.looking_away_sides_timer / total) * 100);
  let up_looking = ((data.looking_away_up_down_timer / total) * 100);
  if (away_looking > 30 || zero_candidate > 30 || up_looking > 30 || multi_user_counter > 30) {
    finalResult = 'High'
  }
  // else if (data.multi_user_counter > 120 || data.looking_away_sides_timer > 120 || data.looking_away_up_down_timer > 120 || data.lighting_check_timer > 120 || data.zero_candidate_timer > 120) {
  //   finalResult = 'High'
  // }
  else if (30 > multi_user_counter > 20) {
    finalResult = 'Medium'
  }
  else if (30 > away_looking > 20) {
    finalResult = 'Medium'
  }
  else if (30 > up_looking > 20) {
    finalResult = 'Medium'
  }
  else  if (multi_user_counter < 20 && away_looking < 20 && up_looking < 20) {
    finalResult = 'Low'
  }
  const processed= {
    finalResult,
    multi_user_percent:multi_user_counter.toFixed(0),
    zero_candidate_percent:zero_candidate.toFixed(0),
    away_looking_percent:away_looking.toFixed(0),
    up_looking_percent:up_looking.toFixed(0),
    total_time:total.toFixed(0),
    zero_candidate_time:data.zero_candidate_timer.toFixed(0)
  }
  return {aiTimer:data,processed}


}
function AIHOC(WrappedComponent) {
  // ...and returns another component...
  return class extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
        aiReady: false,

      };
    }

    componentWillUnmount() {
      if (this.timer) {
        clearInterval(this.timer)
      }
    }
    handleClick(e) {
      console.log(window.aiTimer);
    }
    callback = (type) => {
      if (type == 'init') {
        aiObj = new p5(ai)
        this.timer = setInterval(() => {
          if (aiObj && aiObj._setupDone && window.poseNetModelReady) {
            setTimeout(() => {
              this.setState({ aiReady: 1 })
            }, 2000)
            clearInterval(this.timer)
            console.log('setupDone');
          }
        }, 100);
      }
      else if (type == 'mini') {
        if (aiObj) {
          aiObj.mini()
        }
      }
      else if (type == 'timer') {
        const aiTimer = window.aiTimer;
        const processed= processAITimer(aiTimer)
        return processed;
      }
      else if (type == 'stop') {
        if (aiObj) {
          aiObj.stop()
          aiObj.remove()
        }
      }

      console.log('callbackHoc');
    }


   

    componentDidMount() {
      // const p = { "zero_candidate_timer": 9.079, "multi_user_counter": 0, "looking_away_sides_timer": 0, "looking_away_up_down_timer": 0, "exam_timer": 9.095, "lighting_check_timer": 0 }
      // const r = this.processAITimer(p)
      // console.log({ r });
    }

    render() {
      const { aiReady } = this.state
      return (
        <>
            {/* <div id="square" style={{ display: 'hidden' }} ></div> */}
              
          <WrappedComponent {...this.props} callbackHoc={this.callback} aiobj={this.ai} aiReady={aiReady} />
        </>
      );
    }
  };
}
export default AIHOC;
export const processAITimerhandler =processAITimer;