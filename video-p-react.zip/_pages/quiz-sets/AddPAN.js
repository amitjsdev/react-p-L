import React, { useEffect, useState } from 'react'
import { Spinner, TopNavigationBar } from '../../_components'
import "./quiz-set.scss"
import { MainService } from '../../_services/main.service'
// import Button from '../../_components/button.component'
import { LottieLoader } from '../../_components/lottie-loader.component'
import { Button } from 'react-bootstrap'

const main = new MainService()

const AddPAN = ({ user, setStep }) => {

    const [loading, setLoading] = useState(false);
    const [panInput, setPanInput] = useState('');
    return (
        <>
            <TopNavigationBar />
            <div className="" style={{ marginTop: '60px', marginBottom: '7%' }}></div>
            <div className="main ">
                {loading ? (
                    <div className="d-flex justify-content-center mt-5 pt-5">
                        <LottieLoader />
                    </div>
                ) : (
                    <div className="container">
                        <div className="row">
                            <label>Only 1 test attempt is allowed per candidate. To ensure your unique attempt, we ask you to provide us your PAN card number. .</label>
                            <div className="pan_number">
                                <div className="col-md-6">
                                    <b>Please enter your 10 digit PAN card number very carefully</b>
                                </div>
                                <div className="col-md-6">
                                    <input
                                        type="text"
                                        className="form-control"
                                        style={{ margin: "1rem 0" }}
                                        value={panInput}
                                        maxLength="10"
                                        onChange={e => {
                                            setPanInput(e.target.value);
                                        }} />
                                </div>
                            </div>
                        </div>
                        <div className="row pan_submit">
                            <div className="col-md-12">

                                        

                                <Button variant="success" size="lg" onClick={() => {
                                    
                                    const regex = /[^0-9a-zA-Z]/; //this will admit letters, numbers and dashes
                                    var check_flag = true 
                                    if(panInput.length ==10 ){
                                        setLoading(false)
                                        check_flag = false;
                                        if (panInput.match(regex)) {
                                            alert("Only Alphanumeric Character is allowed.")
                                            
                                        }else{
                                            main.PANDetail(panInput, user.token).
                                            then((obj) =>{ 
                                               if(obj.status == false){
                                                alert(panInput+" PAN Number is already in use.")  
                                               }else{
                                                setStep(3)
                                               }
                                            })
                                            .catch(() => {
                                                setLoading(false)
                                                alert('OOOPS something worng please again!')  
                                               
                                            });
                                        }
                                        
                                    }else{
                                        setLoading(false)
                                        alert("Please enter 10 digit PAN number.")
                                        check_flag = false;
                                    }
                                  
                                }}>
                                    Submit</Button>

                            </div >
                        </div >
                    </div >
                )}
            </div >
        </ >
    )
}
export default AddPAN
