import React, { useEffect, useState } from 'react'
import { Spinner, TopNavigationBar } from '../../_components'
import { Button } from 'react-bootstrap'

const DoAndDont = ({ setStep }) => {

    const [agree, setAgree] = useState(false);
    return (
        <>
            <TopNavigationBar />
            <div className="" style={{ marginTop: '60px', marginBottom: '7%' }}></div>
            <div className="main ">

                <div className="container exam_dos">
                    <div className="row exam_dos_row">
                        <div className="col-md-12">
                            <h2>Exam Do’s and Don’ts</h2>
                        </div>
                        <div className="col-md-12"></div>
                        <p>You are taking an AI based proctored test. Please follow the instructions carefully.</p>
                    </div>
                    <ol>
                        <li>
                            Please find a private, well-lit room with no one else around you.
                        </li>
                        <li>
                            Please be seated in a comfortable chair in front of your computer
                        </li>
                        <li>
                            Clear your workspace and table of any any books, calculators, mobile phones
                        </li>
                        <li>
                            Close all browser tabs and any other programs you are running.
                        </li>
                        <li>
                            You are not permitted to leave your seat once the exam clock starts.
                        </li>
                        <li>
                            You are not allowed to do Alt-tab, Print Screen at any time during the exam.
                        </li>
                        <li>
                            Do not close the exam tab until the exam page instructs that your attempt has been submitted
                        </li>
                    </ol>
                    <div className="row checkbox_pan">
                        <div className="col-md-4">
                            <input
                                type="checkbox"
                                className="form-control"
                                style={{ margin: "1rem 0" }}
                                checked={agree}
                                onChange={e => {
                                    setAgree(!agree);
                                }} />
                            Please check the box to continue
                        </div>
                        <div className="col-md-8">
                            I agree to abide by the exam rules
                        </div>


                    </div>
                    <div className="row checkbox_btn">
                        <div className="col-md-12">
                            <Button
                                disabled={!agree}
                                variant="success" size="lg" onClick={() => {
                                    setStep(4)
                                }}>
                                Continue</Button>

                        </div >
                    </div >

                </div>
            </div>
        </ >
    )
}
export default DoAndDont
