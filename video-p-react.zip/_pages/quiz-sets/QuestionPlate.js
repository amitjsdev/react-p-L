import React, { useEffect, useState } from 'react'
const Tdd = ({ id, ans, onClickHandler }) => {
    const myObj = ans[id - 1];
    return (
        <div
            className="trtd"
            key={id}
            onClick={e => !myObj.disabled ? onClickHandler(id - 1) : {}}
            title={myObj.current ? 'Current' : myObj.answered ? 'Answered' : myObj.visited ? 'Visited but not answered' : 'Not Visited'}
            style={{
                backgroundColor: myObj.answered ? 'green' : myObj.visited ? 'yellow' : 'gray',
                margin: 1,
                width: 30,
                height: 30,
                textAlign: 'center',
                cursor: myObj.disabled ? 'not-allowed' : 'pointer',
                opacity: myObj.disabled ? .3 : 1,
                border: myObj.current ? '4px solid red' : `4px solid ${myObj.answered ? 'green' : myObj.visited ? 'yellow' : 'gray'}`
            }}
        >
            {id}
        </div>
    )
}
const Trr = (props) => {
    const { platequestionLength, onClickHandler, currentIndex, ans, oldAns } = props;
    let { questionLength } = props;
    questionLength = questionLength - 1;
    const [answered, setAnswered] = useState([]);
    const [visited, setVisited] = useState([]);
    useEffect(() => {
        let p = visited;
        p.push(currentIndex)
        p = [...new Set(p)]
        setVisited(p);
        const a = ans.map((item, ind) => item.selectedAnswer ? ind.toString() : null)
        setAnswered(a)
    }, [currentIndex])
    useEffect(() => {
        if (oldAns && oldAns.length) {
            const a = oldAns.map((item, ind) => item.selectedAnswer ? ind.toString() : null)
            const b = oldAns.map((item, ind) => item.selectedAnswer ? ind : null)
            setAnswered(a)
            let p = b;
            p.push(currentIndex)
            p = [...new Set(p)];
            setVisited(p);
        }

    }, [oldAns.length])

    const trArr = Array.from({ length: platequestionLength / 8 }, (v, i) => i);
    const tdArr = Array.from({ length: 8 }, (v, i) => i + 1);
    const ansNew = Array.from({ length: platequestionLength }, (v, i) => ({ current: i === currentIndex, answered: answered.includes(i.toString()), visited: visited.includes(i), disabled: questionLength < i }));
    return (
        <>
            {
                trArr.map((tr) => {
                    return (
                        <div className="row" key={`tr${tr}`}>
                            {
                                tdArr.map((t) => <Tdd key={(tr * 8) + t} id={(tr * 8) + t} ans={ansNew} onClickHandler={onClickHandler} />)
                            }
                        </div>
                    )
                })
            }
        </>
    );
}
// platequestionLength, onClickHandler
const TableComponent = (props) => {

    return (
        <div className="">
            {<Trr {...props} />}
        </div>
    )
}
const QuestionPlate = ({ questionLength = 15, ans = [], onClickHandler, currentIndex, oldAns }) => {

    return (
        <TableComponent platequestionLength={60} questionLength={questionLength} ans={ans} onClickHandler={onClickHandler} currentIndex={currentIndex} oldAns={oldAns} />
    )
}
export default QuestionPlate;