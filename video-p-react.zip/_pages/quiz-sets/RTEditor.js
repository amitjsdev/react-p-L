import React from 'react';
const RTEditor =({data}) =><div dangerouslySetInnerHTML={{__html:data}} />
export default RTEditor;