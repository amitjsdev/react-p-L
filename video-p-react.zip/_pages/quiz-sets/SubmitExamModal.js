import React from 'react';
const SubmitExamModal = ({ submitTheExam, continueExam }) => {

    return (
        <div className="SkipModal">
            <div className="modal-body">
                <h5 className="text-center">Are you sure to Submit Exam</h5>
                <div className="d-flex justify-center">
                    <button className="cancel-exam-button" onClick={() => {
                        submitTheExam();
                    }}>Yes, Submit the Exam</button>
                    <button className="continue-exam-button" onClick={() => {
                        continueExam();
                    }}>No, Continue Exam</button>
                </div>
            </div>
        </div>
    )
}
export default SubmitExamModal;