import React, { useEffect, useRef, useState } from 'react';
import { MainService } from '../../_services/main.service';
import moment from 'moment';
const main = new MainService()
const TimerForTimeLeft = ({ callback, startTime, endTime }) => {
    const [intervelRef, setIntervalRef] =useState()
    useEffect( () => {
         main.serverTime().then((time)=>{
            if(time && time.a && moment(startTime) >  moment(time.a)){
                const inter = setInterval(()=>{
                     const pendingTime = moment(startTime) - moment();
                     if(pendingTime < 0){
                         callback(startTime);
                         clearInterval(intervelRef);
                         return;
                     }
                     console.log('time pending', moment(startTime) - moment());
                 },1000);
                 setIntervalRef(inter);
                
             }
        });
       
        // console.log( moment(startTime) - moment(time.t), startTime,moment(time.t) );
        return () =>{
            if(intervelRef){
                clearInterval(intervelRef);
            }
        }
    }, [startTime, endTime])

    return null;
}
export default TimerForTimeLeft;