import React, { useEffect, useRef, useState } from 'react'
import { Spinner, TopNavigationBar } from '../../_components'
import "./quiz-set.scss"
import { MainService } from '../../_services/main.service'
// import Button from '../../_components/button.component'
import { LottieLoader } from '../../_components/lottie-loader.component'
import { Button } from 'react-bootstrap'
import { history } from '../../_config'
import { QUIZ_SET_ROUTE } from './quiz-set.page'
export const PROCTORED_QUESTIONNAIRE_ROUTE = "/proctored-questionnaire"

const main = new MainService()

type P = {
    user: any;
}

type QuizQuestion = {
    key: string;
    type: string;
    value: string;
    answer: string;
    options?: any;
    required?: boolean;
}

const quizQuestions = [
    { key: "location", value: "Location (City)", answer: "", type: "text", options: [], required: true },
    { key: "graduationCollegeName", value: "Graduation College Name", answer: "", type: "text", options: [], required: true },
    { key: "branchOrDepartment", value: "Branch/Department", answer: "", type: "text", options: [], required: true },
    { key: "graduationGPAorPercent", value: "Graduation Percentage or GPA (out of 10)", answer: "", type: "number", options: [], required: true },
    { key: "class10GPAorPercent", value: "Class 10 Percentage or GPA (out of 10)", answer: "", type: "number", options: [] },
    { key: "graduationDateIfStudent", value: "Graduation Date If Student", answer: "", type: "date", options: [] },
    { key: "finalExamStartIfStudent", value: "If you are a final year student, when does your final semester exam start?", answer: "", type: "date", options: [] },
    { key: "areYouWorkingYN", value: "Are you a working professional currently?", answer: "", type: "radio", options: ['Yes', 'No'] },
    { key: "companyName", value: "Company Name (If your're a working professional or have worked before):", answer: "", type: "text", options: [] },
    { key: "workExperience", value: "Describe your work experience. It can be anything related to some programming tools or languages or even non technical details or internships. Just describe what you have worked on or what you generally work on in your company", answer: "", type: "textarea", options: [] },
    { key: "jeeRank", value: "JEE Mains rank (If applicable)", answer: "", type: "number", options: [] },
    { key: "collegeEntranceName", value: "College Entrance Exam Name (eg: EAMCET, JEE Mains, KCET etc):", answer: "", type: "text", options: [] },
    { key: "stateExamRank", value: "If you didn’t give JEE Mains, Provide the rank of the state level/other entrance test you took to join college :", answer: "", type: "number", options: [] },
    { key: "plansToWorkFullTime", value: "The program is for those who want to seek full time opportunities immediately upon completetion of the course. Do you plan to look for full time opportunity after completion?", answer: "", type: "radio", options: ['Yes', 'No', 'Not Sure'] },
    // { key: "currentAddress", value: "Current Address", answer: "", type: "text" },
    // { key: "whatsappNumber", value: "Whatsapp Number", answer: "", type: "text" },
];
const validateNumber = (val: any) => {
    if (!val) {
        return false;
    }
    if (!isNaN(val) && parseFloat(val) && parseFloat(val) == val) {
        return true;
    }

    return false;
}
const ProctoredQuestionnairePage = ({ user }: P) => {

    const [loading, setLoading] = useState(false);

    const [questionIndex, setQuestionIndex] = useState(0);
    const [questions, setQuestions] = useState<QuizQuestion[]>(quizQuestions);

    const [isFullScreen, setIsFullScreen] = useState(true);
    const [fullScreenInitiated, setFullScreenInitiated] = useState(false);
    const [start, setStart] = useState(false);
    

    useEffect(() => {
        window.onbeforeunload = confirmExit;
        function confirmExit() {
            return "show warning";
        }
        return ()=>{
            window.onbeforeunload=null;  
        }
    }, [])
    const warnOnClosePage = () => {
        window.onbeforeunload = confirmExit;
        const disabled =(questionIndex+1)== questions.length;
        function confirmExit() {
            return disabled ? '': "show message";
        }
    }
    // show next question
    const nextQuestion = () => {
        setQuestionIndex(questionIndex + 1);
        warnOnClosePage()
    }

    // show previous question
    const previousQuestion = () => {
        warnOnClosePage()
        setQuestionIndex(questionIndex - 1);
    }

    const goFullScreen = () => {
        try {
            const elem = document.getElementById("ProctoredQuestionnaire") as any;
            if (elem) {
                if (elem.requestFullscreen) {
                    elem.requestFullscreen()
                        .then(() => {
                            setIsFullScreen(true);
                        })
                        .catch((err: any) => {
                            console.log(err);
                        });
                } else if (elem.mozRequestFullScreen) { /* Firefox */
                    elem.mozRequestFullScreen()
                        .then(() => {
                            setIsFullScreen(true);
                        }).catch((err: any) => {
                            console.log(err);
                        });
                } else if (elem.webkitRequestFullscreen) { /* Chrome, Safari and Opera */
                    elem.webkitRequestFullscreen()
                        .then(() => {
                            setIsFullScreen(true);
                        }).catch((err: any) => {
                            console.log(err);
                        });
                } else if (elem.msRequestFullscreen) { /* IE/Edge */
                    elem.msRequestFullscreen()
                        .then(() => {
                            setIsFullScreen(true);
                        }).catch((err: any) => {
                            console.log(err);
                        });
                }
            }
        } catch (error) {
            console.log({ error });
        }
    }


    useEffect(() => {
        goFullScreen();

        const elem = document.getElementById("QuizAttempt") as any;


        // add listners for fullscreen exit
        const handleFullScreenExit = () => {
            if (!fullScreenInitiated) {
                setFullScreenInitiated(true);
            }
            if (!document.fullscreenElement && fullScreenInitiated) {
                setIsFullScreen(false);
            }
        }

        if (elem) {
            document.addEventListener('fullscreenchange', handleFullScreenExit, false);
            document.addEventListener('mozfullscreenchange', handleFullScreenExit, false);
            document.addEventListener('MSFullscreenChange', handleFullScreenExit, false);
            document.addEventListener('webkitfullscreenchange', handleFullScreenExit, false);
        }

        return () => {
            if (elem) {
                document.removeEventListener('fullscreenchange', handleFullScreenExit, false);
                document.removeEventListener('mozfullscreenchange', handleFullScreenExit, false);
                document.removeEventListener('MSFullscreenChange', handleFullScreenExit, false);
                document.removeEventListener('webkitfullscreenchange', handleFullScreenExit, false);
            }
        }
    }, [fullScreenInitiated]);
    const percent = (100 * (questionIndex / questions.length)).toFixed();

    return (
        <>
            <TopNavigationBar />
            <div className="" style={{ marginTop: '60px', marginBottom: '7%' }}></div>
            <div className="main ">
                {loading ? (
                    <div className="d-flex justify-content-center mt-5 pt-5">
                        <LottieLoader />
                    </div>
                ) : (
                    <div className="container">
                        <div className="progress-label" style={{ width: '50%', margin: '0 auto', textAlign: 'center' }}>Profile Completed %</div>
                        <div className="progress" style={{ width: '50%', margin: '0 auto' }}>

                            <div className="progress-bar progress-bar-success" role="progressbar"
                                style={{ width: `${percent}%`, backgroundColor: '#5cb85c' }} >{percent}%</div>
                        </div>
                        <h4 style={{textAlign:'center', paddingTop:10}}>Estimated time to complete the questionnaire: 2 minutes</h4>
                        {start ? (
                        <ShowQuestion
                            token={user.token}
                            question={questions[questionIndex]}
                            index={questionIndex}
                            setIndex={setQuestionIndex}
                            questions={questions}
                            goToNextQuestion={(answer: string) => {
                                const newAnswer = { ...questions[questionIndex], answer };
                                // update the answer at given index
                                const newQuestions = [...questions];
                                newQuestions[questionIndex] = newAnswer;
                                setQuestions(newQuestions);
                                // go to next question
                                nextQuestion();
                            }}
                            questionsLength={questions.length} />
                        ):(
                            <div style={{ marginTop: "2rem", marginBottom: "2rem", padding: "4rem", backgroundColor: "white", textAlign:'center' }} id="ProctoredQuestionnaire">
                                  <Button variant="success" size="lg" onClick={() => {warnOnClosePage();setStart(true);}}>Continue to Complete Profile</Button>
                            </div>
                        )}
                    </div>
                )}
            </div>
        </>
    )
}

function ShowQuestion({
    question,
    index,
    token,
    setIndex,
    questions,
    goToNextQuestion,
    questionsLength
}: {
    question: QuizQuestion,
    index: number,
    token: string,
    setIndex: Function,
    goToNextQuestion: Function,
    questions: QuizQuestion[],
    questionsLength: number,
}) {

    const [userAnswer, setUserAnswer] = useState(question.answer);
    const [answerError, setAnswerError] = useState('');

    useEffect(() => {
        setUserAnswer(question.answer);
    }, [index]);

    return (
        <div style={{ marginTop: "2rem", marginBottom: "2rem", padding: "4rem", backgroundColor: "white" }} id="ProctoredQuestionnaire">
            <h5>{question.value}
                {question.required && <span style={{ color: 'red' }}>*</span>}
            </h5>
            {
                ["text", "date"].includes(question.type) ? (
                    <input
                        type={question.type}
                        className="form-control"
                        style={{ margin: "1rem 0" }}
                        value={userAnswer}
                        onChange={e => {
                            setUserAnswer(e.target.value);
                        }} />
                ) :
                    question.type === "textarea" ? (
                        <textarea name="" id=""
                            style={{ margin: "1rem 0" }}
                            cols={30} rows={10}
                            value={userAnswer}
                            className="form-control"
                            onChange={e => {
                                setUserAnswer(e.target.value);
                            }} ></textarea>
                    ) :
                        question.type === "radio" ? (
                            question.options.map((op: any) => <>
                                <input name={question.key} id="" type="radio" key={op}
                                    className="form-control-radio"
                                    onChange={e => {
                                        setUserAnswer(op);
                                    }} /><label>{op}</label><br /></>)
                        )

                            : question.type === "number" ?
                                <><input
                                    type="text"
                                    className="form-control number"
                                    style={{ margin: "1rem 0" }}
                                    value={userAnswer}
                                    onChange={e => {
                                        if (e.target.value) {
                                            if (validateNumber(e.target.value)) {
                                                if (parseFloat(e.target.value) <= 100) {
                                                    setUserAnswer(e.target.value);
                                                    setAnswerError('')
                                                } else {
                                                    setAnswerError('Enter 1-10 for GPA or 1-100 for Percentage')
                                                }

                                            } else {
                                                setAnswerError('Only Numeric value allowed')
                                            }
                                        }
                                        else {
                                            setUserAnswer(e.target.value);
                                        }

                                    }} />

                                </>
                                :
                                <input
                                    type="text"
                                    className="form-control"
                                    style={{ margin: "1rem 0" }}
                                    value={userAnswer}
                                    onChange={e => {
                                        setUserAnswer(e.target.value);
                                    }} />


            }

            <span style={{ color: 'red', marginBottom: 10 }} className="error">{answerError}</span>
            <br />
            <br />
            {
                index > 0 ? (
                    <>
                        <Button variant="success" size="lg" onClick={() => {
                            // show next question

                            setIndex(index - 1);
                        }}>Back</Button>
                        &nbsp;&nbsp;&nbsp;&nbsp;
                    </>
                ) : <></>
            }
            {
                index < questionsLength - 1 ? (
                    <Button variant="success" size="lg" onClick={() => {
                        if (question.required && !userAnswer) {
                            setAnswerError('The answer to this question is mandatory')
                        } else {
                            setAnswerError('')
                            goToNextQuestion(userAnswer);
                        }
                        // show next question

                    }}>Next</Button>
                ) : (
                    <Button variant="success" size="lg" onClick={() => {
                        // Finish the test and save the resume
                        // save the result and send back to quiz sets page
                        const answers = {} as any;
                        questions.forEach(q => {
                            answers[q.key] = q.answer;
                        });
                        main.saveProctoredQuestionnaire(token, answers).finally(() => {

                            history.push(QUIZ_SET_ROUTE);
                        });
                    }}>Finish</Button>
                )

            }
        </div >
    )
}

export default ProctoredQuestionnairePage
