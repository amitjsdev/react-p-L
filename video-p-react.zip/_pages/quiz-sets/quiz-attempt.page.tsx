import React, { useEffect, useState } from 'react'
import { connect, useDispatch, useSelector } from 'react-redux'
import AIHOC from './AIHOC'
import { State } from '../../store/reducers'
import { Spinner, TopNavigationBar } from '../../_components'
import { history } from '../../_config'
import "./quiz.scss"
import { MainService } from '../../_services/main.service'
// import Button from '../../_components/button.component'
import { LottieLoader } from '../../_components/lottie-loader.component'
import { Button } from 'react-bootstrap'
import { QUIZ_SET_ROUTE } from './quiz-set.page'
import { PROCTORED_QUESTIONNAIRE_ROUTE } from './proctored-questionnaire.page'
import QuestionPlate from './QuestionPlate'
import SubmitExamModal from './SubmitExamModal'
import RTEditor from './RTEditor';


export const QUIZ_ATTEMPT_ROUTE = "/quiz/:quizSetId";

export const createQuizAttemptRoute = (quizSetId: number) => "/quiz/" + quizSetId;
const optionSaperator = ' ^&^ ';
const main = new MainService()



type QuizSetType = {
    id: number;
    quizSetId: number;
    companyCode: number;
    quizTopic: string;
    timeAllotted: number;
    isProctored: boolean;
    quizCompleted: boolean;
    questionCap: number;
    quizSubTopic: string;
    quizSubject: string;
    questionCount: number;
    created_at?: any;
    updated_at?: any;
    cohort: any;
    time: number,
    answer: any,
}

type QuizQuestionType = {
    id: number;
    quizSetId: number;
    quizSetQuestionId: number;
    questionType: number;
    questionText: string;
    optionChoices: string;
    options: Array<string>;
    difficultyLevel: 1 | 2 | 3;
    created_at?: any;
    updated_at?: any;
}

type AnswerType = {
    quizSetQuestionId: number,
    question: QuizQuestionType,
    isAnswerCorrect: boolean,
    selectedAnswer: string,
    correctAnswer: string,
}
type P = {
    user: any;
    store?: any;
    callbackHoc?: any;
    showResults: boolean,
    setShowResults: Function,
    isRecording: boolean,
    setIsRecording: Function,
    percent: boolean,
    setPercent: Function,
    quizAttemptLogId: number, setquizAttemptLogId: Function
    attemptNumber: number, setAttemptNumber: Function,
    quizSetId: number,
    videoRef: any,
    cameraError:any,
    NetSpeed:any,
    uploaded:any,
    EstimateTime:string
}
const QuizAttemptPageComponent = ({
    user, callbackHoc,
    showResults, setShowResults,
    isRecording, setIsRecording,
    percent, setPercent,
    quizAttemptLogId, setquizAttemptLogId,
    attemptNumber, setAttemptNumber,
    quizSetId,
    videoRef, cameraError,
    NetSpeed, uploaded,EstimateTime,
    ...store }: P) => {



    // quiz related
    const [quizQuestions, setQuizQuestions] = useState<Array<QuizQuestionType>>([]);
    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
    const [quizSet, setQuizSet] = useState<QuizSetType>();
    const [currentQuestion, setCurrentQuestion] = useState<QuizQuestionType>();
    const [answers, setAnswers] = useState<Array<AnswerType>>([]);
    const [OldAnswers, setOldAnswers] = useState<Array<AnswerType>>([]);
    const [questionBuckets, setQuestionBuckets] = useState<any>({});
    const [showUpload, setShowUpload] = useState(false);
    const [QP, setShowQP] = useState(false);

    // loading related
    const [loading, setLoading] = useState(false);
    const [isLoaded, setIsLoaded] = useState(false);
    const [errorMessage, setErrorMessage] = useState("");
    const [hideQuiz, setHideQuiz] = useState(false);
    const [showCancelTestModal, setShowCancelTestModal] = useState(false);
    const [showSubmitTestModal, setShowSubmitTestModal] = useState(false);
    const [allVisited, setAllVisited] = useState(false);
    const [visited, setVisited] = useState<number[]>([]);
    const [cancelTestModalReason, setcancelTestModalReason] = useState(-1);
    const [isFullScreen, setIsFullScreen] = useState(true);
    const [fullScreenInitiated, setFullScreenInitiated] = useState(false);
    const [showProfileQuestion, setShowProfileQuestion] = useState(false);


    const [questionCap, setQuestionCap] = useState(1); // how many questions to display


    const savetimeInterval = 50000 //time in miliseconds
    useEffect(() => {
        console.log({uploaded, NetSpeed});
        
    },[showUpload]);

    useEffect(() => {
            if(cameraError){
                alert('We need access to your camera for the test to proceed but were not able to get it. Please reload the screen and enable. camera access.');
                history.push('/quiz-sets')
            }
        },[cameraError]);



    useEffect(() => {
        if (!process.env.REACT_APP_IS_DEVELOPMENT) {
            document.onkeydown = function (e) {
                //return false;
            }

            document.addEventListener('contextmenu', function (e) {
                e.preventDefault();
            });
            window.onfocus = function () {
                console.log('onfocus');

            };
            window.onblur = function () {
                console.log('onblur');
                setcancelTestModalReason(2);
                setShowCancelTestModal(true)
            };
        }
    }, [])


    const saveTime = async (time: number = 10) => {
        // fire and forgoet
        const aiTimer = await callbackHoc('timer');
        main.saveAttemptTime(user.token, quizAttemptLogId, time, aiTimer)
    }
    const saveUserResponse = async (ans: any, isUserCancel: any = false, isCompleted: any = false) => {
        console.log('saveUserResponse', attemptNumber);

        const aiTimer = await callbackHoc('timer');
        if (attemptNumber) {
            if (isUserCancel) {
                await main.saveAttemptForQuizSet(user.token, quizSetId, attemptNumber, ans, isUserCancel, isCompleted, aiTimer);
                window.location.href = window.location.origin + QUIZ_SET_ROUTE
            } else {
                main.saveAttemptForQuizSet(user.token, quizSetId, attemptNumber, ans, isUserCancel, isCompleted, aiTimer)
            }
        }
    }




    // load the practice sets
    useEffect(() => {
        if (quizSetId) {
            // get quiz questions for quiz set assigned to me
            setLoading(true);
            main.quizSetsAssignedToMeQuestions(user.token, quizSetId)
                .then(({ questions, quizSet }: { questions: Array<QuizQuestionType>, quizSet: QuizSetType }) => {

                    console.log('questions--',questions,'quizSet',quizSet)
                    // save the set
                    setQuizSet(quizSet);

                    setShowProfileQuestion(quizSet.cohort.profile_questionnaire);
                    let adaptiveShuffle = quizSet.cohort.adaptiveShuffle;
                    adaptiveShuffle = !!adaptiveShuffle
                    setShowQP(!adaptiveShuffle);
                    // if (!adaptiveShuffle) {
                    //     setAnswerForNonAdaptive(questions)
                    // }
                    // set new question cap
                    if (quizSet.questionCap) {
                        setQuestionCap(quizSet.questionCap);// how many questions to display
                    } else {
                        setQuestionCap(questions.length);// how many questions to display
                    }
                    // save the questions to state
                    let qq :any = []
                    if (adaptiveShuffle) {
                        console.log('questions',questions)
                        if(!!questions){

                            qq = questions.map(q => {

                                // sort the options
                                if(!!q.optionChoices){
                                    q.options = q.optionChoices.split(optionSaperator).map(o => o.trim()).sort((a, b) => Math.random() - 0.5);
                                    return q;
                                }else{
                                    q.options = [];
                                    return q;
                                }

                            }).sort((a, b) => Math.random() - 0.5);
                    //    console.log('valData--',qq)
                            putQuestionsInBuckets(qq);
                        }
                        
                    } else {
                        if(!!questions){
                        qq = questions.map(q => {
                            // sort the options
                            if(!!q.optionChoices){
                                q.options = q.optionChoices.split(optionSaperator).map(o => o.trim()).sort((a, b) => Math.random() - 0.5);
                                return q;
                            }else{
                                q.options = [];
                                return q;
                            }
                           

                        })
                        console.log('valData--else',qq)

                        setQuizQuestions(qq);
                        
                        if (quizSet.answer) {
                            try {
                                const a = JSON.parse(quizSet.answer);
                                if(a && a.length > 0){
                                    setAnswers(a)
                                    setOldAnswers(a)
                                }
                               
                            } catch (e) {
                                console.log({e});
                                
                            }
                        }
                        setCurrentQuestion(qq[0])
                    }
                    }


                    // put question in relative buckes


                    setIsLoaded(true);
                    setLoading(false);

                    // create attempt for the user
                    main.createAttemptForQuizSet(user.token, quizSetId)
                        .then(({ attempt }: { attempt: any }) => {
                            setAttemptNumber(attempt.attemptNumber);
                            setquizAttemptLogId(attempt.id);
                        })
                        .catch(err => {
                            alert("Failed to create an attempt");
                        });
                })
                .catch(error => {
                    try {
                        setErrorMessage(error.response.data.message);
                    } catch (e) {
                        setErrorMessage("Failed to load quiz questions--");
                    }
                    console.log({ error });
                });
        }
    }, [quizSetId]);

    // full screen if in quiz
    useEffect(() => {
        if (quizSet) {
            const quizAttempt = document.getElementById("QuizAttempt");
            if (quizAttempt) {
                quizAttempt.classList.add("full-screen");
            }
        }
    }, [quizSet])

    // check for questionCap reached, show results in that case
    useEffect(() => {
        if (questionCap === answers.length && !QP) {
            // setShowResults(true);
            setShowUpload(true);
            setIsRecording(false);
        }
    }, [answers.length, questionCap]);

    // stop recording incase we are showing the result
    useEffect(() => {
        if (showResults) {
            setIsRecording(false);
        }
    }, [showResults]);

    // arrange the questions in buckets
    const putQuestionsInBuckets = (questions: Array<QuizQuestionType>) => {
        const bucket = {} as { 1: Array<QuizQuestionType>, 2: Array<QuizQuestionType>, 3: Array<QuizQuestionType> };
        // for each question
        for (const question of questions) {
            // create entry if not there
            if (!bucket.hasOwnProperty(question.difficultyLevel)) {
                bucket[question.difficultyLevel] = [];
            }
            // push question to buck
            bucket[question.difficultyLevel].push(question);
        }

        // shuffle the bucket
        if (bucket[1]) {
            bucket[1] = bucket[1].sort((a, b) => Math.random() - 0.5);
        }
        if (bucket[2]) {
            bucket[2] = bucket[2].sort((a, b) => Math.random() - 0.5);
        }
        if (bucket[3]) {
            bucket[3] = bucket[3].sort((a, b) => Math.random() - 0.5);
        }

        // set question buckets
        if (questions.length > 0) {
            // set current question to lowest of all
            setCurrentQuestion(getNextQuestionAndUpdateBuckets(bucket));
        }
    }

    const getNextQuestionAndUpdateBuckets = (
        oldBuckets: { 1: Array<QuizQuestionType>, 2: Array<QuizQuestionType>, 3: Array<QuizQuestionType> },
        isLastAttemptCorrect = false) => {
        // make bucket close
        const buckets = { ...oldBuckets };
        // make a holder to have the next question
        let nextQuestion: QuizQuestionType | undefined;
        // if there is no currentQuestion, set any question as first (lower to higher)
        if (!currentQuestion) {
            if (buckets[1] && buckets[1].length > 0) {
                // check for bucket 1
                nextQuestion = buckets[1].pop();
            } else if (buckets[2] && buckets[2].length > 0) {
                // check for bucket 2
                nextQuestion = buckets[2].pop();
            } else if (buckets[3] && buckets[3].length > 0) {
                // check for bucket 3 
                nextQuestion = buckets[3].pop();
            }
        } else {
            // we have current question, check if last attempt was correct
            if (isLastAttemptCorrect) {
                // here we try to check for new question in other higher attempts if possible
                // if last attempt was from 1st bucket
                if (currentQuestion.difficultyLevel == 1) {
                    // check for next question in other buckets
                    if (buckets[2] && buckets[2].length > 0) {
                        nextQuestion = buckets[2].pop();
                    } else if (buckets[3] && buckets[3].length > 0) {
                        nextQuestion = buckets[3].pop();
                    } else if (buckets[1] && buckets[1].length > 0) {
                        nextQuestion = buckets[1].pop();
                    }
                } else if (currentQuestion.difficultyLevel == 2) {
                    // check for next question in other buckets
                    if (buckets[3] && buckets[3].length > 0) {
                        nextQuestion = buckets[3].pop();
                    } else if (buckets[2] && buckets[2].length > 0) {
                        nextQuestion = buckets[2].pop();
                    } else if (buckets[1] && buckets[1].length > 0) {
                        nextQuestion = buckets[1].pop();
                    }
                } else if (currentQuestion.difficultyLevel == 3) {
                    // check for next question in other buckets
                    if (buckets[3] && buckets[3].length > 0) {
                        nextQuestion = buckets[3].pop();
                    } else if (buckets[2] && buckets[2].length > 0) {
                        nextQuestion = buckets[2].pop();
                    } else if (buckets[1] && buckets[1].length > 0) {
                        nextQuestion = buckets[1].pop();
                    }
                }
            } else {
                // here we try to check for new question in other lower attempts if possible
                // the last attempt was wrong, find a lower questions
                if (currentQuestion.difficultyLevel == 1) {
                    // check for next question in other buckets
                    if (buckets[1] && buckets[1].length > 0) {
                        nextQuestion = buckets[1].pop();
                    } else if (buckets[2] && buckets[2].length > 0) {
                        nextQuestion = buckets[2].pop();
                    } else if (buckets[3] && buckets[3].length > 0) {
                        nextQuestion = buckets[3].pop();
                    }
                } else if (currentQuestion.difficultyLevel == 2) {
                    // check for next question in other buckets
                    if (buckets[1] && buckets[1].length > 0) {
                        nextQuestion = buckets[1].pop();
                    } else if (buckets[2] && buckets[2].length > 0) {
                        nextQuestion = buckets[2].pop();
                    } else if (buckets[3] && buckets[3].length > 0) {
                        nextQuestion = buckets[3].pop();
                    }
                } else if (currentQuestion.difficultyLevel == 3) {
                    // check for next question in other buckets
                    if (buckets[2] && buckets[2].length > 0) {
                        nextQuestion = buckets[2].pop();
                    } else if (buckets[1] && buckets[1].length > 0) {
                        nextQuestion = buckets[1].pop();
                    } else if (buckets[3] && buckets[3].length > 0) {
                        nextQuestion = buckets[3].pop();
                    }
                }
            }
        }

        setQuestionBuckets(buckets);
        return nextQuestion;
    }

    // select next question
    const switchToNextQuestion = (currentQuestion: QuizQuestionType, isCorrect = false) => {
        if (QP) {
            let nextIndex = currentQuestionIndex + 1;
            nextIndex = nextIndex >= questionCap ? 0 : nextIndex
            setCurrentQuestionIndex(nextIndex);
            setCurrentQuestion(quizQuestions[nextIndex]);
        } else {
            setCurrentQuestion(getNextQuestionAndUpdateBuckets(questionBuckets, isCorrect));
        }

    }
    const checkForAllVisited = () => {

        let v = visited;
        if (v.includes(currentQuestionIndex)) {

        } else {
            v.push(currentQuestionIndex);
            setVisited(v)
        }
        console.log({ visited, quizQuestions });


        if (visited.length === questionCap) {
            setAllVisited(true)
        }
    }
    useEffect(() => {
        checkForAllVisited()
    }, [currentQuestionIndex])

    const setAnswerForNonAdaptive = (data: QuizQuestionType[]) => {
        const ans = data.map((item, i) => {
            const actualAnswer = item.optionChoices.split(optionSaperator)[0].trim();
            return {
                quizSetQuestionId: item.quizSetQuestionId,
                question: { ...item },
                isAnswerCorrect: false,
                selectedAnswer: '',
                correctAnswer: actualAnswer,
            }
        });

        setAnswers(ans);
    }
    const onClickHandlerQuestionPlate = (targetIndex: number) => {
        if (currentQuestion) {

            setCurrentQuestionIndex(targetIndex);
            setCurrentQuestion(quizQuestions[targetIndex]);
        }
    }


    const saveAnswerAndGoToNext = (selectedAnswer: string = "", isCompleted: boolean) => {

        if (!currentQuestion) return;

        const question = currentQuestion;
        // get actual answer
        
        // const actualAnswer = currentQuestion.optionChoices.split(optionSaperator)[0].trim();

        let actualAnswer:any = [];
            if(currentQuestion?.optionChoices){
                actualAnswer = currentQuestion.optionChoices.split(optionSaperator)[0].trim();

            }else{
                actualAnswer = [];

            }
            console.log('currentQuestion',currentQuestion,actualAnswer,selectedAnswer)

        // add the answer to list
        const newAnswer = {
            quizSetQuestionId: currentQuestion.quizSetQuestionId,
            question: { ...currentQuestion },
            isAnswerCorrect: actualAnswer === selectedAnswer,
            selectedAnswer,
            correctAnswer: actualAnswer,
        };
        let ans = [];
        if (QP) {
            ans = answers;
            ans[currentQuestionIndex] = newAnswer;

        } else {
            ans = [...answers, newAnswer]
        }
        setAnswers(ans);
        // switch to next question
        if (!isCompleted) {
            switchToNextQuestion(currentQuestion, actualAnswer === selectedAnswer);
        }

        saveUserResponse(ans, false, isCompleted)
    }
    const cancelTheExamSaveResponse = () => {
        saveUserResponse([...answers], cancelTestModalReason, false)
    }

    const submitExamAnyways = () => {
        setShowResults(true);
        setShowSubmitTestModal(false);
    }


    const goFullScreen = () => {
        if (quizSet && quizSet.isProctored) {
            try {
                const elem = document.getElementById("quiz-window") as any;
                if (elem) {
                    if (elem.requestFullscreen) {
                        elem.requestFullscreen()
                            .then(() => {
                                setIsFullScreen(true);
                            })
                            .catch((err: any) => {
                                // console.log(err);
                            });
                    } else if (elem.mozRequestFullScreen) { /* Firefox */
                        elem.mozRequestFullScreen()
                            .then(() => {
                                setIsFullScreen(true);
                            }).catch((err: any) => {
                                // console.log(err);
                            });
                    } else if (elem.webkitRequestFullscreen) { /* Chrome, Safari and Opera */
                        elem.webkitRequestFullscreen()
                            .then(() => {
                                setIsFullScreen(true);
                            }).catch((err: any) => {
                                // console.log(err);
                            });
                    } else if (elem.msRequestFullscreen) { /* IE/Edge */
                        elem.msRequestFullscreen()
                            .then(() => {
                                setIsFullScreen(true);
                            }).catch((err: any) => {
                                // console.log(err);
                            });
                    }
                }
            } catch (error) {
                // console.log({ error });
            }
        }
    }

    useEffect(() => {
        // go full screen
        if (quizSet && quizSet.isProctored) {
            goFullScreen();
        }

        const elem = document.getElementById("QuizAttempt") as any;


        // add listners for fullscreen exit
        const handleFullScreenExit = () => {
            if (!fullScreenInitiated) {
                setFullScreenInitiated(true);
            }
            if (!document.fullscreenElement && fullScreenInitiated) {
                setIsFullScreen(false);
            }
        }

        if (elem) {
            document.addEventListener('fullscreenchange', handleFullScreenExit, false);
            document.addEventListener('mozfullscreenchange', handleFullScreenExit, false);
            document.addEventListener('MSFullscreenChange', handleFullScreenExit, false);
            document.addEventListener('webkitfullscreenchange', handleFullScreenExit, false);
        }

        return () => {
            if (elem) {
                document.removeEventListener('fullscreenchange', handleFullScreenExit, false);
                document.removeEventListener('mozfullscreenchange', handleFullScreenExit, false);
                document.removeEventListener('MSFullscreenChange', handleFullScreenExit, false);
                document.removeEventListener('webkitfullscreenchange', handleFullScreenExit, false);
            }
        }
    }, [quizSet, fullScreenInitiated]);

    if (errorMessage) {
        return (
            <>
                <div className="" style={{ marginTop: '60px', marginBottom: '7%' }}></div>
                <div className="main text-center">
                    {errorMessage}
                </div>
            </>
        )
    }

    if (hideQuiz) {
        return (
            <div onMouseEnter={e => {
                if (quizSet && quizSet.isProctored && hideQuiz) {
                    setHideQuiz(false);
                }
            }} style={{
                height: '100vh',
                backgroundColor: '#f2f8ff',
            }}>
                <div className="" style={{ marginBottom: '7%' }}></div>
                <div className="main text-center">
                    Please be focused on the quiz.
                </div>
            </div>
        )
    }

    // check for direct access
    if (!quizSetId) {
        return <div className="text-center p-10">Invalid Request!</div>
    }

    return (
        <div onContextMenu={e => {
            // stop right click on isProctored
            if (quizSet && quizSet.isProctored) {
                e.preventDefault();
                // alert("Right click is disabled!");
            }
        }} onMouseLeave={e => {
            // stop right click on isProctored
            if (quizSet && quizSet.isProctored) {
                // setHideQuiz(true);
            }
        }}>

            {
                quizSet && !quizSet.isProctored ? <TopNavigationBar /> : <></>
            }

            <div className="main " id="QuizAttempt" style={{
                marginTop: quizSet && quizSet.isProctored ? '3rem' : '6rem',
            }} onClick={e => {
                e.preventDefault();
            }}>
                <div className='d-flex justify-content-between' style={{ marginLeft: 205 }}>
                    {showSubmitTestModal && <SubmitExamModal submitTheExam={() => {
                        submitExamAnyways();
                        setShowUpload(true)
                    }} continueExam={() => { setShowSubmitTestModal(false) }} />}
                    {!showResults && QP && allVisited &&
                        <button style={{ marginTop: '2rem' }} className="submit-button" onClick={() => {
                            setShowSubmitTestModal(true);
                        }}>Submit Exam</button>
                    }
                    {/* cancel button */}
                    {
                        !showResults && quizSet && quizSet.isProctored && answers.length !== questionCap ?
                            <button style={{ marginTop: '2rem', backgroundColor: 'red' }} className="submit-button" onClick={() => {
                                setShowCancelTestModal(true);
                                setcancelTestModalReason(1)
                            }}>Cancel Exam</button> : null
                    }
                    {/* show timer */}
                    {
                        !showResults && quizSet && quizSet.isProctored && quizSet.cohort && quizSet.cohort.allotted_time && quizSet.cohort.allotted_time > 0 ?
                            <>
                                <Timer
                                    key={quizAttemptLogId}
                                    timeAllotted={quizSet.time}
                                    submitExam={submitExamAnyways}
                                    saveTime={saveTime}
                                    savetimeInterval={savetimeInterval}
                                />
                                {QP && <QuestionPlate currentIndex={currentQuestionIndex} questionLength={quizQuestions.length > questionCap ? questionCap : quizQuestions.length} ans={answers} onClickHandler={onClickHandlerQuestionPlate} 
                                oldAns={OldAnswers}
                                 />}
                            </> :
                            <></>
                    }



                </div>
                {showUpload && !showResults && (
                    <div className="justify-content-center mt-5 pt-5">
                        <div className="row" style={{ justifyContent: 'center' }}>
                            <h5>Please wait while saving your response </h5>
                        </div>
                        <div className="row" style={{ justifyContent: 'center' }}>
                            <h5> {EstimateTime}</h5>
                        </div>
                        <div className="progress" style={{ width: '50%', margin: '0 auto' }}>
                        
                            <div className="progress-bar progress-bar-success" role="progressbar" style={{ width: `${percent}%`, backgroundColor: '#5cb85c' }} />
                        </div>
                        <div className="row">
                            <LottieLoader />
                        </div>
                    </div>
                )}
                {/* quiz app */}
                {loading || !isLoaded || !quizSet ? (
                    <div className="d-flex justify-content-center mt-5 pt-5">
                        <LottieLoader />
                    </div>
                ) : (
                    <div className="container QuizAttempt">
                        <div >
                            {/* <h5>{quizSet.quizTopic}</h5> */}
                            {
                                !showResults && !showUpload && currentQuestion && ((answers.length < questionCap) || QP) ? (
                                    <QuizView
                                        saveUserResponse={saveUserResponse}
                                        question={currentQuestion}
                                        index={answers.length + 1}
                                        total={quizQuestions.length > questionCap ? questionCap : quizQuestions.length}
                                        goFullScreen={goFullScreen}
                                        showCancelTestModal={showCancelTestModal || (quizSet && quizSet.isProctored && !isFullScreen)}
                                        setShowCancelTestModal={setShowCancelTestModal}
                                        cancelTheExamSaveResponse={cancelTheExamSaveResponse}
                                        saveAnswerAndGoToNext={saveAnswerAndGoToNext}
                                        currentQuestionIndex={currentQuestionIndex}
                                        QP={QP}
                                        answers={answers}
                                        setShowSubmitTestModal={setShowSubmitTestModal}
                                    />
                                ) : <></>
                            }
                            {
                                showResults ? (
                                    quizSet && quizSet.isProctored ? (
                                        <ShowExamResult
                                            token={user.token}
                                            answers={answers}
                                            attemptNumber={attemptNumber}
                                            quizSetId={quizSetId}
                                            showProfileQuestion={showProfileQuestion}
                                        />
                                    )
                                        : <ShowResults
                                            setShowSubmitTestModal={setShowSubmitTestModal}
                                            cancelTheExamSaveResponse={cancelTheExamSaveResponse}
                                            saveUserResponse={saveUserResponse}
                                            token={user.token}
                                            answers={answers}
                                            attemptNumber={attemptNumber}
                                            quizSetId={quizSetId}
                                            currentQuestionIndex={currentQuestionIndex}
                                            QP={QP}
                                        />
                                ) : <></>
                            }
                        </div>
                    </div>
                )}
            </div>
        </div>
    )
}

/**
 * Show Quiz View
 */
function QuizView({
    question,
    index,
    total,
    saveAnswerAndGoToNext,
    userSelectedAnswer,
    correctAnswer,
    setShowCancelTestModal,
    goFullScreen,
    showCancelTestModal,
    saveUserResponse,
    cancelTheExamSaveResponse,
    QP,
    currentQuestionIndex,
    answers,
    setShowSubmitTestModal
}: {
    question: QuizQuestionType,
    index: number, // will have the current non programming index ie number
    total: number, // will have count of total number of question
    saveAnswerAndGoToNext: Function,
    setShowCancelTestModal?: Function,
    goFullScreen?: Function,
    showCancelTestModal?: boolean,
    userSelectedAnswer?: string,
    correctAnswer?: string,
    saveUserResponse: Function,
    cancelTheExamSaveResponse: Function,
    QP: boolean,
    currentQuestionIndex: number,
    answers: AnswerType[],
    setShowSubmitTestModal: Function
}) {

    const [showSkipModal, setShowSkipModal] = useState(false);

    const [selectedAnswer, setSelectedAnswer] = useState<string>(userSelectedAnswer ? userSelectedAnswer : "");
    const questionId = QP ? currentQuestionIndex + 1 : index
    useEffect(() => {
        if (QP && answers && answers[currentQuestionIndex]) {
            const oldAns = answers[currentQuestionIndex]
            if (oldAns) {
                setSelectedAnswer(oldAns.selectedAnswer)
            }
        }

    }, [currentQuestionIndex])

   const  handleChange = (e:any) =>{
       console.log('handleChange',e.target.value)
        setSelectedAnswer(e.target.value)
    }

    return (
        <div className="QuizView">
            {
                !userSelectedAnswer ? (
                    <div className="question-index">
                       Question {questionId} of {total}
                        {/* <div className={"difficulty-level level-" + question.difficultyLevel}>{getDifficultyText(question.difficultyLevel)}</div> */}
                    </div>
                ) : <></>
            }
            {/* question text */}
            <div className="question-text">
                Q{questionId}. <RTEditor data={question.questionText} />
            </div>
            {/* options */}
            {/* {console.log('question--',question,selectedAnswer)} */}
            {question.questionType ===3  ? (
                <textarea
                onChange={handleChange}
                className="form-control"
                name="writtenTest"
                id="exampleFormControlTextarea1"
                value={selectedAnswer}
                />
            ) :(
                <OptionChoices
                enabled={userSelectedAnswer ? false : true}
                options={question.options}
                selectedAnswer={selectedAnswer}
                setSelectedAnswer={userSelectedAnswer ? (e: any) => { } : setSelectedAnswer} />
            )}

            {/* next button */}
            {
                correctAnswer ? (
                    <>
                        {
                            userSelectedAnswer === correctAnswer ? (
                                <div className="answer-holder correct">
                                    <div className="answer-result">Correct</div>
                                </div>
                            ) : (
                                !userSelectedAnswer ? (
                                    <div className="answer-holder incorrect">
                                        <div className="answer-result">Skipped Question</div>
                                        <div className="answer-hint">The correct answer is <b>{correctAnswer}</b></div>
                                    </div>
                                ) : (
                                    <div className="answer-holder incorrect">
                                        <div className="answer-result">Incorrect Answer</div>
                                        <div className="answer-hint">The correct answer is <b>{correctAnswer}</b></div>
                                    </div>
                                )
                            )
                        }
                    </>
                ) : (
                    <div style={{ display: "flex", justifyContent: "center", alignItems: "center" }}>
                        {/* skip button */}
                        <div className="skip-button" onClick={e => {
                            setShowSkipModal(true);
                        }}>Skip</div>
                        {
                            index === total && !QP ? (
                                <button className="next-button" onClick={e => {
                                    if (!selectedAnswer) return alert("Please select an answer");
                                    // save answer
                                    saveAnswerAndGoToNext(selectedAnswer, true);
                                    // clear selection
                                    setSelectedAnswer("");
                                }}>Finish</button>
                            ) : (
                                <>
                                    {QP && questionId === total ? (
                                        <button className="next-button" onClick={e => {
                                            if (!selectedAnswer) return alert("Please select an answer");
                                            // save answer
                                            saveAnswerAndGoToNext(selectedAnswer, true);
                                            setShowSubmitTestModal(true)
                                        }}>Submit</button>
                                    ) : (
                                        <button className="next-button" onClick={e => {
                                            if (!selectedAnswer) return alert("Please select an answer");
                                            // save answer
                                            saveAnswerAndGoToNext(selectedAnswer, false);

                                            // clear selection
                                            setSelectedAnswer("");
                                        }}>Next</button>
                                    )}

                                </>
                            )
                        }
                    </div>
                )
            }
            <SkipModal
                isActive={showSkipModal}
                setIsActive={setShowSkipModal}
                showNextQuestion={(e: any) => {
                    saveAnswerAndGoToNext("", false, false);
                }} />
            {/* show cancel modal */}
            <CancelTestModal
                isActive={showCancelTestModal ? showCancelTestModal : false}
                setIsActive={setShowCancelTestModal ? setShowCancelTestModal : () => { }}
                cancelTheExam={cancelTheExamSaveResponse}
                continueExam={(e: any) => {
                    if (goFullScreen) {
                        // go fullscreen
                        goFullScreen();
                    }
                }} />

        </div>
    )
}

/**
 * Show option choices
 * @param param0 
 * @returns 
 */
function OptionChoices({ enabled, options, selectedAnswer, setSelectedAnswer }: {
    options: Array<string>,
    enabled: boolean,
    selectedAnswer: string | undefined,
    setSelectedAnswer: Function
}) {
    return (
        <div className={"options-holder " + (
            enabled ? " enabled" : ""
        )}>
            {
                options.map((option: string) => {
                    return <div key={option} className={"option " + (
                        selectedAnswer === option ? "selected" : ""
                    )} onClick={e => {
                        setSelectedAnswer(option);
                    }} style={{ backgroundColor: selectedAnswer === option ? 'rgba(106, 146, 212, 0.5)' : '' }}><span>{option.toString().replaceAll(';', ',')}</span></div>
                })
            }
        </div>
    )
}

function ShowExamResult({ token, answers, attemptNumber, quizSetId, showProfileQuestion }:
    { token: string, answers: Array<AnswerType>, attemptNumber: number | undefined, quizSetId: number, showProfileQuestion: boolean }) {

    useEffect(() => {
        if (attemptNumber) {
            // save the attempt
            main.saveAttemptForQuizSet(token, quizSetId, attemptNumber, answers, null, 1, null)
                .then(({ attempt }: { attempt: any }) => {
                    console.log("Attempt saved");
                })
                .catch(err => {
                    alert("Failed to save attempt");
                });
        }

    }, [attemptNumber]);


    return (
        <div style={{
            height: '100vh',
            backgroundColor: '#f2f8ff',
        }}>
            <div className="" style={{ marginBottom: '7%' }}></div>
            <div className="main text-center">
                <h5>Your responses have been recorded and the assessment is complete.</h5>
                {/* <h5 style={{ padding: 5, backgroundColor: 'blue', borderRadius: 10, width: '50%', margin: '10px auto', color: 'white' }}>Please answer the following Profile questions to complete your application</h5>
                 */}
                <Button variant="success" size="lg" onClick={() => {
                    const url = `${window.location.origin}${!!showProfileQuestion ? PROCTORED_QUESTIONNAIRE_ROUTE : '/quiz-sets'}`;

                    window.location.href = url;
                    // history.push(PROCTORED_QUESTIONNAIRE_ROUTE);
                }}>Continue</Button>
            </div>
        </div>
    )
}

function ShowResults(
    { token, answers, attemptNumber, quizSetId, saveUserResponse, cancelTheExamSaveResponse, currentQuestionIndex, QP, setShowSubmitTestModal }
        : {
            token: string, answers: Array<AnswerType>, attemptNumber: number | undefined,
            quizSetId: number, saveUserResponse: Function, cancelTheExamSaveResponse: Function,
            currentQuestionIndex: number,
            QP: boolean,
            setShowSubmitTestModal: Function
        }) {

    useEffect(() => {
        if (attemptNumber) {
            // save the attempt
            main.saveAttemptForQuizSet(token, quizSetId, attemptNumber, answers, null, 1, null)
                .then(({ attempt }: { attempt: any }) => {
                    console.log("Attempt saved");
                })
                .catch(err => {
                    alert("Failed to save attempt");
                });
        }
    }, [attemptNumber]);

    const total = parseFloat(((answers.reduce((acc, v) => {
        return (v.isAnswerCorrect) ? acc + 1 : acc;
    }, 0) / answers.length) * 100).toFixed(2));

    return (
        <div className="answers">
            <div className="answer-total">SCORE: {total}%</div>
            {
                answers.map((answer, index: number) => (
                    <div key={index}>
                        <QuizView
                            saveUserResponse={saveUserResponse}
                            question={answer.question}
                            index={index + 1}
                            total={answers.length}
                            saveAnswerAndGoToNext={(e: any) => { }}
                            userSelectedAnswer={answer.selectedAnswer}
                            cancelTheExamSaveResponse={cancelTheExamSaveResponse}
                            correctAnswer={answer.correctAnswer}
                            currentQuestionIndex={currentQuestionIndex}
                            QP={QP}
                            answers={answers}
                            setShowSubmitTestModal={setShowSubmitTestModal}
                        />
                    </div>
                ))
            }
        </div>
    )
}

function CancelTestModal({
    isActive = false,
    setIsActive = (e: any) => { },
    cancelTheExam,
    continueExam
}: {
    isActive: boolean,
    setIsActive: Function,
    cancelTheExam: Function,
    continueExam: Function,
}) {

    // have the timer here
    const [countDown, setCountDown] = useState(60);

    // make a countdown timer
    useEffect(() => {
        if (isActive) {
            const timer = setInterval(() => {
                if (countDown > 0) {
                    setCountDown(countDown - 1);
                } else {
                    // send to quiz sets page
                    cancelTheExam();
                }
            }, 1000);
            return () => {
                clearInterval(timer);
            }
        }
    }, [isActive, countDown]);

    if (!isActive) return <></>;

    return (
        <div className="SkipModal">
            <div className="modal-body">
                <h5 className="text-center">Clicking on cancel or exiting full screen will cancel the exam.</h5>
                <div className="d-flex justify-center">
                    <button className="cancel-exam-button" onClick={() => {
                        setIsActive(false);
                        cancelTheExam();
                    }}>Yes, Cancel the Exam</button>
                    <button className="continue-exam-button" onClick={() => {
                        continueExam();
                        setIsActive(false);
                    }}>No, Continue Exam</button>
                </div>
            </div>
        </div>
    )
}

function SkipModal({ isActive = false, setIsActive = (e: any) => { }, showNextQuestion }: { isActive: boolean, setIsActive: Function, showNextQuestion: Function }) {

    if (!isActive) return <></>;

    return (
        <div className="SkipModal">
            <div className="modal-body">
                <h5>Are you sure you want to skip this question?</h5>
                <div className="d-flex justify-center">
                    <button className="skip-button" onClick={() => {
                        setIsActive(false);
                        showNextQuestion();
                    }}>Yes</button>
                    <button className="next-button" onClick={() => setIsActive(false)}>No</button>
                </div>
            </div>
        </div>
    )
}

function Timer({
    timeAllotted,
    submitExam,
    saveTime,
    savetimeInterval
}: {
    timeAllotted: number,
    submitExam: Function
    saveTime: Function,
    savetimeInterval: number
}) {
    const [timeLeft, setTimeLeft] = useState(timeAllotted ? timeAllotted * 60 : 0);
    const [savetimeIntervalLeft, setsavetimeIntervalLeft] = useState(timeAllotted ? timeAllotted * 60 : 0);
    // decrease only if time allotted is not 0
    useEffect(() => {

        // if time left is 0 then submit the exam
        if (timeLeft === 0) {
            return submitExam();
        }

        if (timeAllotted) {
            const interval = setInterval(() => {
                setTimeLeft(timeLeft - 1);


            }, 1000);


            return () => {
                clearInterval(interval);
            }
        }
    }, [timeLeft, timeAllotted]);

    useEffect(() => {

        const interval2 = setInterval(() => {
            setsavetimeIntervalLeft(prevTime => prevTime - savetimeInterval / 1000)

            saveTime(savetimeIntervalLeft)

        }, savetimeInterval);
        return () => {
            clearInterval(interval2);
        }
    }, [savetimeIntervalLeft])

    if (!timeAllotted) {
        return <></>;
    }

    return (
        <div className="QuizTimer">
            <div className="timer" style={{ color: timeLeft > 180 ? 'green' : 'red' }}>{getTimeString(timeLeft)}</div>
        </div>
    )
}

// create time string from seconds
function getTimeString(time: number) {
    const minutes = Math.floor(time / 60);
    const seconds = time % 60;

    return `${minutes < 10 ? "0" + minutes : minutes}:${seconds < 10 ? "0" + seconds : seconds}`;
}


export default AIHOC(QuizAttemptPageComponent)
