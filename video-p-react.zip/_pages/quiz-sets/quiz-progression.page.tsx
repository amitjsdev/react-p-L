import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { State } from '../../store/reducers'
import { Spinner, TopNavigationBar } from '../../_components'
import { history } from '../../_config'
import "./quiz-set.scss"
import { withdrawMoney, despositMoney, changeModuleNumber, setUserToken } from "../../store/action-creator"
import { MainService } from '../../_services/main.service'
import getFormatedDate from '../../_config/getFormatedDate'
// import Button from '../../_components/button.component'
import { LottieLoader } from '../../_components/lottie-loader.component'
import Joyride from 'react-joyride';
import { Button } from 'react-bootstrap'
import { createQuizAttemptRoute } from './quiz-attempt.page'
import { Link, useParams } from 'react-router-dom'
import { QUIZ_SET_ROUTE } from './quiz-set.page'
import { Checkbox } from '@material-ui/core'

export const QUIZ_PROGRESSION_ROUTE = "/quiz-set/:quizSetId/progressions";

export const createQuizProgressionRoute = (quizSetId: number) => `/quiz-set/${quizSetId}/progressions`;

const main = new MainService()

type P = {
    user: any;
}


type QuizSetType = {
    id: number;
    quizSetId: number;
    companyCode: number;
    quizTopic: string;
    quizSubTopic: string;
    quizSubject: string;
    questionCount: number;
    created_at?: any;
    updated_at?: any;
}

type AnswerJSON = {
    quizSetId: number;
    selectedAnswer: number;
    isAnswerCorrect: boolean;
    quizSetQuestionId: number;
}

type QuizAttemptType = {
    id: number;
    userId: string;
    quizSetId: number;
    attemptNumber?: any;
    attemptStatus: number;
    answerJSON: AnswerJSON[];
    scorePercentage: number;
    difficultPercentage: number;
    difficultCount: number;
    mediumPercentage: number;
    mediumCount: number;
    easyPercentage: number;
    easyCount: number;
    created_at: Date;
    updated_at: Date;
}

const QuizSetProgressionPage = ({ user }: P) => {
    const [quizProgressions, setQuizProgressions] = useState<Array<QuizAttemptType>>([]);
    const [quizSet, setQuizSet] = useState<QuizSetType>();
    const [loading, setLoading] = useState(false);

    const [filterPending, setFilterPending] = useState(true);

    const { quizSetId } = useParams() as { quizSetId: string };

    // load the practice sets
    useEffect(() => {
        // get quizset assigned to me
        setLoading(true);
        main.quizSetsAssignedToMeProgression(user.token, parseInt(quizSetId))
            .then(({ attempts, quizSet }: { attempts: Array<QuizAttemptType>, quizSet: QuizSetType }) => {
                // save the set
                setQuizSet(quizSet);

                setQuizProgressions(attempts);
                setLoading(false);
            })
            .catch(error => {
                alert("Something went wrong!");
                setLoading(false);
            })
    }, []);

    const attempts = filterPending ? quizProgressions.filter(attempt => attempt.attemptStatus === 1) : quizProgressions;

    return (
        <>
            <TopNavigationBar />
            <div className="" style={{ marginTop: '60px', marginBottom: '7%' }}></div>
            <div className="main ">
                {loading ? (
                    <div className="d-flex justify-content-center mt-5 pt-5">
                        <LottieLoader />
                    </div>
                ) : (
                    <div className="container">
                        <div style={{ marginBottom: "2rem" }}>
                            <div><Link to={QUIZ_SET_ROUTE}>Back</Link></div>
                            {
                                quizSet ? (
                                    <div style={{ display: "flex", alignItems: "center" }}>
                                        <h5 style={{ marginBottom: "0" }}>{quizSet.quizTopic}</h5>
                                        <div style={{ display: "flex", alignItems: "center", cursor: "pointer" }} onClick={e => {
                                            setFilterPending(!filterPending);
                                        }}>
                                            <Checkbox checked={filterPending} /> <span style={{ marginLeft: "5px" }}>Hide pending attempts</span>
                                        </div>
                                    </div>
                                ) : <></>
                            }
                        </div>
                        {attempts ? (
                            attempts.length > 0 ? attempts.map((set) => {
                                const { created_at, id, quizSetId, attemptNumber, mediumPercentage, mediumCount, easyPercentage, easyCount, scorePercentage, difficultPercentage, difficultCount, attemptStatus } = set;
                                return (
                                    <div key={id} className="card mb-5" style={{ cursor: 'pointer', backgroundColor: attemptStatus ? "white" : "#FDD" }} onClick={() => { }}>
                                        <div className="card-body">
                                            <table className="table table-borderless" style={{ fontWeight: 600 }}>
                                                <thead>
                                                    <tr>
                                                        <th scope="col">Attempt Number</th>
                                                        {
                                                            attemptStatus ? (
                                                                <>
                                                                    <th scope="col">Score</th>
                                                                    <th scope="col">Easy Questions</th>
                                                                    <th scope="col">Medium Questions</th>
                                                                    <th scope="col">Difficult Questions</th>
                                                                </>
                                                            ) : (
                                                                <>
                                                                    <th scope="col"></th>
                                                                    <th scope="col"></th>
                                                                    <th scope="col"></th>
                                                                    <th scope="col">Status</th>
                                                                </>
                                                            )
                                                        }
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td className="" style={{ paddingTop: '32px' }}>{attemptNumber}</td>
                                                        {
                                                            attemptStatus ? (
                                                                <>
                                                                    <td className="w-25" style={{ paddingTop: '32px' }}>{scorePercentage}%</td>
                                                                    <td className="w-25" style={{ paddingTop: '32px' }}>{easyCount}</td>
                                                                    <td className="w-25" style={{ paddingTop: '32px' }}>{mediumCount}</td>
                                                                    <td className="w-25" style={{ paddingTop: '32px' }}>{difficultCount}</td>
                                                                </>
                                                            ) : (
                                                                <>
                                                                    <td className="w-25" style={{ paddingTop: '32px' }}>&nbsp;</td>
                                                                    <td className="w-25" style={{ paddingTop: '32px' }}>&nbsp;</td>
                                                                    <td className="w-25" style={{ paddingTop: '32px' }}>&nbsp;</td>
                                                                    <td className="w-25" style={{ paddingTop: '32px' }}>Incomplete Attempt</td>
                                                                </>
                                                            )
                                                        }
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                )
                            }) : <div className="text-center">No quiz set attempts to show!</div>
                        ) : null}
                    </div>
                )}
            </div>
        </>
    )
}

export default QuizSetProgressionPage;
