import React, { useEffect, useState } from 'react'
import { connect, useDispatch, useSelector } from 'react-redux'
import { State } from '../../store/reducers'
import { Spinner, TopNavigationBar } from '../../_components'
import { history } from '../../_config'
import "./quiz-set.scss"
import { withdrawMoney, despositMoney, changeModuleNumber, setUserToken, setQuizSetId } from "../../store/action-creator"
import { MainService } from '../../_services/main.service'
import getFormatedDate from '../../_config/getFormatedDate'
// import Button from '../../_components/button.component'
import { LottieLoader } from '../../_components/lottie-loader.component'
import Joyride from 'react-joyride';
import { Button } from 'react-bootstrap'
import { createQuizAttemptRoute } from './quiz-attempt.page'
import { Link } from 'react-router-dom'
import { createQuizProgressionRoute } from './quiz-progression.page'
import VideoRecorder from '../../_components/video-recorder.component'
import { PROCTORED_QUESTIONNAIRE_ROUTE } from './proctored-questionnaire.page'
import { withWidth } from '@material-ui/core'
import moment from 'moment';
import AIHOC from './AIHOC'
import AddPAN from './AddPAN'
import DoAndDont from './DoAndDont'
import TimerForTimeLeft from './TimerForTimeLeft'
export const QUIZ_SET_ROUTE = "/quiz-sets"

const main = new MainService()

type P = {
    user: any;
    store?: any;
    callbackHoc?: any;
    aiReady: boolean;
    allotted_time: number;
    startTest:Function;
    callbackTimerForTimeLeft:Function;
    cameraError: boolean;
}

type QuizSetType = {
    id: number;
    time:any;
    quizSetId: number;
    companyCode: number;
    quizTopic: string;
    isProctored: boolean;
    quizCompleted: boolean;
    profileCompleted: boolean;
    quizNeedsRetest: boolean;
    quizSubTopic: string;
    quizSubject: string;
    questionCount: number;
    hasProgression: boolean;
    created_at?: any;
    updated_at?: any;
    cohort: any;
    allowedReattempt:number;
    allowedReattemptStatus:string;
}

const QuizSetPageComponent = ({ user, callbackHoc, aiReady,startTest,callbackTimerForTimeLeft,cameraError, store, ...rest }: P) => {


    const [quizSets, setQuizSets] = useState<Array<QuizSetType>>([]);
    const [loading, setLoading] = useState(false);

    const [selectedTest, setSelectedTest] = useState<number>();
    const [allotted_time, setAllotted_time] = useState(0)
    const [helpDeskEmail, setHelpDeskEmail] = useState('')
    const [PAN, setPAN] = useState('');
    const [allowedReattemptVisible, setAllowedReattemptModal] = useState(false);
    const [reattemptVisible, setReattemptModal] = useState(0);
    const [reattemptId, setReattemptId] = useState<number>();
    const [allowedReattemptVisibleMsg, setAllowedReattemptModalMSG] = useState('');

   
    const setAllowedReattempt =(st:boolean, msg:string) =>{
        setAllowedReattemptModal(st)
        setAllowedReattemptModalMSG(msg)
    }
    const retakeExamConfirm =(quizSetId:any) =>{
        setReattemptModal(0)
        if (PAN) {
            setSelectedTest(reattemptId);
            // add quizSetId to 
            if (store && (store as any).dispatch) {
                (store as any).dispatch(setQuizSetId(quizSetId));
            }
        } else {
            history.push('/add-pan')
        }
    }
    const retakeExam =(quizSetId:any,id:number) =>{
        console.log({quizSetId,id});
        
        setReattemptModal(quizSetId)
        setReattemptId(quizSetId)
    }

    // load the practice sets
    useEffect(() => {
        // get quizset assigned to me
        setLoading(true);
        main.getQuizSetsAssignedToMe(user.token)
            .then(({ quizSets, pan }: { quizSets: Array<QuizSetType>, pan: any }) => {
                setQuizSets(quizSets);
                setLoading(false);
                setPAN(pan);
            })
            .catch(error => {
                alert("Something went wrong!");
                setLoading(false);
            })
    }, []);
    useEffect(() => {
        if (selectedTest && quizSets && quizSets.length > 0) {
            const q = quizSets.find(item => item.quizSetId == selectedTest)
            if (q && q.cohort) {
                setAllotted_time(q.time)
                setHelpDeskEmail(q.cohort.instructorEmails)
            }
        }
    }, [selectedTest]);

    return selectedTest ? (
        <ShowInstructions
            selectedTest={selectedTest}
            setSelectedTest={setSelectedTest}
            user={user}
            callbackHoc={callbackHoc}
            aiReady={aiReady}
            allotted_time={allotted_time}
            helpDeskEmail={helpDeskEmail}
            PAN={PAN}
            rest={rest}
            startTest={startTest}
            cameraError={cameraError}
        />
    ) : (
        <>
            <TopNavigationBar />
            {allowedReattemptVisible && (
                <div className="SkipModal">
                <div className="modal-body">
                    <h5 className="text-center" style={{padding:20}}> Contact {allowedReattemptVisibleMsg} for Reattempting the exam.</h5>
                    <div className="d-flex justify-center">
                    <button className="continue-exam-button" onClick={() => {
                       setAllowedReattemptModal(false);
                       setAllowedReattemptModalMSG('');
                    }}>Close</button>
                   
                    </div>
                </div>
                </div>
            )}
            {!!reattemptVisible && (
                <div className="SkipModal">
                <div className="modal-body">
                    <h5 className="text-center" style={{padding:20}}>Do you want to Reattempt Exam</h5>
                    <div className="d-flex justify-center">
                    <button className="cancel-exam-button" onClick={() => {
                         setReattemptModal(0)
                    }}>No, Cancel the Exam</button>
                    <button className="continue-exam-button" onClick={() => {
                        retakeExamConfirm(reattemptVisible)
                    }}>Yes, Continue Exam</button>
                </div>
                </div>
                </div>
            )}
            <div className="" style={{ marginTop: '60px', marginBottom: '7%' }}></div>
            <div className="main ">
                {loading ? (
                    <div className="d-flex justify-content-center mt-5 pt-5">
                        <LottieLoader />
                    </div>
                ) : (
                    <div className="container">
                        <div style={{ marginBottom: "2rem" }}>
                            <h5>Quizzes Available</h5>
                        </div>
                        {quizSets ? (
                            quizSets.length > 0 ? quizSets.map((set) => {
                                const { cohort, created_at, id, quizSetId, quizTopic, questionCount, quizCompleted, profileCompleted, allowedReattempt,allowedReattemptStatus, isProctored, hasProgression } = set;
                                return (
                                    <div key={id} className="card mb-5" style={{ cursor: 'pointer' }} onClick={() => { }}>
                                        <div className="card-body">
                                            <table className={"table table-borderless " + (
                                                isProctored ? "proctored" : ""
                                            )}>
                                                <thead>
                                                    <tr>
                                                        <th scope="col">{isProctored ? "Assessment" : "Topic"}</th>
                                                        <th scope="col">&nbsp;</th>
                                                        {/* <th scope="col">Questions</th> */}
                                                        <th scope="col"></th>
                                                        {
                                                            hasProgression ? <th scope="col"></th> : <></>
                                                        }
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td width="615px" className="" style={{ paddingTop: '32px' }}>{quizTopic}</td>
                                                        <td className="" style={{ paddingTop: '32px' }}>&nbsp;</td>
                                                        {/* <td className="w-25" style={{ paddingTop: '32px' }}>{questionCount}</td> */}
                                                        {
                                                            moment() < moment(cohort.exam_start_time) ? <>
                                                            Exam will start at {moment(cohort.exam_start_time).format('DD/MM/YYYY hh:mm:ssA')}
                                                            <TimerForTimeLeft 
                                                                        callback={callbackTimerForTimeLeft} 
                                                                        startTime={cohort.exam_start_time}
                                                                        endTime={cohort.exam_end_time}
                                                                         />
                                                            </> :
                                                                !moment().isBetween(cohort.exam_start_time, cohort.exam_end_time) ?

                                                                    <td>Test not available at this time 
                                                                       
                                                                    </td> :
                                                                    <td width="400px" colSpan={hasProgression && !isProctored ? 1 : 2}>
                                                                   
                                                                        {
                                                                            isProctored ? (
                                                                                <>
                                                                                    {
                                                                                        !hasProgression ? (
                                                                                            <Button variant="success" size="lg" onClick={() => {
                                                                                                setSelectedTest(quizSetId);
                                                                                                // add quizSetId to 
                                                                                                if (store && (store as any).dispatch) {
                                                                                                    (store as any).dispatch(setQuizSetId(quizSetId));
                                                                                                }

                                                                                            }}>Take The Exam</Button>
                                                                                        ) : (
                                                                                            quizCompleted && !allowedReattempt ? (
                                                                                                <h5 style={{ paddingTop: "32px" }}>Test Successfully Submitted</h5>
                                                                                            ) : (
                                                                                                allowedReattempt > 0 ? (
                                                                                                    <Button variant="success" size="lg" onClick={() => {
                                                                                                       retakeExam(quizSetId,id)

                                                                                                    }}>{allowedReattemptStatus}</Button>
                                                                                                ) : (
                                                                                                    <Button variant="success" size="lg" onClick={() => { 
                                                                                                        // setSelectedTest(quizSetId);
                                                                                                        // // add quizSetId to 
                                                                                                        // if (store && (store as any).dispatch) {
                                                                                                        //     (store as any).dispatch(setQuizSetId(quizSetId));
                                                                                                        // }
        
                                                                                                        setAllowedReattempt (true, cohort.instructorEmails)
                                                                                                    }}>Incomplete</Button>
                                                                                                )
                                                                                            )
                                                                                        )
                                                                                    }
                                                                                    {/* profile */}
                                                                                    {
                                                                                        quizCompleted && !!cohort.profile_questionnaire ? (
                                                                                            profileCompleted ? (
                                                                                                <h5>Profile Successfully Completed</h5>
                                                                                            ) : (
                                                                                                <Button style={{marginTop:5}} variant="success" size="lg" onClick={(e) => {
                                                                                                    // send to proctored questionnaire route
                                                                                                    e.preventDefault();
                                                                                                    window.location.href =window.location.origin+PROCTORED_QUESTIONNAIRE_ROUTE
                                                                                                    // history.push(PROCTORED_QUESTIONNAIRE_ROUTE);
                                                                                                   
                                                                                                }}>Complete Profile</Button>
                                                                                            )
                                                                                        ) : <></>
                                                                                    }
                                                                                </>
                                                                            ) : (
                                                                                <Button variant="success" size="lg" onClick={() => {

                                                                                    // add quizSetId to 
                                                                                    setSelectedTest(quizSetId)
                                                                                    if (store && (store as any).dispatch) {
                                                                                        (store as any).dispatch(setQuizSetId(quizSetId));
                                                                                    }


                                                                                    // history.push(createQuizAttemptRoute(quizSetId));
                                                                                }}>Take Test</Button>
                                                                            )
                                                                        }
                                                                    </td>
                                                        }
                                                    </tr>
                                                    {
                                                        hasProgression && !isProctored && cohort.type_id != 2 ? (
                                                            <td style={{ verticalAlign: "middle" }} width="100px">
                                                                <Link to={createQuizProgressionRoute(quizSetId)}>See Progression</Link>
                                                            </td>
                                                        ) : <tr>

                                                            <td>
                                                                {isProctored && (
                                                                    <div style={{ fontSize: "20px", fontWeight: "bold", paddingTop: "17px" }}>This is a proctored exam. You can take it only once </div>
                                                                )}</td>
                                                            <td></td>
                                                            <td>
                                                                <div>This test is only available from</div>
                                                                <div style={{ fontSize: "15px", fontWeight: "bold" }}>  {moment(cohort.exam_start_time).format('DD-MMM-yy hh:mm A')} <span> and the duration of the test is </span>
                                                                {cohort.allotted_time} minutes.
                                                                 {/* {moment(cohort.allotted_time).format('DD-MMM-yy:hh mm A')} */}
                                                                 
                                                                 </div>
                                                            </td>

                                                        </tr>
                                                    }

                                                </tbody>
                                            </table>

                                        </div>
                                    </div>
                                )
                            }) : <div className="text-center">No quiz set available for you!</div>
                        ) : null}
                    </div>
                )}
            </div>
        </>
    )
}

function ShowInstructions({
    selectedTest,
    setSelectedTest,
    callbackHoc,
    aiReady,
    allotted_time,
    helpDeskEmail,
    user,
    PAN,
    rest,
    startTest,
    cameraError
}: {
    selectedTest: number,
    setSelectedTest: any,
    user: any
    callbackHoc: any,
    aiReady: boolean,
    allotted_time: number,
    helpDeskEmail: string,
    PAN: string,
    rest:any,
    startTest:Function,
    cameraError:any
}) {



    const [step, setStep] = useState(1);

    if (!selectedTest) {
        return <></>;
    }

    if (step === 1) {
        return <InstructionsStep1 setStep={setStep} selectedTest={selectedTest} allotted_time={allotted_time} helpDeskEmail={helpDeskEmail} PAN={PAN} />
    }

    if (step === 2) {
        return <AddPAN user={user} setStep={setStep} />
    }
    if (step === 3) {
        return <DoAndDont setStep={setStep} />
    }
    if (step === 4) {
        return <InstructionsStep4 cameraError={cameraError} rest={rest} user={user} aiReady={aiReady} setStep={setStep} selectedTest={selectedTest} callbackHoc={callbackHoc} />
    }
    if (step === 5) {
        return <InstructionsStep5 time={allotted_time} selectedTest={selectedTest} startTest={startTest}/>
    }

    return <></>;
}

function InstructionsStep1({
    setStep,
    helpDeskEmail,
    allotted_time,
    selectedTest,
    PAN
}: {
    setStep: Function,
    selectedTest: number,
    allotted_time: number,
    helpDeskEmail: string,
    PAN: string
}) {
    return (
        <>
            <div className="TopNavigationBarHome"></div>
            <div style={{ padding: "5rem 2rem" }} className="instruction-screen">
                <div style={{ textAlign: "center" }}>
                    <h5>Proctored Multiple Choice Assessment</h5>
                    <br />
                    {/* <p>Time Allotted per question is 45 seconds</p> */}
                    <p>Total time Allotted {allotted_time} Minutes</p>
                    <h5>Instructions for Proctored Exam</h5>
                </div>
                <div style={{ padding: "2rem", maxWidth: "720px", margin: "auto" }} className="instruction-set">
                    <p>
                        <span className="instruction-heading">
                            <b>1.</b>
                            <span>You can only take the exam once.</span>
                        </span> <br />
                        {/* <span className="instruction-body">If you want to practice the exam, please use this link <a href="/">Practice Set Exam</a></span> */}
                    </p>
                    <p>
                        <span className="instruction-heading">
                            <b>2.</b>
                            <span>The exam will be conducted in full-screen mode.</span>
                        </span> <br />
                        <span className="instruction-body">This will enable the virtual proctor to asses your performance accurately</span>
                    </p>
                    <p>
                       
                        <span className="instruction-body">Please contact <a href={`mailto:${helpDeskEmail}`}>{helpDeskEmail}</a> to retest due to system failure.</span>
                    </p>
                </div>
                <div className="text-center">
                    <Button variant="success" size="lg" onClick={() => {

                        setStep(PAN ? 3 : 2);
                    }}>Continue</Button>
                </div>
            </div>
        </>
    )
}


function InstructionsStep4({
    setStep,
    selectedTest,
    callbackHoc,
    aiReady,
    user,
    rest,
    cameraError
}: {
    callbackHoc: Function,
    setStep: Function,
    selectedTest: number,
    aiReady: boolean,
    user:any,
    rest:any,
    cameraError:any
}) {

    const {cameraEnabledAgree,cameraActive, isAlignConfirmed,setAlginConfirm,setCameraActive,setCameraEnabledAgree}=rest;
    useEffect(() => {
        if (cameraEnabledAgree) {
            setTimeout(() => {
                callbackHoc('init')
            }, 100)
        }

    }, [cameraEnabledAgree])

    return (
        <>

            <div className="instruction-screen" style={{ textAlign: 'center' }}>
                {rest.cameraEnabledAgree ? (
                    <>
                        {cameraActive && !cameraError ? (
                            <>
                                <div className="row">
                                    <div className="col-md-12" style={{
                                        paddingTop: "10px",
                                        textAlign: 'center'
                                    }}>
                                    </div>
                                </div>

                                <div className="row">
                                    <div className="col-md-12">
                                        <label>
                                            <h3> Camera Alignment Check</h3>
                                        </label>

                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-md-12">
                                        <h6>In this step, you will align your face with the camera to ensure accuracy of AI tool</h6>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-md-12">
                                        <div className="camera-placeholder" style={{
                                            width: '670px',
                                            margin: '0px auto',
                                            padding: '10px',
                                            textAlign: 'center',
                                            height: '507px',
                                            border: '5px solid #713CFB'
                                        }}>
                                            {!aiReady && <LottieLoader />}
                                            <div id="square" style={{ display: aiReady ? 'block' : 'none' }}></div>

                                        </div>
                                    </div>
                                </div>
                                <div className="row">
                                    <div style={{
                                        display: 'inline-flex',
                                        justifyContent: 'center',
                                        width: '100%'
                                    }}>
                                        <input
                                            type="checkbox"
                                            style={{
                                                height: '30px',
                                                width: '30px',
                                                margin: '10px',

                                            }}
                                            checked={isAlignConfirmed}
                                            onChange={e => {
                                                setAlginConfirm(!isAlignConfirmed);
                                            }} />

                                        <h4 style={{ marginTop: 7 }}>
                                            My face is aligned with the white outline in the camera
                                        </h4>


                                    </div>
                                </div>
                                <div className="row">

                                    <div className="col-md-12">
                                        <Button
                                            disabled={!isAlignConfirmed || !aiReady}
                                            variant="success" size="lg" onClick={() => {
                                                callbackHoc('mini')
                                                setStep(5)
                                            }}>
                                            Continue</Button>

                                    </div >
                                </div >


                            </>
                        ) : (
                            <div className="col-md-12">
                                We need access to your camera for the test to proceed but were not able to get it. Please reload the screen and enable. camera access.
                            </div>
                        )}


                        
                    </>
                ) :
                    (
                        <div className="row" style={{ textAlign: 'center' }}>
                            <div className="col-md-12" style={{
                                paddingTop: "10%",
                                paddingLeft: "2rem",
                                textAlign: 'center'
                            }}>
                                <label>
                                    <h3>  The AI proctored test requires access to your camera and microphone at all times </h3>
                                </label>

                            </div>
                            <div className="col-md-12">

                                <div className="text-center" style={{ paddingTop: '100px' }}>
                                    {
                                        !cameraActive ? (
                                            <Button variant="success" size="lg" onClick={() => {
                                                setCameraActive(true);
                                                setCameraEnabledAgree(true)
                                            }}>Enable camera and Continue </Button>
                                        ) : <></>
                                    }
                                </div>
                            </div>
                        </div>
                    )}
            </div>

        </>
    )
}

function InstructionsStep5({ time,selectedTest ,startTest}: { time: number,selectedTest:number,startTest:Function }) {
    return (
        <div className="instruction-screen" style={{ textAlign: 'center' }}>
            <div className="row" style={{ textAlign: 'center' }}>
                <div className="col-md-12" style={{
                    paddingTop: "10%",
                    textAlign: 'center'
                }}>
                </div>
                <div className="col-md-12">
                    <h3 style={{fontWeight:'bold'}}>You have {time} minutes to complete the test</h3>
                </div>
               
            </div>
            <div className="col-md-12">

            </div>

            <div className="text-center" style={{ paddingTop: '100px' }}>
                <Button className="start_test" variant="success" size="lg"
                    onClick={() => { 
                        startTest(selectedTest)
                        // history.push(createQuizAttemptRoute(selectedTest));
                    }}>
                    Start Test
                </Button>
            </div>

        </div>
    )
}

const QuizSetPage = connect(s => s)(QuizSetPageComponent);
export default AIHOC(QuizSetPage)
