import React, { FormEvent, useState } from 'react';
import { Link } from 'react-router-dom';
import { BackArrow } from '../_components/back-arrow.component';
import logo from '../_assets/main-logo-alt.png';
import google from '../_assets/google.svg';
import { AuthService } from '../_services';
import { Spinner } from '../_components';
import { history } from '../_config';
import { HOME_ROUTE } from './home_learn.page';
import GoogleLogin from 'react-google-login';
import FacebookLogin from 'react-facebook-login';
import SocialConfig from '../_config/social.config';
import { LOGIN_ROUTE } from './login.page';

export const REGISTER_ROUTE = "/register";

const auth = new AuthService();

type P = {
    setUser: Function,
    preferredLevel: string, // level of language
    preferredCourse: number | undefined
}

export default function RegisterPage(props: P) {
    const [message, setMessage] = useState('');
    const [isPasswordVisible, setIsPasswordVisible] = useState(false);
    const [isLoading, setIsLoading] = useState(false);

    const register = (event: FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        const form = event.target as HTMLFormElement;
        const credentials = {
            fullname: form.email.value,
            email: form.email.value,
            password: form.password.value,
            levelOfLanguage: props.preferredLevel,
            currentModule: props.preferredCourse
        };
        setIsLoading(true);
        auth.register(credentials)
            .then(response => {
                if ('message' in response.data) {
                    setMessage(response.data.message);
                    if (response.data.message === "Email registered successfully.") {
                        // history.push(LOGIN_ROUTE);
                        // log the user in
                        auth.login(credentials)
                            .then(response => {
                                if ('message' in response.data) {
                                    setMessage(response.data.message);
                                    setIsLoading(false);
                                } else {
                                    const user = response.data;
                                    props.setUser(user);
                                    localStorage.setItem('user', JSON.stringify(user));
                                    history.push(HOME_ROUTE);
                                }
                            })
                            .catch(err => {
                                setIsLoading(false);
                                setMessage(err.Message);
                            });
                    }
                }
            })
            .catch(err => {
                setIsLoading(false);
                setMessage(err.Message);
            });

    }

    /**
     * Google Auth
     * @param {*} response 
     */
    const googleAuthResponse = (response: any) => {
        // Check if there is a token

        if (response && ('accessToken' in response)) {
            const accessToken = response.accessToken;
            auth.loginGoogle(accessToken)
                .then(response => {
                    if ('message' in response.data) {
                        setMessage(response.data.message);
                        setIsLoading(false);
                    } else {
                        const user = response.data;
                        props.setUser(user);
                        localStorage.setItem('user', JSON.stringify(user));
                        history.push(HOME_ROUTE);
                    }
                })
                .catch(err => {
                    setIsLoading(false);
                    setMessage(err.Message);
                    console.log({ err })
                });
        } else {
            console.log({ response })
            alert('something went wrong, please try again!');
        }
    }

    /**
     * Google Auth
     * @param {*} response 
     */
    const facebookAuthResponse = (response: any) => {
        // Check if there is a token

        console.log({ facebookResponse: response })

        if (response && ('accessToken' in response)) {
            const accessToken = response.accessToken;
            auth.loginFacebook(accessToken)
                .then(response => {
                    if ('message' in response.data) {
                        setMessage(response.data.message);
                        setIsLoading(false);
                    } else {
                        const user = response.data;
                        props.setUser(user);
                        localStorage.setItem('user', JSON.stringify(user));
                        history.push(HOME_ROUTE);
                    }
                })
                .catch(err => {
                    setIsLoading(false);
                    setMessage(err.Message);
                });
        } else {
            alert('something went wrong, please try again!');
        }
    }

    return (
        <div className="LoginPage RegisterPage">
            <BackArrow />
            <div>
                <div className="registerTitle">Create an account</div>
                {/* <img className="main-logo" src={logo} alt="Main Logo" /> */}
                <div className="socialCLinks" style={{ marginTop: "2rem", marginBottom: "1rem" }}>
                    <GoogleLogin
                        clientId={SocialConfig.google.clientId}
                        buttonText="Continue with Google"
                        onSuccess={googleAuthResponse}
                        onFailure={googleAuthResponse}
                        cookiePolicy={'single_host_origin'}
                    />
                    <FacebookLogin
                        appId={SocialConfig.facebook.appId}
                        textButton="Continue with Facebook"
                        callback={facebookAuthResponse}
                        cssClass="btnFacebook"
                        icon="fa-facebook"
                    />
                </div>
                <div className="or" style={{ marginBottom: "1rem", fontWeight: "bold" }}>- OR -</div>
                <div className="text">Create an account with your email</div>
                <form onSubmit={register}>
                    {message && <div style={{ color: 'red', fontSize: '21px', marginBottom: '1rem' }}>{message}</div>}
                    <input className="form-control" name="fullname" type="text" placeholder="Name" />
                    <input className="form-control" name="email" type="email" placeholder="Email" />
                    <div className="password-holder">
                        <input className="form-control" name="password" type={isPasswordVisible ? "text" : "password"} placeholder="Password" />
                        <span className={"password-toggler " + ((isPasswordVisible) ? "password-visible" : "")} onClick={() => {
                            setIsPasswordVisible(!isPasswordVisible)
                        }}>
                            <img src="/_assets/eye-icon.png" alt="Show Password" />
                        </span>
                    </div>
                    {
                        isLoading ?
                            <div style={{
                                fontSize: '25px',
                                padding: '1rem',
                                marginTop: '32px'
                            }}>
                                <Spinner color="red" larger />
                            </div> :
                            <button type="submit">Sign Up</button>
                    }
                    <span className="password-forgot-link">Have an account? <Link to={LOGIN_ROUTE}>Log in</Link></span>
                </form>
            </div>
        </div>
    );
}