import { HttpService } from "./http.service";
import { endpoints } from "../_config";

export class AuthService {
    private http = new HttpService();

    /**
     * Service to log the user in
     * @param credentials Login Credentials
     */
    login(credentials: { email: any, password: any, levelOfLanguage?: string, currentModule?: number | undefined }) {
        if (!credentials.levelOfLanguage) {
            delete credentials.levelOfLanguage;
        }
        if (!credentials.currentModule) {
            delete credentials.currentModule;
        }
        return this.http.post(endpoints.auth.login, credentials, {})
    }

    /**
     * Service to log the user in
     * @param credentials Login Credentials
     */
    register(credentials: { email: any, fullname: any, password: any, levelOfLanguage?: string, currentModule?: number | undefined }) {
        if (!credentials.levelOfLanguage) {
            delete credentials.levelOfLanguage;
        }
        if (!credentials.currentModule) {
            delete credentials.currentModule;
        }
        return this.http.post(endpoints.auth.register, credentials, {})
    }

    loginGoogle(token: string) {
        // Get a token from api server using the fetch api
        return this.http.get(endpoints.auth.social.google, {
            'Accept': 'application/json',
            'Authorization': `Bearer ${token}`
        });
    }

    loginFacebook(token: string) {
        // Get a token from api server using the fetch api
        return this.http.get(endpoints.auth.social.facebook, {
            'Accept': 'application/json',
            'Authorization': `Bearer ${token}`
        });
    }

    profile(user: any) {
        return this.http.get(endpoints.auth.profile + '?userId=' + user.email, {
            Authorization: 'Bearer ' + user.token
        });
    }

    getActivityLog(user: any) {
        return this.http.get(endpoints.auth.userActivityLog + '?userId=' + user.email, {
            Authorization: 'Bearer ' + user.token
        });
    }

    saveActivityLog(user: any, payload: any) {
        return this.http.post(endpoints.auth.userActivityLog, payload, {
            Authorization: 'Bearer ' + user.token
        });
    }

    resetPassword(email: string) {
        return this.http.post(endpoints.auth.passwordReset, { email }, {});
    }
}