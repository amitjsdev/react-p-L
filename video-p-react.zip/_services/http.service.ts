import axios from 'axios';

const defaultHeaders = {
    Accept: 'application/json',
    'Content-Type': 'application/json'
}

export class HttpService {
    /**
     * Create a post request
     * @param url string
     * @param data json object
     * @param headers json object
     */
    post(url: string, data: any, headers: any) {
        return axios.post(url, data, {
            headers: { ...defaultHeaders, ...headers }
        })
    }
    upload(url: string, data: any, headers: any, callback:any) {
        return axios.post(url, data, {
            headers: { ...defaultHeaders, ...headers },
            onUploadProgress: callback
        })
    }

    put(url: string, data: any, type:any) {
        return axios.put(url, data, {
            headers: {
                "Content-Type": type,
                "x-amz-acl": "public-read"
            },
            transformRequest: [
                (data, headers) => {
                    delete headers.common.Authorization;
                    return data;
                }
            ]
        }
        )
    }

    delete(url: string, headers: any) {
        return axios.delete(url, {
            headers: { ...defaultHeaders, ...headers }
        })
    }

    get(url: string, headers: any) {
        return axios.get(url, {
            headers: { ...defaultHeaders, ...headers }
        })
    }
}