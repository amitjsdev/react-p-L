import { HttpService } from "./http.service";
import { endpoints } from "../_config";
import { baseUrl } from "../_config/endpoints.config"
import { ResponsePayWallDetail, V2Exercise } from "../_types";
import moment from 'moment';
import axios from 'axios';
export class MainService {
    private http = new HttpService();

    private buildQuery(params: any) {
        // const response = {...params};
        for (const param in params) {
            if (params.hasOwnProperty(param)) {
                if (params[param] === undefined || params[param] === null) {
                    delete params[param];
                }
            }
        }
        return "?" + (new URLSearchParams(params)).toString();
    }

    // get list of modules
    getModules(user: any, moduleNo?: number, fetchLevel?: number) {
        const query = this.buildQuery({ moduleNo, fetchLevel });
        return this.http.get(endpoints.module + query, {
            Authorization: 'Bearer ' + user.token
        });
    } 
    serverTime() {
        return this.http.get(endpoints.serverTime,{}).then(({data})=>data);
    }
    
    

    // get user rank
    async getMyRank(user: any) {
        const { data } = await this.http.get(endpoints.myRank, {
            Authorization: 'Bearer ' + user.token
        });

        return data.rank;
    }

    // get user streak
    async getMyStreak(user: any) {
        const { data } = await this.http.get(endpoints.myStreak, {
            Authorization: 'Bearer ' + user.token
        });

        return data;
    }

    /**
     * Get video tldr
     * @param user 
     */
    async getVideoTLDR(user: any, moduleno: number, routeno: number, lessonno: number) {
        const { data } = await this.http.get(endpoints.videoTLDR(
            moduleno.toString(),
            routeno.toString(),
            lessonno.toString(),
        ), {
            Authorization: 'Bearer ' + user.token
        });

        return data;
    }

    // get Lessons
    moduleLesson(user: any, moduleno: number) {
        return this.http.get(endpoints.moduleLesson(moduleno?.toString()), {
            Authorization: 'Bearer ' + user.token
        });
    }

    // get Lesson
    getLesson(user: any, moduleno: number, routeno: number, lessonno: number) {
        return this.http.get(endpoints.lesson(moduleno?.toString(), routeno?.toString(), lessonno?.toString()), {
            Authorization: 'Bearer ' + user.token
        });
    }

    // get exercise
    getExercise(user: any, moduleno: number, routeno: number, lessonno: number) {
        return this.http.get(endpoints.exercise(moduleno?.toString(), routeno?.toString(), lessonno?.toString()), {
            Authorization: 'Bearer ' + user.token
        });
    }

    // get v2 exercises
    async getExercises(user: any, moduleno: number, routeno: number, lessonno: number): Promise<V2Exercise[]> {
        // get response
        let exercises = (await this.http.get(endpoints.exercises(moduleno?.toString(), routeno?.toString(), lessonno?.toString()), {
            Authorization: 'Bearer ' + user.token
        })).data as V2Exercise[];

        // return only allowed exercises for now
        return exercises.filter(exercise => {
            return [
                'translate_sentence',
                'tap_what_you_hear',
                'tap_the_pair',
                'tap_the_pair_sentences',
                'mini_lesson_1',
                'mini_lesson_2',
                'mini_lesson_3',
            ].includes(exercise.exerciseType);
        })
    }

    async getPayWallDetails(user: any): Promise<ResponsePayWallDetail> {
        // get response
        let payWallDetails = (await this.http.get(endpoints.payWallDetails, {
            Authorization: 'Bearer ' + user.token
        })).data as ResponsePayWallDetail;

        // return response
        return payWallDetails;

    }

    /**
     * Fetch employee data
     * @param user 
     * @param obj 
     */
    async getEmployee(user: any): Promise<any> {
        // get response
        const employee = (await this.http.get(endpoints.employee(user.email), {
            Authorization: 'Bearer ' + user.token
        })).data;

        // return response
        return employee;
    } 
    async PANDetail(pan:any, token: string): Promise<any> {
        // get response
        const employee = (await this.http.post(endpoints.updatePAN,{pan}, {
            Authorization: 'Bearer ' + token
        })).data;

        // return response
        return employee;
    } 
    async getProfilePicUploadUrl(token:string, data:any): Promise<any> {
        const res = await this.http.post(endpoints.profileImageUploadUrl, data, {
            Authorization: 'Bearer ' +token
        })

        // return response
        return res && res.data && res.data.data ? res.data.data : null;
    }
    async setProfilePic(token: string, data:any): Promise<any> {
        const res = await this.http.post(endpoints.profilePic,data, {
            Authorization: 'Bearer ' +token
        })

        // return response
        return res;
    }

    /**
     * Fetch custom employee fields
     * @param user 
     * @param obj 
     */
    async getEmployeeCustomFetch(user: any, obj: any): Promise<any> {
        // get response
        const customFetch = (await this.http.get(endpoints.employeeCustomFetch(obj), {
            Authorization: 'Bearer ' + user.token
        })).data;

        // return response
        return customFetch;
    }

    // get resource
    getResource(moduleno: number, routeno: number, lessonno: number, resource: string) {
        return `https://langappnew.s3.amazonaws.com/Lesson_${moduleno}_${routeno}_${lessonno}_Pack/${resource}`;
    }

    /**
     * Save round log with user data
     * @param user 
     * @param payload 
     */
    saveRoundLog(user: any, payload: any) {
        return this.http.post(endpoints.saveRoundLog, payload, {
            Authorization: 'Bearer ' + user.token
        });
    }

    /**
     * Save the points earned by user in exercise
     * @param user 
     * @param moduleno 
     * @param routeno 
     * @param lessonno 
     * @param points 
     */
    saveDailyGoalLog(user: any, moduleno: number, routeno: number, lessonno: number, points: number) {
        const dated = moment().format('Y-MM-DD');
        return this.http.post(endpoints.saveDailyGoalLog, {
            dated,
            points,
            moduleNo: moduleno,
            routeNo: routeno,
            lessonNo: lessonno
        }, {
            Authorization: 'Bearer ' + user.token
        });
    }

    playSound(sound: String = "") {
        const audio = new Audio();

        switch (sound) {
            case "success":
                audio.src = '/_assets/_sounds/success_3.wav';
                break;
            case "failure":
                audio.src = '/_assets/_sounds/failure_0_lives.wav';
                break;
            case "streak":
                audio.src = '/_assets/_sounds/streaks_sound.wav';
                break;

            default:
                audio.src = '/_assets/_sounds/success_4.wav';
        }

        // play the audio
        audio.play();
    }
    // Get all previous attempts
    async getAllPreviousAttempts(token: string, email:string='') {
        if(email) {
            const { data } = await this.http.get(`${endpoints.allPreviousAttempts}/${email}`, {
                Authorization: 'Bearer ' + token
            });
            return data;
        } else{
            const { data } = await this.http.get(endpoints.allPreviousAttempts, {
                Authorization: 'Bearer ' + token
            });
            return data;
        }
      
    }
    // Get parameters for self review and external review
    async getSelfReviewParameters(token?: string) {
        const { data } = await this.http.get(endpoints.getParameters, {
            Authorization: 'Bearer ' + token
        })
        return data;
    }
    // Get all practice sets
    async getAllPracticeSets(setNumber: number, token: string) {
        const { data } = await this.http.get(endpoints.getAllPracticeSets + setNumber, { Authorization: 'Bearer ' + token })
        return data;
    }
    // Get self review of the current attempt
    async getSelfReview(attemptId: number, token: string) {
        const { data } = await this.http.get(endpoints.getSelfReview + attemptId, { Authorization: 'Bearer ' + token })
        return data;
    }
    // Get External review of the current attempt
    async getExternalReview(attemptId: number, token: string) {
        const { data } = await this.http.get(endpoints.getExternalReview + attemptId, { Authorization: 'Bearer ' + token })
        return data;
    }
    // Fetch all practice sets available for practice-set page
    async fetchAllPracticeSets(token: string) {
        const { data } = await this.http.get(endpoints.fetchAllPracticeSets, { Authorization: 'Bearer ' + token })
        return data;
    }
    // Module related Previous Attempts
    async moduleRelatedPreviousAttempts(token: string, moduleNo: any, routeNo: any, lessonNo: any) {
        const { data } = await this.http.get(endpoints.moduleRelatedPreviousAttempts(moduleNo, routeNo, lessonNo), { Authorization: 'Bearer ' + token })
        return data;
    }
    //save external Review
    async saveExternalReview(videoId: number, payload: any,audio:File,video:File, token?: string) {
        const setPercent =()=>{}
        const formData = new FormData();
        formData.append('audio', audio);
        formData.append('video', video);
        formData.append('payload', JSON.stringify(payload));
        const { data } = await this.http.upload(endpoints.saveExternalReview + videoId, formData, { Authorization: 'Bearer ' + token },setPercent)
        return data;
    }
    //save external Review
    async saveMentorReview(videoId: number, payload: any, audio:File,video:File,token?: string) {
        const setPercent =()=>{}
        const formData = new FormData();
        formData.append('audio', audio);
        formData.append('video', video);
        formData.append('payload', JSON.stringify(payload));
        console.log('save',{video});
        
        const { data } = await this.http.upload(endpoints.saveMentorReview + videoId, formData, { Authorization: 'Bearer ' + token },setPercent)
        return data;
    }
     async updateMentorReview(id: number, payload: any, audio:File,video:File, token?: string,) {
        const setPercent =()=>{}
        const formData = new FormData();
        formData.append('audio', audio);
        formData.append('video', video);
        formData.append('payload', JSON.stringify(payload));
        console.log('update',{video});
        const { data } = await this.http.upload(endpoints.updateMentorReview + id, 
        formData, { Authorization: 'Bearer ' + token }, setPercent);
        return data;
    }
    //save self review
    async saveSelfReview(token: string, attemptNum: number, payload: any) {
        const { data } = await this.http.post(endpoints.saveSelfReview + attemptNum, payload, { Authorization: 'Bearer ' + token })
        return data;
    }
    // Get previous attempts by uuid
    async getPrevAttemptByuuid(uuid: any, token?: string) {
        const { data } = await this.http.get(endpoints.prevAttemptByuuid + uuid, { Authorization: 'Bearer ' + token })
        return data;
    }
    // Get previous attempts by uuid
    async getPrevAttemptsByuuid(uuid: any) {
        const { data } = await this.http.get(endpoints.prevAttemptsByuuid + uuid, {})
        return data;
    }
    // Get previous attempts by uuid
    async getPrevAttemptsByUuidForMentor(uuid: any, token: string) {
        const { data } = await this.http.get(endpoints.prevAttemptsByUuidForMentor + uuid, {
            Authorization: 'Bearer ' + token
        })
        return data;
    }
    // Share attempts by uuid
    async shareAttemptsByuuid(token: string, payload: any) {
        const { data } = await this.http.post(endpoints.shareAttemptsByuuid, payload, { Authorization: 'Bearer ' + token })
        return data;
    }
    async deleteVideo(token: string, uuid: any) {
        const { data } = await this.http.delete(endpoints.deleteVideoByuuid(uuid), { Authorization: 'Bearer ' + token })
        return data;
    }
    async getStudentPracticeAnswer(token: string, payload: any) {
        const { data } = await this.http.get(endpoints.getStudentPracticeAnswerUrl(payload), { Authorization: 'Bearer ' + token })
        return data;
    }
    async saveStudentPracticeAnswer(token: string, payload: any) {
        const { data } = await this.http.post(endpoints.saveStudentPracticeAnswerUrl, payload, { Authorization: 'Bearer ' + token })
        return data;
    }

    async getCohortDetail(token: string) {
        let id =await this.getCohortId(token);
        id =id && id.length > 0 ? id[0]:''
        const { data } = await this.http.get(endpoints.cohortDetail + `/${id}`, { Authorization: 'Bearer ' + token })
        return data;
    }
    async getCohortId(token: string) {
        const { data } = await this.http.get(endpoints.userCohortId , { Authorization: 'Bearer ' + token })
        
        return data;
    }

    // quiz set related
    async getQuizSetsAssignedToMe(token: string) {
        const { data } = await this.http.get(endpoints.quizSetsAssignedToMe, { Authorization: 'Bearer ' + token });
        return data;
    }

    // quiz set related
    async quizSetsAssignedToMeQuestions(token: string, quizSetId: number) {
        const { data } = await this.http.get(endpoints.quizSetsAssignedToMeQuestions(quizSetId), { Authorization: 'Bearer ' + token });
        return data;
    }
    async saveAttemptTime(token: string, quizSetId: number, time: number,aiTimer:any) {
        try{
            this.http.post(endpoints.saveAttemptTime,{quizSetId, time,aiTimer} ,{ Authorization: 'Bearer ' + token });
        } catch (e){
            console.log(e);
            
        }
      
    }

    // quiz set progression
    async quizSetsAssignedToMeProgression(token: string, quizSetId: number) {
        const { data } = await this.http.get(endpoints.quizSetsAssignedToMeProgression(quizSetId), { Authorization: 'Bearer ' + token });
        return data;
    }

    // quiz set related
    async createAttemptForQuizSet(token: string, quizSetId: number) {
        const { data } = await this.http.post(endpoints.createAttemptForQuizSet(quizSetId), {}, { Authorization: 'Bearer ' + token });
        return data;
    }

    // quiz set related
    async saveAttemptForQuizSet(token: string, quizSetId: number, attemptNumber: number, answers: Array<any>,reasonIncomplete:any=null,isCompleted:any=null,aiTimer:any) {
        const { data } = await this.http.post(endpoints.saveAttemptForQuizSet(quizSetId, attemptNumber),
         { answers,reasonIncomplete,isCompleted,aiTimer },
          { Authorization: 'Bearer ' + token });
        return data;
    }
    async saveAttemptVideoForQuizSet(token: string, quizSetId: number, attemptNumber: number, video: any,aiTimer:any,setPercent:Function) {
        // create form data with video blob
        const formData = new FormData();
        formData.append('video', video);
        formData.append('aiTimer', JSON.stringify(aiTimer));

        const { data } = await this.http.upload(endpoints.saveAttemptVideoForQuizSet(quizSetId, attemptNumber), formData, { Authorization: 'Bearer ' + token }, setPercent);
        return data;
    }
    async saveProctoredQuestionnaire(token: string, answers: any) {
        const { data } = await this.http.post(endpoints.saveProctoredQuestionnaire, {
            questionnaire: answers
        }, { Authorization: 'Bearer ' + token });
        return data;
    }

    // resume builder

    async getAllResume(token: string) {
        const { data } = await this.http.get(endpoints.getAllResume, { Authorization: 'Bearer ' + token })
        return data;
    }
    async getSingleResume(token: string, id: number) {
        const { data } = await this.http.get(`${endpoints.getSingleResume}/${id}`, { Authorization: 'Bearer ' + token })
        return data;
    }
    async createResume(token: string, payload: any) {
        const { data } = await this.http.post(`${endpoints.getAllResume}`, payload, { Authorization: 'Bearer ' + token })
        return data;
    }
    async postBasicInfoResume(token: string, id: number, payload: any) {
        const { data } = await this.http.post(`${endpoints.postBasicInfoResume}/${id}/basic-info`, payload, { Authorization: 'Bearer ' + token })
        return data;
    }
    async postSummaryResume(token: string, id: number, payload: any) {
        const { data } = await this.http.post(`${endpoints.postSummaryResume}/${id}/summary`, payload, { Authorization: 'Bearer ' + token })
        return data;
    }
    async postEducationResume(token: string, id: number, payload: any) {
        const { data } = await this.http.post(`${endpoints.postSummaryResume}/${id}/education`, payload, { Authorization: 'Bearer ' + token })
        return data;
    }
    async postExperienceResume(token: string, id: number, payload: any) {
        const { data } = await this.http.post(`${endpoints.postSummaryResume}/${id}/work-experience`, payload, { Authorization: 'Bearer ' + token })
        return data;
    }
    async postCertificationResume(token: string, id: number, payload: any) {
        const { data } = await this.http.post(`${endpoints.postSummaryResume}/${id}/certifications-received`, payload, { Authorization: 'Bearer ' + token })
        return data;
    }

    async getMentorCohorts(token: string) {
        return await (await this.http.get(`${endpoints.mentorCohorts}`, { Authorization: 'Bearer ' + token })).data;
    }

    async getCohortStatById(token: string, cohortId: any) {
        return await (await this.http.get(`${endpoints.cohortStatById(cohortId)}`, { Authorization: 'Bearer ' + token })).data;
    }

    async saveOverallFeedback(token: string, payload: any) {
        const { data } = await this.http.post(`${baseUrl}overall-feedback`, payload, { Authorization: 'Bearer ' + token })
        return data;
    }

    async checkUserDetails(token: string) {
        const { data } = await this.http.get(endpoints.checkUserDetails, { Authorization: 'Bearer ' + token })
        return data;
    }

}
