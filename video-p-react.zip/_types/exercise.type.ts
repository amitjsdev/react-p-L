export enum ExerciseType {
    READING = 11,
    VOICE,
    LISTEN
}

export type Exercise = {
    id: number,
    exercise_no: ExerciseType,
    routeno: number,
    moduleno: number,
    lesson_no: number,
    lesson_id: number,
    lesson_name: string,
    lesson_status: string,
    exercise_type_id: number,
    exercise_type_name: string,
    title: string,
    total_questions: number,
    description: Array<string>,
    media: Array<string>,
    media_alt1: Array<string>,
    media_alt2: Array<string>,
    media_alt3: Array<string>,
    summary_translation: Array<string>,
    summary_new_format: string,
    image: string,
    status: string
}