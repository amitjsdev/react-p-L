export type ModuleWithLesson = {
    id: number;
    moduleno: number;
    courseNumber: string;
    description: string;
    long_description: string;
    module_level: number;
    module_type: string;
    module_tags: string;
    single_speaker: number;
    adddate: string;
    status: string;
    lite_zip_flag: string;
    from_language: string;
    to_language: string;
    moduleDetailInformation: string;
    categoryRanking: number;
    routeCount: string;
    module_lesson_count: number;
    routes: Route[];
    score: number;
    totalScore: number;
    latestMilestone: number;
}

type Route = {
    routeno: number;
    route_lesson_count: number;
    description: string;
    long_description: string;
    levels: Level[];
}

type Level = {
    levelno: number;
    lessons: Lesson[];
}

type Lesson = {
    levelno: string;
    lessonno: number;
    description: string;
    long_description: string;
    isChallenge: number;
    challengeType: string;
    livesLeft: number;
    additionalLivesClaimed: number | string | string | string;
    speaker_gender: string;
    progress: number;
    failCount: number;
}