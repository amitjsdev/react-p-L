// data type for response of the /module endpoint

export type Module = {
    id: number,
    moduleno: number,
    companyno: number,
    description: string,
    long_description: string,
    courseFlag: boolean,
    module_level: number,
    module_type: string,
    module_tags: string,
    module_color_A: string,
    module_color_B: string,
    module_color_C: string,
    adddate: Date,
    status: string,
    lite_zip_flag: string,
    demo_only_status: string,
    from_language: string,
    to_language: string,
    availableForConsumer: string,
    userFriendlyName: string,
    moduleDetailInformation: string,
    routeCount: number,
    module_lesson_count: number,
    routes: Array<Route>,
}

type Route = {
    routeno: number,
    route_lesson_count: number,
    description: string,
    long_description: string,
    levels: Array<Level>
}

type Level = {
    levelno: number,
    lessonno: number,
    description: string,
    long_description: string,
}

export type ModuleRoute = Route;