export type RecentModule = {
    courseName: string,
    courseNumber: string,
    lesssonLevel?: string,
    long_description?: string,
    moduleCompletion_percent: number,
    moduleNumber?: string,
    detailed: any
}