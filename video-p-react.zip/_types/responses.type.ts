
export type ResponsePayWallDetail = {
    userId: string;
    enforceWall: number;
    payWallLesson: string;
    payWallSummary: string;
    livesLessonWall: string;
    subscriptionExpires?: any;
    dailyLivesCount: number;
    dailyLivesLeft: number;
    replenishesCount: number;
    replenishesLeft: number;
}

export type ResponseMyStreak = {
    userId: string;
    currentDate: string;
    currentStreak: number;
    currentStreakDate: string;
    maxStreak: number;
    maxStreakDate: string;
    progress: number[];
}