export const V2ExerciseType = {
    translate_sentence: 'translate_sentence', // on list
    tap_what_you_hear: 'tap_what_you_hear', // on list
    voice_recognition: 'voice_recognition', // skip
    mini_lesson_1: 'mini_lesson_1', // on list
    mini_lesson_2: 'mini_lesson_2', // on list
    mini_lesson_3: 'mini_lesson_3', // on list
    tap_the_pair: 'tap_the_pair',
    tap_the_pair_sentences: 'tap_the_pair_sentences',
    select_missing_word: 'select_missing_word',
    multiple_choice: 'multiple_choice',
    select_correct_translation: 'select_correct_translation',
    informational: 'informational',
    pick_correct_type: 'pick_correct_type',
}

export type V2Exercise = {
    id: number;
    sequenceNo: number;
    moduleNo: string;
    routeNo: string;
    lessonNo: string;
    toLanguage: string;
    fromLanguage: string;
    exerciseType: string;
    exerciseDescription: string;
    question: string;
    options: string;
    answer: string;
    translation: string;
}