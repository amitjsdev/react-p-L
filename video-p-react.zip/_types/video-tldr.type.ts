export type VideoTLDR = {
    id: number;
    moduleNo: number;
    routeNo: number;
    lessonNo: number;
    created_at: Date;
    updated_at: Date;
    title: string;
    description: string;
    image: string;
    voice: string[];
    extra_info: string;
    miniLesson: { sentence: string, translation: string }[];
    videoTime: string;
}

export function getVideoTLDRFromJson(json: any): VideoTLDR {
    return {
        id: json.id,
        moduleNo: json.moduleNo,
        routeNo: json.routeNo,
        lessonNo: json.lessonNo,
        created_at: new Date(json.created_at),
        updated_at: new Date(json.updated_at),
        title: json.title,
        description: json.description,
        image: json.image,
        voice: json.voice ? json.voice.split(";") : [],
        extra_info: json.extra_info,
        // restructure mini lessons
        miniLesson: json.miniLesson ? json.miniLesson.split(";").map((minilesson: string) => {
            const [sentence, translation] = minilesson.trim().split(",");

            return {
                sentence: sentence.trim(),
                translation: translation.trim()
            }
        }) : [],
        videoTime: json.videoTime
    }
}