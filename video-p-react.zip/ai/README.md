# Head Pose Estimation

This document explains the usage of files and how the pose estimation can be done.

Main Files
  
  1. index.html
  2. key_pose_features.js

## Pre requisits to be added to index.html

```
<!-- Javascript -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/p5.js/0.8.0/p5.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/p5.js/0.8.0/addons/p5.dom.min.js">
  </script>

  <script src="ml5.min.js" type="text/javascript"></script>
  <script src="key_pose_features.js"></script>

```


---

## index.html

The file contains the fromtend compnents. Notably the fields to display the following

1. The Pose estimation result draw canvas

    ```<div id="square" style="display: hidden;" ></div>```
    
    The canvas is sent from backend line number ```149``` in key_pose_features.js

2. Video preview canvas

    ```<div id="square1" style="display: hidden;" ></div>```
    
    This canvas is sent from the canvas from line ```156``` in key_pose_features.js

3. Output lines
 
     ```
        <span> <b>Exam timer <p id="et"></p></b></span>
        <span>  looking_away sides <p id="l_aw_s"></p> </span>
        <span>  looking_away up/down <p id="l_aw_d"></p> </span>
        <span>   zero candidates <p id="z_can"></p> </span>
        <span>  multiple candidates <p id="m_can"></p> </span>
        Final Exam time <p id="etc"></p>
        Lighting condition : <p id="lit"></p>
    ```
    
    These values are updated dynamically from backend.


## key_pose_features.js

The javascript file opens webcams for preview and pose estimation, does the pose estimation and populates a dictionary with timer update values.

---


### Setup function

Setup function runs only once and is uysed to load the requirements at startup. In this process, the following are executed.


#### Lines 144 to 156 

First, the canvas for drawing shapes and output are created and parent is set to a div with id="square". ```The width and height of the cavnvas is fixed and this shall not be changed.```

This is a small window in the frontend. the size ```(Height and Width)``` shall be any based on the requirement. The video preview captures the video from web cam, set size and update.


#### Lines 165 to 167

You can hide or view canvas with these function calls.

#### Lines 171 to 176 

Loading Ai Module

#### Lines 204 to 274

Draw funbction is like an infinite loop. this functions draws on the canvas, update the frontend with timer data, contains logic for starting/ stoping timers.

from here, we get the ```total_timers``` dictionary and we can extract live data from there.

### Lines 275 to 491

Functions to calculate timers and draw on canvas.