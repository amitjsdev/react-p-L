// Developed for Taplingua

import * as ml5 from "ml5";
import * as p5 from "p5";// Developed for Taplingua
var {  PI,CENTER,  LEFT,  BOTTOM, BOLD,RIGHT, NORMAL,} = p5;
let video;
let video_preview;
let poseNet;
let currentPoses = [];
let poseNetModelReady = false;
let leftEar = []
let nose = []
let rightEar = []
let dict = {}
let set_cam = 0
var width = 640
var height = 480

// Timer flags - 0 or 1
var zero_candidates = 0
var looking_away_side = 1
var looking_away_up_down = 1
var multiple_candidates = 0
let lighting_condition_check = 1

// Final timer output - total_timer contains all the timers
let total_timers = {
  'zero_candidate_timer': 0,
  'multi_user_counter': 0,
  'looking_away_sides_timer': 0,
  'looking_away_up_down_timer': 0,
  'exam_timer': 0
}

// All the timers initialized
var zero_candidate_timer 
var looking_away_sides_timer
var looking_away_up_down_timer 
var multi_user_counter 
var exam_timer 
var lighting_check_timer

// The side to side threshoulds
var rough_ln_y = 0
var rough_rn_y = 0

// Calculate size of face
var rough_size = 0
// The up/down threshould
var rough_change = 0

// All variables change inside draw() function and fetching the variables 
// from draw() function is recommended. total_timers and rough_* are needed for 
// calculations

// Function to calculate time

var Stopwatch = function (timer_name, options) {

  var timer = createTimer(),
    offset,
    clock,
    interval;

  // default options
  options = options || {};
  options.delay = options.delay || 1;

  reset();

  function createTimer() {
    return document.createElement("span");
  }

  function createButton(action, handler) {
    var a = document.createElement("a");
    a.href = "#" + action;
    a.innerHTML = action;
    a.addEventListener("click", function (event) {
      handler();
      event.preventDefault();
    });
    return a;
  }

  function start() {
    if (!interval) {
      offset = Date.now();
      interval = setInterval(update, options.delay);
    }
    return interval
  }

  function stop() {
    if (interval) {
      clearInterval(interval);
      interval = null;
    }
  }

  function reset() {
    clock = 0;
    render(0);
  }

  function update() {
    clock += delta();
    render();
  }

  function render() {
    timer.innerHTML = clock / 1000;
    total_timers[timer_name] = clock / 1000

  }

  function delta() {
    var now = Date.now(),
      d = now - offset;

    offset = now;
    return d;
  }
  // start stop and reset functions can be called for each timer.
  this.start = start;
  this.stop = stop;
  this.reset = reset;
};

zero_candidate_timer = new Stopwatch('zero_candidate_timer')
looking_away_sides_timer = new Stopwatch('looking_away_sides_timer');
looking_away_up_down_timer = new Stopwatch('looking_away_up_down_timer')
multi_user_counter = new Stopwatch('multi_user_counter');
exam_timer = new Stopwatch('exam_timer')
lighting_check_timer = new Stopwatch('lighting_check_timer')


// When onclick="set_button(state)" is triggered, stops/starts timers.


// Load Ai Model.
const poseNetOptions = { detectionType: "multiple", nmsRadius: 20, minConfidence: 0.5 };

// Function only runs once for initializing camera and models

/**
 * Callback function called by ml5.js PoseNet when the Ai Engine is ready
 * Will be called once and only once
 */
function onPoseNetModelReady() {
  exam_timer.start()
  //console.log("The Ai Engine is ready...");

  poseNetModelReady = true;
  window.poseNetModelReady =true
  const val = total_timers['zero_candidate_timer']
  //console.log({ val });
  // document.getElementById('z_can').innerText = val // / total_timers['exam_timer']) * 100) + ' %'

}

/**
 * Callback function called by ml5.js PosetNet when a pose has been detected
 */
function onPoseDetected(poses) {
  currentPoses = poses;

}



// This function is like a loop. it runs over and over again to draw on the canvas created.


// drawing pose on canvas.

var s = function (p) {
  p.setup = function () {

    let renderer = p.createCanvas(width, height);

    renderer = p.createCanvas(width, height);
    renderer.parent("square");
    const constraints = {
      audio:true,
       video: { 
           frameRate: { min:5, ideal: 10, max: 15 },
           width: { min: 426, ideal: 640, max: 1920 },
           height: { min: 240, ideal: 360, max: 1080 }
          } 
      };
    video = p.createCapture(p.VIDEO);
    video.size(width, height);

    video_preview = p.createCapture(p.VIDEO, (stream)=>{
      window.aiStream =stream;
    });
    video_preview.size(200, 100)
    video_preview.parent('square1')



    // //console.log(video.width + ' ' + video.height)
    // resizeCanvas(320, 240)
    video.hide();
    // video_preview.hide()
    // renderer.hide();

    // Setup PoseNet. This can take a while, so we load it 
    // asynchronously (when it's done, it will call modelReady)
    poseNet = ml5.poseNet(video, poseNetOptions, onPoseNetModelReady); //call onModelReady when setup

    // PoseNet has one and only one event subscription called 'pose', which is
    // called when pose is detected

    poseNet.on('pose', onPoseDetected); // call onPoseDetected when pose detected
    //frameRate(1);
  }
  p.stop = function () {
    console.log('stop ai');
    video.stop()
    p.remove()
  }
  p.mini = function () {
    // //console.log(video.width + ' ' + video.height)
    // resizeCanvas(320, 240)
    video.hide();
    // video_preview.hide()
  }
  p.draw= function() {
    // These lines can be commented out 
    window.aiTimer =total_timers;
    // document.getElementById('l_aw_s').innerText   = total_timers['looking_away_sides_timer']  // / total_timers['exam_timer']) * 100) + ' %'
    // document.getElementById('l_aw_d').innerText = total_timers['looking_away_up_down_timer']
    // document.getElementById('z_can').innerText  = total_timers['zero_candidate_timer']// / total_timers['exam_timer']) * 100) + ' %'
    // document.getElementById('m_can').innerText  = total_timers['multi_user_counter']  // / total_timers['exam_timer']) * 100) + ' %'
    // document.getElementById('et').innerText = total_timers['exam_timer']
    
    // define the output image to drow on. here, it draws on the video capture
    p.image(video, 0, 0, width, height);
    
    // Conditions to start and stop timers.
    if(lighting_condition_check != 1){
      lighting_check_timer.start()
    }
    else{
      lighting_check_timer.stop()
    }
  
    if(zero_candidates == 1){
      zero_candidate_timer.start()
    }
    else{
      zero_candidate_timer.stop()
    }
  
    if(looking_away_side == 0){
      looking_away_sides_timer.start()
    }
    else{
      looking_away_sides_timer.stop()
    }
  
    if(looking_away_up_down == 0){
      looking_away_up_down_timer.start()
    }
    else{
      looking_away_up_down_timer.stop()
    }
  
    // See all the timer values in console. This output is to be fetched and processed inside
    // draw function (infinity loop) to do checks.
  
    //console.log(total_timers)
    
    // if model not ready, show empty gray area on canvas
    if(!poseNetModelReady){
      p.background('white');
      // Set colors
      p.fill(204, 101, 192, 0);
      p.strokeWeight(8);
      p.stroke(113, 60, 251, 220);
    
      // Draw the user icon   
      p.translate(width/2, height/2.2);
      p.ellipse(0, 0, 280, 280);
      p.translate(0, height/1.5);
      p.ellipse(0, 0, 600, 350);
      p.rotate(PI/5.9);
      p.push();
      p.textSize(32);
      p.textAlign(CENTER);
      p.fill(255);
      p.noStroke();
      p.text("Waiting for Ai Engine to load...", width/2, height/2);
      p.pop();
      zero_candidates = 0
    }
    else{
      p.strokeWeight(10);
      p.stroke(255, 255, 255, 220);


      p.translate(width / 2, height / 2.3);
      p.ellipse(0, 0, 280, 280);
      p.translate(0, height / 1.5);
      p.ellipse(0, 0, 600, 350);
      p.rotate(PI / 5.9);
      zero_candidates = 1
    }
  
    // zero_candidates = 1
    // Iterate through all poses and print them out
    if(currentPoses){
      // Pose is detected.
      // document.getElementById('lit').innerText = total_timers['lighting_check_timer']
      // zero_candidates = 1
      for (let i = 0; i < currentPoses.length; i++) {
        
        if(currentPoses[i].pose.score > 0.18){
          zero_candidates = 0
          lighting_condition_check = 1
         var length_t = currentPoses.length
          p.drawPose(currentPoses[i], i, length_t);
          // document.getElementById('lit').innerText = total_timers['lighting_check_timer']
  
        }
        else if (currentPoses[i].pose.score <= 0.18 && currentPoses[i].pose.score > 0.0) {
          length_t = 0
          lighting_condition_check = 0
          // Uncomment the following line to start the zero candidate timer when the lighting is bad
          // zero_candidates = 1
          // document.getElementById('lit').innerText = total_timers['lighting_check_timer']
  
        }
      }
    }
    else{
      
      //console.log('Pose')
    }
  }
  p.set_button=function (state) {
    set_cam = state
    var final_zero_candidate_timer = total_timers["zero_candidate_timer"]
    var final_looking_away_sides_timer = total_timers["looking_away_sides_timer"]
    var final_looking_away_up_down_timer = total_timers["looking_away_up_down_timer"]
    var final_multi_user_counter = total_timers["multi_user_counter"]
    var final_exam_timer = total_timers["exam_timer"]
  
    // //console.log(final_exam_timer) 
    if (state == 1) {
      console.log('stopping');
      exam_timer.stop()
      zero_candidate_timer.stop()
      looking_away_sides_timer.stop()
      looking_away_up_down_timer.stop()
      multi_user_counter.stop()
      exam_timer.stop()
      // document.getElementById('button_state').innerHTML = '<button class="btn btn-outline-primary" onclick="' + 'set_button(0)' + '">Restart exam</button>'
    }
    else {
      zero_candidate_timer.start()
      looking_away_sides_timer.start()
      looking_away_up_down_timer.stop()
      multi_user_counter.start()
      exam_timer.start()
      // document.getElementById('button_state').innerHTML = '<button class="btn btn-outline-danger" onclick="' + 'set_button(1)' + '">Stop exam</button>'
  
    }
  
  }
  p.drawPose =function (pose, poseIndex, length_t) {

    if (length_t > 3) {
      multi_user_counter.start()
    }
    else {
      multi_user_counter.stop()
    }
    // Draw skeleton
    const skeletonColor = p.color(255, 255, 255, 128);
    p.stroke(skeletonColor);
    p.strokeWeight(2);
    const skeleton = pose.skeleton;
    for (let j = 0; j < skeleton.length; j += 1) {
      const partA = skeleton[j][0];
      const partB = skeleton[j][1];
      // line(partA.position.x, partA.position.y, partB.position.x, partB.position.y);
    }
  
    // Draw keypoints with text
    const kpFillColor = p.color(255, 255, 255, 255);
    const textColor = p.color(255, 255, 0, 230);
    const kpOutlineColor = p.color(0, 0, 0, 150);
    p.strokeWeight(1);
  
    const keypoints = pose.pose.keypoints;
    const kpSize = Math.abs(width - height) / 18;
    const kpTextMargin = 2;
    let xPoseLeftMost = width;
    let xPoseRightMost = -1;
    let yPoseTop = height;
    let yPoseBottom = -1;
    let arr = ['nose', 'leftEar', 'rightEar'];
  
  
  
  
    for (let j = 0; j < keypoints.length; j += 1) {
      // A keypoint is an object describing a body part (like rightArm or leftShoulder)
      const kp = keypoints[j];
  
      if (kp.score > 0.18 && arr.includes(kp.part)) {
        if (xPoseLeftMost > kp.position.x) {
          xPoseLeftMost = kp.position.x;
        } else if (xPoseRightMost < kp.position.x) {
          xPoseRightMost = kp.position.x;
        }
  
        if (yPoseBottom < kp.position.y) {
          yPoseBottom = kp.position.y;
        } else if (yPoseTop > kp.position.y) {
          yPoseTop = kp.position.y;
        }
  
        if (set_cam == 0) {
  
          p.fill(kpFillColor);
          p.noStroke();
          // p.circle(kp.position.x, kp.position.y, kpSize);
  
          p.fill(textColor);
          p.textAlign(LEFT);
          let xText = kp.position.x + kpSize + kpTextMargin;
          let yText = kp.position.y;
          if (kp.part.startsWith("right")) {
            p.textAlign(RIGHT);
            xText = kp.position.x - (kpSize + kpTextMargin);
          }
          p.textStyle(BOLD);
          p.textStyle(NORMAL);
          yText += p.textSize();
          // p.text(p.int(kp.position.x) + ", " + p.int(kp.position.y), xText, yText);
  
          yText += p.textSize();
          // p.text(p.nf(kp.part, 1, 2), xText, yText);
          p.noFill();
          // p.circle(kp.position.x, kp.position.y, kpSize);
        }
        var part_n = kp.part
        dict[part_n] = [kp.position.x, kp.position.y]
  
      }
  
  
    }
  
    try {
      var pose_corr_x = 0
      var pose_corr_y = 0
      rough_change = Math.abs(dict['leftEar'][0] - dict['nose'][0]) / Math.abs(dict['nose'][0] - dict['rightEar'][0])
      rough_size = Math.abs(dict['leftEar'][0] - dict['rightEar'][0])
      rough_ln_y = dict['leftEar'][1] - dict['nose'][1] 
      rough_rn_y = dict['rightEar'][1] - dict['nose'][1]
  
      if (rough_ln_y < -45.0 || rough_rn_y > 55.0) {
        pose_corr_y = 0
  
      }
      else {
  
        pose_corr_y = 1
      }
  
      if (rough_change > 2.8 || rough_change < 0.5) {
        pose_corr_x = 0
      }
      else {
        pose_corr_x = 1
      }
  
      if (rough_size > 110) {
        // //console.log('Face outside')
      }
  
      looking_away_side = pose_corr_x
      looking_away_up_down = pose_corr_y
  
      if (pose_corr_x == 1 && pose_corr_y == 1) {
  
        if (set_cam == 0) {
          p.strokeWeight(10);
          p.stroke(255, 255, 255, 220);
  
  
          p.translate(width / 2, height / 2.3);
          p.ellipse(0, 0, 280, 280);
          p.translate(0, height / 1.5);
          p.ellipse(0, 0, 600, 350);
          p.rotate(PI / 5.9);
        }
      }
      else {
  
        if (set_cam == 0) {
          p.fill(255, 0, 0, 40);
          p.textStyle(BOLD);
          p.textAlign(LEFT, BOTTOM);
          p.rect(0, 0, 640, 480);
          p.strokeWeight(10);
          p.stroke(255, 255, 255, 220);
  
  
          p.translate(width / 2, height / 2.3);
  
          p.ellipse(0, 0, 280, 280);
          p.translate(0, height / 1.5);
          p.ellipse(0, 0, 600, 350);
          p.rotate(PI / 5.9);
        }
  
  
      }
      const boundingBoxExpandFraction = 0.1;
      let boundingBoxWidth = xPoseRightMost - xPoseLeftMost;
      let boundingBoxHeight = yPoseBottom - yPoseTop;
      let boundingBoxXMargin = boundingBoxWidth * boundingBoxExpandFraction;
      let boundingBoxYMargin = boundingBoxHeight * boundingBoxExpandFraction;
      xPoseRightMost += boundingBoxXMargin / 2;
      xPoseLeftMost -= boundingBoxXMargin / 2;
      yPoseTop -= boundingBoxYMargin / 2;
      yPoseBottom += boundingBoxYMargin / 2;
  
      p.noStroke();
      p.fill(textColor);
      p.textStyle(BOLD);
      p.textAlign(LEFT, BOTTOM);
      const strPoseNum = "Person: " + (poseIndex + 1);
  
      const strWidth = p.textWidth(strPoseNum);
      p.textStyle(NORMAL);
  
      p.noFill();
      p.stroke(kpFillColor);
  
    }
    catch (err) {
      //console.log(err)
  
    }
  
  }
}




export default s;


