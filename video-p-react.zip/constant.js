export const CDN_URL = "https://cdnnew2.taplingua.com";
