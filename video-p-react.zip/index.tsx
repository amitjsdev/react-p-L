import React from 'react';
import ReactDOM from 'react-dom';
import './_styles/common.style.scss';
import './_styles/main.style.scss';
import 'bootstrap/dist/css/bootstrap.min.css';
import { App } from './_components';
import * as serviceWorker from './serviceWorker';
import { Provider } from 'react-redux';
import store from "./store/store";
import { I18 } from './_components';

var isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
/** TO DISABLE SCREEN CAPTURE **/
document.addEventListener('keyup', (e) => {
  if (e.key == 'PrintScreen') {
      try {
      navigator.clipboard.writeText('');
      // alert('Screenshots disabled!');
      } catch (e){
        console.log(e);
        
      }
  }
});

// /** TO DISABLE PRINTS WHIT CTRL+P **/
document.addEventListener('keydown', (e) => {
  if (e.ctrlKey && e.key == 'p') {
      // alert('This section is not allowed to print');
      e.cancelBubble = true;
      e.preventDefault();
      e.stopImmediatePropagation();
  }
});
// document.onkeydown = function (e) {
//   return false;
// }


ReactDOM.render(
  <React.StrictMode>
    <I18>
      <Provider store={store}>
        {
          isSafari ? (
            <div style={{ height: "100vh", display: "flex", justifyContent: "center", alignItems: "center" }}>
              Currently, Safari is not a supported browser. Please use Google Chrome or Microsoft Edge to access the Taplingua Interview Prep App
            </div>
          ) : <App />
        }
      </Provider>
    </I18>
  </React.StrictMode>,
  document.getElementById('root')
);

serviceWorker.unregister();
