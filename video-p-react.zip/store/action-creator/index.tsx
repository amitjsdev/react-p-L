import { ActionTypes } from "../actions/actionTypes"
import { Dispatch } from 'redux'
import { Action } from "../actions/action"

export const despositMoney = (money: number) => {
    return (dispatch: Dispatch<Action>) => {
        dispatch({
            type: ActionTypes.DEPOST,
            payload: money
        })
    }
}
export const withdrawMoney = (money: number) => {
    return (dispatch: Dispatch<Action>) => {
        dispatch({
            type: ActionTypes.WITHDRAW,
            payload: money
        })
    }
}
export const bankrupt = () => {
    return (dispatch: Dispatch<Action>) => {
        dispatch({
            type: ActionTypes.BANKRUPT,

        })
    }
}
export const changeModuleNumber = (newModuleNumber: number) => {
    localStorage.setItem("practiceset.moduleNumber", newModuleNumber + "")
    return (dispatch: Dispatch<Action>) => {
        dispatch({
            type: ActionTypes.CHANGE_MODULE_NUMBER,
            payload: newModuleNumber
        })
    }
}
export const currentAttempt = (attempt: any) => {
    return (dispatch: Dispatch<any>) => {
        dispatch({
            type: ActionTypes.CURRENT_ATTEMPT,
            payload: attempt
        })

    }
}
// Setting Token
export const setUserToken = (token: string) => {
    return (dispatch: Dispatch<any>) => {
        dispatch({
            type: ActionTypes.TOKEN,
            payload: token
        })
    }
}
export const selfReviewModal = (show: boolean) => {
    return (dispatch: Dispatch<any>) => {
        dispatch({
            type: ActionTypes.SELF_REVIEW_MODAL,
            payload: show
        })
    }
}
// for closing modal
export const closeModal = (close: boolean) => (dispatch: Dispatch<any>) => {
    dispatch({
        type: ActionTypes.CLOSE_MODAL,
        payload: close
    })
}
export const showOtherReviews = (show: boolean) => (dispatch: Dispatch<any>) => {
    dispatch({ type: ActionTypes.SHOW_OTHER_REVIEWS, payload: show })
}


export const setQuizSetId = (quizSetId: number) => {
    return {
        type: ActionTypes.QUIZ_SET_CURRENT_ATTEMPT,
        payload: quizSetId
    }
}