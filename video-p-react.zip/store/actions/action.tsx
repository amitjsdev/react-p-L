import {ActionTypes} from "./actionTypes"
interface Deposit{
    type: ActionTypes.DEPOST
    payload: number
}
interface Withdraw{
    type: ActionTypes.WITHDRAW
    payload: number
}
interface Bankrut{
    type: ActionTypes.BANKRUPT
}
interface ModuleNumber {
    type: ActionTypes.MODULE_NUMBER
}
interface ChangeModuleNumber {
    payload: number;
    type: ActionTypes.CHANGE_MODULE_NUMBER
}
export type Action = Withdraw | Bankrut | Deposit | ModuleNumber | ChangeModuleNumber