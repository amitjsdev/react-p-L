import { ActionTypes } from "../actions/actionTypes";

const initialState = {
    currentAttempt: []
}

const attemptReducer = (state = initialState, action: any) => {
    switch (action.type) {
        case ActionTypes.CURRENT_ATTEMPT:
            return {
                ...state,
                currentAttempt: action.payload
            }
        default:
            return state;

    }
}
export default attemptReducer;