import { combineReducers } from 'redux'
import attemptReducer from './attemptReducer';
import bankReducer from "./bankReducer";
import modalReducer from './modalReducer';
import moduleReducer from './moduleReducer';
import quizSetIdReducer from './quizSetAttemptReducer';
import userReducer from './userReducer';

const reducers = combineReducers({
    // bank: bankReducer,
    module: moduleReducer,
    attempt: attemptReducer,
    // user: userReducer,
    modal: modalReducer,
    quizSetId: quizSetIdReducer,
})

export default reducers

export type State = ReturnType<typeof reducers>