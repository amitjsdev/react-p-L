import { ActionTypes } from "../actions/actionTypes"

const initialState = {
    show: false,
    close: false,
}
const modalReducer = (state = initialState, action: any) => {
    switch (action.type) {
        case ActionTypes.SELF_REVIEW_MODAL:
            return {
                ...state,
                show: action.payload
            }
        case ActionTypes.CLOSE_MODAL:
            return {
                ...state,
                close: action.payload
            }
        case ActionTypes.SHOW_OTHER_REVIEWS:
            return {
                ...state,
                show: action.payload
            }
        default:
            return state;
    }
}

export default modalReducer