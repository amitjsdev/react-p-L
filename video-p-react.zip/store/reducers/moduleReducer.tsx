import { Action } from "../actions/action";
import { ActionTypes } from "../actions/actionTypes";

const initialState ={
    moduleNumber: localStorage.getItem("practiceset.moduleNumber")
}
const moduleReducer=(state = initialState,action: Action)=>{
    switch(action.type){
        case ActionTypes.MODULE_NUMBER:
            return state.moduleNumber;
        case ActionTypes.CHANGE_MODULE_NUMBER:
            return {
                ...state,
                moduleNumber: action.payload
            }
        default:
            return state;
    }
}

export default moduleReducer;