import { ActionTypes } from "../actions/actionTypes";

const initialState = null

const quizSetIdReducer = (state = initialState, action: any) => {
    switch (action.type) {
        case ActionTypes.QUIZ_SET_CURRENT_ATTEMPT:
            return action.payload
        default:
            return state;

    }
}
export default quizSetIdReducer;