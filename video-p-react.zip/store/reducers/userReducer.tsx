import { Action } from "../actions/action";
import { ActionTypes } from "../actions/actionTypes";

const initialState = {
    token: null
}
const userReducer=(state= initialState,action:any)=>{
    switch(action.type as any){
        case ActionTypes.TOKEN:
            return {
                ...state,
                token: action.payload
            }
        default: 
            return state;
    }
}
export default userReducer;